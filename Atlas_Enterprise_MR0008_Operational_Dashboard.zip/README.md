# Atlas Enterprise

Atlas is an operational intelligence platform with a complete closed-loop incident workflow and a live operational command center.

## Complete workflow

```text
Draft
→ SupervisorReview
→ SafetyReview
→ Investigation
→ CAPA
→ Verification
→ Closed
```

## Current capabilities

- Incident reporting and controlled review
- Structured investigation and root cause
- CAPA completion, verification, and effectiveness
- Final closure and SMETA evidence links
- Executive and Safety dashboard
- Incident and CAPA workload metrics
- Closure performance
- Severity and workflow distributions
- Department performance summaries

## Start locally

```bash
docker compose down -v
docker compose up --build
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger
