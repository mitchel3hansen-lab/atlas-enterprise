# Atlas Enterprise

Atlas is an operational intelligence platform with a closed-loop incident workflow, role-based security, audit logging, operational dashboards, pilot deployment tooling, and automated database/browser testing.

## Start Atlas

```bash
cp .env.example .env
# Replace the default secrets.

docker compose up --build -d
./tools/pilot-health.sh
./tools/pilot-acceptance.sh
```

## Run tests

```bash
./tools/test-integration.sh
./tools/test-e2e.sh
./tools/test-all.sh
```

Integration tests use a disposable PostgreSQL Testcontainer and apply the real migration files. End-to-end tests use Playwright in desktop and mobile Chromium configurations.

## Open

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger
- Liveness: http://localhost:8085/health/live
- Readiness: http://localhost:8085/health/ready

## Documentation

- `docs/TESTING_STRATEGY.md`
- `docs/PILOT_DEPLOYMENT_GUIDE.md`
- `docs/PILOT_ACCEPTANCE_CHECKLIST.md`
