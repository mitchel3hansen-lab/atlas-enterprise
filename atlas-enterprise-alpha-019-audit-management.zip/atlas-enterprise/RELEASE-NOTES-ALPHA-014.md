# Atlas Enterprise Alpha 0.14 — Operational Knowledge

This release turns connected records into reusable organizational learning.

## Added

- Operational Knowledge API and repository
- Searchable Lessons Learned records
- Similar-record context retrieval
- Explainable recommendations with confidence and supporting evidence
- Relationship counts by operational object type
- PostgreSQL migration V028 and rollback
- Operational Knowledge React workspace
- Domain tests and architecture decision record

## Security and trust

Recommendations are deterministic decision support, always marked for human review, and scoped to the active tenant.
