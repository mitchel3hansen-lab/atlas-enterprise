#!/usr/bin/env bash
set -euo pipefail

failures=0
check_file() {
  if [[ -f "$1" ]]; then
    printf 'PASS file %s\n' "$1"
  else
    printf 'FAIL missing %s\n' "$1" >&2
    failures=$((failures + 1))
  fi
}

check_file "docker-compose.yml"
check_file "Atlas.sln"
check_file "README.md"
check_file "SECURITY.md"
check_file "docs/alpha/ALPHA-RELEASE-CHARTER.md"
check_file "docs/alpha/ALPHA-BACKLOG.md"
check_file "docs/alpha/ALPHA-ACCEPTANCE-TEST.md"
check_file "docs/alpha/RELEASE-READINESS-CHECKLIST.md"

if command -v docker >/dev/null 2>&1; then
  docker compose config >/dev/null
  printf 'PASS docker compose configuration\n'
else
  printf 'SKIP docker is not installed\n'
fi

if command -v dotnet >/dev/null 2>&1; then
  dotnet build Atlas.sln --configuration Release --no-restore
else
  printf 'SKIP dotnet is not installed\n'
fi

if [[ "$failures" -ne 0 ]]; then
  exit 1
fi
