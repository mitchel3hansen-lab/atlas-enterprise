#!/usr/bin/env sh
set -eu

test -f Atlas.sln
test -f LICENSE
test -f docker-compose.yml
test -f apps/api/Atlas.Api.csproj
test -f apps/web/package.json
test -f .github/workflows/ci.yml

echo "Repository structure verified."

test -f platform/SharedKernel/Atlas.SharedKernel.csproj
test -f tests/Atlas.SharedKernel.Tests/Atlas.SharedKernel.Tests.csproj
test -f docs/architecture/SHARED-KERNEL.md
test -f docs/architecture/decisions/ADR-0002-shared-kernel.md
