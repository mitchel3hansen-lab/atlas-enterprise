# Security Policy

## Reporting a vulnerability

Do not disclose suspected vulnerabilities in a public issue. Report them privately to the repository owner or through GitHub private vulnerability reporting once enabled.

Include the affected component, reproduction steps, potential impact, and any suggested mitigation. Do not include production credentials or sensitive personal information.

## Supported versions

Until the first stable release, security fixes are applied to the current `main` branch only.

## Security baseline

- Secrets must be supplied through environment variables or an approved secret store.
- Tenant boundaries must be enforced in application and persistence layers.
- Authorization is required for every non-public endpoint.
- Audit records must be append-only except for approved redaction workflows.
- Dependencies and container images are scanned in CI.
