# Atlas Shared Kernel

`Atlas.SharedKernel` provides stable primitives shared across Atlas platform and product bounded contexts.

## Components

| Area | Purpose |
|---|---|
| Entities | Identity equality, aggregate boundaries, Atlas tenant/audit fields |
| Events | Immutable domain facts queued by aggregate roots |
| Results | Explicit expected success and failure outcomes |
| Errors | Stable error codes mapped to consistent API behavior |
| Value objects | Immutable, component-based equality |
| Abstractions | Testable clock, ID generation, current user, tenant, and execution context |
| Specifications | Reusable and composable business predicates |

## Dependency rule

The Shared Kernel has no infrastructure or product dependencies. Platform and product projects may depend on it; it must never depend on them.

## AtlasObject lifecycle

A new `AtlasObject` begins at version `1`. A successful domain mutation calls `MarkUpdated`, updates audit fields, and advances the version. `SoftDelete` records the actor and timestamp and is idempotent. Persistence adapters should map `Version` to optimistic-concurrency controls.

## Usage example

```csharp
public sealed class Incident : AtlasObject
{
    public Incident(Guid id, Guid tenantId, Guid organizationId, string actor, DateTimeOffset now)
        : base(id, tenantId, organizationId, null, actor, now)
    {
    }

    public string Title { get; private set; } = string.Empty;

    public void Rename(string title, string actor, DateTimeOffset now)
    {
        Title = title;
        MarkUpdated(actor, now);
    }
}
```

## Validation

Run:

```bash
dotnet test tests/Atlas.SharedKernel.Tests/Atlas.SharedKernel.Tests.csproj --collect:"XPlat Code Coverage"
```
