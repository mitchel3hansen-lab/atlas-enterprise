# ADR-0010: Investigation aggregate and reusable corrective actions

**Status:** Accepted

Atlas models an investigation as a tenant-scoped operational record associated one-to-one with an incident. Notes and witness statements are append-only. Root-cause analysis is versioned and supports 5 Whys and Fishbone. Corrective actions are durable child records with independent ownership, due dates, completion, and verification states.

Corrective actions remain incident-linked in Alpha but use a reusable model so inspections, audits, JHAs, and SMETA findings can adopt the same capability later. Investigation completion is blocked until root cause exists and all actions are verified or closed.
