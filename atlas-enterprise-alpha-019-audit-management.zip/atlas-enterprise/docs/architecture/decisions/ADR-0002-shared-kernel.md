# ADR-0002: Establish a Minimal Shared Kernel

- Status: Accepted
- Date: 2026-07-27

## Context

Atlas products need consistent identity, auditing, tenant scope, domain-event handling, expected-error handling, and testable time and identifier generation. Duplicating these concepts in each module would create incompatible semantics and unnecessary coupling.

## Decision

Create `Atlas.SharedKernel` as a dependency-light .NET class library. It contains only stable domain primitives and abstractions:

- `Entity<TId>` and `AggregateRoot<TId>`
- `AtlasObject`
- domain events
- value-object equality
- `Result` and the error catalog
- clock, identifier, user, tenant, and execution-context abstractions
- composable specifications

The Shared Kernel must not reference ASP.NET Core, Entity Framework Core, PostgreSQL, messaging systems, or any product module. Product-specific value objects and business rules remain within their owning bounded context.

## Consequences

- Domain modules receive consistent semantics and cleaner tests.
- Changes to the kernel require heightened review because they affect every product.
- The kernel remains intentionally small; convenience utilities do not qualify automatically.
- Existing API models will migrate incrementally rather than through a high-risk rewrite.
