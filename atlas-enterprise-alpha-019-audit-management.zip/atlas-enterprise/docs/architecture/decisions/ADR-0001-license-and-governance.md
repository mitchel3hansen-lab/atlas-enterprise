# ADR-0001: License and Repository Governance

- Status: Accepted
- Date: 2026-07-27

## Decision

Atlas Enterprise uses the Apache License 2.0, a single canonical Git repository, a protected `main` branch, short-lived feature branches, and pull-request-based changes.

## Rationale

Apache 2.0 permits commercial and open-source use while providing an explicit patent license. A single source of truth prevents drift among generated release packages and supports reproducible builds, reviewable history, automated testing, and controlled releases.

## Consequences

All contributions must be compatible with Apache 2.0. Historical release-package documentation is retained for traceability but does not define separate product lines or repositories.
