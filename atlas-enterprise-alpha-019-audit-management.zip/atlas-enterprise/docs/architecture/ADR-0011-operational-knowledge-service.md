# ADR-0011: Operational Knowledge as an Explainable Platform Service

**Status:** Accepted  
**Release:** Alpha 0.14

## Decision

Atlas will implement Operational Knowledge as a reusable platform service above the Knowledge Graph. The graph stores relationships; Operational Knowledge turns those relationships into searchable lessons, contextual similarity, and evidence-linked recommendations.

## Guardrails

- Recommendations remain decision support and require human review.
- Every recommendation includes confidence, rationale, evidence, and suggested actions.
- Similarity is deterministic for Alpha and may not be represented as predictive analytics.
- Tenant boundaries are enforced at every repository query.
- Lessons retain links to their source operational records.

## Consequences

This separation allows Safety Management Systems, Government Risk, Emergency Management, and future products to share one learning capability without embedding product-specific logic in the graph engine.
