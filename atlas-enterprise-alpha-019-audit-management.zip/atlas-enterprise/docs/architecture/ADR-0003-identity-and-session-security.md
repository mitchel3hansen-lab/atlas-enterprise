# ADR-0003: Identity and Session Security

**Status:** Accepted  
**Date:** 2026-07-27

## Decision

Atlas uses short-lived signed JWT access tokens with server-persisted, rotating refresh sessions. Access tokens include a unique JWT identifier (`jti`) and are rejected after logout through a revocation registry. Refresh tokens are random, stored only as SHA-256 hashes, rotated on every use, and bound to a user, membership, and organization.

Atlas also enforces configurable failed-login lockout and a minimum password policy at account creation and password-change boundaries.

## Rationale

Purely stateless JWT authentication cannot reliably support immediate logout, session termination, or refresh-token replay controls. Persisted session metadata adds those controls while keeping API authorization efficient.

## Consequences

- Authentication requires PostgreSQL availability for login, refresh, logout, and revoked-token checks.
- Expired refresh and revocation records require scheduled cleanup in a later operations sprint.
- Production deployments must replace development signing keys with secret-managed keys and should migrate to asymmetric signing before external release.
