# ADR-0014: Model Training as a Competency Control

**Status:** Accepted

## Decision
Separate course definitions, assignments, and durable competency records. Completion of a valid assignment updates the employee-course competency record and calculates its renewal date.

## Why
Attendance alone does not prove readiness. Atlas needs an auditable relationship between assigned learning, assessment evidence, qualification status, and expiration risk.

## Consequences
- Courses remain reusable and independently governed.
- Assignment history is retained.
- Current competency can be queried without reconstructing all completions.
- Future incident and risk modules can verify qualification at the time of an event.
