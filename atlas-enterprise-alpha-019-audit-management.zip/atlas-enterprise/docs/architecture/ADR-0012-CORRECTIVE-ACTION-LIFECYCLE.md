# ADR-0012: Corrective Action Lifecycle and Effectiveness Gate

**Status:** Accepted  
**Release:** Alpha 0.16

## Decision
Implement corrective actions as a tenant-scoped aggregate with explicit transition methods and a mandatory effectiveness gate. Evidence, verification records, and lifecycle history remain part of the aggregate snapshot in Alpha. External evidence content is retained by the platform evidence service and referenced by identifier.

## Rationale
Task completion does not prove risk reduction. A separate verification stage prevents administrative closure from being confused with operational effectiveness. A generic source type allows the capability to serve incidents, inspections, audits, risk assessments, and future Atlas products.

## Consequences
- Closure requires an effective verification record.
- Ineffective or partially effective outcomes preserve the record and enable rework.
- Authorization separates management, execution, and verification duties.
- JSONB snapshot collections simplify Alpha delivery; later releases may normalize history and verification tables for high-volume analytics.
