# ADR-0013: Shared Risk Assessment Engine

## Status
Accepted for Alpha 0.17.

## Decision
Atlas will use one reusable risk aggregate for risk-register, JHA, and HIRA assessments. Method-specific forms are projections over the shared aggregate rather than separate persistence models.

Risk is calculated deterministically from configurable ordinal likelihood and severity values. Inherent and residual ratings are retained so changes remain explainable. Controls use the hierarchy of controls and require explicit verification status.

## Consequences
- Cross-module risk reporting is consistent.
- Future matrix configurations can be tenant metadata without rewriting the domain.
- Acceptance of high or critical residual risk is blocked by the service layer.
- Specialized assessment methods can add metadata while retaining a common lifecycle.
