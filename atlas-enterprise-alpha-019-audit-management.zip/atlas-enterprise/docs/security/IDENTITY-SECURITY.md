# Atlas Identity and Security

## Controls implemented in Sprint 002

- PBKDF2-SHA256 password hashing with per-password random salt
- Twelve-character password minimum with upper, lower, numeric, and symbol requirements
- Configurable lockout after repeated failed login attempts
- Short-lived JWT access tokens with unique `jti` claims
- Rotating refresh tokens stored only as SHA-256 hashes
- Organization and membership binding on every session
- Logout-driven access-token revocation and refresh-session termination
- Database validation of revoked access tokens
- Tenant context derived from the authenticated organization claim

## Production requirements

Use a secret manager for signing keys and database credentials. Enforce TLS at the edge and between services where supported. Configure rate limiting at the gateway and API. Add asymmetric token signing, MFA, security-event monitoring, and refresh-session cleanup before General Availability.
