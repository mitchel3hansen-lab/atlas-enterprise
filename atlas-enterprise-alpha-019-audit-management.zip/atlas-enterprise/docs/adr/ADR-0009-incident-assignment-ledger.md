# ADR-0009: Incident assignment ledger

## Status
Accepted

## Decision
Store current assignment state on the incident for efficient reads and append every assignment to `atlas.incident_assignments` for auditability. Assignment uses a dedicated command endpoint rather than the generic transition endpoint.

## Consequences
- Current queues remain fast.
- Reassignment history is durable and reviewable.
- Assignment and workflow semantics are explicit.
- A later transaction boundary should atomically persist incident, ledger, timeline, and outbox events.
