# ADR-0008: Incident retention and deletion

Incident records are operational evidence and are not hard-deleted through the product API. Future archival will preserve timeline, audit, and evidence relationships and will follow tenant retention policy and legal-hold controls.
