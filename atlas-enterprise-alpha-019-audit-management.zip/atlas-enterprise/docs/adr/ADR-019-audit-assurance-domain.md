# ADR-019: Model audits as a governed assurance domain

## Status
Accepted

## Decision
Atlas will implement audits as a dedicated domain while linking findings to the shared Corrective Action service. Audit lifecycle, scope, scoring, evidence, and review remain distinct from inspection execution.

## Rationale
Inspections are frequent operational checks; audits independently evaluate conformance against defined requirements. Separating the domains preserves assurance independence while reusing remediation and evidence capabilities.

## Consequences
- Audit permissions and lifecycle are independently governed.
- Findings can generate or link corrective actions without duplicating CAPA logic.
- Future standards packs can configure requirements without changing the core domain.
