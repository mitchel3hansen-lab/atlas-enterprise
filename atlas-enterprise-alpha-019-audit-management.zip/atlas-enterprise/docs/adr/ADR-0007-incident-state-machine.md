# ADR-0007: Incident state machine

Incidents progress through Draft, Submitted, Assigned, Investigating, Verification, and Closed. State changes use explicit commands and optimistic concurrency. Milestone 1 exposes create and view while preserving the transition contract for later increments.
