# ADR-0006: Tenant-scoped incident numbering

## Decision
Use `INC-{year}-{sequence:00000}`. A PostgreSQL row locked inside a transaction allocates each tenant/year sequence without scanning the incident table.

## Consequences
Numbers are readable, tenant-scoped, monotonic, and safe under concurrent creation. Deleted or failed transactions do not cause number reuse.
