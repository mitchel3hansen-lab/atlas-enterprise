# Branching and Pull Requests

`main` is the only long-lived branch and must remain production-ready. Development occurs on short-lived branches named by intent, such as `feat/incident-assignment`, `fix/timeline-ordering`, or `docs/security-policy`.

Required branch protection for `main`:

- Pull request required before merge
- At least one approving review
- CI checks required
- Conversation resolution required
- Force pushes and branch deletion disabled
- Linear history preferred

Squash merge is the default so each pull request becomes one coherent change in repository history.
