# Release Governance

Atlas uses a single repository and a single release history.

A release candidate requires green CI, migration and rollback review, updated release notes, dependency review, container build validation, and a documented deployment plan. Releases are tagged from `main` using Semantic Versioning after the public versioning baseline is established.
