# Alpha 0.14 — Operational Knowledge

## User outcome

A safety manager can open an operational context, review similar records, understand recurring signals, locate relevant lessons learned, and see explainable recommendations supported by evidence.

## Included

- Lessons Learned domain model and PostgreSQL persistence
- Context endpoint for incidents and other operational objects
- Similar-record retrieval through graph relationships
- Deterministic, evidence-linked recommendations
- Searchable lesson library
- Operational Knowledge user interface
- Human-review and confidence guardrails

## API

- `GET /api/v1/knowledge/context/{objectType}/{objectId}`
- `GET /api/v1/knowledge/lessons`
- `POST /api/v1/knowledge/lessons`

## Not included

- Machine learning
- Autonomous corrective actions
- Natural-language generation
- Cross-tenant learning
