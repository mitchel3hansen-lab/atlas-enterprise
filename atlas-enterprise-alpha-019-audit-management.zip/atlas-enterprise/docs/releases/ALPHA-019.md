# Atlas Enterprise Alpha 0.19 — Audit Management

## Added
- Audit program lifecycle and searchable register
- Five audit types and four finding severity levels
- Finding-to-corrective-action linkage
- Dashboard assurance metrics
- PostgreSQL migration V033 and rollback
- Audit API, repository, service, controller, tests, permissions, UI workspace, product specification, and ADR

## Validation limits
Repository integrity and archive validation are performed in the generation runtime. Full .NET and frontend dependency builds require a development environment with the SDK and installed packages.
