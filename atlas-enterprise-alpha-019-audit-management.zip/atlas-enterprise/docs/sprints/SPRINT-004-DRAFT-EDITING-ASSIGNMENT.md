# Sprint 004 — Draft Editing and Investigator Assignment

## Goal
Allow authorized users to revise draft incident records and route submitted incidents to a named investigator with a durable assignment history.

## Delivered
- Draft-only editing with optimistic concurrency.
- Timeline and rules events for `Incident.DraftUpdated`.
- Dedicated `POST /api/v1/incidents/{id}/assign` endpoint.
- Assignment history endpoint and PostgreSQL ledger.
- Investigator display name, assigned timestamp, and assigning actor on the incident record.
- React edit and assignment interactions.
- Migration V026 and rollback.

## Acceptance criteria
1. Non-draft incidents reject edits.
2. Stale versions reject edits and assignments.
3. Only submitted incidents may be assigned.
4. Assignment moves the incident to `Assigned`.
5. Every assignment is retained in an append-only history table.
6. Tenant filters apply to incident and assignment reads.
