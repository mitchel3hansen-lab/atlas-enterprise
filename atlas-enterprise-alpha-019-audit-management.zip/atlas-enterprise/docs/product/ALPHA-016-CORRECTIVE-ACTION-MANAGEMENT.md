# Alpha 0.16 — Corrective Action Management

## Objective
Close the operational improvement loop with a controlled corrective-action lifecycle from source finding through independent effectiveness verification.

## Included capability
- Corrective actions linked to incidents, investigations, inspections, audits, risks, observations, complaints, and management reviews.
- Tenant-scoped human-readable numbering.
- Risk priority, owner, facility, department, and due-date context.
- Controlled lifecycle: Draft → Assigned → In Progress → Evidence Submitted → Pending Verification → Effective/Ineffective → Closed.
- Objective evidence references integrated with the Atlas evidence service.
- Independent effectiveness verification and rework when controls are ineffective.
- Immutable in-record history entries for key lifecycle events.
- Search, overdue filtering, dashboards, and role-based permissions.

## Acceptance criteria
1. A manager can create and assign a corrective action.
2. The assigned owner can start implementation and submit evidence.
3. Verification cannot begin without evidence.
4. Closure is blocked until an effective verification is recorded.
5. An ineffective result returns the action to a controlled rework path.
6. API reads and writes are tenant scoped and authorization protected.
7. Dashboard metrics expose open, overdue, critical, verification, closure, and effectiveness indicators.

## Human-control principle
Atlas may prioritize and summarize corrective actions, but an authorized person must verify effectiveness. The system never auto-closes an action based only on task completion.
