# Alpha 0.15 — Inspection Management

## Objective
Deliver the first mobile-ready inspection vertical slice: approved templates, scheduling, field execution, findings, submission, and controlled closure.

## Included
- Tenant-scoped inspection templates and checklist items
- Facility and inspector assignment
- Draft, scheduled, in-progress, submitted, closed, and cancelled lifecycle
- Pass/fail/observation/not-applicable responses
- Evidence references on checklist responses
- Findings with severity, owner, due date, and CAPA linkage placeholder
- Completion calculation and submission guardrails
- PostgreSQL migration V029 and rollback
- Role-based permissions for read, manage, and execute
- React inspection queue and execution workspace

## Acceptance criteria
1. An administrator can create a reusable inspection template.
2. A manager can schedule an inspection for a facility and inspector.
3. The assigned inspector can start and save responses.
4. Submission is blocked until the checklist is complete.
5. Findings remain visible through closure and unresolved findings block closure.
6. Tenant boundaries are applied to every repository query.

## Product principle
An inspection is not complete merely because a checklist was submitted. Atlas keeps findings actionable and requires verification before operational closure.
