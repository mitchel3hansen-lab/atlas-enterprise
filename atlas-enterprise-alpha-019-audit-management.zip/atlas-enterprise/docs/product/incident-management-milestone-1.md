# Incident Management — Milestone 1

## Delivered
- Create a tenant-scoped incident in Draft status.
- Allocate a concurrency-safe human-readable incident number.
- Read incident detail by ID.
- Search and filter by text, status, severity, type, facility, department, and occurrence window.
- Append the `Incident.Created` timeline event and execute applicable rules.
- Display incident register, creation form, and detail panel in React.

## API
- `POST /api/v1/incidents`
- `GET /api/v1/incidents`
- `GET /api/v1/incidents/{id}`

## Next increment
Draft editing, assignment, authorization matrix, and API-connected UI state.
