# ALPHA-012 — Investigation Workspace

## Outcome
An assigned incident can be advanced into a structured investigation without leaving the incident workspace.

## Included
- Start investigation and move incident to Investigating
- Investigation notes and witness statements
- 5 Whys and Fishbone root-cause records
- Corrective-action numbering, ownership, due dates, completion, and verification
- Controlled investigation lifecycle
- Investigation quality score
- Timeline events for material actions
- Tenant-scoped PostgreSQL persistence
- React workspace reference implementation

## Release acceptance
1. Only Assigned incidents can start an investigation.
2. Root cause is required before Corrective Actions.
3. At least one corrective action is required before Verification.
4. All actions must be Verified or Closed before Completed.
5. Every write is tenant-scoped and produces a traceable timeline event.
