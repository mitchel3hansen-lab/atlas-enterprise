# Audit Management — Alpha 0.19

Atlas Audit Management provides a governed assurance workflow for internal, regulatory, customer, supplier, and certification audits.

## Scope

- Audit planning by tenant, facility, department, type, lead auditor, and date range
- Lifecycle: Draft → Scheduled → In Progress → Pending Review → Closed
- Requirement-based findings with Observation, Minor, Major, and Critical severity
- Finding due dates and overdue monitoring
- Corrective-action linkage
- Independent review and scored closure
- Dashboard metrics and search
- Tenant isolation and role-based permissions

## Acceptance criteria

1. An audit cannot be scheduled without a valid lead auditor and date range.
2. Lifecycle transitions occur only in the defined sequence.
3. Findings cannot be added to closed or cancelled audits.
4. Findings can link to governed corrective actions.
5. Only authorized reviewers can close an audit.
6. Dashboard metrics expose scheduled work, active audits, open findings, critical findings, overdue findings, and average score.
