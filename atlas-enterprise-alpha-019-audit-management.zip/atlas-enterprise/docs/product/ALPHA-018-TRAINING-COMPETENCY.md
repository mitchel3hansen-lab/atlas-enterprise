# Alpha 0.18 — Training & Competency Management

Atlas now manages required training as an operational control rather than a detached attendance log.

## Scope
- Versioned training courses and assessment requirements
- Employee assignments by facility and department
- Assigned, in-progress, completed, overdue, and waived states
- Passing-score enforcement and completion evidence
- Competency records with qualification and expiration dates
- Search, dashboard metrics, and expiring-qualification visibility
- Tenant-scoped permissions and PostgreSQL persistence

## Operational outcome
Training records can now support risk controls, incident analysis, inspection findings, and workforce-readiness decisions through a reusable qualification model.
