# ALPHA-013 — Atlas Command Center

## Outcome

Deliver the first role-oriented operational landing page for Atlas. The Command Center turns active records into a prioritized daily operating view rather than a passive dashboard.

## Included

- Operational health and readiness KPI cards
- Explainable risk signals with confidence, evidence, and recommended actions
- Personal work queue with due-state filters
- Six-month incident/action trend visualization
- Organization safety snapshot
- Responsive desktop and mobile layouts
- Human-review and evidence-traceability governance cues

## Acceptance criteria

1. Command Center is the default authenticated landing view.
2. Users can filter personal work by due state.
3. Each intelligence signal exposes reasons, supporting evidence, and next actions.
4. The interface remains usable at tablet and mobile breakpoints.
5. The frontend compiles successfully with TypeScript and Vite.

## Product principle

Every panel answers an operational question:

- **What needs attention?** — Intelligence signals
- **What must I do today?** — Personal work queue
- **Are controls working?** — Trend and closure metrics
- **How healthy is the organization?** — Operational snapshot
