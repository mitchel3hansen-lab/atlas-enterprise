# Alpha 0.17 — Risk Management

## Objective
Provide a tenant-scoped risk capability that supports Risk Register, Job Hazard Analysis (JHA), and Hazard Identification and Risk Assessment (HIRA) workflows.

## Included
- Configurable 5×5 likelihood and severity model with deterministic risk bands.
- Inherent and residual risk scoring.
- Hierarchy-of-controls classification.
- Control ownership, due dates, implementation, and verification status.
- Review history and risk acceptance guardrails.
- Facility and department context.
- Search, filters, dashboard metrics, and least-privilege permissions.

## Acceptance criteria
1. Scores are constrained to 1–5 and calculated as likelihood × severity.
2. High and critical residual risks cannot be accepted without further treatment.
3. Every risk has an owner and tenant-scoped identifier.
4. Controls retain type, owner, due date, status, and verification method.
5. JHA, HIRA, and risk-register records use one reusable domain capability.
