# Alpha Reference Acceptance Test

## Scenario

A worker reports a high-severity hand injury at a manufacturing facility. A supervisor submits and assigns the record. An investigator gathers evidence, performs a 5 Whys analysis, creates two corrective actions, obtains verification, and closes the incident. A manager then confirms the record in search and on the dashboard.

## Preconditions

- Alpha stack is running.
- Demo organization, facility, department, and personas are seeded.
- Email capture is available through Mailpit.
- Test users have unique role assignments.

## Test sequence

1. Sign in as employee reporter.
2. Create an incident with occurrence time, facility, department, severity, title, description, and immediate actions.
3. Confirm an incident number is generated and the incident is visible only inside the current tenant.
4. Edit the draft and confirm optimistic-concurrency protection rejects a stale update.
5. Submit the incident and confirm draft fields are no longer freely editable.
6. Sign in as supervisor and assign an investigator.
7. Confirm assignment history, timeline activity, and notification output.
8. Sign in as investigator and start the investigation.
9. Add investigation notes, one witness, equipment details, and immediate-control status.
10. Upload photo and document evidence; verify hashes and access history are recorded.
11. Complete a 5 Whys analysis and identify at least one root cause.
12. Create two corrective actions with different owners and due dates.
13. Attempt premature closure and confirm it is rejected.
14. Complete each action with evidence.
15. Sign in as verifier and independently verify each action.
16. Complete management review and close the incident.
17. Confirm the timeline contains creation, edits, submission, assignment, investigation, evidence, root cause, CAPA, verification, and closure events.
18. Search by incident number, title term, severity, facility, and date.
19. Confirm leadership dashboard counts and aging metrics reflect the closed incident.
20. Attempt access from a second tenant and confirm the resource is not disclosed.

## Pass criteria

All steps pass without direct database manipulation. Failures produce clear, non-sensitive errors and an auditable trace. No record, version, or relationship is silently overwritten.
