# Alpha Known Limitations

This file must be updated during release-candidate preparation.

- The alpha is intended for controlled evaluation and is not yet approved as a regulated system of record.
- External identity federation and enterprise single sign-on are not complete.
- The logging event publisher is a development adapter until a durable broker is selected and validated.
- Some platform repositories and legacy paths require final consolidation and integration testing.
- Native mobile clients and offline reporting are not included.
- Regulatory reports require human review before submission.
- Performance targets apply only to the documented reference environment and seeded dataset.
- Disaster recovery is limited to the alpha backup-and-restore procedure.
