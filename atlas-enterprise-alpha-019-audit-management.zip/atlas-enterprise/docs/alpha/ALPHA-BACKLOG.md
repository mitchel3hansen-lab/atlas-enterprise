# Atlas Enterprise Alpha Backlog

## Milestone A — Foundation and Security

| ID | Work item | State | Acceptance outcome |
|---|---|---|---|
| ALPHA-001 | Canonical repository and container stack | Implemented; validation pending | A new developer can start the stack from documented commands. |
| ALPHA-002 | Shared Kernel | Implemented; CI pending | Domain primitives compile and automated tests pass. |
| ALPHA-003 | Identity and tenant security | Implemented; hardening pending | Sessions rotate, logout revokes access, and tenants remain isolated. |
| ALPHA-004 | Organization administration | Planned | Admin can manage organization, sites, departments, users, and roles. |
| ALPHA-005 | Security threat model and review | Planned | Critical trust boundaries and mitigations are documented and tested. |

## Milestone B — Incident Management MVP

| ID | Work item | State | Acceptance outcome |
|---|---|---|---|
| ALPHA-010 | Create, view, and search incidents | Implemented; CI pending | Reporter can create and retrieve a tenant-scoped incident. |
| ALPHA-011 | Draft editing and investigator assignment | Implemented; CI pending | Drafts use concurrency control and assignment history is durable. |
| ALPHA-012 | Investigation workspace | Next | Investigator records team, notes, witnesses, immediate actions, and findings. |
| ALPHA-013 | Root-cause analysis | Planned | Investigator can complete 5 Whys and fishbone analyses. |
| ALPHA-014 | CAPA lifecycle | Planned | Actions have owner, due date, completion evidence, and independent verification. |
| ALPHA-015 | Workflow and approvals | Planned | Required transitions and approvals cannot be bypassed. |
| ALPHA-016 | Evidence lifecycle | Planned | Files are hashed, versioned, related, audited, and retrievable. |
| ALPHA-017 | Unified incident timeline | Planned | Material activity is presented in one ordered and integrity-verifiable history. |
| ALPHA-018 | Notifications and escalation | Planned | Assignment, due-date, overdue, and critical-event notices are dispatched. |
| ALPHA-019 | Closure review | Planned | Incident closes only after required investigation and CAPA criteria pass. |

## Milestone C — Operational Intelligence

| ID | Work item | State | Acceptance outcome |
|---|---|---|---|
| ALPHA-020 | Leadership dashboard | Planned | Leaders see open incidents, aging, CAPAs, severity, and trends. |
| ALPHA-021 | Investigation quality score | Planned | Completeness and rigor are measurable and explainable. |
| ALPHA-022 | Search and export | Planned | Authorized users can filter and export operational records. |
| ALPHA-023 | Similar-incident foundation | Planned | Related records can be discovered through deterministic metadata and graph links. |
| ALPHA-024 | Risk summary | Planned | Incident risk and organizational exposure are calculated with an explanation. |

## Milestone D — Alpha Operations

| ID | Work item | State | Acceptance outcome |
|---|---|---|---|
| ALPHA-030 | Seeded demonstration tenant | Planned | Evaluators can run the reference lifecycle without manual database setup. |
| ALPHA-031 | Backup and restore | Planned | Operator can back up and restore the alpha database and evidence store. |
| ALPHA-032 | Observability | Planned | Logs, traces, metrics, and correlation IDs support incident diagnosis. |
| ALPHA-033 | Performance baseline | Planned | Core scenarios are benchmarked against alpha targets. |
| ALPHA-034 | Security and dependency scanning | Planned | CI reports vulnerable packages and container findings. |
| ALPHA-035 | Alpha documentation | Planned | Installation, administration, operation, evaluation, and limitations are documented. |
| ALPHA-036 | Release candidate rehearsal | Planned | Clean install, upgrade, rollback, backup, restore, and workflow tests pass. |
