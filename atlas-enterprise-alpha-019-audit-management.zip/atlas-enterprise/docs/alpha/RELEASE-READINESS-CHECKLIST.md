# Alpha Release Readiness Checklist

## Product

- [ ] Alpha scope is frozen.
- [ ] Reference acceptance test passes.
- [ ] Known limitations are approved and published.
- [ ] Demonstration tenant and workflow are available.

## Engineering

- [ ] Backend solution builds with warnings reviewed.
- [ ] Frontend production build completes.
- [ ] Unit, integration, contract, and end-to-end tests pass.
- [ ] Database migrations apply to a clean database.
- [ ] Upgrade from the preceding baseline succeeds.
- [ ] Rollback procedure is rehearsed.
- [ ] Repository has no committed secrets.

## Security

- [ ] Tenant-isolation tests pass.
- [ ] Authorization tests cover every alpha endpoint.
- [ ] Refresh, revocation, expiration, and lockout tests pass.
- [ ] Dependency and container scans have no unaccepted critical/high findings.
- [ ] Evidence access and audit events are verified.
- [ ] Threat model is reviewed.

## Operations

- [ ] Docker health checks pass.
- [ ] Structured logs include tenant, user, request, trace, and correlation context.
- [ ] Backup and restore are demonstrated.
- [ ] Failure and recovery procedures are documented.
- [ ] Default credentials are absent or require first-run change.

## Documentation

- [ ] Installation guide
- [ ] Administrator guide
- [ ] Operator runbook
- [ ] Evaluator guide
- [ ] API documentation
- [ ] Data-retention and privacy notes
- [ ] Release notes and checksums

## Approval

- [ ] Product
- [ ] Engineering
- [ ] Security
- [ ] Operations
