# Atlas Enterprise Alpha Release Charter

## Mission

Deliver an installable Manufacturing and Safety Management Systems alpha that proves Atlas can manage an incident from report through investigation, corrective action, verification, and closure while preserving tenant isolation, evidence integrity, workflow history, and auditability.

## Alpha success statement

A pilot organization can install Atlas, configure one organization and facility, create users, report an incident, assign an investigator, document the investigation, attach evidence, create and verify corrective actions, close the incident, search the resulting record, and view leadership metrics.

## In scope

- Authentication, refresh sessions, logout, tenant isolation, and role permissions
- Organization, facility, department, and user administration
- Incident create, view, search, draft edit, submit, and assignment
- Investigation workspace with notes, witnesses, immediate actions, and root-cause analysis
- Corrective and preventive actions with owners, due dates, evidence, and verification
- Evidence hashing, immutable versions, access history, and incident relationships
- Unified timeline and audit history
- Workflow transitions, rules hooks, notifications, and escalation foundations
- Alpha dashboards and CSV/PDF-ready reporting contracts
- Docker Compose installation, migrations, seeded demo data, and operator documentation

## Explicitly out of scope

- Native mobile applications
- Artificial-intelligence recommendations
- Full OSHA electronic submission
- Enterprise SSO federation beyond the authentication scaffold
- Billing, subscriptions, and commercial licensing enforcement
- General-purpose no-code configuration studio
- Additional product modules such as JHA, HIRA, training, chemicals, and SMETA

## Release gates

The alpha may be tagged only when all gates pass:

1. `docker compose up --build` starts the supported local stack.
2. API, database, Redis, and web health checks pass.
3. The reference incident lifecycle passes end to end.
4. Cross-tenant access tests pass.
5. No open critical or high-severity security defects remain.
6. Database upgrade and rollback are rehearsed.
7. Backup and restore are demonstrated.
8. Alpha operator, administrator, and evaluator guides are complete.
9. Known limitations are documented.
10. A release candidate is approved by Product, Engineering, Security, and Operations.

## Alpha personas

- Employee reporter
- Supervisor
- Investigator
- Corrective-action owner
- Safety or risk manager
- Organization administrator
- Executive viewer
- Platform operator

## Target quality objectives

- No known cross-tenant data leakage
- No silent loss of incident, evidence, timeline, or CAPA records
- API p95 response time below 750 ms for core alpha operations in the reference environment
- Search results returned within two seconds for the seeded alpha dataset
- Recovery-point objective of 24 hours for the alpha environment
- Recovery-time objective of four hours for the alpha environment

## Governance

The alpha uses short-lived branches, pull requests, required CI, architecture decision records, migration review, and release-candidate sign-off. Scope changes require an issue linked to the Alpha milestone.
