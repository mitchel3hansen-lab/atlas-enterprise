# Atlas Enterprise Alpha 0.18

## Training & Competency Management
Added a complete training-management vertical slice with course governance, assignments, completion validation, evidence references, qualification records, renewal dates, dashboard metrics, RBAC permissions, PostgreSQL migration V032, API endpoints, React workspace, tests, and documentation.
