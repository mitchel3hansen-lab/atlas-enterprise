# Atlas Enterprise Alpha 0.13 — Command Center

This increment introduces the Atlas Command Center as the default landing experience.

## Highlights

- Five operational KPI cards
- Explainable risk alerts
- Personal priority queue
- Incident versus action-closure trend
- Safety performance snapshot
- Responsive layout and accessibility labels

## Validation

- Frontend TypeScript build
- Vite production bundle
- Repository integrity verification

## Known limitations

- Command Center data is seeded demonstration data pending backend aggregation endpoints.
- Role-specific widget configuration and saved dashboard preferences are planned for a later increment.
