using Atlas.SharedKernel.Entities;
using Atlas.SharedKernel.Events;

namespace Atlas.SharedKernel.Tests;

public sealed class AggregateRootTests
{
    [Fact]
    public void Dequeue_returns_events_and_clears_queue()
    {
        var aggregate = new TestAggregate(Guid.NewGuid());
        aggregate.Record("created");

        var events = aggregate.DequeueDomainEvents();

        Assert.Single(events);
        Assert.Empty(aggregate.DomainEvents);
    }

    private sealed class TestAggregate(Guid id) : AggregateRoot<Guid>(id)
    {
        public void Record(string name) => RaiseDomainEvent(new TestEvent(Guid.NewGuid(), DateTimeOffset.UtcNow, name));
    }

    private sealed record TestEvent(Guid Id, DateTimeOffset At, string Name) : DomainEvent(Id, At);
}
