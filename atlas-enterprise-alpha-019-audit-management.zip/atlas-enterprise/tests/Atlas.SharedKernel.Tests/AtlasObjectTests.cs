using Atlas.SharedKernel.Entities;

namespace Atlas.SharedKernel.Tests;

public sealed class AtlasObjectTests
{
    [Fact]
    public void New_object_starts_at_version_one()
    {
        var now = DateTimeOffset.Parse("2026-07-27T12:00:00Z");
        var subject = Create(now);

        Assert.Equal(1, subject.Version);
        Assert.Equal(now, subject.CreatedAt);
        Assert.Equal(now, subject.UpdatedAt);
        Assert.False(subject.IsDeleted);
    }

    [Fact]
    public void Update_advances_version_and_audit_fields()
    {
        var now = DateTimeOffset.Parse("2026-07-27T12:00:00Z");
        var subject = Create(now);

        subject.Rename("updated", "user-2", now.AddMinutes(1));

        Assert.Equal(2, subject.Version);
        Assert.Equal("user-2", subject.UpdatedBy);
        Assert.Equal("updated", subject.Name);
    }

    [Fact]
    public void Soft_delete_is_idempotent()
    {
        var now = DateTimeOffset.Parse("2026-07-27T12:00:00Z");
        var subject = Create(now);

        subject.SoftDelete("user-2", now.AddMinutes(1));
        subject.SoftDelete("user-3", now.AddMinutes(2));

        Assert.True(subject.IsDeleted);
        Assert.Equal("user-2", subject.DeletedBy);
        Assert.Equal(2, subject.Version);
    }

    private static TestAtlasObject Create(DateTimeOffset now) =>
        new(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), null, "user-1", now, "initial");

    private sealed class TestAtlasObject(
        Guid id,
        Guid tenantId,
        Guid organizationId,
        Guid? siteId,
        string createdBy,
        DateTimeOffset createdAt,
        string name) : AtlasObject(id, tenantId, organizationId, siteId, createdBy, createdAt)
    {
        public string Name { get; private set; } = name;

        public void Rename(string name, string actor, DateTimeOffset at)
        {
            Name = name;
            MarkUpdated(actor, at);
        }
    }
}
