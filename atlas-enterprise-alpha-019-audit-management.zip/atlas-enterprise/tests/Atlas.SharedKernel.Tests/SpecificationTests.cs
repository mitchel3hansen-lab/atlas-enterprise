using System.Linq.Expressions;
using Atlas.SharedKernel.Specifications;

namespace Atlas.SharedKernel.Tests;

public sealed class SpecificationTests
{
    [Fact]
    public void Specifications_compose_with_boolean_operators()
    {
        var critical = new SeveritySpecification("Critical");
        var open = new OpenSpecification();

        Assert.True(critical.And(open).IsSatisfiedBy(new Incident("Critical", false)));
        Assert.False(critical.And(open).IsSatisfiedBy(new Incident("Critical", true)));
        Assert.True(critical.Or(open).IsSatisfiedBy(new Incident("Low", false)));
        Assert.True(open.Not().IsSatisfiedBy(new Incident("Low", true)));
    }

    private sealed record Incident(string Severity, bool IsClosed);

    private sealed class SeveritySpecification(string severity) : Specification<Incident>
    {
        public override Expression<Func<Incident, bool>> ToExpression() => incident => incident.Severity == severity;
    }

    private sealed class OpenSpecification : Specification<Incident>
    {
        public override Expression<Func<Incident, bool>> ToExpression() => incident => !incident.IsClosed;
    }
}
