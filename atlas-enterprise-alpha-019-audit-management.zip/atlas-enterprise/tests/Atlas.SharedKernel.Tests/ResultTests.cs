using Atlas.SharedKernel.Errors;
using Atlas.SharedKernel.Results;

namespace Atlas.SharedKernel.Tests;

public sealed class ResultTests
{
    [Fact]
    public void Success_has_no_error()
    {
        var result = Result.Success();
        Assert.True(result.IsSuccess);
        Assert.Equal(Error.None, result.Error);
    }

    [Fact]
    public void Failure_exposes_error()
    {
        var error = Error.Validation("incident.title.required", "Title is required.");
        var result = Result.Failure(error);
        Assert.True(result.IsFailure);
        Assert.Equal(error, result.Error);
    }

    [Fact]
    public void Failed_generic_result_does_not_expose_value()
    {
        var result = Result.Failure<string>(Error.NotFound("item.not_found", "Item was not found."));
        Assert.Throws<InvalidOperationException>(() => _ = result.Value);
    }
}
