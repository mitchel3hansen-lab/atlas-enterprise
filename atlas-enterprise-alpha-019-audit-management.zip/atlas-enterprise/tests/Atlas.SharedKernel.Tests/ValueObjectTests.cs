using Atlas.SharedKernel.ValueObjects;

namespace Atlas.SharedKernel.Tests;

public sealed class ValueObjectTests
{
    [Fact]
    public void Equal_components_produce_value_equality()
    {
        Assert.Equal(new Coordinate(41.0m, -112.0m), new Coordinate(41.0m, -112.0m));
        Assert.NotEqual(new Coordinate(41.0m, -112.0m), new Coordinate(40.0m, -112.0m));
    }

    private sealed class Coordinate(decimal latitude, decimal longitude) : ValueObject
    {
        protected override IEnumerable<object?> GetEqualityComponents()
        {
            yield return latitude;
            yield return longitude;
        }
    }
}
