using Atlas.SharedKernel.Entities;

namespace Atlas.SharedKernel.Tests;

public sealed class EntityTests
{
    [Fact]
    public void Same_type_and_id_are_equal()
    {
        var id = Guid.NewGuid();
        Assert.Equal(new TestEntity(id), new TestEntity(id));
    }

    [Fact]
    public void Different_types_with_same_id_are_not_equal()
    {
        var id = Guid.NewGuid();
        Assert.NotEqual<Entity<Guid>>(new TestEntity(id), new OtherEntity(id));
    }

    private sealed class TestEntity(Guid id) : Entity<Guid>(id);
    private sealed class OtherEntity(Guid id) : Entity<Guid>(id);
}
