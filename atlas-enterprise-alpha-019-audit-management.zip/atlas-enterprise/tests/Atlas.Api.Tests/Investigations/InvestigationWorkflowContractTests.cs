using Atlas.Api.Investigations;
using Xunit;

namespace Atlas.Api.Tests.Investigations;
public sealed class InvestigationWorkflowContractTests
{
 [Fact] public void Lifecycle_is_ordered_and_complete(){var stages=Enum.GetValues<InvestigationStage>();Assert.Equal(8,stages.Length);Assert.Equal(InvestigationStage.Assigned,stages[0]);Assert.Equal(InvestigationStage.Completed,stages[^1]);}
 [Fact] public void Corrective_actions_support_independent_verification(){Assert.Contains(CorrectiveActionStatus.ReadyForVerification,Enum.GetValues<CorrectiveActionStatus>());Assert.Contains(CorrectiveActionStatus.Verified,Enum.GetValues<CorrectiveActionStatus>());}
 [Theory][InlineData(0,false)][InlineData(70,true)][InlineData(100,true)] public void Quality_gate_requires_strong_score(int score,bool ready)=>Assert.Equal(ready,score>=70);
}
