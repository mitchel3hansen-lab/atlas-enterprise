using Atlas.Api.OperationalKnowledge;
using Xunit;

namespace Atlas.Api.Tests.OperationalKnowledge;

public sealed class OperationalKnowledgeServiceTests
{
    [Fact]
    public async Task CreateLesson_CleansDuplicates_AndPublishes()
    {
        var repository = new FakeRepository();
        var service = new OperationalKnowledgeService(repository);
        var lesson = await service.CreateLessonAsync(Guid.NewGuid(), Guid.NewGuid(),
            new("Forklift congestion", "Restricted aisle increased interaction risk", "Insufficient operating clearance",
                new[] { "Reconfigure aisle", "reconfigure aisle", "Verify pedestrian route" }, new[] { "Incident" },
                new[] { Guid.NewGuid() }, null, true), default);
        Assert.Equal(LessonStatus.Published, lesson.Status);
        Assert.Equal(2, lesson.EffectiveControls.Count);
    }

    [Fact]
    public async Task BuildContext_CreatesExplainableRecommendation_ForRecurringSignals()
    {
        var repository = new FakeRepository { Similar = new[] {
            new SimilarRecord(Guid.NewGuid(), "Incident", "Beam strike", .88m, new[] { "restricted-space", "forklift" }, Array.Empty<Guid>()),
            new SimilarRecord(Guid.NewGuid(), "Incident", "Pedestrian near miss", .81m, new[] { "restricted-space", "forklift" }, Array.Empty<Guid>()) } };
        var context = await new OperationalKnowledgeService(repository).BuildContextAsync(Guid.NewGuid(), "Incident", Guid.NewGuid(), default);
        Assert.Single(context.Recommendations);
        Assert.True(context.Recommendations[0].RequiresHumanReview);
        Assert.NotEmpty(context.Recommendations[0].Evidence);
    }

    private sealed class FakeRepository : IOperationalKnowledgeRepository
    {
        public IReadOnlyList<SimilarRecord> Similar { get; init; } = Array.Empty<SimilarRecord>();
        public Task<LessonLearned> AddLessonAsync(LessonLearned lesson, CancellationToken ct) => Task.FromResult(lesson);
        public Task<LessonLearned?> GetLessonAsync(Guid tenantId, Guid id, CancellationToken ct) => Task.FromResult<LessonLearned?>(null);
        public Task<KnowledgeSearchResult> SearchLessonsAsync(Guid tenantId, KnowledgeSearchQuery query, CancellationToken ct) => Task.FromResult(new KnowledgeSearchResult(Array.Empty<LessonLearned>(),0,query.Limit,query.Offset));
        public Task<IReadOnlyList<LessonLearned>> FindLessonsForObjectsAsync(Guid tenantId, IReadOnlyList<Guid> objectIds, CancellationToken ct) => Task.FromResult<IReadOnlyList<LessonLearned>>(Array.Empty<LessonLearned>());
        public Task<IReadOnlyList<SimilarRecord>> FindSimilarAsync(Guid tenantId, string objectType, Guid objectId, int limit, CancellationToken ct) => Task.FromResult(Similar);
        public Task<IReadOnlyDictionary<string, int>> GetRelationshipCountsAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken ct) => Task.FromResult<IReadOnlyDictionary<string,int>>(new Dictionary<string,int>{{"Incident",Similar.Count}});
    }
}
