using Atlas.Api.Inspections;
using Xunit;

namespace Atlas.Api.Tests.Inspections;

public sealed class InspectionServiceTests
{
    [Fact]
    public async Task Submit_requires_complete_responses()
    {
        var repo = new MemoryRepository(); var service = new InspectionService(repo); var tenant = Guid.NewGuid(); var inspector = Guid.NewGuid();
        var item = new InspectionTemplateItem(Guid.NewGuid(), "Housekeeping", "Aisles clear", true, "29 CFR 1910.22", 1);
        var template = await service.CreateTemplateAsync(tenant, new("Daily Walk", "", "Safety", new[]{item}), default);
        var inspection = await service.ScheduleAsync(tenant, new(template.Id, Guid.NewGuid(), "Morning walk", inspector, null), default);
        await service.StartAsync(tenant, inspection.Id, inspector, default);
        await Assert.ThrowsAsync<InvalidOperationException>(() => service.SubmitAsync(tenant, inspection.Id, default));
    }

    [Fact]
    public async Task Response_completion_allows_submission()
    {
        var repo = new MemoryRepository(); var service = new InspectionService(repo); var tenant = Guid.NewGuid(); var inspector = Guid.NewGuid(); var itemId=Guid.NewGuid();
        var template = await service.CreateTemplateAsync(tenant,new("Forklift","","PIT",new[]{new InspectionTemplateItem(itemId,"Equipment","Horn works",true,null,1)}),default);
        var inspection=await service.ScheduleAsync(tenant,new(template.Id,Guid.NewGuid(),"Pre-shift",inspector,null),default); await service.StartAsync(tenant,inspection.Id,inspector,default);
        var updated=await service.SaveResponseAsync(tenant,inspection.Id,new(itemId,"Pass",null,null),default); Assert.Equal(100m,updated.CompletionPercent);
        var submitted=await service.SubmitAsync(tenant,inspection.Id,default); Assert.Equal(InspectionStatus.Submitted,submitted.Status);
    }

    private sealed class MemoryRepository : IInspectionRepository
    {
        private readonly Dictionary<Guid,InspectionTemplate> templates=new(); private readonly Dictionary<Guid,Inspection> inspections=new();
        public Task<InspectionTemplate> AddTemplateAsync(InspectionTemplate x,CancellationToken ct){templates[x.Id]=x;return Task.FromResult(x);} public Task<IReadOnlyList<InspectionTemplate>> ListTemplatesAsync(Guid tenantId,bool activeOnly,CancellationToken ct)=>Task.FromResult<IReadOnlyList<InspectionTemplate>>(templates.Values.Where(x=>x.TenantId==tenantId&&(!activeOnly||x.IsActive)).ToArray());
        public Task<Inspection> AddInspectionAsync(Inspection x,CancellationToken ct){inspections[x.Id]=x;return Task.FromResult(x);} public Task<Inspection?> GetInspectionAsync(Guid tenantId,Guid id,CancellationToken ct)=>Task.FromResult(inspections.TryGetValue(id,out var x)&&x.TenantId==tenantId?x:null); public Task<Inspection> UpdateInspectionAsync(Inspection x,CancellationToken ct){inspections[x.Id]=x;return Task.FromResult(x);} public Task<InspectionSearchResult> SearchAsync(Guid tenantId,InspectionSearchQuery q,CancellationToken ct){var x=inspections.Values.Where(i=>i.TenantId==tenantId).ToArray();return Task.FromResult(new InspectionSearchResult(x,x.Length,q.Limit,q.Offset));}
    }
}
