using Atlas.Api.Auth;
using Xunit;

namespace Atlas.Api.Tests.Auth;

public sealed class RefreshTokenServiceTests
{
    [Fact]
    public void Create_generates_unique_tokens_and_stable_hashes()
    {
        var service = new RefreshTokenService();
        var first = service.Create();
        var second = service.Create();

        Assert.NotEqual(first.PlainText, second.PlainText);
        Assert.NotEqual(first.Hash, second.Hash);
        Assert.Equal(first.Hash, service.Hash(first.PlainText));
        Assert.Equal(64, first.Hash.Length);
    }
}
