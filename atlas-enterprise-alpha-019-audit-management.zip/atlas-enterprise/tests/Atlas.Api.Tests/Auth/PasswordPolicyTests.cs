using Atlas.Api.Auth;
using Xunit;

namespace Atlas.Api.Tests.Auth;

public sealed class PasswordPolicyTests
{
    private readonly PasswordPolicy _policy = new();

    [Theory]
    [InlineData("")]
    [InlineData("short")]
    [InlineData("alllowercase1!")]
    [InlineData("ALLUPPERCASE1!")]
    [InlineData("NoNumbersHere!")]
    [InlineData("NoSymbolsHere1")]
    public void Rejects_weak_passwords(string password)
    {
        Assert.True(_policy.Validate(password).IsFailure);
    }

    [Fact]
    public void Accepts_strong_password()
    {
        Assert.True(_policy.Validate("AtlasSecure1!").IsSuccess);
    }
}
