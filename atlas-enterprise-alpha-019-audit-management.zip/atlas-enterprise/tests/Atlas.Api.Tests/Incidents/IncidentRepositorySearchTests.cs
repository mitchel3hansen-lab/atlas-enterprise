using Atlas.Api.Incidents;
using Xunit;

namespace Atlas.Api.Tests.Incidents;

public sealed class IncidentRepositorySearchTests
{
    [Fact]
    public async Task Search_is_tenant_scoped_and_filters_by_text_and_severity()
    {
        var repository = new InMemoryIncidentRepository();
        var tenant = Guid.NewGuid(); var otherTenant = Guid.NewGuid();
        await repository.AddAsync(Create(tenant, "Forklift contacted beam", IncidentSeverity.High), default);
        await repository.AddAsync(Create(tenant, "Minor paper cut", IncidentSeverity.Low), default);
        await repository.AddAsync(Create(otherTenant, "Forklift event outside tenant", IncidentSeverity.High), default);

        var query = new IncidentSearchQuery("forklift", null, IncidentSeverity.High, null, null, null, null, null, 50, 0);
        var results = await repository.SearchAsync(tenant, query, default);

        var incident = Assert.Single(results);
        Assert.Equal(tenant, incident.TenantId);
        Assert.Contains("Forklift", incident.Title);
    }

    [Fact]
    public async Task Sequence_is_monotonic_per_tenant_and_year()
    {
        var repository = new InMemoryIncidentRepository(); var tenant = Guid.NewGuid();
        Assert.Equal(1, await repository.NextSequenceAsync(tenant, 2026, default));
        Assert.Equal(2, await repository.NextSequenceAsync(tenant, 2026, default));
        Assert.Equal(1, await repository.NextSequenceAsync(tenant, 2027, default));
    }

    private static IncidentRecord Create(Guid tenant, string title, IncidentSeverity severity) => new(
        Guid.NewGuid(), tenant, $"INC-2026-{Guid.NewGuid().ToString()[..5]}", title, "Description", DateTimeOffset.UtcNow,
        Guid.NewGuid(), null, IncidentType.NearMiss, severity, IncidentStatus.Draft, null, Guid.NewGuid(), null, null, null, null, null, null, null,
        severity == IncidentSeverity.High ? 70 : 20, severity == IncidentSeverity.High, null, [], new Dictionary<string, System.Text.Json.JsonElement>(),
        DateTimeOffset.UtcNow, DateTimeOffset.UtcNow, 1);
}
