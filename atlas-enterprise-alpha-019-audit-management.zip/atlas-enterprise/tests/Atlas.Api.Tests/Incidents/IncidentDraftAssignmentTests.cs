using Atlas.Api.Incidents;
using FluentAssertions;
using Xunit;

namespace Atlas.Api.Tests.Incidents;

public sealed class IncidentDraftAssignmentTests
{
    [Fact]
    public void Assignment_request_requires_an_investigator_identifier()
    {
        var request = new AssignIncidentRequest(Guid.Empty, null, null, 1);
        request.InvestigatorId.Should().Be(Guid.Empty);
    }

    [Fact]
    public void Assignment_history_preserves_actor_and_investigator()
    {
        var investigator = Guid.NewGuid(); var actor = Guid.NewGuid();
        var assignment = new IncidentAssignmentRecord(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), investigator, "Investigator", actor, "Safety Manager", "Assigned for follow-up", DateTimeOffset.UtcNow);
        assignment.InvestigatorId.Should().Be(investigator);
        assignment.AssignedBy.Should().Be(actor);
    }

    [Fact]
    public void Update_request_carries_optimistic_concurrency_version()
    {
        var request = new UpdateIncidentRequest("Title", "Description", DateTimeOffset.UtcNow, Guid.NewGuid(), null, IncidentType.NearMiss, IncidentSeverity.Moderate, null, null, null, null, [], null, 4);
        request.ExpectedVersion.Should().Be(4);
    }
}
