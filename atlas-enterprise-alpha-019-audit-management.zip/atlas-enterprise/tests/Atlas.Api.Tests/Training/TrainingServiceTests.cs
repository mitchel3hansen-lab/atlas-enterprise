using Atlas.Api.Training;
using Xunit;
namespace Atlas.Api.Tests.Training;

public sealed class TrainingServiceTests
{
    [Fact] public async Task Completion_creates_qualified_competency()
    {
        var repo=new MemoryRepo(); var service=new TrainingService(repo); var tenant=Guid.NewGuid();
        var course=await service.CreateCourseAsync(tenant,new("PIT-101","Forklift",string.Empty,365,true,80),default);
        var assignment=await service.AssignAsync(tenant,Guid.NewGuid(),new(course.Id,Guid.NewGuid(),null,null,DateTimeOffset.UtcNow.AddDays(5)),default);
        var completed=await service.CompleteAsync(tenant,assignment.Id,new(92,"evidence://certificate"),default);
        Assert.Equal(AssignmentStatus.Completed,completed.Status); Assert.NotNull(repo.Competency); Assert.Equal(CompetencyStatus.Qualified,repo.Competency!.Status);
    }
    [Fact] public async Task Completion_rejects_failing_score()
    {
        var repo=new MemoryRepo(); var service=new TrainingService(repo); var tenant=Guid.NewGuid();
        var course=await service.CreateCourseAsync(tenant,new("LOTO-301","LOTO",string.Empty,365,true,80),default);
        var assignment=await service.AssignAsync(tenant,Guid.NewGuid(),new(course.Id,Guid.NewGuid(),null,null,DateTimeOffset.UtcNow.AddDays(5)),default);
        await Assert.ThrowsAsync<InvalidOperationException>(()=>service.CompleteAsync(tenant,assignment.Id,new(70,null),default));
    }
    private sealed class MemoryRepo:ITrainingRepository
    {
        public TrainingCourse? Course; public TrainingAssignment? Assignment; public CompetencyRecord? Competency;
        public Task<TrainingCourse> AddCourseAsync(TrainingCourse x,CancellationToken ct){Course=x;return Task.FromResult(x);} public Task<TrainingCourse?> GetCourseAsync(Guid t,Guid id,CancellationToken ct)=>Task.FromResult(Course?.Id==id?Course:null);
        public Task<TrainingAssignment> AddAssignmentAsync(TrainingAssignment x,CancellationToken ct){Assignment=x;return Task.FromResult(x);} public Task<TrainingAssignment?> GetAssignmentAsync(Guid t,Guid id,CancellationToken ct)=>Task.FromResult(Assignment?.Id==id?Assignment:null);
        public Task<TrainingAssignment> UpdateAssignmentAsync(TrainingAssignment x,CancellationToken ct){Assignment=x;return Task.FromResult(x);} public Task UpsertCompetencyAsync(CompetencyRecord x,CancellationToken ct){Competency=x;return Task.CompletedTask;}
        public Task<TrainingSearchResult> SearchAsync(Guid t,TrainingSearchQuery q,CancellationToken ct)=>Task.FromResult(new TrainingSearchResult([],0,q.Limit,q.Offset)); public Task<TrainingDashboard> DashboardAsync(Guid t,DateTimeOffset n,CancellationToken ct)=>Task.FromResult(new TrainingDashboard(0,0,0,0,0,0));
    }
}
