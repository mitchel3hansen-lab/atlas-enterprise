using Atlas.Api.Risks;
using Xunit;

namespace Atlas.Api.Tests.Risks;

public sealed class RiskServiceTests
{
    [Theory]
    [InlineData(1,1,"Low")]
    [InlineData(2,3,"Moderate")]
    [InlineData(2,5,"High")]
    [InlineData(4,5,"Critical")]
    public void Band_is_deterministic(int likelihood,int severity,string expected)
        => Assert.Equal(expected,RiskService.Band(likelihood*severity));

    [Fact]
    public async Task High_residual_risk_cannot_be_accepted()
    {
        var repo=new MemoryRiskRepository();
        var service=new RiskService(repo);
        var risk=await service.CreateAsync(Guid.NewGuid(),Guid.NewGuid(),new("Forklift traffic","",RiskAssessmentType.Hira,null,null,"Material movement","Pedestrian strike","Serious injury",4,4,Guid.NewGuid(),null),default);
        risk=await service.ActivateAsync(risk.TenantId,risk.Id,Guid.NewGuid(),default);
        await Assert.ThrowsAsync<InvalidOperationException>(()=>service.AcceptAsync(risk.TenantId,risk.Id,default));
    }

    private sealed class MemoryRiskRepository:IRiskRepository
    {
        private readonly Dictionary<Guid,RiskAssessment> data=[];
        public Task<string> NextNumberAsync(Guid t,CancellationToken ct)=>Task.FromResult("RSK-00001");
        public Task<RiskAssessment> AddAsync(RiskAssessment x,CancellationToken ct){data[x.Id]=x;return Task.FromResult(x);}
        public Task<RiskAssessment?> GetAsync(Guid t,Guid id,CancellationToken ct)=>Task.FromResult(data.GetValueOrDefault(id));
        public Task<RiskAssessment> UpdateAsync(RiskAssessment x,CancellationToken ct){data[x.Id]=x;return Task.FromResult(x);}
        public Task<RiskSearchResult> SearchAsync(Guid t,RiskSearchQuery q,CancellationToken ct)=>Task.FromResult(new RiskSearchResult(data.Values.ToArray(),data.Count,q.Limit,q.Offset));
        public Task<RiskDashboard> DashboardAsync(Guid t,DateTimeOffset n,CancellationToken ct)=>Task.FromResult(new RiskDashboard(0,0,0,0,0,0));
    }
}
