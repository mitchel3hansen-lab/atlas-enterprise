using Atlas.Api.CorrectiveActions;
using Xunit;

namespace Atlas.Api.Tests.CorrectiveActions;

public sealed class CorrectiveActionServiceTests
{
    private readonly Guid _tenant = Guid.NewGuid();
    private readonly Guid _owner = Guid.NewGuid();
    private readonly Guid _manager = Guid.NewGuid();

    [Fact]
    public async Task Create_Assigns_number_and_owner_state()
    {
        var repo = new FakeRepository();
        var service = new CorrectiveActionService(repo);
        var item = await service.CreateAsync(_tenant, _manager, new("Repair eyewash inspection process", "Implement a verified weekly check.", CorrectiveActionSourceType.Inspection, Guid.NewGuid(), CorrectiveActionPriority.High, Guid.NewGuid(), null, _owner, DateTimeOffset.UtcNow.AddDays(7)), default);
        Assert.Equal("CA-TEST-00001", item.Number);
        Assert.Equal(CorrectiveActionStatus.Assigned, item.Status);
        Assert.Equal(_owner, item.OwnerId);
        Assert.Equal(2, item.History.Count);
    }

    [Fact]
    public async Task Cannot_close_without_effective_verification()
    {
        var repo = new FakeRepository();
        var service = new CorrectiveActionService(repo);
        var item = await service.CreateAsync(_tenant, _manager, new("Guard repair", "Install and validate guarding.", CorrectiveActionSourceType.Incident, null, CorrectiveActionPriority.Critical, null, null, _owner, DateTimeOffset.UtcNow.AddDays(7)), default);
        await Assert.ThrowsAsync<InvalidOperationException>(() => service.CloseAsync(_tenant, item.Id, _manager, default));
    }

    [Fact]
    public async Task Full_lifecycle_requires_evidence_and_verification()
    {
        var repo = new FakeRepository();
        var service = new CorrectiveActionService(repo);
        var item = await service.CreateAsync(_tenant, _manager, new("Traffic flow redesign", "Increase aisle clearance and separate pedestrians.", CorrectiveActionSourceType.Investigation, Guid.NewGuid(), CorrectiveActionPriority.High, null, null, _owner, DateTimeOffset.UtcNow.AddDays(14)), default);
        item = await service.StartAsync(_tenant, item.Id, _owner, default);
        item = await service.SubmitEvidenceAsync(_tenant, item.Id, _owner, new(Guid.NewGuid(), "Photo", "Installed pedestrian barrier and aisle markings."), default);
        item = await service.RequestVerificationAsync(_tenant, item.Id, _manager, default);
        item = await service.VerifyAsync(_tenant, item.Id, _manager, new(VerificationOutcome.Effective, "Thirty-day observation found no repeat conflicts.", null), default);
        item = await service.CloseAsync(_tenant, item.Id, _manager, default);
        Assert.Equal(CorrectiveActionStatus.Closed, item.Status);
        Assert.NotNull(item.ClosedAt);
        Assert.Single(item.Evidence);
        Assert.Single(item.Verifications);
    }

    [Fact]
    public async Task Ineffective_verification_returns_action_to_rework_path()
    {
        var repo = new FakeRepository();
        var service = new CorrectiveActionService(repo);
        var item = await service.CreateAsync(_tenant, _manager, new("Retrain operators", "Complete focused training and field observation.", CorrectiveActionSourceType.NearMiss, null, CorrectiveActionPriority.Moderate, null, null, _owner, DateTimeOffset.UtcNow.AddDays(10)), default);
        item = await service.StartAsync(_tenant, item.Id, _owner, default);
        item = await service.SubmitEvidenceAsync(_tenant, item.Id, _owner, new(Guid.NewGuid(), "TrainingRecord", "All assigned operators completed training."), default);
        item = await service.RequestVerificationAsync(_tenant, item.Id, _manager, default);
        item = await service.VerifyAsync(_tenant, item.Id, _manager, new(VerificationOutcome.Ineffective, "Unsafe behavior recurred during verification.", DateTimeOffset.UtcNow.AddDays(7)), default);
        Assert.Equal(CorrectiveActionStatus.Ineffective, item.Status);
        item = await service.StartAsync(_tenant, item.Id, _owner, default);
        Assert.Equal(CorrectiveActionStatus.InProgress, item.Status);
    }

    private sealed class FakeRepository : ICorrectiveActionRepository
    {
        private readonly Dictionary<Guid, CorrectiveAction> _items = [];
        public Task<string> NextNumberAsync(Guid tenantId, CancellationToken ct) => Task.FromResult("CA-TEST-00001");
        public Task<CorrectiveAction> AddAsync(CorrectiveAction action, CancellationToken ct) { _items[action.Id] = action; return Task.FromResult(action); }
        public Task<CorrectiveAction?> GetAsync(Guid tenantId, Guid id, CancellationToken ct) => Task.FromResult(_items.GetValueOrDefault(id));
        public Task<CorrectiveAction> UpdateAsync(CorrectiveAction action, CancellationToken ct) { _items[action.Id] = action; return Task.FromResult(action); }
        public Task<CorrectiveActionSearchResult> SearchAsync(Guid tenantId, CorrectiveActionSearchQuery query, CancellationToken ct) => Task.FromResult(new CorrectiveActionSearchResult(_items.Values.ToArray(), _items.Count, query.Limit, query.Offset));
        public Task<CorrectiveActionDashboard> DashboardAsync(Guid tenantId, DateTimeOffset now, CancellationToken ct) => Task.FromResult(new CorrectiveActionDashboard(_items.Count, 0, 0, 0, 0, 0, 0));
    }
}
