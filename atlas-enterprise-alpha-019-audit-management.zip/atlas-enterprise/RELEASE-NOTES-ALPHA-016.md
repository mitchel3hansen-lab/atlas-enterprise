# Atlas Enterprise Alpha 0.16 Release Notes

Alpha 0.16 introduces Corrective Action Management, completing the core finding-to-verification improvement loop.

## Added
- Corrective action API, domain service, PostgreSQL repository, migration, and rollback.
- Creation, assignment, implementation, evidence submission, verification, closure, and rework workflows.
- CAPA dashboard and filtered search contract.
- Four least-privilege permissions for read, manage, execute, and verify operations.
- React corrective-action queue and effectiveness workspace.
- Lifecycle unit tests and architecture/product documentation.

## Guardrails
- Work cannot begin without an assigned owner.
- Verification cannot begin without submitted evidence.
- Closure requires an effective verification outcome.
- Ineffective actions cannot be closed and may be returned to implementation.
