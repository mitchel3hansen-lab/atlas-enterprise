# Atlas Manufacturing

Atlas Manufacturing is the first Atlas Enterprise product. Its initial vertical slice is Incident Management, followed by CAPA, inspections, JHA/HIRA, training, chemical inventory, PPE, operational health, risk, and executive reporting.
