BEGIN;

ALTER TABLE "Users"
    ADD COLUMN IF NOT EXISTS "FailedLoginCount" integer NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS "LockedUntilUtc" timestamptz NULL,
    ADD COLUMN IF NOT EXISTS "LastLoginAtUtc" timestamptz NULL,
    ADD COLUMN IF NOT EXISTS "PasswordChangedAtUtc" timestamptz NULL;

CREATE TABLE IF NOT EXISTS "RefreshSessions" (
    "Id" uuid PRIMARY KEY,
    "OrganizationId" uuid NOT NULL REFERENCES "Organizations"("Id") ON DELETE RESTRICT,
    "UserId" uuid NOT NULL REFERENCES "Users"("Id") ON DELETE RESTRICT,
    "MembershipId" uuid NOT NULL REFERENCES "OrganizationMemberships"("Id") ON DELETE RESTRICT,
    "TokenHash" varchar(64) NOT NULL UNIQUE,
    "JwtId" varchar(64) NOT NULL,
    "CreatedAtUtc" timestamptz NOT NULL,
    "ExpiresAtUtc" timestamptz NOT NULL,
    "LastUsedAtUtc" timestamptz NULL,
    "RevokedAtUtc" timestamptz NULL,
    "CreatedByIp" varchar(64) NOT NULL,
    "ReplacedByTokenHash" varchar(64) NULL
);

CREATE INDEX IF NOT EXISTS "IX_RefreshSessions_OrganizationId_UserId_RevokedAtUtc"
    ON "RefreshSessions" ("OrganizationId", "UserId", "RevokedAtUtc");
CREATE INDEX IF NOT EXISTS "IX_RefreshSessions_ExpiresAtUtc"
    ON "RefreshSessions" ("ExpiresAtUtc");
CREATE INDEX IF NOT EXISTS "IX_Users_LockedUntilUtc"
    ON "Users" ("LockedUntilUtc") WHERE "LockedUntilUtc" IS NOT NULL;

COMMIT;
