BEGIN;
DROP TABLE IF EXISTS "RefreshSessions";
ALTER TABLE "Users"
    DROP COLUMN IF EXISTS "FailedLoginCount",
    DROP COLUMN IF EXISTS "LockedUntilUtc",
    DROP COLUMN IF EXISTS "LastLoginAtUtc",
    DROP COLUMN IF EXISTS "PasswordChangedAtUtc";
COMMIT;
