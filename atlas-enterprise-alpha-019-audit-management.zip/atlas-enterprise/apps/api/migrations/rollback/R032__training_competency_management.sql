DELETE FROM atlas.permissions WHERE key IN ('training.read','training.manage','training.assign','training.complete');
DROP TABLE IF EXISTS atlas.competency_records;
DROP TABLE IF EXISTS atlas.training_assignments;
DROP TABLE IF EXISTS atlas.training_courses;
