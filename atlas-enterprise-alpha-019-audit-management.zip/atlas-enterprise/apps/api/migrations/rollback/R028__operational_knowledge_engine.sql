BEGIN;
DROP FUNCTION IF EXISTS atlas.find_similar_operational_records(uuid,text,uuid,int);
DROP TABLE IF EXISTS atlas.lessons_learned;
COMMIT;
