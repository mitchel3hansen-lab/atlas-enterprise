delete from permissions where code in ('audits.read','audits.manage','audits.execute','audits.verify');
drop table if exists audit_findings;
drop table if exists audits;
drop type if exists audit_finding_status;
drop type if exists audit_finding_severity;
drop type if exists audit_status;
drop type if exists audit_type;
