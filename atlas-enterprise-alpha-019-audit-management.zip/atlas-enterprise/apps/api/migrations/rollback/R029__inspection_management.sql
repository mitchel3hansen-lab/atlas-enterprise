DROP TABLE IF EXISTS atlas.inspections;
DROP TABLE IF EXISTS atlas.inspection_templates;
