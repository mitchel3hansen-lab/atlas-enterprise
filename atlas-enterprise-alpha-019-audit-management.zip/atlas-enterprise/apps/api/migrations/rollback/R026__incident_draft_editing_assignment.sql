BEGIN;
DROP TABLE IF EXISTS atlas.incident_assignments;
ALTER TABLE atlas.incidents DROP COLUMN IF EXISTS assigned_by, DROP COLUMN IF EXISTS assigned_at, DROP COLUMN IF EXISTS assignee_display_name;
COMMIT;
