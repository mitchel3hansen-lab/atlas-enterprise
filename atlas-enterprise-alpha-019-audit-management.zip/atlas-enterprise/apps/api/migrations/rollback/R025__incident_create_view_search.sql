DROP INDEX IF EXISTS atlas.ix_incidents_tenant_department;
DROP INDEX IF EXISTS atlas.ix_incidents_tenant_type;
DROP INDEX IF EXISTS atlas.ix_incidents_search_document;
ALTER TABLE atlas.incidents DROP COLUMN IF EXISTS search_document;
ALTER TABLE atlas.incidents DROP COLUMN IF EXISTS immediate_actions;
ALTER TABLE atlas.incidents DROP COLUMN IF EXISTS incident_type;
ALTER TABLE atlas.incidents DROP COLUMN IF EXISTS department_id;
DROP TABLE IF EXISTS atlas.incident_number_sequences;
