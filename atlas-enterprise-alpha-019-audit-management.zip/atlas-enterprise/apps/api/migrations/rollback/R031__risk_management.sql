DROP TABLE IF EXISTS atlas.risk_assessments;
