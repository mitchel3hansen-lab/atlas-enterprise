DROP TABLE IF EXISTS atlas.incidents;
