create type audit_type as enum ('Internal','Regulatory','Customer','Supplier','Certification');
create type audit_status as enum ('Draft','Scheduled','InProgress','PendingReview','Closed','Cancelled');
create type audit_finding_severity as enum ('Observation','Minor','Major','Critical');
create type audit_finding_status as enum ('Open','ActionAssigned','PendingVerification','Closed');
create table audits(
 id uuid primary key, tenant_id uuid not null, number text not null, title text not null,
 type audit_type not null, facility_id uuid null, department_id uuid null, lead_auditor_id uuid not null,
 planned_start timestamptz not null, planned_end timestamptz not null, status audit_status not null,
 score int not null default 0 check(score between 0 and 100), created_at timestamptz not null,
 updated_at timestamptz not null, version bigint not null default 1,
 unique(tenant_id,number), check(planned_end>planned_start));
create index ix_audits_tenant_status on audits(tenant_id,status);
create index ix_audits_tenant_facility on audits(tenant_id,facility_id);
create table audit_findings(
 id uuid primary key, tenant_id uuid not null, audit_id uuid not null references audits(id) on delete cascade,
 reference text not null, requirement text not null, description text not null,
 severity audit_finding_severity not null, status audit_finding_status not null,
 corrective_action_id uuid null, due_at timestamptz not null, created_at timestamptz not null,
 updated_at timestamptz not null, version bigint not null default 1);
create index ix_audit_findings_tenant_audit on audit_findings(tenant_id,audit_id);
create index ix_audit_findings_open_due on audit_findings(tenant_id,due_at) where status<>'Closed';
insert into permissions(code,description) values
 ('audits.read','View audits and findings'),('audits.manage','Create and administer audits'),
 ('audits.execute','Execute audits and document findings'),('audits.verify','Review and close audits')
on conflict(code) do nothing;
