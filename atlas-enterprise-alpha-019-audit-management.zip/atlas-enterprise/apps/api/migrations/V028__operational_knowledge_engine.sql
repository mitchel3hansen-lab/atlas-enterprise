BEGIN;

CREATE TABLE IF NOT EXISTS atlas.lessons_learned (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    organization_id uuid NULL,
    title varchar(240) NOT NULL,
    summary text NOT NULL,
    root_cause text NOT NULL,
    effective_controls jsonb NOT NULL DEFAULT '[]'::jsonb,
    applicable_object_types jsonb NOT NULL DEFAULT '[]'::jsonb,
    source_object_ids uuid[] NOT NULL DEFAULT '{}',
    status varchar(30) NOT NULL CHECK (status IN ('Draft','Published','Retired')),
    created_by uuid NOT NULL,
    created_at timestamptz NOT NULL,
    updated_at timestamptz NOT NULL,
    version bigint NOT NULL DEFAULT 1,
    search_document tsvector GENERATED ALWAYS AS (
        to_tsvector('simple', coalesce(title,'') || ' ' || coalesce(summary,'') || ' ' || coalesce(root_cause,''))
    ) STORED
);
CREATE INDEX IF NOT EXISTS ix_lessons_tenant_status ON atlas.lessons_learned(tenant_id,status,updated_at DESC);
CREATE INDEX IF NOT EXISTS ix_lessons_search ON atlas.lessons_learned USING gin(search_document);
CREATE INDEX IF NOT EXISTS ix_lessons_sources ON atlas.lessons_learned USING gin(source_object_ids);
CREATE INDEX IF NOT EXISTS ix_lessons_object_types ON atlas.lessons_learned USING gin(applicable_object_types);

CREATE OR REPLACE FUNCTION atlas.find_similar_operational_records(
    p_tenant uuid, p_object_type text, p_object_id uuid, p_limit int DEFAULT 8)
RETURNS TABLE(candidate_object_id uuid, candidate_object_type text, candidate_display_name text,
    similarity numeric, shared_signals jsonb, supporting_evidence_ids uuid[])
LANGUAGE sql STABLE AS $$
WITH root AS (
  SELECT id FROM atlas.knowledge_nodes
  WHERE tenant_id=p_tenant AND object_type=p_object_type AND object_id=p_object_id
  LIMIT 1
), root_neighbors AS (
  SELECT CASE WHEN e.source_node_id=r.id THEN e.target_node_id ELSE e.source_node_id END AS node_id,
         e.relationship_type_id, e.evidence_ids
  FROM root r JOIN atlas.knowledge_edges e
    ON e.tenant_id=p_tenant AND (e.source_node_id=r.id OR e.target_node_id=r.id) AND e.valid_to IS NULL
), candidates AS (
  SELECT n.object_id,n.object_type,n.display_name,
         count(*)::numeric AS shared_count,
         jsonb_agg(DISTINCT rt.code) AS signals,
         array_agg(DISTINCT ev) FILTER (WHERE ev IS NOT NULL) AS evidence
  FROM root_neighbors rn
  JOIN atlas.knowledge_edges e ON e.tenant_id=p_tenant AND (e.source_node_id=rn.node_id OR e.target_node_id=rn.node_id) AND e.valid_to IS NULL
  JOIN atlas.knowledge_nodes n ON n.tenant_id=p_tenant AND n.id=CASE WHEN e.source_node_id=rn.node_id THEN e.target_node_id ELSE e.source_node_id END
  LEFT JOIN atlas.relationship_types rt ON rt.id=e.relationship_type_id
  LEFT JOIN LATERAL unnest(e.evidence_ids) ev ON true
  WHERE NOT (n.object_type=p_object_type AND n.object_id=p_object_id)
  GROUP BY n.object_id,n.object_type,n.display_name
)
SELECT object_id,object_type,display_name,least(0.99,0.45 + shared_count*0.12)::numeric(4,3),
       coalesce(signals,'[]'::jsonb),coalesce(evidence,'{}'::uuid[])
FROM candidates ORDER BY shared_count DESC,display_name LIMIT greatest(1,least(p_limit,25));
$$;

COMMIT;
