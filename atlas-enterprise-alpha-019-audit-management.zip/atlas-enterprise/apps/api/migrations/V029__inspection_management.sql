CREATE TABLE IF NOT EXISTS atlas.inspection_templates (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    description text NOT NULL DEFAULT '',
    category text NOT NULL DEFAULT 'General',
    items jsonb NOT NULL DEFAULT '[]'::jsonb,
    is_active boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL,
    updated_at timestamptz NOT NULL,
    version bigint NOT NULL DEFAULT 1,
    CONSTRAINT uq_inspection_template_name UNIQUE(tenant_id,name)
);

CREATE TABLE IF NOT EXISTS atlas.inspections (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    template_id uuid NOT NULL REFERENCES atlas.inspection_templates(id),
    facility_id uuid NOT NULL,
    title text NOT NULL,
    status text NOT NULL CHECK(status IN ('Draft','Scheduled','InProgress','Submitted','Closed','Cancelled')),
    inspector_id uuid NOT NULL,
    scheduled_for timestamptz NULL,
    started_at timestamptz NULL,
    submitted_at timestamptz NULL,
    responses jsonb NOT NULL DEFAULT '[]'::jsonb,
    findings jsonb NOT NULL DEFAULT '[]'::jsonb,
    completion_percent numeric(5,1) NOT NULL DEFAULT 0 CHECK(completion_percent BETWEEN 0 AND 100),
    created_at timestamptz NOT NULL,
    updated_at timestamptz NOT NULL,
    version bigint NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS ix_inspections_tenant_status ON atlas.inspections(tenant_id,status);
CREATE INDEX IF NOT EXISTS ix_inspections_tenant_facility ON atlas.inspections(tenant_id,facility_id);
CREATE INDEX IF NOT EXISTS ix_inspections_tenant_inspector ON atlas.inspections(tenant_id,inspector_id);
CREATE INDEX IF NOT EXISTS ix_inspections_schedule ON atlas.inspections(tenant_id,scheduled_for DESC);
