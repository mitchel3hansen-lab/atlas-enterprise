CREATE SCHEMA IF NOT EXISTS atlas;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS atlas.incidents (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    incident_number varchar(32) NOT NULL,
    title varchar(200) NOT NULL,
    description text NOT NULL,
    occurred_at timestamptz NOT NULL,
    facility_id uuid NOT NULL,
    severity varchar(20) NOT NULL,
    status varchar(30) NOT NULL,
    reporter_id uuid NULL,
    assignee_id uuid NULL,
    employee_id uuid NULL,
    equipment_id uuid NULL,
    chemical_id uuid NULL,
    risk_score integer NOT NULL CHECK (risk_score BETWEEN 0 AND 100),
    capa_required boolean NOT NULL DEFAULT false,
    capa_id uuid NULL,
    tags text[] NOT NULL DEFAULT '{}',
    metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version bigint NOT NULL DEFAULT 1,
    CONSTRAINT uq_atlas_incidents_number UNIQUE (tenant_id, incident_number)
);
CREATE INDEX IF NOT EXISTS ix_atlas_incidents_tenant_status ON atlas.incidents (tenant_id, status);
CREATE INDEX IF NOT EXISTS ix_atlas_incidents_tenant_occurred ON atlas.incidents (tenant_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS ix_atlas_incidents_facility ON atlas.incidents (tenant_id, facility_id);
ALTER TABLE atlas.incidents ENABLE ROW LEVEL SECURITY;
