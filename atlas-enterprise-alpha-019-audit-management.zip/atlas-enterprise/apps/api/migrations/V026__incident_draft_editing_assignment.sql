BEGIN;

ALTER TABLE atlas.incidents
  ADD COLUMN IF NOT EXISTS assignee_display_name text NULL,
  ADD COLUMN IF NOT EXISTS assigned_at timestamptz NULL,
  ADD COLUMN IF NOT EXISTS assigned_by uuid NULL;

CREATE TABLE IF NOT EXISTS atlas.incident_assignments (
  id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  incident_id uuid NOT NULL REFERENCES atlas.incidents(id) ON DELETE CASCADE,
  investigator_id uuid NOT NULL,
  investigator_display_name text NULL,
  assigned_by uuid NOT NULL,
  assigned_by_display_name text NULL,
  comment text NULL,
  assigned_at timestamptz NOT NULL
);

CREATE INDEX IF NOT EXISTS ix_incident_assignments_tenant_incident_time
  ON atlas.incident_assignments(tenant_id, incident_id, assigned_at DESC);

COMMIT;
