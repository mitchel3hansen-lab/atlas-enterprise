CREATE TABLE atlas.training_courses(
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, code varchar(50) NOT NULL, title varchar(200) NOT NULL,
 description text NOT NULL DEFAULT '', status varchar(30) NOT NULL, valid_for_days integer NOT NULL DEFAULT 0,
 requires_assessment boolean NOT NULL DEFAULT false, passing_score integer NOT NULL DEFAULT 0,
 created_at timestamptz NOT NULL, updated_at timestamptz NOT NULL, version bigint NOT NULL DEFAULT 1,
 UNIQUE(tenant_id,code), CHECK(passing_score BETWEEN 0 AND 100));
CREATE TABLE atlas.training_assignments(
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, course_id uuid NOT NULL REFERENCES atlas.training_courses(id), user_id uuid NOT NULL,
 facility_id uuid NULL, department_id uuid NULL, status varchar(30) NOT NULL, assigned_at timestamptz NOT NULL,
 due_at timestamptz NOT NULL, completed_at timestamptz NULL, score integer NULL, evidence_reference text NULL,
 assigned_by uuid NOT NULL, updated_at timestamptz NOT NULL, version bigint NOT NULL DEFAULT 1,
 CHECK(score IS NULL OR score BETWEEN 0 AND 100));
CREATE TABLE atlas.competency_records(
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, user_id uuid NOT NULL, course_id uuid NOT NULL REFERENCES atlas.training_courses(id),
 status varchar(30) NOT NULL, qualified_at timestamptz NULL, expires_at timestamptz NULL, score integer NULL,
 evidence_reference text NULL, updated_at timestamptz NOT NULL, version bigint NOT NULL DEFAULT 1,
 UNIQUE(tenant_id,user_id,course_id));
CREATE INDEX ix_training_assignments_tenant_status_due ON atlas.training_assignments(tenant_id,status,due_at);
CREATE INDEX ix_competency_records_tenant_expiry ON atlas.competency_records(tenant_id,expires_at);
INSERT INTO atlas.permissions(key,description) VALUES
 ('training.read','View training and competency records'),('training.manage','Manage training courses'),
 ('training.assign','Assign required training'),('training.complete','Record training completion')
ON CONFLICT(key) DO NOTHING;
