CREATE SCHEMA IF NOT EXISTS atlas;

CREATE TABLE IF NOT EXISTS atlas.corrective_action_counters (
    tenant_id uuid PRIMARY KEY,
    last_value bigint NOT NULL DEFAULT 0
);

CREATE OR REPLACE FUNCTION atlas.next_corrective_action_number(p_tenant uuid)
RETURNS text LANGUAGE plpgsql AS $$
DECLARE next_value bigint;
BEGIN
    INSERT INTO atlas.corrective_action_counters(tenant_id,last_value)
    VALUES(p_tenant,1)
    ON CONFLICT(tenant_id) DO UPDATE SET last_value=atlas.corrective_action_counters.last_value+1
    RETURNING last_value INTO next_value;
    RETURN 'CA-' || to_char(current_date,'YYYY') || '-' || lpad(next_value::text,5,'0');
END;
$$;

CREATE TABLE IF NOT EXISTS atlas.corrective_actions (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    number varchar(32) NOT NULL,
    title varchar(250) NOT NULL,
    description text NOT NULL,
    source_type varchar(50) NOT NULL,
    source_id uuid NULL,
    priority varchar(20) NOT NULL,
    status varchar(40) NOT NULL,
    facility_id uuid NULL,
    department_id uuid NULL,
    owner_id uuid NULL,
    created_by uuid NOT NULL,
    due_at timestamptz NULL,
    implemented_at timestamptz NULL,
    closed_at timestamptz NULL,
    evidence jsonb NOT NULL DEFAULT '[]'::jsonb,
    verifications jsonb NOT NULL DEFAULT '[]'::jsonb,
    history jsonb NOT NULL DEFAULT '[]'::jsonb,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('english',coalesce(number,'') || ' ' || coalesce(title,'') || ' ' || coalesce(description,''))) STORED,
    created_at timestamptz NOT NULL,
    updated_at timestamptz NOT NULL,
    version bigint NOT NULL DEFAULT 1,
    CONSTRAINT uq_corrective_actions_tenant_number UNIQUE(tenant_id,number),
    CONSTRAINT ck_corrective_action_priority CHECK(priority IN ('Low','Moderate','High','Critical')),
    CONSTRAINT ck_corrective_action_status CHECK(status IN ('Draft','Assigned','InProgress','EvidenceSubmitted','PendingVerification','Effective','Ineffective','Closed','Cancelled'))
);

CREATE INDEX IF NOT EXISTS ix_corrective_actions_tenant_status ON atlas.corrective_actions(tenant_id,status);
CREATE INDEX IF NOT EXISTS ix_corrective_actions_tenant_owner ON atlas.corrective_actions(tenant_id,owner_id);
CREATE INDEX IF NOT EXISTS ix_corrective_actions_tenant_due ON atlas.corrective_actions(tenant_id,due_at) WHERE status NOT IN ('Closed','Cancelled');
CREATE INDEX IF NOT EXISTS ix_corrective_actions_search ON atlas.corrective_actions USING gin(search_vector);

INSERT INTO atlas.permissions(id,code,description)
VALUES
(gen_random_uuid(),'corrective_actions.read','View corrective and preventive actions'),
(gen_random_uuid(),'corrective_actions.manage','Create, assign, and close corrective actions'),
(gen_random_uuid(),'corrective_actions.execute','Implement corrective actions and submit evidence'),
(gen_random_uuid(),'corrective_actions.verify','Perform independent effectiveness verification')
ON CONFLICT(code) DO NOTHING;
