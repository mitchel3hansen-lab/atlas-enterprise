CREATE SCHEMA IF NOT EXISTS atlas;
CREATE TABLE IF NOT EXISTS atlas.risk_assessments (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, number varchar(32) NOT NULL, title varchar(240) NOT NULL,
 description text NOT NULL DEFAULT '', assessment_type varchar(32) NOT NULL, status varchar(32) NOT NULL,
 facility_id uuid NULL, department_id uuid NULL, activity varchar(500) NOT NULL DEFAULT '', hazard varchar(500) NOT NULL,
 potential_consequence text NOT NULL DEFAULT '', inherent_likelihood int NOT NULL CHECK(inherent_likelihood BETWEEN 1 AND 5),
 inherent_severity int NOT NULL CHECK(inherent_severity BETWEEN 1 AND 5), inherent_score int NOT NULL,
 residual_likelihood int NOT NULL CHECK(residual_likelihood BETWEEN 1 AND 5), residual_severity int NOT NULL CHECK(residual_severity BETWEEN 1 AND 5),
 residual_score int NOT NULL, risk_band varchar(16) NOT NULL, owner_id uuid NOT NULL, review_due_at timestamptz NULL,
 controls jsonb NOT NULL DEFAULT '[]', reviews jsonb NOT NULL DEFAULT '[]', created_at timestamptz NOT NULL,
 updated_at timestamptz NOT NULL, version bigint NOT NULL DEFAULT 1,
 search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple',coalesce(title,'')||' '||coalesce(activity,'')||' '||coalesce(hazard,'')||' '||coalesce(potential_consequence,''))) STORED,
 UNIQUE(tenant_id,number)
);
CREATE INDEX IF NOT EXISTS ix_risk_tenant_status ON atlas.risk_assessments(tenant_id,status);
CREATE INDEX IF NOT EXISTS ix_risk_tenant_score ON atlas.risk_assessments(tenant_id,residual_score DESC);
CREATE INDEX IF NOT EXISTS ix_risk_search ON atlas.risk_assessments USING gin(search_vector);
