CREATE TABLE IF NOT EXISTS atlas.incident_number_sequences (
    tenant_id uuid NOT NULL,
    incident_year integer NOT NULL,
    next_incident_number integer NOT NULL CHECK (next_incident_number > 0),
    PRIMARY KEY (tenant_id, incident_year)
);

ALTER TABLE atlas.incidents ADD COLUMN IF NOT EXISTS department_id uuid NULL;
ALTER TABLE atlas.incidents ADD COLUMN IF NOT EXISTS incident_type varchar(40) NOT NULL DEFAULT 'Other';
ALTER TABLE atlas.incidents ADD COLUMN IF NOT EXISTS immediate_actions text NULL;
ALTER TABLE atlas.incidents ADD COLUMN IF NOT EXISTS search_document tsvector
    GENERATED ALWAYS AS (to_tsvector('simple', coalesce(incident_number,'') || ' ' || coalesce(title,'') || ' ' || coalesce(description,''))) STORED;

CREATE INDEX IF NOT EXISTS ix_incidents_search_document ON atlas.incidents USING gin(search_document);
CREATE INDEX IF NOT EXISTS ix_incidents_tenant_type ON atlas.incidents(tenant_id, incident_type);
CREATE INDEX IF NOT EXISTS ix_incidents_tenant_department ON atlas.incidents(tenant_id, department_id) WHERE department_id IS NOT NULL;
