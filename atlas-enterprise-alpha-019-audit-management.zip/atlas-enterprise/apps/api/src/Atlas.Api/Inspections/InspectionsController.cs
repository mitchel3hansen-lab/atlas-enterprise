using System.Security.Claims;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Atlas.Api.Inspections;

[ApiController]
[Route("api/v1/inspections")]
[Authorize]
public sealed class InspectionsController(InspectionService service, TenantContext tenantContext) : ControllerBase
{
    [HttpGet("templates")]
    [Authorize(Policy = AtlasPermissions.InspectionsRead)]
    public async Task<ActionResult<IReadOnlyList<InspectionTemplate>>> Templates([FromQuery] bool activeOnly = true, CancellationToken ct = default)
        => Ok(await service.ListTemplatesAsync(tenantContext.TenantId, activeOnly, ct));

    [HttpPost("templates")]
    [Authorize(Policy = AtlasPermissions.InspectionsManage)]
    public async Task<ActionResult<InspectionTemplate>> CreateTemplate(CreateInspectionTemplateRequest request, CancellationToken ct)
    {
        var created = await service.CreateTemplateAsync(tenantContext.TenantId, request, ct);
        return Created($"api/v1/inspections/templates/{created.Id}", created);
    }

    [HttpGet]
    [Authorize(Policy = AtlasPermissions.InspectionsRead)]
    public async Task<ActionResult<InspectionSearchResult>> Search([FromQuery] Guid? facilityId = null, [FromQuery] InspectionStatus? status = null, [FromQuery] Guid? inspectorId = null, [FromQuery] DateTimeOffset? from = null, [FromQuery] DateTimeOffset? to = null, [FromQuery] int limit = 50, [FromQuery] int offset = 0, CancellationToken ct = default)
        => Ok(await service.SearchAsync(tenantContext.TenantId, new(facilityId, status, inspectorId, from, to, limit, offset), ct));

    [HttpGet("{id:guid}")]
    [Authorize(Policy = AtlasPermissions.InspectionsRead)]
    public async Task<ActionResult<Inspection>> Get(Guid id, CancellationToken ct)
        => await service.GetAsync(tenantContext.TenantId, id, ct) is { } item ? Ok(item) : NotFound();

    [HttpPost]
    [Authorize(Policy = AtlasPermissions.InspectionsManage)]
    public async Task<ActionResult<Inspection>> Schedule(ScheduleInspectionRequest request, CancellationToken ct)
    {
        var created = await service.ScheduleAsync(tenantContext.TenantId, request, ct);
        return CreatedAtAction(nameof(Get), new { id = created.Id }, created);
    }

    [HttpPost("{id:guid}/start")]
    [Authorize(Policy = AtlasPermissions.InspectionsExecute)]
    public async Task<ActionResult<Inspection>> Start(Guid id, CancellationToken ct) => Ok(await service.StartAsync(tenantContext.TenantId, id, ActorId(), ct));

    [HttpPut("{id:guid}/responses/{itemId:guid}")]
    [Authorize(Policy = AtlasPermissions.InspectionsExecute)]
    public async Task<ActionResult<Inspection>> SaveResponse(Guid id, Guid itemId, SaveInspectionResponseRequest request, CancellationToken ct)
        => Ok(await service.SaveResponseAsync(tenantContext.TenantId, id, request with { ItemId = itemId }, ct));

    [HttpPost("{id:guid}/findings")]
    [Authorize(Policy = AtlasPermissions.InspectionsExecute)]
    public async Task<ActionResult<Inspection>> AddFinding(Guid id, CreateFindingRequest request, CancellationToken ct)
        => Ok(await service.AddFindingAsync(tenantContext.TenantId, id, request, ct));

    [HttpPost("{id:guid}/submit")]
    [Authorize(Policy = AtlasPermissions.InspectionsExecute)]
    public async Task<ActionResult<Inspection>> Submit(Guid id, CancellationToken ct) => Ok(await service.SubmitAsync(tenantContext.TenantId, id, ct));

    [HttpPost("{id:guid}/close")]
    [Authorize(Policy = AtlasPermissions.InspectionsManage)]
    public async Task<ActionResult<Inspection>> Close(Guid id, CancellationToken ct) => Ok(await service.CloseAsync(tenantContext.TenantId, id, ct));

    private Guid ActorId(){var raw=User.FindFirstValue(ClaimTypes.NameIdentifier)??User.FindFirstValue("sub");return Guid.TryParse(raw,out var id)?id:Guid.Empty;}
}
