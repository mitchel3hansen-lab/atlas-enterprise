namespace Atlas.Api.Inspections;

public sealed class InspectionService(IInspectionRepository repository)
{
    private static readonly HashSet<string> AllowedResults = new(StringComparer.OrdinalIgnoreCase)
    { "Pass", "Fail", "NotApplicable", "Observation" };

    public Task<IReadOnlyList<InspectionTemplate>> ListTemplatesAsync(Guid tenantId, bool activeOnly, CancellationToken ct)
        => repository.ListTemplatesAsync(tenantId, activeOnly, ct);

    public async Task<InspectionTemplate> CreateTemplateAsync(Guid tenantId, CreateInspectionTemplateRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Name)) throw new ArgumentException("Template name is required.");
        if (request.Items.Count == 0) throw new ArgumentException("At least one inspection item is required.");
        if (request.Items.Select(x => x.Id).Distinct().Count() != request.Items.Count) throw new ArgumentException("Inspection item identifiers must be unique.");
        var now = DateTimeOffset.UtcNow;
        return await repository.AddTemplateAsync(new(Guid.NewGuid(), tenantId, request.Name.Trim(), request.Description.Trim(), request.Category.Trim(), request.Items.OrderBy(x => x.SortOrder).ToArray(), true, now, now, 1), ct);
    }

    public async Task<Inspection> ScheduleAsync(Guid tenantId, ScheduleInspectionRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Title)) throw new ArgumentException("Inspection title is required.");
        var now = DateTimeOffset.UtcNow;
        var status = request.ScheduledFor is null || request.ScheduledFor <= now ? InspectionStatus.Draft : InspectionStatus.Scheduled;
        return await repository.AddInspectionAsync(new(Guid.NewGuid(), tenantId, request.TemplateId, request.FacilityId, request.Title.Trim(), status, request.InspectorId, request.ScheduledFor, null, null, Array.Empty<InspectionResponse>(), Array.Empty<InspectionFinding>(), 0m, now, now, 1), ct);
    }

    public Task<Inspection?> GetAsync(Guid tenantId, Guid id, CancellationToken ct) => repository.GetInspectionAsync(tenantId, id, ct);
    public Task<InspectionSearchResult> SearchAsync(Guid tenantId, InspectionSearchQuery query, CancellationToken ct)
        => repository.SearchAsync(tenantId, query with { Limit = Math.Clamp(query.Limit, 1, 200), Offset = Math.Max(0, query.Offset) }, ct);

    public async Task<Inspection> StartAsync(Guid tenantId, Guid inspectionId, Guid actorId, CancellationToken ct)
    {
        var inspection = await RequireAsync(tenantId, inspectionId, ct);
        if (inspection.InspectorId != actorId && actorId != Guid.Empty) throw new InvalidOperationException("Only the assigned inspector may start this inspection.");
        if (inspection.Status is not (InspectionStatus.Draft or InspectionStatus.Scheduled)) throw new InvalidOperationException("Inspection cannot be started from its current status.");
        return await repository.UpdateInspectionAsync(inspection with { Status = InspectionStatus.InProgress, StartedAt = DateTimeOffset.UtcNow, UpdatedAt = DateTimeOffset.UtcNow, Version = inspection.Version + 1 }, ct);
    }

    public async Task<Inspection> SaveResponseAsync(Guid tenantId, Guid inspectionId, SaveInspectionResponseRequest request, CancellationToken ct)
    {
        var inspection = await RequireAsync(tenantId, inspectionId, ct);
        if (inspection.Status != InspectionStatus.InProgress) throw new InvalidOperationException("Responses can only be saved while an inspection is in progress.");
        if (!AllowedResults.Contains(request.Result)) throw new ArgumentException("Result must be Pass, Fail, NotApplicable, or Observation.");
        var responses = inspection.Responses.Where(x => x.ItemId != request.ItemId).Append(new(request.ItemId, request.Result, request.Notes?.Trim(), request.EvidenceIds ?? Array.Empty<Guid>())).ToArray();
        var templates = await repository.ListTemplatesAsync(tenantId, false, ct);
        var template = templates.SingleOrDefault(x => x.Id == inspection.TemplateId) ?? throw new InvalidOperationException("Inspection template was not found.");
        var completion = template.Items.Count == 0 ? 0 : Math.Round((decimal)responses.Select(x => x.ItemId).Distinct().Count() / template.Items.Count * 100m, 1);
        return await repository.UpdateInspectionAsync(inspection with { Responses = responses, CompletionPercent = Math.Min(100, completion), UpdatedAt = DateTimeOffset.UtcNow, Version = inspection.Version + 1 }, ct);
    }

    public async Task<Inspection> AddFindingAsync(Guid tenantId, Guid inspectionId, CreateFindingRequest request, CancellationToken ct)
    {
        var inspection = await RequireAsync(tenantId, inspectionId, ct);
        if (inspection.Status is InspectionStatus.Closed or InspectionStatus.Cancelled) throw new InvalidOperationException("Findings cannot be added to a closed inspection.");
        if (string.IsNullOrWhiteSpace(request.Title)) throw new ArgumentException("Finding title is required.");
        var now = DateTimeOffset.UtcNow;
        var finding = new InspectionFinding(Guid.NewGuid(), inspectionId, request.Title.Trim(), request.Description.Trim(), request.Severity, request.AssignedTo is null ? FindingStatus.Open : FindingStatus.ActionAssigned, request.AssignedTo, request.DueAt, null, now, now);
        return await repository.UpdateInspectionAsync(inspection with { Findings = inspection.Findings.Append(finding).ToArray(), UpdatedAt = now, Version = inspection.Version + 1 }, ct);
    }

    public async Task<Inspection> SubmitAsync(Guid tenantId, Guid inspectionId, CancellationToken ct)
    {
        var inspection = await RequireAsync(tenantId, inspectionId, ct);
        if (inspection.Status != InspectionStatus.InProgress) throw new InvalidOperationException("Only in-progress inspections may be submitted.");
        if (inspection.CompletionPercent < 100m) throw new InvalidOperationException("All inspection items must be answered before submission.");
        var now = DateTimeOffset.UtcNow;
        return await repository.UpdateInspectionAsync(inspection with { Status = InspectionStatus.Submitted, SubmittedAt = now, UpdatedAt = now, Version = inspection.Version + 1 }, ct);
    }

    public async Task<Inspection> CloseAsync(Guid tenantId, Guid inspectionId, CancellationToken ct)
    {
        var inspection = await RequireAsync(tenantId, inspectionId, ct);
        if (inspection.Status != InspectionStatus.Submitted) throw new InvalidOperationException("Only submitted inspections may be closed.");
        if (inspection.Findings.Any(x => x.Status is FindingStatus.Open or FindingStatus.ActionAssigned)) throw new InvalidOperationException("Open findings must be resolved or formally accepted before closure.");
        return await repository.UpdateInspectionAsync(inspection with { Status = InspectionStatus.Closed, UpdatedAt = DateTimeOffset.UtcNow, Version = inspection.Version + 1 }, ct);
    }

    private async Task<Inspection> RequireAsync(Guid tenantId, Guid id, CancellationToken ct)
        => await repository.GetInspectionAsync(tenantId, id, ct) ?? throw new KeyNotFoundException("Inspection was not found.");
}
