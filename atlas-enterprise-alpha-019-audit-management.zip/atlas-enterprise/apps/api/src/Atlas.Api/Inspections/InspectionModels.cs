namespace Atlas.Api.Inspections;

public enum InspectionStatus { Draft, Scheduled, InProgress, Submitted, Closed, Cancelled }
public enum FindingSeverity { Observation, Low, Moderate, High, Critical }
public enum FindingStatus { Open, ActionAssigned, Verified, Closed }

public sealed record InspectionTemplateItem(
    Guid Id,
    string Section,
    string Prompt,
    bool Required,
    string? RegulatoryReference,
    int SortOrder);

public sealed record InspectionTemplate(
    Guid Id,
    Guid TenantId,
    string Name,
    string Description,
    string Category,
    IReadOnlyList<InspectionTemplateItem> Items,
    bool IsActive,
    DateTimeOffset CreatedAt,
    DateTimeOffset UpdatedAt,
    long Version);

public sealed record InspectionResponse(
    Guid ItemId,
    string Result,
    string? Notes,
    IReadOnlyList<Guid> EvidenceIds);

public sealed record InspectionFinding(
    Guid Id,
    Guid InspectionId,
    string Title,
    string Description,
    FindingSeverity Severity,
    FindingStatus Status,
    Guid? AssignedTo,
    DateTimeOffset? DueAt,
    Guid? CorrectiveActionId,
    DateTimeOffset CreatedAt,
    DateTimeOffset UpdatedAt);

public sealed record Inspection(
    Guid Id,
    Guid TenantId,
    Guid TemplateId,
    Guid FacilityId,
    string Title,
    InspectionStatus Status,
    Guid InspectorId,
    DateTimeOffset? ScheduledFor,
    DateTimeOffset? StartedAt,
    DateTimeOffset? SubmittedAt,
    IReadOnlyList<InspectionResponse> Responses,
    IReadOnlyList<InspectionFinding> Findings,
    decimal CompletionPercent,
    DateTimeOffset CreatedAt,
    DateTimeOffset UpdatedAt,
    long Version);

public sealed record CreateInspectionTemplateRequest(string Name, string Description, string Category, IReadOnlyList<InspectionTemplateItem> Items);
public sealed record ScheduleInspectionRequest(Guid TemplateId, Guid FacilityId, string Title, Guid InspectorId, DateTimeOffset? ScheduledFor);
public sealed record SaveInspectionResponseRequest(Guid ItemId, string Result, string? Notes, IReadOnlyList<Guid>? EvidenceIds);
public sealed record CreateFindingRequest(string Title, string Description, FindingSeverity Severity, Guid? AssignedTo, DateTimeOffset? DueAt);
public sealed record InspectionSearchQuery(Guid? FacilityId, InspectionStatus? Status, Guid? InspectorId, DateTimeOffset? From, DateTimeOffset? To, int Limit = 50, int Offset = 0);
public sealed record InspectionSearchResult(IReadOnlyList<Inspection> Items, int Total, int Limit, int Offset);
