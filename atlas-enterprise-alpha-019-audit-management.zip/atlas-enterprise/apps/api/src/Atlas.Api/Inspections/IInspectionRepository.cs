namespace Atlas.Api.Inspections;

public interface IInspectionRepository
{
    Task<InspectionTemplate> AddTemplateAsync(InspectionTemplate template, CancellationToken ct);
    Task<IReadOnlyList<InspectionTemplate>> ListTemplatesAsync(Guid tenantId, bool activeOnly, CancellationToken ct);
    Task<Inspection> AddInspectionAsync(Inspection inspection, CancellationToken ct);
    Task<Inspection?> GetInspectionAsync(Guid tenantId, Guid id, CancellationToken ct);
    Task<Inspection> UpdateInspectionAsync(Inspection inspection, CancellationToken ct);
    Task<InspectionSearchResult> SearchAsync(Guid tenantId, InspectionSearchQuery query, CancellationToken ct);
}
