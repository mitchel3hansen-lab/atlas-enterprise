using System.Text.Json;
using Npgsql;
using NpgsqlTypes;

namespace Atlas.Api.Inspections;

public sealed class PostgresInspectionRepository(IConfiguration configuration) : IInspectionRepository
{
    private string ConnectionString => configuration.GetConnectionString("Atlas") ?? throw new InvalidOperationException("ConnectionStrings:Atlas is required.");

    public async Task<InspectionTemplate> AddTemplateAsync(InspectionTemplate x, CancellationToken ct)
    {
        await using var c = await OpenAsync(ct);
        await using var cmd = new NpgsqlCommand("""INSERT INTO atlas.inspection_templates(id,tenant_id,name,description,category,items,is_active,created_at,updated_at,version) VALUES(@id,@tenant,@name,@description,@category,@items,@active,@created,@updated,@version)""", c);
        cmd.Parameters.AddWithValue("id", x.Id); cmd.Parameters.AddWithValue("tenant", x.TenantId); cmd.Parameters.AddWithValue("name", x.Name); cmd.Parameters.AddWithValue("description", x.Description); cmd.Parameters.AddWithValue("category", x.Category);
        cmd.Parameters.Add(new NpgsqlParameter("items", NpgsqlDbType.Jsonb) { Value = JsonSerializer.Serialize(x.Items) }); cmd.Parameters.AddWithValue("active", x.IsActive); cmd.Parameters.AddWithValue("created", x.CreatedAt); cmd.Parameters.AddWithValue("updated", x.UpdatedAt); cmd.Parameters.AddWithValue("version", x.Version);
        await cmd.ExecuteNonQueryAsync(ct); return x;
    }

    public async Task<IReadOnlyList<InspectionTemplate>> ListTemplatesAsync(Guid tenantId, bool activeOnly, CancellationToken ct)
    {
        await using var c = await OpenAsync(ct); await using var cmd = new NpgsqlCommand($"SELECT * FROM atlas.inspection_templates WHERE tenant_id=@tenant {(activeOnly ? "AND is_active=true" : "")} ORDER BY name", c); cmd.Parameters.AddWithValue("tenant", tenantId);
        var result = new List<InspectionTemplate>(); await using var r = await cmd.ExecuteReaderAsync(ct); while (await r.ReadAsync(ct)) result.Add(MapTemplate(r)); return result;
    }

    public async Task<Inspection> AddInspectionAsync(Inspection x, CancellationToken ct) { await WriteInspectionAsync(x, true, ct); return x; }
    public async Task<Inspection> UpdateInspectionAsync(Inspection x, CancellationToken ct) { await WriteInspectionAsync(x, false, ct); return x; }

    public async Task<Inspection?> GetInspectionAsync(Guid tenantId, Guid id, CancellationToken ct)
    {
        await using var c = await OpenAsync(ct); await using var cmd = new NpgsqlCommand("SELECT * FROM atlas.inspections WHERE tenant_id=@tenant AND id=@id", c); cmd.Parameters.AddWithValue("tenant", tenantId); cmd.Parameters.AddWithValue("id", id); await using var r = await cmd.ExecuteReaderAsync(ct); return await r.ReadAsync(ct) ? MapInspection(r) : null;
    }

    public async Task<InspectionSearchResult> SearchAsync(Guid tenantId, InspectionSearchQuery q, CancellationToken ct)
    {
        await using var c = await OpenAsync(ct); var clauses = new List<string>{"tenant_id=@tenant"}; await using var cmd = new NpgsqlCommand{Connection=c}; cmd.Parameters.AddWithValue("tenant", tenantId);
        if (q.FacilityId is not null) { clauses.Add("facility_id=@facility"); cmd.Parameters.AddWithValue("facility", q.FacilityId); }
        if (q.Status is not null) { clauses.Add("status=@status"); cmd.Parameters.AddWithValue("status", q.Status.ToString()!); }
        if (q.InspectorId is not null) { clauses.Add("inspector_id=@inspector"); cmd.Parameters.AddWithValue("inspector", q.InspectorId); }
        if (q.From is not null) { clauses.Add("coalesce(scheduled_for,created_at)>=@from"); cmd.Parameters.AddWithValue("from", q.From); }
        if (q.To is not null) { clauses.Add("coalesce(scheduled_for,created_at)<=@to"); cmd.Parameters.AddWithValue("to", q.To); }
        cmd.CommandText=$"SELECT *,count(*) OVER()::int total_count FROM atlas.inspections WHERE {string.Join(" AND ",clauses)} ORDER BY coalesce(scheduled_for,created_at) DESC LIMIT @limit OFFSET @offset"; cmd.Parameters.AddWithValue("limit",q.Limit); cmd.Parameters.AddWithValue("offset",q.Offset);
        var items=new List<Inspection>(); var total=0; await using var r=await cmd.ExecuteReaderAsync(ct); while(await r.ReadAsync(ct)){items.Add(MapInspection(r)); total=r.GetInt32(r.GetOrdinal("total_count"));} return new(items,total,q.Limit,q.Offset);
    }

    private async Task WriteInspectionAsync(Inspection x, bool insert, CancellationToken ct)
    {
        await using var c=await OpenAsync(ct); var sql=insert ? """INSERT INTO atlas.inspections(id,tenant_id,template_id,facility_id,title,status,inspector_id,scheduled_for,started_at,submitted_at,responses,findings,completion_percent,created_at,updated_at,version) VALUES(@id,@tenant,@template,@facility,@title,@status,@inspector,@scheduled,@started,@submitted,@responses,@findings,@completion,@created,@updated,@version)""" : """UPDATE atlas.inspections SET status=@status,scheduled_for=@scheduled,started_at=@started,submitted_at=@submitted,responses=@responses,findings=@findings,completion_percent=@completion,updated_at=@updated,version=@version WHERE tenant_id=@tenant AND id=@id""";
        await using var cmd=new NpgsqlCommand(sql,c); cmd.Parameters.AddWithValue("id",x.Id); cmd.Parameters.AddWithValue("tenant",x.TenantId); cmd.Parameters.AddWithValue("template",x.TemplateId); cmd.Parameters.AddWithValue("facility",x.FacilityId); cmd.Parameters.AddWithValue("title",x.Title); cmd.Parameters.AddWithValue("status",x.Status.ToString()); cmd.Parameters.AddWithValue("inspector",x.InspectorId); cmd.Parameters.AddWithValue("scheduled",(object?)x.ScheduledFor??DBNull.Value); cmd.Parameters.AddWithValue("started",(object?)x.StartedAt??DBNull.Value); cmd.Parameters.AddWithValue("submitted",(object?)x.SubmittedAt??DBNull.Value); cmd.Parameters.Add(new NpgsqlParameter("responses",NpgsqlDbType.Jsonb){Value=JsonSerializer.Serialize(x.Responses)}); cmd.Parameters.Add(new NpgsqlParameter("findings",NpgsqlDbType.Jsonb){Value=JsonSerializer.Serialize(x.Findings)}); cmd.Parameters.AddWithValue("completion",x.CompletionPercent); cmd.Parameters.AddWithValue("created",x.CreatedAt); cmd.Parameters.AddWithValue("updated",x.UpdatedAt); cmd.Parameters.AddWithValue("version",x.Version); await cmd.ExecuteNonQueryAsync(ct);
    }

    private async Task<NpgsqlConnection> OpenAsync(CancellationToken ct){var c=new NpgsqlConnection(ConnectionString);await c.OpenAsync(ct);return c;}
    private static InspectionTemplate MapTemplate(NpgsqlDataReader r)=>new(r.GetGuid(r.GetOrdinal("id")),r.GetGuid(r.GetOrdinal("tenant_id")),r.GetString(r.GetOrdinal("name")),r.GetString(r.GetOrdinal("description")),r.GetString(r.GetOrdinal("category")),JsonSerializer.Deserialize<InspectionTemplateItem[]>(r.GetString(r.GetOrdinal("items")))??Array.Empty<InspectionTemplateItem>(),r.GetBoolean(r.GetOrdinal("is_active")),r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("created_at")),r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("updated_at")),r.GetInt64(r.GetOrdinal("version")));
    private static Inspection MapInspection(NpgsqlDataReader r)=>new(r.GetGuid(r.GetOrdinal("id")),r.GetGuid(r.GetOrdinal("tenant_id")),r.GetGuid(r.GetOrdinal("template_id")),r.GetGuid(r.GetOrdinal("facility_id")),r.GetString(r.GetOrdinal("title")),Enum.Parse<InspectionStatus>(r.GetString(r.GetOrdinal("status")),true),r.GetGuid(r.GetOrdinal("inspector_id")),r.IsDBNull(r.GetOrdinal("scheduled_for"))?null:r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("scheduled_for")),r.IsDBNull(r.GetOrdinal("started_at"))?null:r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("started_at")),r.IsDBNull(r.GetOrdinal("submitted_at"))?null:r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("submitted_at")),JsonSerializer.Deserialize<InspectionResponse[]>(r.GetString(r.GetOrdinal("responses")))??Array.Empty<InspectionResponse>(),JsonSerializer.Deserialize<InspectionFinding[]>(r.GetString(r.GetOrdinal("findings")))??Array.Empty<InspectionFinding>(),r.GetDecimal(r.GetOrdinal("completion_percent")),r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("created_at")),r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("updated_at")),r.GetInt64(r.GetOrdinal("version")));
}
