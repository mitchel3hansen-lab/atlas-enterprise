namespace Atlas.Api.Audits;

public enum AuditType { Internal, Regulatory, Customer, Supplier, Certification }
public enum AuditStatus { Draft, Scheduled, InProgress, PendingReview, Closed, Cancelled }
public enum AuditFindingSeverity { Observation, Minor, Major, Critical }
public enum AuditFindingStatus { Open, ActionAssigned, PendingVerification, Closed }

public sealed record AuditRecord(Guid Id, Guid TenantId, string Number, string Title, AuditType Type, Guid? FacilityId, Guid? DepartmentId, Guid LeadAuditorId, DateTimeOffset PlannedStart, DateTimeOffset PlannedEnd, AuditStatus Status, int Score, DateTimeOffset CreatedAt, DateTimeOffset UpdatedAt, long Version);
public sealed record AuditFinding(Guid Id, Guid TenantId, Guid AuditId, string Reference, string Requirement, string Description, AuditFindingSeverity Severity, AuditFindingStatus Status, Guid? CorrectiveActionId, DateTimeOffset DueAt, DateTimeOffset CreatedAt, DateTimeOffset UpdatedAt, long Version);
public sealed record CreateAuditRequest(string Title, AuditType Type, Guid? FacilityId, Guid? DepartmentId, Guid LeadAuditorId, DateTimeOffset PlannedStart, DateTimeOffset PlannedEnd);
public sealed record AddAuditFindingRequest(string Reference, string Requirement, string Description, AuditFindingSeverity Severity, DateTimeOffset DueAt);
public sealed record LinkCorrectiveActionRequest(Guid CorrectiveActionId);
public sealed record AuditSearchQuery(AuditStatus? Status, AuditType? Type, Guid? FacilityId, string? Search, int Limit=50, int Offset=0);
public sealed record AuditSearchResult(IReadOnlyList<AuditRecord> Items, int Total, int Limit, int Offset);
public sealed record AuditDashboard(int Scheduled, int InProgress, int OpenFindings, int CriticalFindings, int OverdueFindings, decimal AverageScore);
