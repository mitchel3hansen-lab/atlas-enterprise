using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace Atlas.Api.Audits;
[ApiController,Route("api/audits"),Authorize]
public sealed class AuditsController(AuditService service,TenantContext tenant):ControllerBase
{
    private Guid T=>tenant.TenantId;
    [HttpGet,Authorize(Policy=AtlasPermissions.AuditsRead)] public Task<AuditSearchResult> Search([FromQuery]AuditSearchQuery q,CancellationToken ct)=>service.SearchAsync(T,q,ct);
    [HttpGet("dashboard"),Authorize(Policy=AtlasPermissions.AuditsRead)] public Task<AuditDashboard> Dashboard(CancellationToken ct)=>service.DashboardAsync(T,ct);
    [HttpPost,Authorize(Policy=AtlasPermissions.AuditsManage)] public Task<AuditRecord> Create(CreateAuditRequest r,CancellationToken ct)=>service.CreateAsync(T,r,ct);
    [HttpPost("{id:guid}/schedule"),Authorize(Policy=AtlasPermissions.AuditsManage)] public Task<AuditRecord> Schedule(Guid id,CancellationToken ct)=>service.ScheduleAsync(T,id,ct);
    [HttpPost("{id:guid}/start"),Authorize(Policy=AtlasPermissions.AuditsExecute)] public Task<AuditRecord> Start(Guid id,CancellationToken ct)=>service.StartAsync(T,id,ct);
    [HttpPost("{id:guid}/submit-review"),Authorize(Policy=AtlasPermissions.AuditsExecute)] public Task<AuditRecord> Review(Guid id,CancellationToken ct)=>service.SubmitReviewAsync(T,id,ct);
    [HttpPost("{id:guid}/close"),Authorize(Policy=AtlasPermissions.AuditsVerify)] public Task<AuditRecord> Close(Guid id,[FromQuery]int score,CancellationToken ct)=>service.CloseAsync(T,id,score,ct);
    [HttpPost("{id:guid}/findings"),Authorize(Policy=AtlasPermissions.AuditsExecute)] public Task<AuditFinding> Finding(Guid id,AddAuditFindingRequest r,CancellationToken ct)=>service.AddFindingAsync(T,id,r,ct);
    [HttpPost("findings/{id:guid}/corrective-action"),Authorize(Policy=AtlasPermissions.AuditsManage)] public Task<AuditFinding> Link(Guid id,LinkCorrectiveActionRequest r,CancellationToken ct)=>service.LinkCorrectiveActionAsync(T,id,r.CorrectiveActionId,ct);
}
