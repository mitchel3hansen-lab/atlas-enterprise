namespace Atlas.Api.Audits;
public sealed class AuditService(IAuditRepository repository)
{
    public async Task<AuditRecord> CreateAsync(Guid tenantId,CreateAuditRequest r,CancellationToken ct)
    {
        if(string.IsNullOrWhiteSpace(r.Title)) throw new ArgumentException("Audit title is required.");
        if(r.LeadAuditorId==Guid.Empty) throw new ArgumentException("Lead auditor is required.");
        if(r.PlannedEnd<=r.PlannedStart) throw new ArgumentException("Planned end must be after planned start.");
        var now=DateTimeOffset.UtcNow;
        return await repository.AddAsync(new(Guid.NewGuid(),tenantId,$"AUD-{now:yyyy}-{Guid.NewGuid().ToString("N")[..6].ToUpperInvariant()}",r.Title.Trim(),r.Type,r.FacilityId,r.DepartmentId,r.LeadAuditorId,r.PlannedStart,r.PlannedEnd,AuditStatus.Draft,0,now,now,1),ct);
    }
    public Task<AuditRecord> ScheduleAsync(Guid tenantId,Guid id,CancellationToken ct)=>Transition(tenantId,id,AuditStatus.Draft,AuditStatus.Scheduled,ct);
    public Task<AuditRecord> StartAsync(Guid tenantId,Guid id,CancellationToken ct)=>Transition(tenantId,id,AuditStatus.Scheduled,AuditStatus.InProgress,ct);
    public Task<AuditRecord> SubmitReviewAsync(Guid tenantId,Guid id,CancellationToken ct)=>Transition(tenantId,id,AuditStatus.InProgress,AuditStatus.PendingReview,ct);
    public async Task<AuditRecord> CloseAsync(Guid tenantId,Guid id,int score,CancellationToken ct)
    {
        if(score is <0 or >100) throw new ArgumentOutOfRangeException(nameof(score));
        var audit=await Require(tenantId,id,ct);
        if(audit.Status!=AuditStatus.PendingReview) throw new InvalidOperationException("Only audits pending review may be closed.");
        return await repository.UpdateAsync(audit with{Status=AuditStatus.Closed,Score=score,UpdatedAt=DateTimeOffset.UtcNow,Version=audit.Version+1},ct);
    }
    public async Task<AuditFinding> AddFindingAsync(Guid tenantId,Guid auditId,AddAuditFindingRequest r,CancellationToken ct)
    {
        var audit=await Require(tenantId,auditId,ct);
        if(audit.Status is AuditStatus.Closed or AuditStatus.Cancelled) throw new InvalidOperationException("Findings cannot be added to a finalized audit.");
        if(string.IsNullOrWhiteSpace(r.Description)||string.IsNullOrWhiteSpace(r.Requirement)) throw new ArgumentException("Requirement and description are required.");
        var now=DateTimeOffset.UtcNow;
        return await repository.AddFindingAsync(new(Guid.NewGuid(),tenantId,auditId,r.Reference.Trim(),r.Requirement.Trim(),r.Description.Trim(),r.Severity,AuditFindingStatus.Open,null,r.DueAt,now,now,1),ct);
    }
    public async Task<AuditFinding> LinkCorrectiveActionAsync(Guid tenantId,Guid findingId,Guid correctiveActionId,CancellationToken ct)
    {
        if(correctiveActionId==Guid.Empty) throw new ArgumentException("Corrective action is required.");
        var x=await repository.GetFindingAsync(tenantId,findingId,ct)??throw new KeyNotFoundException("Audit finding was not found.");
        return await repository.UpdateFindingAsync(x with{CorrectiveActionId=correctiveActionId,Status=AuditFindingStatus.ActionAssigned,UpdatedAt=DateTimeOffset.UtcNow,Version=x.Version+1},ct);
    }
    public Task<AuditSearchResult> SearchAsync(Guid tenantId,AuditSearchQuery q,CancellationToken ct)=>repository.SearchAsync(tenantId,q with{Limit=Math.Clamp(q.Limit,1,200),Offset=Math.Max(0,q.Offset),Search=q.Search?.Trim()},ct);
    public Task<AuditDashboard> DashboardAsync(Guid tenantId,CancellationToken ct)=>repository.DashboardAsync(tenantId,DateTimeOffset.UtcNow,ct);
    private async Task<AuditRecord> Transition(Guid tenantId,Guid id,AuditStatus from,AuditStatus to,CancellationToken ct){var x=await Require(tenantId,id,ct);if(x.Status!=from)throw new InvalidOperationException($"Audit must be {from}.");return await repository.UpdateAsync(x with{Status=to,UpdatedAt=DateTimeOffset.UtcNow,Version=x.Version+1},ct);}
    private async Task<AuditRecord> Require(Guid tenantId,Guid id,CancellationToken ct)=>await repository.GetAsync(tenantId,id,ct)??throw new KeyNotFoundException("Audit was not found.");
}
