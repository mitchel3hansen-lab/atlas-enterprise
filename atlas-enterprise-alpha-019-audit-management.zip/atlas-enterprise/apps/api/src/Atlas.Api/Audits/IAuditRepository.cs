namespace Atlas.Api.Audits;
public interface IAuditRepository
{
    Task<AuditRecord> AddAsync(AuditRecord audit,CancellationToken ct);
    Task<AuditRecord?> GetAsync(Guid tenantId,Guid id,CancellationToken ct);
    Task<AuditRecord> UpdateAsync(AuditRecord audit,CancellationToken ct);
    Task<AuditFinding> AddFindingAsync(AuditFinding finding,CancellationToken ct);
    Task<AuditFinding?> GetFindingAsync(Guid tenantId,Guid id,CancellationToken ct);
    Task<AuditFinding> UpdateFindingAsync(AuditFinding finding,CancellationToken ct);
    Task<AuditSearchResult> SearchAsync(Guid tenantId,AuditSearchQuery query,CancellationToken ct);
    Task<AuditDashboard> DashboardAsync(Guid tenantId,DateTimeOffset now,CancellationToken ct);
}
