using System.Text.Json;

namespace Atlas.Api.Incidents;

public enum IncidentStatus { Draft, Submitted, Assigned, Investigating, Verification, Closed }
public enum IncidentSeverity { Low, Moderate, High, Critical }
public enum IncidentType { Injury, Illness, NearMiss, PropertyDamage, Environmental, Security, Quality, Other }

public sealed record CreateIncidentRequest(
    string Title,
    string Description,
    DateTimeOffset OccurredAt,
    Guid FacilityId,
    Guid? DepartmentId,
    IncidentType IncidentType,
    IncidentSeverity Severity,
    string? ImmediateActions,
    Guid? EmployeeId,
    Guid? EquipmentId,
    Guid? ChemicalId,
    IReadOnlyList<string>? Tags,
    IReadOnlyDictionary<string, JsonElement>? Metadata);

public sealed record UpdateIncidentRequest(
    string Title,
    string Description,
    DateTimeOffset OccurredAt,
    Guid FacilityId,
    Guid? DepartmentId,
    IncidentType IncidentType,
    IncidentSeverity Severity,
    string? ImmediateActions,
    Guid? EmployeeId,
    Guid? EquipmentId,
    Guid? ChemicalId,
    IReadOnlyList<string>? Tags,
    IReadOnlyDictionary<string, JsonElement>? Metadata,
    long ExpectedVersion);

public sealed record TransitionIncidentRequest(
    IncidentStatus TargetStatus,
    Guid ActorId,
    string? ActorDisplayName,
    Guid? AssigneeId,
    string? Comment,
    long ExpectedVersion);

public sealed record AssignIncidentRequest(
    Guid InvestigatorId,
    string? InvestigatorDisplayName,
    string? Comment,
    long ExpectedVersion);

public sealed record IncidentAssignmentRecord(
    Guid Id,
    Guid TenantId,
    Guid IncidentId,
    Guid InvestigatorId,
    string? InvestigatorDisplayName,
    Guid AssignedBy,
    string? AssignedByDisplayName,
    string? Comment,
    DateTimeOffset AssignedAt);

public sealed record IncidentSearchQuery(
    string? Search,
    IncidentStatus? Status,
    IncidentSeverity? Severity,
    IncidentType? IncidentType,
    Guid? FacilityId,
    Guid? DepartmentId,
    DateTimeOffset? OccurredFrom,
    DateTimeOffset? OccurredTo,
    int Limit = 50,
    int Offset = 0);

public sealed record IncidentRecord(
    Guid Id,
    Guid TenantId,
    string Number,
    string Title,
    string Description,
    DateTimeOffset OccurredAt,
    Guid FacilityId,
    Guid? DepartmentId,
    IncidentType IncidentType,
    IncidentSeverity Severity,
    IncidentStatus Status,
    string? ImmediateActions,
    Guid? ReporterId,
    Guid? AssigneeId,
    string? AssigneeDisplayName,
    DateTimeOffset? AssignedAt,
    Guid? AssignedBy,
    Guid? EmployeeId,
    Guid? EquipmentId,
    Guid? ChemicalId,
    int RiskScore,
    bool CapaRequired,
    Guid? CapaId,
    IReadOnlyList<string> Tags,
    IReadOnlyDictionary<string, JsonElement> Metadata,
    DateTimeOffset CreatedAt,
    DateTimeOffset UpdatedAt,
    long Version);

public sealed record IncidentPage(IReadOnlyList<IncidentRecord> Items, int Total, int Limit, int Offset);

public sealed record IncidentTransitionResult(
    IncidentRecord Incident,
    IReadOnlyList<Guid> RuleExecutionIds,
    IReadOnlyList<Guid> TimelineEntryIds,
    Guid? KnowledgeGraphNodeId,
    string CorrelationId);
