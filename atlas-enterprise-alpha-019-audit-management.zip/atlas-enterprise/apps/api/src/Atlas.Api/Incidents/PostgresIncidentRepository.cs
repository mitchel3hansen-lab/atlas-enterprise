using System.Text;
using System.Text.Json;
using Npgsql;
using NpgsqlTypes;

namespace Atlas.Api.Incidents;

public sealed class PostgresIncidentRepository(IConfiguration configuration) : IIncidentRepository
{
    private string ConnectionString => configuration.GetConnectionString("Atlas") ?? throw new InvalidOperationException("ConnectionStrings:Atlas is required.");

    public async Task<IncidentRecord?> GetAsync(Guid tenantId, Guid id, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = new NpgsqlCommand("SELECT * FROM atlas.incidents WHERE tenant_id=@tenant AND id=@id", connection);
        command.Parameters.AddWithValue("tenant", tenantId); command.Parameters.AddWithValue("id", id);
        await using var reader = await command.ExecuteReaderAsync(ct);
        return await reader.ReadAsync(ct) ? Map(reader) : null;
    }

    public async Task<IncidentRecord> AddAsync(IncidentRecord incident, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = BuildWrite(connection, incident, false, 0);
        await command.ExecuteNonQueryAsync(ct);
        return incident;
    }

    public async Task<IncidentRecord> ReplaceAsync(IncidentRecord incident, long expectedVersion, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        var updated = incident with { Version = expectedVersion + 1, UpdatedAt = DateTimeOffset.UtcNow };
        await using var command = BuildWrite(connection, updated, true, expectedVersion);
        if (await command.ExecuteNonQueryAsync(ct) != 1) throw new InvalidOperationException("Incident was modified by another user.");
        return updated;
    }

    public async Task<IReadOnlyList<IncidentRecord>> SearchAsync(Guid tenantId, IncidentSearchQuery query, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        var (where, parameters) = BuildFilter(tenantId, query);
        await using var command = new NpgsqlCommand($"SELECT * FROM atlas.incidents {where} ORDER BY occurred_at DESC, created_at DESC LIMIT @limit OFFSET @offset", connection);
        AddParameters(command, parameters); command.Parameters.AddWithValue("limit", query.Limit); command.Parameters.AddWithValue("offset", query.Offset);
        var items = new List<IncidentRecord>();
        await using var reader = await command.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) items.Add(Map(reader));
        return items;
    }

    public async Task<int> CountAsync(Guid tenantId, IncidentSearchQuery query, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        var (where, parameters) = BuildFilter(tenantId, query);
        await using var command = new NpgsqlCommand($"SELECT count(*)::int FROM atlas.incidents {where}", connection);
        AddParameters(command, parameters);
        return Convert.ToInt32(await command.ExecuteScalarAsync(ct));
    }

    public async Task<int> NextSequenceAsync(Guid tenantId, int year, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var transaction = await connection.BeginTransactionAsync(ct);
        await using var command = new NpgsqlCommand("SELECT next_incident_number FROM atlas.incident_number_sequences WHERE tenant_id=@tenant AND incident_year=@year FOR UPDATE", connection, transaction);
        command.Parameters.AddWithValue("tenant", tenantId); command.Parameters.AddWithValue("year", year);
        var existing = await command.ExecuteScalarAsync(ct);
        int next;
        if (existing is null)
        {
            next = 1;
            await using var insert = new NpgsqlCommand("INSERT INTO atlas.incident_number_sequences(tenant_id, incident_year, next_incident_number) VALUES(@tenant,@year,2)", connection, transaction);
            insert.Parameters.AddWithValue("tenant", tenantId); insert.Parameters.AddWithValue("year", year); await insert.ExecuteNonQueryAsync(ct);
        }
        else
        {
            next = Convert.ToInt32(existing);
            await using var update = new NpgsqlCommand("UPDATE atlas.incident_number_sequences SET next_incident_number=next_incident_number+1 WHERE tenant_id=@tenant AND incident_year=@year", connection, transaction);
            update.Parameters.AddWithValue("tenant", tenantId); update.Parameters.AddWithValue("year", year); await update.ExecuteNonQueryAsync(ct);
        }
        await transaction.CommitAsync(ct);
        return next;
    }

    public async Task AddAssignmentAsync(IncidentAssignmentRecord assignment, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = new NpgsqlCommand("""INSERT INTO atlas.incident_assignments(id,tenant_id,incident_id,investigator_id,investigator_display_name,assigned_by,assigned_by_display_name,comment,assigned_at) VALUES(@id,@tenant,@incident,@investigator,@investigatorName,@assignedBy,@assignedByName,@comment,@assignedAt)""", connection);
        command.Parameters.AddWithValue("id", assignment.Id); command.Parameters.AddWithValue("tenant", assignment.TenantId);
        command.Parameters.AddWithValue("incident", assignment.IncidentId); command.Parameters.AddWithValue("investigator", assignment.InvestigatorId);
        command.Parameters.AddWithValue("investigatorName", (object?)assignment.InvestigatorDisplayName ?? DBNull.Value);
        command.Parameters.AddWithValue("assignedBy", assignment.AssignedBy); command.Parameters.AddWithValue("assignedByName", (object?)assignment.AssignedByDisplayName ?? DBNull.Value);
        command.Parameters.AddWithValue("comment", (object?)assignment.Comment ?? DBNull.Value); command.Parameters.AddWithValue("assignedAt", assignment.AssignedAt);
        await command.ExecuteNonQueryAsync(ct);
    }

    public async Task<IReadOnlyList<IncidentAssignmentRecord>> GetAssignmentsAsync(Guid tenantId, Guid incidentId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = new NpgsqlCommand("SELECT id,tenant_id,incident_id,investigator_id,investigator_display_name,assigned_by,assigned_by_display_name,comment,assigned_at FROM atlas.incident_assignments WHERE tenant_id=@tenant AND incident_id=@incident ORDER BY assigned_at DESC", connection);
        command.Parameters.AddWithValue("tenant", tenantId); command.Parameters.AddWithValue("incident", incidentId);
        var items = new List<IncidentAssignmentRecord>();
        await using var reader = await command.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) items.Add(new(reader.GetGuid(0), reader.GetGuid(1), reader.GetGuid(2), reader.GetGuid(3), reader.IsDBNull(4) ? null : reader.GetString(4), reader.GetGuid(5), reader.IsDBNull(6) ? null : reader.GetString(6), reader.IsDBNull(7) ? null : reader.GetString(7), reader.GetFieldValue<DateTimeOffset>(8)));
        return items;
    }

    private async Task<NpgsqlConnection> OpenAsync(CancellationToken ct) { var connection = new NpgsqlConnection(ConnectionString); await connection.OpenAsync(ct); return connection; }

    private static (string Where, Dictionary<string, object> Parameters) BuildFilter(Guid tenantId, IncidentSearchQuery query)
    {
        var clauses = new List<string> { "tenant_id=@tenant" }; var values = new Dictionary<string, object> { ["tenant"] = tenantId };
        if (!string.IsNullOrWhiteSpace(query.Search)) { clauses.Add("search_document @@ websearch_to_tsquery('simple', @search) OR incident_number ILIKE '%' || @search || '%'"); values["search"] = query.Search.Trim(); }
        if (query.Status is not null) { clauses.Add("status=@status"); values["status"] = query.Status.ToString()!; }
        if (query.Severity is not null) { clauses.Add("severity=@severity"); values["severity"] = query.Severity.ToString()!; }
        if (query.IncidentType is not null) { clauses.Add("incident_type=@incidentType"); values["incidentType"] = query.IncidentType.ToString()!; }
        if (query.FacilityId is not null) { clauses.Add("facility_id=@facility"); values["facility"] = query.FacilityId.Value; }
        if (query.DepartmentId is not null) { clauses.Add("department_id=@department"); values["department"] = query.DepartmentId.Value; }
        if (query.OccurredFrom is not null) { clauses.Add("occurred_at>=@from"); values["from"] = query.OccurredFrom.Value; }
        if (query.OccurredTo is not null) { clauses.Add("occurred_at<=@to"); values["to"] = query.OccurredTo.Value; }
        return ($"WHERE {string.Join(" AND ", clauses)}", values);
    }

    private static void AddParameters(NpgsqlCommand command, Dictionary<string, object> values) { foreach (var pair in values) command.Parameters.AddWithValue(pair.Key, pair.Value); }

    private static NpgsqlCommand BuildWrite(NpgsqlConnection connection, IncidentRecord x, bool replace, long expected)
    {
        const string insert = """INSERT INTO atlas.incidents(id,tenant_id,incident_number,title,description,occurred_at,facility_id,department_id,incident_type,severity,status,immediate_actions,reporter_id,assignee_id,assignee_display_name,assigned_at,assigned_by,employee_id,equipment_id,chemical_id,risk_score,capa_required,capa_id,tags,metadata,created_at,updated_at,version) VALUES(@id,@tenant,@number,@title,@description,@occurred,@facility,@department,@incidentType,@severity,@status,@immediateActions,@reporter,@assignee,@assigneeName,@assignedAt,@assignedBy,@employee,@equipment,@chemical,@risk,@capaRequired,@capa,@tags,@metadata,@created,@updated,@version)""";
        const string update = """UPDATE atlas.incidents SET title=@title,description=@description,occurred_at=@occurred,facility_id=@facility,department_id=@department,incident_type=@incidentType,severity=@severity,status=@status,immediate_actions=@immediateActions,reporter_id=@reporter,assignee_id=@assignee,assignee_display_name=@assigneeName,assigned_at=@assignedAt,assigned_by=@assignedBy,employee_id=@employee,equipment_id=@equipment,chemical_id=@chemical,risk_score=@risk,capa_required=@capaRequired,capa_id=@capa,tags=@tags,metadata=@metadata,updated_at=@updated,version=@version WHERE tenant_id=@tenant AND id=@id AND version=@expected""";
        var command = new NpgsqlCommand(replace ? update : insert, connection);
        void Add(string name, object? value) => command.Parameters.AddWithValue(name, value ?? DBNull.Value);
        Add("id", x.Id); Add("tenant", x.TenantId); Add("number", x.Number); Add("title", x.Title); Add("description", x.Description); Add("occurred", x.OccurredAt); Add("facility", x.FacilityId); Add("department", x.DepartmentId); Add("incidentType", x.IncidentType.ToString()); Add("severity", x.Severity.ToString()); Add("status", x.Status.ToString()); Add("immediateActions", x.ImmediateActions); Add("reporter", x.ReporterId); Add("assignee", x.AssigneeId); Add("assigneeName", x.AssigneeDisplayName); Add("assignedAt", x.AssignedAt); Add("assignedBy", x.AssignedBy); Add("employee", x.EmployeeId); Add("equipment", x.EquipmentId); Add("chemical", x.ChemicalId); Add("risk", x.RiskScore); Add("capaRequired", x.CapaRequired); Add("capa", x.CapaId); Add("tags", x.Tags.ToArray());
        var metadata = command.Parameters.Add("metadata", NpgsqlDbType.Jsonb); metadata.Value = JsonSerializer.Serialize(x.Metadata);
        Add("created", x.CreatedAt); Add("updated", x.UpdatedAt); Add("version", x.Version); if (replace) Add("expected", expected);
        return command;
    }

    private static IncidentRecord Map(NpgsqlDataReader reader)
    {
        int O(string name) => reader.GetOrdinal(name); T? N<T>(string name) where T : struct => reader.IsDBNull(O(name)) ? null : reader.GetFieldValue<T>(O(name));
        string? S(string name) => reader.IsDBNull(O(name)) ? null : reader.GetString(O(name));
        return new(reader.GetGuid(O("id")), reader.GetGuid(O("tenant_id")), reader.GetString(O("incident_number")), reader.GetString(O("title")), reader.GetString(O("description")), reader.GetFieldValue<DateTimeOffset>(O("occurred_at")), reader.GetGuid(O("facility_id")), N<Guid>("department_id"), Enum.Parse<IncidentType>(reader.GetString(O("incident_type")), true), Enum.Parse<IncidentSeverity>(reader.GetString(O("severity")), true), Enum.Parse<IncidentStatus>(reader.GetString(O("status")), true), S("immediate_actions"), N<Guid>("reporter_id"), N<Guid>("assignee_id"), S("assignee_display_name"), N<DateTimeOffset>("assigned_at"), N<Guid>("assigned_by"), N<Guid>("employee_id"), N<Guid>("equipment_id"), N<Guid>("chemical_id"), reader.GetInt32(O("risk_score")), reader.GetBoolean(O("capa_required")), N<Guid>("capa_id"), reader.GetFieldValue<string[]>(O("tags")), JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(reader.GetString(O("metadata"))) ?? new(), reader.GetFieldValue<DateTimeOffset>(O("created_at")), reader.GetFieldValue<DateTimeOffset>(O("updated_at")), reader.GetInt64(O("version")));
    }
}
