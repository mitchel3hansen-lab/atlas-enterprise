namespace Atlas.Api.Incidents;

public interface IIncidentRepository
{
    Task<IncidentRecord?> GetAsync(Guid tenantId, Guid id, CancellationToken cancellationToken);
    Task<IncidentRecord> AddAsync(IncidentRecord incident, CancellationToken cancellationToken);
    Task<IncidentRecord> ReplaceAsync(IncidentRecord incident, long expectedVersion, CancellationToken cancellationToken);
    Task<IReadOnlyList<IncidentRecord>> SearchAsync(Guid tenantId, IncidentSearchQuery query, CancellationToken cancellationToken);
    Task<int> CountAsync(Guid tenantId, IncidentSearchQuery query, CancellationToken cancellationToken);
    Task<int> NextSequenceAsync(Guid tenantId, int year, CancellationToken cancellationToken);
    Task AddAssignmentAsync(IncidentAssignmentRecord assignment, CancellationToken cancellationToken);
    Task<IReadOnlyList<IncidentAssignmentRecord>> GetAssignmentsAsync(Guid tenantId, Guid incidentId, CancellationToken cancellationToken);
}
