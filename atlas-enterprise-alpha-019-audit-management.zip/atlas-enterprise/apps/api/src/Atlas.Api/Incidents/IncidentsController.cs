using System.Security.Claims;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Atlas.Api.Incidents;

[ApiController]
[Route("api/v1/incidents")]
public sealed class IncidentsController(IncidentService service, TenantContext tenantContext) : ControllerBase
{
    [HttpPost]
    [Authorize(Policy = AtlasPermissions.IncidentsManage)]
    public async Task<ActionResult<IncidentTransitionResult>> Create(CreateIncidentRequest request, CancellationToken ct)
    {
        var result = await service.CreateAsync(tenantContext.TenantId, ActorId(), User.Identity?.Name, request, HttpContext.TraceIdentifier, ct);
        return CreatedAtAction(nameof(Get), new { id = result.Incident.Id }, result);
    }

    [HttpGet]
    [Authorize(Policy = AtlasPermissions.IncidentsRead)]
    public async Task<ActionResult<IncidentPage>> Search(
        [FromQuery] string? search = null,
        [FromQuery] IncidentStatus? status = null,
        [FromQuery] IncidentSeverity? severity = null,
        [FromQuery] IncidentType? incidentType = null,
        [FromQuery] Guid? facilityId = null,
        [FromQuery] Guid? departmentId = null,
        [FromQuery] DateTimeOffset? occurredFrom = null,
        [FromQuery] DateTimeOffset? occurredTo = null,
        [FromQuery] int limit = 50,
        [FromQuery] int offset = 0,
        CancellationToken ct = default)
        => Ok(await service.SearchAsync(tenantContext.TenantId,
            new(search, status, severity, incidentType, facilityId, departmentId, occurredFrom, occurredTo, limit, offset), ct));

    [HttpGet("{id:guid}")]
    [Authorize(Policy = AtlasPermissions.IncidentsRead)]
    public async Task<ActionResult<IncidentRecord>> Get(Guid id, CancellationToken ct)
        => Ok(await service.GetAsync(tenantContext.TenantId, id, ct));

    [HttpPut("{id:guid}")]
    [Authorize(Policy = AtlasPermissions.IncidentsManage)]
    public async Task<ActionResult<IncidentRecord>> Update(Guid id, UpdateIncidentRequest request, CancellationToken ct)
        => Ok(await service.UpdateAsync(tenantContext.TenantId, id, ActorId(), User.Identity?.Name, request, HttpContext.TraceIdentifier, ct));

    [HttpPost("{id:guid}/assign")]
    [Authorize(Policy = AtlasPermissions.IncidentsTransition)]
    public async Task<ActionResult<IncidentTransitionResult>> Assign(Guid id, AssignIncidentRequest request, CancellationToken ct)
        => Ok(await service.AssignAsync(tenantContext.TenantId, id, ActorId(), User.Identity?.Name, request, HttpContext.TraceIdentifier, ct));

    [HttpGet("{id:guid}/assignments")]
    [Authorize(Policy = AtlasPermissions.IncidentsRead)]
    public async Task<ActionResult<IReadOnlyList<IncidentAssignmentRecord>>> Assignments(Guid id, CancellationToken ct)
        => Ok(await service.GetAssignmentsAsync(tenantContext.TenantId, id, ct));

    [HttpPost("{id:guid}/transitions")]
    [Authorize(Policy = AtlasPermissions.IncidentsTransition)]
    public async Task<ActionResult<IncidentTransitionResult>> Transition(Guid id, TransitionIncidentRequest request, CancellationToken ct)
        => Ok(await service.TransitionAsync(tenantContext.TenantId, id, request, HttpContext.TraceIdentifier, ct));

    private Guid ActorId()
    {
        var raw = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub");
        return Guid.TryParse(raw, out var id) ? id : Guid.Empty;
    }
}
