namespace Atlas.Api.Domain;

public enum OrganizationStatus { Active, Suspended, Archived }

public sealed class Organization
{
    public Guid Id { get; init; }
    public required string Name { get; set; }
    public required string LegalName { get; set; }
    public required string DisplayName { get; set; }
    public required string Slug { get; set; }
    public OrganizationStatus Status { get; set; } = OrganizationStatus.Active;
    public string? Industry { get; set; }
    public required string TimeZone { get; set; }
    public required string CountryCode { get; set; }
    public string? Region { get; set; }
    public string? LogoUrl { get; set; }
    public string? PrimaryColor { get; set; }
    public string? SecondaryColor { get; set; }
    public DateTimeOffset CreatedAtUtc { get; init; }
    public DateTimeOffset UpdatedAtUtc { get; set; }
    public DateTimeOffset? ArchivedAtUtc { get; set; }
    public Guid? CreatedByUserId { get; init; }
    public Guid? UpdatedByUserId { get; set; }
    public uint Version { get; set; }
}

public enum FacilityStatus { Active, Inactive, Archived }
public enum FacilityType { Site, Plant, Warehouse, Office, Laboratory, DistributionCenter, Other }

public sealed class Facility
{
    public Guid Id { get; init; }
    public Guid OrganizationId { get; init; }
    public required string Name { get; set; }
    public required string Code { get; set; }
    public FacilityType Type { get; set; } = FacilityType.Site;
    public FacilityStatus Status { get; set; } = FacilityStatus.Active;
    public string? Description { get; set; }
    public required string TimeZone { get; set; }
    public required string CountryCode { get; set; }
    public string? Region { get; set; }
    public string? City { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? PostalCode { get; set; }
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
    public string? EmergencyZone { get; set; }
    public DateTimeOffset CreatedAtUtc { get; init; }
    public DateTimeOffset UpdatedAtUtc { get; set; }
    public DateTimeOffset? ArchivedAtUtc { get; set; }
    public Guid? CreatedByUserId { get; init; }
    public Guid? UpdatedByUserId { get; set; }
    public uint Version { get; set; }
}

public sealed class FacilityAuditEvent
{
    public Guid Id { get; init; }
    public Guid OrganizationId { get; init; }
    public Guid FacilityId { get; init; }
    public Guid? ActorUserId { get; init; }
    public required string Action { get; init; }
    public required string ChangesJson { get; init; }
    public DateTimeOffset OccurredAtUtc { get; init; }
}
public sealed record SafetyRecord(Guid Id, Guid OrganizationId, Guid? FacilityId, string RecordType, string Title, string Status, string Severity, DateTimeOffset OccurredAtUtc, DateTimeOffset CreatedAtUtc);

public sealed class AtlasUser
{
    public Guid Id { get; init; }
    public required string Email { get; set; }
    public required string NormalizedEmail { get; set; }
    public required string DisplayName { get; set; }
    public required string PasswordHash { get; set; }
    public bool IsActive { get; set; } = true;
    public int FailedLoginCount { get; set; }
    public DateTimeOffset? LockedUntilUtc { get; set; }
    public DateTimeOffset? LastLoginAtUtc { get; set; }
    public DateTimeOffset? PasswordChangedAtUtc { get; set; }
    public DateTimeOffset CreatedAtUtc { get; init; }
}
public sealed class OrganizationMembership { public Guid Id { get; init; } public Guid OrganizationId { get; init; } public Guid UserId { get; init; } public bool IsActive { get; set; } = true; public DateTimeOffset CreatedAtUtc { get; init; } }
public sealed class Role { public Guid Id { get; init; } public Guid? OrganizationId { get; init; } public required string Name { get; set; } public required string NormalizedName { get; set; } public bool IsSystemRole { get; init; } }
public sealed class Permission { public Guid Id { get; init; } public required string Code { get; init; } public required string Description { get; init; } }
public sealed class MembershipRole { public Guid MembershipId { get; init; } public Guid RoleId { get; init; } }
public sealed class RolePermission { public Guid RoleId { get; init; } public Guid PermissionId { get; init; } }
public sealed class UserInvitation { public Guid Id { get; init; } public Guid OrganizationId { get; init; } public required string Email { get; set; } public required string NormalizedEmail { get; set; } public required string TokenHash { get; init; } public Guid InvitedByUserId { get; init; } public DateTimeOffset ExpiresAtUtc { get; init; } public DateTimeOffset? AcceptedAtUtc { get; set; } public DateTimeOffset? RevokedAtUtc { get; set; } public DateTimeOffset CreatedAtUtc { get; init; } }
public sealed class AccessAuditEvent { public Guid Id { get; init; } public Guid OrganizationId { get; init; } public Guid? ActorUserId { get; init; } public Guid? SubjectUserId { get; init; } public required string Action { get; init; } public required string DetailsJson { get; init; } public DateTimeOffset OccurredAtUtc { get; init; } }
public sealed class RevokedSession { public Guid Id { get; init; } public Guid OrganizationId { get; init; } public Guid UserId { get; init; } public required string JwtId { get; init; } public DateTimeOffset ExpiresAtUtc { get; init; } public DateTimeOffset RevokedAtUtc { get; init; } }
public sealed class RefreshSession
{
    public Guid Id { get; init; }
    public Guid OrganizationId { get; init; }
    public Guid UserId { get; init; }
    public Guid MembershipId { get; init; }
    public required string TokenHash { get; set; }
    public required string JwtId { get; set; }
    public DateTimeOffset CreatedAtUtc { get; init; }
    public DateTimeOffset ExpiresAtUtc { get; set; }
    public DateTimeOffset? LastUsedAtUtc { get; set; }
    public DateTimeOffset? RevokedAtUtc { get; set; }
    public required string CreatedByIp { get; init; }
    public string? ReplacedByTokenHash { get; set; }
}

public sealed class OrganizationAuditEvent
{
    public Guid Id { get; init; }
    public Guid OrganizationId { get; init; }
    public Guid? ActorUserId { get; init; }
    public required string Action { get; init; }
    public required string ChangesJson { get; init; }
    public DateTimeOffset OccurredAtUtc { get; init; }
}

public enum AtlasObjectType { Organization, Facility, Department, Hazard, Risk, Control, Incident, Inspection, Training, Asset, Regulation, Action, KnowledgeObject }
public enum EvidenceStrength { Low, Moderate, Strong, Verified }

public sealed class KnowledgeRelationship
{
    public Guid Id { get; init; }
    public Guid OrganizationId { get; init; }
    public AtlasObjectType SourceType { get; init; }
    public Guid SourceId { get; init; }
    public AtlasObjectType TargetType { get; init; }
    public Guid TargetId { get; init; }
    public required string RelationshipType { get; init; }
    public decimal Weight { get; init; } = 1m;
    public string? Rationale { get; init; }
    public DateTimeOffset CreatedAtUtc { get; init; }
    public Guid? CreatedByUserId { get; init; }
}

public sealed class EvidenceRecord
{
    public Guid Id { get; init; }
    public Guid OrganizationId { get; init; }
    public AtlasObjectType ObjectType { get; init; }
    public Guid ObjectId { get; init; }
    public required string EvidenceType { get; init; }
    public required string Title { get; init; }
    public string? Summary { get; init; }
    public string? SourceReference { get; init; }
    public EvidenceStrength Strength { get; init; } = EvidenceStrength.Moderate;
    public decimal Confidence { get; init; } = 0.70m;
    public DateTimeOffset ObservedAtUtc { get; init; }
    public DateTimeOffset CreatedAtUtc { get; init; }
}
