namespace Atlas.Api.Risks;

public enum RiskAssessmentType { RiskRegister, Jha, Hira }
public enum RiskStatus { Draft, Active, UnderReview, Accepted, TreatmentRequired, Closed, Archived }
public enum ControlType { Elimination, Substitution, Engineering, Administrative, Ppe }
public enum ControlStatus { Proposed, Implementing, Implemented, Verified, Ineffective }

public sealed record RiskControl(Guid Id, string Description, ControlType Type, ControlStatus Status, Guid? OwnerId, DateTimeOffset? DueAt, string? VerificationMethod);
public sealed record RiskReview(Guid Id, int Likelihood, int Severity, int Score, string Rationale, Guid ReviewedBy, DateTimeOffset ReviewedAt);
public sealed record RiskAssessment(
    Guid Id, Guid TenantId, string Number, string Title, string Description, RiskAssessmentType Type,
    RiskStatus Status, Guid? FacilityId, Guid? DepartmentId, string Activity, string Hazard, string PotentialConsequence,
    int InherentLikelihood, int InherentSeverity, int InherentScore, int ResidualLikelihood, int ResidualSeverity,
    int ResidualScore, string RiskBand, Guid OwnerId, DateTimeOffset? ReviewDueAt,
    IReadOnlyList<RiskControl> Controls, IReadOnlyList<RiskReview> Reviews,
    DateTimeOffset CreatedAt, DateTimeOffset UpdatedAt, long Version);

public sealed record CreateRiskAssessmentRequest(string Title, string Description, RiskAssessmentType Type, Guid? FacilityId,
    Guid? DepartmentId, string Activity, string Hazard, string PotentialConsequence, int Likelihood, int Severity,
    Guid OwnerId, DateTimeOffset? ReviewDueAt);
public sealed record AddRiskControlRequest(string Description, ControlType Type, Guid? OwnerId, DateTimeOffset? DueAt, string? VerificationMethod);
public sealed record UpdateRiskControlRequest(ControlStatus Status, string? VerificationMethod);
public sealed record ReviewRiskRequest(int ResidualLikelihood, int ResidualSeverity, string Rationale);
public sealed record RiskSearchQuery(RiskAssessmentType? Type, RiskStatus? Status, Guid? FacilityId, string? RiskBand, string? Search, int Limit=50, int Offset=0);
public sealed record RiskSearchResult(IReadOnlyList<RiskAssessment> Items, int Total, int Limit, int Offset);
public sealed record RiskDashboard(int Active, int HighOrCritical, int ReviewsDue, int TreatmentRequired, decimal AverageResidualScore, int VerifiedControls);
