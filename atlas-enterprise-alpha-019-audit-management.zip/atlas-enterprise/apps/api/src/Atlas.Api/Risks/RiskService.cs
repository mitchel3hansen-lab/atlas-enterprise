namespace Atlas.Api.Risks;

public sealed class RiskService(IRiskRepository repository)
{
    public async Task<RiskAssessment> CreateAsync(Guid tenantId, Guid actorId, CreateRiskAssessmentRequest request, CancellationToken ct)
    {
        ValidateScore(request.Likelihood, request.Severity);
        if (string.IsNullOrWhiteSpace(request.Title) || string.IsNullOrWhiteSpace(request.Hazard)) throw new ArgumentException("Title and hazard are required.");
        if (request.OwnerId == Guid.Empty) throw new ArgumentException("Risk owner is required.");
        var now=DateTimeOffset.UtcNow; var score=request.Likelihood*request.Severity;
        var item=new RiskAssessment(Guid.NewGuid(),tenantId,await repository.NextNumberAsync(tenantId,ct),request.Title.Trim(),request.Description.Trim(),request.Type,
            RiskStatus.Draft,request.FacilityId,request.DepartmentId,request.Activity.Trim(),request.Hazard.Trim(),request.PotentialConsequence.Trim(),
            request.Likelihood,request.Severity,score,request.Likelihood,request.Severity,score,Band(score),request.OwnerId,request.ReviewDueAt,
            Array.Empty<RiskControl>(),Array.Empty<RiskReview>(),now,now,1);
        return await repository.AddAsync(item,ct);
    }

    public Task<RiskAssessment?> GetAsync(Guid tenantId,Guid id,CancellationToken ct)=>repository.GetAsync(tenantId,id,ct);
    public Task<RiskSearchResult> SearchAsync(Guid tenantId,RiskSearchQuery query,CancellationToken ct)=>repository.SearchAsync(tenantId,query with{Limit=Math.Clamp(query.Limit,1,200),Offset=Math.Max(0,query.Offset),Search=query.Search?.Trim()},ct);
    public Task<RiskDashboard> DashboardAsync(Guid tenantId,CancellationToken ct)=>repository.DashboardAsync(tenantId,DateTimeOffset.UtcNow,ct);

    public async Task<RiskAssessment> ActivateAsync(Guid tenantId,Guid id,Guid actorId,CancellationToken ct)
    {
        var item=await Require(tenantId,id,ct);
        if(item.Status!=RiskStatus.Draft) throw new InvalidOperationException("Only draft risks may be activated.");
        return await Save(item with{Status=item.ResidualScore>=10?RiskStatus.TreatmentRequired:RiskStatus.Active},ct);
    }

    public async Task<RiskAssessment> AddControlAsync(Guid tenantId,Guid id,AddRiskControlRequest request,CancellationToken ct)
    {
        var item=await Require(tenantId,id,ct); EnsureMutable(item);
        if(string.IsNullOrWhiteSpace(request.Description)) throw new ArgumentException("Control description is required.");
        var control=new RiskControl(Guid.NewGuid(),request.Description.Trim(),request.Type,ControlStatus.Proposed,request.OwnerId,request.DueAt,request.VerificationMethod?.Trim());
        return await Save(item with{Controls=item.Controls.Append(control).ToArray(),Status=RiskStatus.TreatmentRequired},ct);
    }

    public async Task<RiskAssessment> UpdateControlAsync(Guid tenantId,Guid id,Guid controlId,UpdateRiskControlRequest request,CancellationToken ct)
    {
        var item=await Require(tenantId,id,ct); EnsureMutable(item);
        if(!item.Controls.Any(x=>x.Id==controlId)) throw new KeyNotFoundException("Risk control was not found.");
        var controls=item.Controls.Select(x=>x.Id==controlId?x with{Status=request.Status,VerificationMethod=request.VerificationMethod?.Trim()??x.VerificationMethod}:x).ToArray();
        return await Save(item with{Controls=controls},ct);
    }

    public async Task<RiskAssessment> ReviewAsync(Guid tenantId,Guid id,Guid actorId,ReviewRiskRequest request,CancellationToken ct)
    {
        ValidateScore(request.ResidualLikelihood,request.ResidualSeverity);
        if(string.IsNullOrWhiteSpace(request.Rationale)) throw new ArgumentException("Review rationale is required.");
        var item=await Require(tenantId,id,ct); EnsureMutable(item);
        var score=request.ResidualLikelihood*request.ResidualSeverity;
        var review=new RiskReview(Guid.NewGuid(),request.ResidualLikelihood,request.ResidualSeverity,score,request.Rationale.Trim(),actorId,DateTimeOffset.UtcNow);
        var status=score>=10?RiskStatus.TreatmentRequired:RiskStatus.Active;
        return await Save(item with{ResidualLikelihood=request.ResidualLikelihood,ResidualSeverity=request.ResidualSeverity,ResidualScore=score,RiskBand=Band(score),Reviews=item.Reviews.Append(review).ToArray(),Status=status},ct);
    }

    public async Task<RiskAssessment> AcceptAsync(Guid tenantId,Guid id,CancellationToken ct)
    {
        var item=await Require(tenantId,id,ct);
        if(item.ResidualScore>=10) throw new InvalidOperationException("High or critical residual risk cannot be accepted without additional treatment.");
        if(item.Controls.Count>0 && item.Controls.Any(x=>x.Status is not (ControlStatus.Verified or ControlStatus.Implemented))) throw new InvalidOperationException("All controls must be implemented or verified before acceptance.");
        return await Save(item with{Status=RiskStatus.Accepted},ct);
    }

    private async Task<RiskAssessment> Require(Guid t,Guid id,CancellationToken ct)=>await repository.GetAsync(t,id,ct)??throw new KeyNotFoundException("Risk assessment was not found.");
    private async Task<RiskAssessment> Save(RiskAssessment item,CancellationToken ct)=>await repository.UpdateAsync(item with{UpdatedAt=DateTimeOffset.UtcNow,Version=item.Version+1},ct);
    private static void EnsureMutable(RiskAssessment item){if(item.Status is RiskStatus.Closed or RiskStatus.Archived)throw new InvalidOperationException("Closed or archived risks cannot be modified.");}
    private static void ValidateScore(int l,int s){if(l is <1 or >5 || s is <1 or >5)throw new ArgumentOutOfRangeException(nameof(l),"Likelihood and severity must be between 1 and 5.");}
    public static string Band(int score)=>score switch{>=20=>"Critical",>=10=>"High",>=5=>"Moderate",_=>"Low"};
}
