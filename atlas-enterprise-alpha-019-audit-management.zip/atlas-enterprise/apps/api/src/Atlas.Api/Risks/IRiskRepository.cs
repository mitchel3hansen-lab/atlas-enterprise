namespace Atlas.Api.Risks;

public interface IRiskRepository
{
    Task<string> NextNumberAsync(Guid tenantId, CancellationToken ct);
    Task<RiskAssessment> AddAsync(RiskAssessment risk, CancellationToken ct);
    Task<RiskAssessment?> GetAsync(Guid tenantId, Guid id, CancellationToken ct);
    Task<RiskAssessment> UpdateAsync(RiskAssessment risk, CancellationToken ct);
    Task<RiskSearchResult> SearchAsync(Guid tenantId, RiskSearchQuery query, CancellationToken ct);
    Task<RiskDashboard> DashboardAsync(Guid tenantId, DateTimeOffset now, CancellationToken ct);
}
