using System.Security.Claims;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Atlas.Api.Risks;

[ApiController,Route("api/v1/risks"),Authorize]
public sealed class RisksController(RiskService service,TenantContext tenant):ControllerBase
{
    [HttpGet,Authorize(Policy=AtlasPermissions.RisksRead)] public async Task<ActionResult<RiskSearchResult>> Search([FromQuery]RiskAssessmentType? type=null,[FromQuery]RiskStatus? status=null,[FromQuery]Guid? facilityId=null,[FromQuery]string? riskBand=null,[FromQuery]string? search=null,[FromQuery]int limit=50,[FromQuery]int offset=0,CancellationToken ct=default)=>Ok(await service.SearchAsync(tenant.TenantId,new(type,status,facilityId,riskBand,search,limit,offset),ct));
    [HttpGet("dashboard"),Authorize(Policy=AtlasPermissions.RisksRead)] public async Task<ActionResult<RiskDashboard>> Dashboard(CancellationToken ct)=>Ok(await service.DashboardAsync(tenant.TenantId,ct));
    [HttpGet("{id:guid}"),Authorize(Policy=AtlasPermissions.RisksRead)] public async Task<ActionResult<RiskAssessment>> Get(Guid id,CancellationToken ct)=>await service.GetAsync(tenant.TenantId,id,ct) is{} x?Ok(x):NotFound();
    [HttpPost,Authorize(Policy=AtlasPermissions.RisksManage)] public async Task<ActionResult<RiskAssessment>> Create(CreateRiskAssessmentRequest request,CancellationToken ct){var x=await service.CreateAsync(tenant.TenantId,Actor(),request,ct);return CreatedAtAction(nameof(Get),new{id=x.Id},x);}
    [HttpPost("{id:guid}/activate"),Authorize(Policy=AtlasPermissions.RisksManage)] public async Task<ActionResult<RiskAssessment>> Activate(Guid id,CancellationToken ct)=>Ok(await service.ActivateAsync(tenant.TenantId,id,Actor(),ct));
    [HttpPost("{id:guid}/controls"),Authorize(Policy=AtlasPermissions.RisksManage)] public async Task<ActionResult<RiskAssessment>> AddControl(Guid id,AddRiskControlRequest request,CancellationToken ct)=>Ok(await service.AddControlAsync(tenant.TenantId,id,request,ct));
    [HttpPut("{id:guid}/controls/{controlId:guid}"),Authorize(Policy=AtlasPermissions.RisksVerify)] public async Task<ActionResult<RiskAssessment>> UpdateControl(Guid id,Guid controlId,UpdateRiskControlRequest request,CancellationToken ct)=>Ok(await service.UpdateControlAsync(tenant.TenantId,id,controlId,request,ct));
    [HttpPost("{id:guid}/review"),Authorize(Policy=AtlasPermissions.RisksVerify)] public async Task<ActionResult<RiskAssessment>> Review(Guid id,ReviewRiskRequest request,CancellationToken ct)=>Ok(await service.ReviewAsync(tenant.TenantId,id,Actor(),request,ct));
    [HttpPost("{id:guid}/accept"),Authorize(Policy=AtlasPermissions.RisksAccept)] public async Task<ActionResult<RiskAssessment>> Accept(Guid id,CancellationToken ct)=>Ok(await service.AcceptAsync(tenant.TenantId,id,ct));
    private Guid Actor(){var raw=User.FindFirstValue(ClaimTypes.NameIdentifier)??User.FindFirstValue("sub");return Guid.TryParse(raw,out var id)?id:Guid.Empty;}
}
