namespace Atlas.Api.Training;

public enum CourseStatus { Draft, Active, Retired }
public enum AssignmentStatus { Assigned, InProgress, Completed, Overdue, Waived }
public enum CompetencyStatus { NotAssessed, Qualified, Expiring, Expired, Suspended }

public sealed record TrainingCourse(Guid Id, Guid TenantId, string Code, string Title, string Description, CourseStatus Status, int ValidForDays, bool RequiresAssessment, int PassingScore, DateTimeOffset CreatedAt, DateTimeOffset UpdatedAt, long Version);
public sealed record TrainingAssignment(Guid Id, Guid TenantId, Guid CourseId, Guid UserId, Guid? FacilityId, Guid? DepartmentId, AssignmentStatus Status, DateTimeOffset AssignedAt, DateTimeOffset DueAt, DateTimeOffset? CompletedAt, int? Score, string? EvidenceReference, Guid AssignedBy, DateTimeOffset UpdatedAt, long Version);
public sealed record CompetencyRecord(Guid Id, Guid TenantId, Guid UserId, Guid CourseId, CompetencyStatus Status, DateTimeOffset? QualifiedAt, DateTimeOffset? ExpiresAt, int? Score, string? EvidenceReference, DateTimeOffset UpdatedAt, long Version);
public sealed record CreateCourseRequest(string Code, string Title, string Description, int ValidForDays, bool RequiresAssessment, int PassingScore);
public sealed record AssignTrainingRequest(Guid CourseId, Guid UserId, Guid? FacilityId, Guid? DepartmentId, DateTimeOffset DueAt);
public sealed record CompleteTrainingRequest(int? Score, string? EvidenceReference);
public sealed record TrainingSearchQuery(AssignmentStatus? Status, Guid? CourseId, Guid? UserId, Guid? FacilityId, string? Search, int Limit=50, int Offset=0);
public sealed record TrainingSearchResult(IReadOnlyList<TrainingAssignment> Items, int Total, int Limit, int Offset);
public sealed record TrainingDashboard(int Assigned, int InProgress, int Completed, int Overdue, int ExpiringCompetencies, decimal CompletionRate);
