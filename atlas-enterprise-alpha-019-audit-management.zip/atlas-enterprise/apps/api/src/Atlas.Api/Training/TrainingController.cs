using System.Security.Claims;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace Atlas.Api.Training;

[ApiController,Route("api/v1/training"),Authorize]
public sealed class TrainingController(TrainingService service,TenantContext tenant):ControllerBase
{
    [HttpGet,Authorize(Policy=AtlasPermissions.TrainingRead)] public async Task<ActionResult<TrainingSearchResult>> Search([FromQuery]AssignmentStatus? status=null,[FromQuery]Guid? courseId=null,[FromQuery]Guid? userId=null,[FromQuery]Guid? facilityId=null,[FromQuery]string? search=null,[FromQuery]int limit=50,[FromQuery]int offset=0,CancellationToken ct=default)=>Ok(await service.SearchAsync(tenant.TenantId,new(status,courseId,userId,facilityId,search,limit,offset),ct));
    [HttpGet("dashboard"),Authorize(Policy=AtlasPermissions.TrainingRead)] public async Task<ActionResult<TrainingDashboard>> Dashboard(CancellationToken ct)=>Ok(await service.DashboardAsync(tenant.TenantId,ct));
    [HttpPost("courses"),Authorize(Policy=AtlasPermissions.TrainingManage)] public async Task<ActionResult<TrainingCourse>> CreateCourse(CreateCourseRequest request,CancellationToken ct)=>Ok(await service.CreateCourseAsync(tenant.TenantId,request,ct));
    [HttpPost("assignments"),Authorize(Policy=AtlasPermissions.TrainingAssign)] public async Task<ActionResult<TrainingAssignment>> Assign(AssignTrainingRequest request,CancellationToken ct)=>Ok(await service.AssignAsync(tenant.TenantId,Actor(),request,ct));
    [HttpPost("assignments/{id:guid}/start"),Authorize(Policy=AtlasPermissions.TrainingComplete)] public async Task<ActionResult<TrainingAssignment>> Start(Guid id,CancellationToken ct)=>Ok(await service.StartAsync(tenant.TenantId,id,ct));
    [HttpPost("assignments/{id:guid}/complete"),Authorize(Policy=AtlasPermissions.TrainingComplete)] public async Task<ActionResult<TrainingAssignment>> Complete(Guid id,CompleteTrainingRequest request,CancellationToken ct)=>Ok(await service.CompleteAsync(tenant.TenantId,id,request,ct));
    private Guid Actor(){var raw=User.FindFirstValue(ClaimTypes.NameIdentifier)??User.FindFirstValue("sub");return Guid.TryParse(raw,out var id)?id:Guid.Empty;}
}
