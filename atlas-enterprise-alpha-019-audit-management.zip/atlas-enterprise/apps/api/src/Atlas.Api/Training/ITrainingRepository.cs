namespace Atlas.Api.Training;

public interface ITrainingRepository
{
    Task<TrainingCourse> AddCourseAsync(TrainingCourse course, CancellationToken ct);
    Task<TrainingCourse?> GetCourseAsync(Guid tenantId, Guid id, CancellationToken ct);
    Task<TrainingAssignment> AddAssignmentAsync(TrainingAssignment assignment, CancellationToken ct);
    Task<TrainingAssignment?> GetAssignmentAsync(Guid tenantId, Guid id, CancellationToken ct);
    Task<TrainingAssignment> UpdateAssignmentAsync(TrainingAssignment assignment, CancellationToken ct);
    Task UpsertCompetencyAsync(CompetencyRecord competency, CancellationToken ct);
    Task<TrainingSearchResult> SearchAsync(Guid tenantId, TrainingSearchQuery query, CancellationToken ct);
    Task<TrainingDashboard> DashboardAsync(Guid tenantId, DateTimeOffset now, CancellationToken ct);
}
