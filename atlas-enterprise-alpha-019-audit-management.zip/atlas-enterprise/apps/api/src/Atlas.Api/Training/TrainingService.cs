namespace Atlas.Api.Training;

public sealed class TrainingService(ITrainingRepository repository)
{
    public async Task<TrainingCourse> CreateCourseAsync(Guid tenantId, CreateCourseRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Code) || string.IsNullOrWhiteSpace(request.Title)) throw new ArgumentException("Course code and title are required.");
        if (request.ValidForDays < 0) throw new ArgumentOutOfRangeException(nameof(request.ValidForDays));
        if (request.PassingScore is < 0 or > 100) throw new ArgumentOutOfRangeException(nameof(request.PassingScore));
        var now=DateTimeOffset.UtcNow;
        return await repository.AddCourseAsync(new(Guid.NewGuid(),tenantId,request.Code.Trim().ToUpperInvariant(),request.Title.Trim(),request.Description.Trim(),CourseStatus.Active,request.ValidForDays,request.RequiresAssessment,request.PassingScore,now,now,1),ct);
    }

    public async Task<TrainingAssignment> AssignAsync(Guid tenantId, Guid actorId, AssignTrainingRequest request, CancellationToken ct)
    {
        if(request.UserId==Guid.Empty) throw new ArgumentException("User is required.");
        var course=await repository.GetCourseAsync(tenantId,request.CourseId,ct)??throw new KeyNotFoundException("Training course was not found.");
        if(course.Status!=CourseStatus.Active) throw new InvalidOperationException("Only active courses may be assigned.");
        var now=DateTimeOffset.UtcNow;
        if(request.DueAt<=now) throw new ArgumentException("Due date must be in the future.");
        return await repository.AddAssignmentAsync(new(Guid.NewGuid(),tenantId,course.Id,request.UserId,request.FacilityId,request.DepartmentId,AssignmentStatus.Assigned,now,request.DueAt,null,null,null,actorId,now,1),ct);
    }

    public async Task<TrainingAssignment> StartAsync(Guid tenantId,Guid id,CancellationToken ct)
    {
        var x=await Require(tenantId,id,ct);
        if(x.Status!=AssignmentStatus.Assigned) throw new InvalidOperationException("Only assigned training may be started.");
        return await Save(x with{Status=AssignmentStatus.InProgress},ct);
    }

    public async Task<TrainingAssignment> CompleteAsync(Guid tenantId,Guid id,CompleteTrainingRequest request,CancellationToken ct)
    {
        var x=await Require(tenantId,id,ct);
        if(x.Status is AssignmentStatus.Completed or AssignmentStatus.Waived) throw new InvalidOperationException("Training is already finalized.");
        var course=await repository.GetCourseAsync(tenantId,x.CourseId,ct)??throw new KeyNotFoundException("Training course was not found.");
        if(course.RequiresAssessment && request.Score is null) throw new ArgumentException("Assessment score is required.");
        if(request.Score is <0 or >100) throw new ArgumentOutOfRangeException(nameof(request.Score));
        if(course.RequiresAssessment && request.Score<course.PassingScore) throw new InvalidOperationException("Passing score was not achieved.");
        var now=DateTimeOffset.UtcNow;
        var completed=await Save(x with{Status=AssignmentStatus.Completed,CompletedAt=now,Score=request.Score,EvidenceReference=request.EvidenceReference?.Trim()},ct);
        var expiry=course.ValidForDays>0?now.AddDays(course.ValidForDays):null;
        await repository.UpsertCompetencyAsync(new(Guid.NewGuid(),tenantId,x.UserId,x.CourseId,CompetencyStatus.Qualified,now,expiry,request.Score,request.EvidenceReference?.Trim(),now,1),ct);
        return completed;
    }

    public Task<TrainingSearchResult> SearchAsync(Guid tenantId,TrainingSearchQuery q,CancellationToken ct)=>repository.SearchAsync(tenantId,q with{Limit=Math.Clamp(q.Limit,1,200),Offset=Math.Max(0,q.Offset),Search=q.Search?.Trim()},ct);
    public Task<TrainingDashboard> DashboardAsync(Guid tenantId,CancellationToken ct)=>repository.DashboardAsync(tenantId,DateTimeOffset.UtcNow,ct);
    private async Task<TrainingAssignment> Require(Guid tenantId,Guid id,CancellationToken ct)=>await repository.GetAssignmentAsync(tenantId,id,ct)??throw new KeyNotFoundException("Training assignment was not found.");
    private Task<TrainingAssignment> Save(TrainingAssignment x,CancellationToken ct)=>repository.UpdateAssignmentAsync(x with{UpdatedAt=DateTimeOffset.UtcNow,Version=x.Version+1},ct);
}
