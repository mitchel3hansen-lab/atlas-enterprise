namespace Atlas.Api.OperationalKnowledge;

public interface IOperationalKnowledgeRepository
{
    Task<LessonLearned> AddLessonAsync(LessonLearned lesson, CancellationToken ct);
    Task<LessonLearned?> GetLessonAsync(Guid tenantId, Guid id, CancellationToken ct);
    Task<KnowledgeSearchResult> SearchLessonsAsync(Guid tenantId, KnowledgeSearchQuery query, CancellationToken ct);
    Task<IReadOnlyList<LessonLearned>> FindLessonsForObjectsAsync(Guid tenantId, IReadOnlyList<Guid> objectIds, CancellationToken ct);
    Task<IReadOnlyList<SimilarRecord>> FindSimilarAsync(Guid tenantId, string objectType, Guid objectId, int limit, CancellationToken ct);
    Task<IReadOnlyDictionary<string, int>> GetRelationshipCountsAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken ct);
}
