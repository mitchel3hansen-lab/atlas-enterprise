using System.Security.Claims;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Atlas.Api.OperationalKnowledge;

[ApiController]
[Route("api/v1/knowledge")]
[Authorize]
public sealed class OperationalKnowledgeController(OperationalKnowledgeService service, TenantContext tenantContext) : ControllerBase
{
    [HttpGet("context/{objectType}/{objectId:guid}")]
    [Authorize(Policy = AtlasPermissions.IncidentsRead)]
    public async Task<ActionResult<KnowledgeContext>> Context(string objectType, Guid objectId, CancellationToken ct)
        => Ok(await service.BuildContextAsync(tenantContext.TenantId, objectType, objectId, ct));

    [HttpGet("lessons")]
    [Authorize(Policy = AtlasPermissions.IncidentsRead)]
    public async Task<ActionResult<KnowledgeSearchResult>> Search(
        [FromQuery] string? search = null,
        [FromQuery] string? objectType = null,
        [FromQuery] LessonStatus? status = null,
        [FromQuery] int limit = 50,
        [FromQuery] int offset = 0,
        CancellationToken ct = default)
        => Ok(await service.SearchAsync(tenantContext.TenantId, new(search, objectType, status, limit, offset), ct));

    [HttpPost("lessons")]
    [Authorize(Policy = AtlasPermissions.IncidentsManage)]
    public async Task<ActionResult<LessonLearned>> Create(CreateLessonRequest request, CancellationToken ct)
    {
        var created = await service.CreateLessonAsync(tenantContext.TenantId, ActorId(), request, ct);
        return CreatedAtAction(nameof(Search), new { search = created.Title }, created);
    }

    private Guid ActorId()
    {
        var raw = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub");
        return Guid.TryParse(raw, out var id) ? id : Guid.Empty;
    }
}
