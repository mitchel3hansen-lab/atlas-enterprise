namespace Atlas.Api.OperationalKnowledge;

public enum LessonStatus { Draft, Published, Retired }
public enum RecommendationPriority { Low, Moderate, High, Critical }

public sealed record LessonLearned(
    Guid Id,
    Guid TenantId,
    Guid? OrganizationId,
    string Title,
    string Summary,
    string RootCause,
    IReadOnlyList<string> EffectiveControls,
    IReadOnlyList<string> ApplicableObjectTypes,
    IReadOnlyList<Guid> SourceObjectIds,
    LessonStatus Status,
    Guid CreatedBy,
    DateTimeOffset CreatedAt,
    DateTimeOffset UpdatedAt,
    long Version);

public sealed record CreateLessonRequest(
    string Title,
    string Summary,
    string RootCause,
    IReadOnlyList<string>? EffectiveControls,
    IReadOnlyList<string>? ApplicableObjectTypes,
    IReadOnlyList<Guid>? SourceObjectIds,
    Guid? OrganizationId,
    bool Publish = false);

public sealed record KnowledgeEvidence(
    string ObjectType,
    Guid ObjectId,
    string DisplayName,
    decimal Relevance,
    string Reason);

public sealed record KnowledgeRecommendation(
    Guid Id,
    string Title,
    string Rationale,
    RecommendationPriority Priority,
    decimal Confidence,
    IReadOnlyList<KnowledgeEvidence> Evidence,
    IReadOnlyList<string> SuggestedActions,
    bool RequiresHumanReview = true);

public sealed record SimilarRecord(
    Guid ObjectId,
    string ObjectType,
    string DisplayName,
    decimal Similarity,
    IReadOnlyList<string> SharedSignals,
    IReadOnlyList<Guid> SupportingEvidenceIds);

public sealed record KnowledgeContext(
    Guid ObjectId,
    string ObjectType,
    IReadOnlyList<SimilarRecord> SimilarRecords,
    IReadOnlyList<LessonLearned> Lessons,
    IReadOnlyList<KnowledgeRecommendation> Recommendations,
    IReadOnlyDictionary<string, int> RelationshipCounts,
    DateTimeOffset GeneratedAt);

public sealed record KnowledgeSearchQuery(
    string? Search,
    string? ObjectType,
    LessonStatus? Status,
    int Limit = 50,
    int Offset = 0);

public sealed record KnowledgeSearchResult(IReadOnlyList<LessonLearned> Items, int Total, int Limit, int Offset);
