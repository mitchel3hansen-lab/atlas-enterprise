namespace Atlas.Api.OperationalKnowledge;

public sealed class OperationalKnowledgeService(IOperationalKnowledgeRepository repository)
{
    public async Task<LessonLearned> CreateLessonAsync(Guid tenantId, Guid actorId, CreateLessonRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Title)) throw new ArgumentException("Title is required.");
        if (string.IsNullOrWhiteSpace(request.Summary)) throw new ArgumentException("Summary is required.");
        if (string.IsNullOrWhiteSpace(request.RootCause)) throw new ArgumentException("Root cause is required.");

        static IReadOnlyList<string> Clean(IReadOnlyList<string>? values) =>
            (values ?? Array.Empty<string>()).Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).Take(50).ToArray();

        var now = DateTimeOffset.UtcNow;
        var lesson = new LessonLearned(
            Guid.NewGuid(), tenantId, request.OrganizationId, request.Title.Trim(), request.Summary.Trim(),
            request.RootCause.Trim(), Clean(request.EffectiveControls), Clean(request.ApplicableObjectTypes),
            (request.SourceObjectIds ?? Array.Empty<Guid>()).Distinct().Take(100).ToArray(),
            request.Publish ? LessonStatus.Published : LessonStatus.Draft,
            actorId, now, now, 1);

        return await repository.AddLessonAsync(lesson, ct);
    }

    public Task<KnowledgeSearchResult> SearchAsync(Guid tenantId, KnowledgeSearchQuery query, CancellationToken ct)
    {
        if (query.Limit is < 1 or > 200) throw new ArgumentOutOfRangeException(nameof(query.Limit));
        if (query.Offset < 0) throw new ArgumentOutOfRangeException(nameof(query.Offset));
        return repository.SearchLessonsAsync(tenantId, query, ct);
    }

    public async Task<KnowledgeContext> BuildContextAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(objectType)) throw new ArgumentException("Object type is required.");
        var similar = await repository.FindSimilarAsync(tenantId, objectType.Trim(), objectId, 8, ct);
        var connectedIds = similar.Select(x => x.ObjectId).Append(objectId).Distinct().ToArray();
        var lessons = await repository.FindLessonsForObjectsAsync(tenantId, connectedIds, ct);
        var counts = await repository.GetRelationshipCountsAsync(tenantId, objectType.Trim(), objectId, ct);
        var recommendations = BuildRecommendations(similar, lessons);
        return new(objectId, objectType.Trim(), similar, lessons, recommendations, counts, DateTimeOffset.UtcNow);
    }

    private static IReadOnlyList<KnowledgeRecommendation> BuildRecommendations(
        IReadOnlyList<SimilarRecord> similar,
        IReadOnlyList<LessonLearned> lessons)
    {
        var results = new List<KnowledgeRecommendation>();
        var recurringSignals = similar.SelectMany(x => x.SharedSignals)
            .GroupBy(x => x, StringComparer.OrdinalIgnoreCase)
            .Where(x => x.Count() >= 2)
            .OrderByDescending(x => x.Count()).Take(3).ToArray();

        if (recurringSignals.Length > 0)
        {
            var confidence = Math.Min(0.95m, 0.60m + recurringSignals.Sum(x => x.Count()) * 0.04m);
            results.Add(new(
                Guid.NewGuid(),
                "Review recurring operational signals",
                $"{recurringSignals.Length} signals recur across related records and may indicate a systemic condition.",
                confidence >= 0.85m ? RecommendationPriority.High : RecommendationPriority.Moderate,
                confidence,
                similar.Take(5).Select(x => new KnowledgeEvidence(x.ObjectType, x.ObjectId, x.DisplayName, x.Similarity,
                    string.Join(", ", x.SharedSignals))).ToArray(),
                new[] { "Validate the recurring signals with operational owners", "Review existing controls for effectiveness", "Document the decision and verification date" }));
        }

        if (lessons.Count > 0)
        {
            var published = lessons.Where(x => x.Status == LessonStatus.Published).ToArray();
            if (published.Length > 0)
                results.Add(new(Guid.NewGuid(), "Apply relevant lessons learned",
                    $"{published.Length} published lesson(s) are connected to this operational context.",
                    RecommendationPriority.Moderate, 0.82m,
                    published.Take(5).Select(x => new KnowledgeEvidence("LessonLearned", x.Id, x.Title, 0.82m, x.RootCause)).ToArray(),
                    published.SelectMany(x => x.EffectiveControls).Distinct(StringComparer.OrdinalIgnoreCase).Take(6).ToArray()));
        }

        return results;
    }
}
