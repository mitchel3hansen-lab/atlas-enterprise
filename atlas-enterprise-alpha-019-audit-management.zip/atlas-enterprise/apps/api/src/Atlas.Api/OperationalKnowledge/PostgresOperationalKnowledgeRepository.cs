using System.Text.Json;
using Npgsql;
using NpgsqlTypes;

namespace Atlas.Api.OperationalKnowledge;

public sealed class PostgresOperationalKnowledgeRepository(IConfiguration configuration) : IOperationalKnowledgeRepository
{
    private string ConnectionString => configuration.GetConnectionString("Atlas") ?? throw new InvalidOperationException("ConnectionStrings:Atlas is required.");

    public async Task<LessonLearned> AddLessonAsync(LessonLearned x, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = new NpgsqlCommand("""INSERT INTO atlas.lessons_learned(id,tenant_id,organization_id,title,summary,root_cause,effective_controls,applicable_object_types,source_object_ids,status,created_by,created_at,updated_at,version) VALUES(@id,@tenant,@organization,@title,@summary,@rootCause,@controls,@types,@sources,@status,@createdBy,@createdAt,@updatedAt,@version)""", connection);
        command.Parameters.AddWithValue("id", x.Id); command.Parameters.AddWithValue("tenant", x.TenantId);
        command.Parameters.AddWithValue("organization", (object?)x.OrganizationId ?? DBNull.Value);
        command.Parameters.AddWithValue("title", x.Title); command.Parameters.AddWithValue("summary", x.Summary);
        command.Parameters.AddWithValue("rootCause", x.RootCause);
        command.Parameters.Add(new NpgsqlParameter("controls", NpgsqlDbType.Jsonb) { Value = JsonSerializer.Serialize(x.EffectiveControls) });
        command.Parameters.Add(new NpgsqlParameter("types", NpgsqlDbType.Jsonb) { Value = JsonSerializer.Serialize(x.ApplicableObjectTypes) });
        command.Parameters.Add(new NpgsqlParameter("sources", NpgsqlDbType.Array | NpgsqlDbType.Uuid) { Value = x.SourceObjectIds.ToArray() });
        command.Parameters.AddWithValue("status", x.Status.ToString()); command.Parameters.AddWithValue("createdBy", x.CreatedBy);
        command.Parameters.AddWithValue("createdAt", x.CreatedAt); command.Parameters.AddWithValue("updatedAt", x.UpdatedAt); command.Parameters.AddWithValue("version", x.Version);
        await command.ExecuteNonQueryAsync(ct); return x;
    }

    public async Task<LessonLearned?> GetLessonAsync(Guid tenantId, Guid id, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = new NpgsqlCommand("SELECT * FROM atlas.lessons_learned WHERE tenant_id=@tenant AND id=@id", connection);
        command.Parameters.AddWithValue("tenant", tenantId); command.Parameters.AddWithValue("id", id);
        await using var reader = await command.ExecuteReaderAsync(ct);
        return await reader.ReadAsync(ct) ? Map(reader) : null;
    }

    public async Task<KnowledgeSearchResult> SearchLessonsAsync(Guid tenantId, KnowledgeSearchQuery query, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        var clauses = new List<string> { "tenant_id=@tenant" };
        await using var command = new NpgsqlCommand { Connection = connection };
        command.Parameters.AddWithValue("tenant", tenantId);
        if (!string.IsNullOrWhiteSpace(query.Search)) { clauses.Add("search_document @@ websearch_to_tsquery('simple', @search)"); command.Parameters.AddWithValue("search", query.Search.Trim()); }
        if (query.Status is not null) { clauses.Add("status=@status"); command.Parameters.AddWithValue("status", query.Status.ToString()!); }
        if (!string.IsNullOrWhiteSpace(query.ObjectType)) { clauses.Add("applicable_object_types @> @objectType::jsonb"); command.Parameters.AddWithValue("objectType", JsonSerializer.Serialize(new[] { query.ObjectType.Trim() })); }
        var where = string.Join(" AND ", clauses);
        command.CommandText = $"SELECT *, count(*) OVER()::int AS total_count FROM atlas.lessons_learned WHERE {where} ORDER BY updated_at DESC LIMIT @limit OFFSET @offset";
        command.Parameters.AddWithValue("limit", query.Limit); command.Parameters.AddWithValue("offset", query.Offset);
        var items = new List<LessonLearned>(); var total = 0;
        await using var reader = await command.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) { items.Add(Map(reader)); total = reader.GetInt32(reader.GetOrdinal("total_count")); }
        return new(items, total, query.Limit, query.Offset);
    }

    public async Task<IReadOnlyList<LessonLearned>> FindLessonsForObjectsAsync(Guid tenantId, IReadOnlyList<Guid> objectIds, CancellationToken ct)
    {
        if (objectIds.Count == 0) return Array.Empty<LessonLearned>();
        await using var connection = await OpenAsync(ct);
        await using var command = new NpgsqlCommand("SELECT * FROM atlas.lessons_learned WHERE tenant_id=@tenant AND source_object_ids && @ids ORDER BY status='Published' DESC, updated_at DESC LIMIT 20", connection);
        command.Parameters.AddWithValue("tenant", tenantId);
        command.Parameters.Add(new NpgsqlParameter("ids", NpgsqlDbType.Array | NpgsqlDbType.Uuid) { Value = objectIds.ToArray() });
        var items = new List<LessonLearned>(); await using var reader = await command.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) items.Add(Map(reader)); return items;
    }

    public async Task<IReadOnlyList<SimilarRecord>> FindSimilarAsync(Guid tenantId, string objectType, Guid objectId, int limit, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = new NpgsqlCommand("SELECT candidate_object_id,candidate_object_type,candidate_display_name,similarity,shared_signals,supporting_evidence_ids FROM atlas.find_similar_operational_records(@tenant,@objectType,@objectId,@limit)", connection);
        command.Parameters.AddWithValue("tenant", tenantId); command.Parameters.AddWithValue("objectType", objectType); command.Parameters.AddWithValue("objectId", objectId); command.Parameters.AddWithValue("limit", limit);
        var items = new List<SimilarRecord>(); await using var reader = await command.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) items.Add(new(reader.GetGuid(0), reader.GetString(1), reader.GetString(2), reader.GetDecimal(3),
            JsonSerializer.Deserialize<string[]>(reader.GetString(4)) ?? Array.Empty<string>(), reader.GetFieldValue<Guid[]>(5)));
        return items;
    }

    public async Task<IReadOnlyDictionary<string, int>> GetRelationshipCountsAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = new NpgsqlCommand("""SELECT object_type, count(*)::int FROM (SELECT n.object_type FROM atlas.knowledge_nodes root JOIN atlas.knowledge_edges e ON e.tenant_id=root.tenant_id AND (e.source_node_id=root.id OR e.target_node_id=root.id) JOIN atlas.knowledge_nodes n ON n.tenant_id=root.tenant_id AND n.id=CASE WHEN e.source_node_id=root.id THEN e.target_node_id ELSE e.source_node_id END WHERE root.tenant_id=@tenant AND root.object_type=@objectType AND root.object_id=@objectId AND e.valid_to IS NULL) connected GROUP BY object_type""", connection);
        command.Parameters.AddWithValue("tenant", tenantId); command.Parameters.AddWithValue("objectType", objectType); command.Parameters.AddWithValue("objectId", objectId);
        var result = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase); await using var reader = await command.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) result[reader.GetString(0)] = reader.GetInt32(1); return result;
    }

    private async Task<NpgsqlConnection> OpenAsync(CancellationToken ct) { var c = new NpgsqlConnection(ConnectionString); await c.OpenAsync(ct); return c; }
    private static LessonLearned Map(NpgsqlDataReader r) => new(
        r.GetGuid(r.GetOrdinal("id")), r.GetGuid(r.GetOrdinal("tenant_id")), r.IsDBNull(r.GetOrdinal("organization_id")) ? null : r.GetGuid(r.GetOrdinal("organization_id")),
        r.GetString(r.GetOrdinal("title")), r.GetString(r.GetOrdinal("summary")), r.GetString(r.GetOrdinal("root_cause")),
        JsonSerializer.Deserialize<string[]>(r.GetString(r.GetOrdinal("effective_controls"))) ?? Array.Empty<string>(),
        JsonSerializer.Deserialize<string[]>(r.GetString(r.GetOrdinal("applicable_object_types"))) ?? Array.Empty<string>(),
        r.GetFieldValue<Guid[]>(r.GetOrdinal("source_object_ids")), Enum.Parse<LessonStatus>(r.GetString(r.GetOrdinal("status")), true),
        r.GetGuid(r.GetOrdinal("created_by")), r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("created_at")), r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("updated_at")), r.GetInt64(r.GetOrdinal("version")));
}
