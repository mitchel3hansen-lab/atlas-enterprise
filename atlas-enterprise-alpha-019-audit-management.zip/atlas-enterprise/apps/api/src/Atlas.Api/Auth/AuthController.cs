using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Atlas.Api.Domain;
using Atlas.Api.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace Atlas.Api.Auth;

[ApiController]
[Route("api/v1/auth")]
public sealed class AuthController(
    AtlasDbContext db,
    PasswordService passwords,
    PasswordPolicy passwordPolicy,
    TokenService tokens,
    RefreshTokenService refreshTokens,
    IOptions<AuthSecurityOptions> securityOptions,
    IWebHostEnvironment environment) : ControllerBase
{
    private readonly AuthSecurityOptions _security = securityOptions.Value;

    [AllowAnonymous]
    [HttpPost("login")]
    public async Task<ActionResult<LoginResponse>> Login(LoginRequest request, CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;
        var normalizedEmail = request.Email.Trim().ToUpperInvariant();
        var user = await db.Users.SingleOrDefaultAsync(x => x.NormalizedEmail == normalizedEmail, cancellationToken);

        if (user?.LockedUntilUtc > now)
            return StatusCode(StatusCodes.Status423Locked, new ProblemDetails { Title = "Account temporarily locked" });

        if (user is null || !user.IsActive || !passwords.Verify(request.Password, user.PasswordHash))
        {
            if (user is not null)
            {
                user.FailedLoginCount++;
                if (user.FailedLoginCount >= _security.MaximumFailedAttempts)
                {
                    user.LockedUntilUtc = now.AddMinutes(_security.LockoutMinutes);
                    user.FailedLoginCount = 0;
                }
                await db.SaveChangesAsync(cancellationToken);
            }
            return Unauthorized(new ProblemDetails { Title = "Invalid credentials" });
        }

        var membership = await db.OrganizationMemberships.SingleOrDefaultAsync(
            x => x.UserId == user.Id && x.OrganizationId == request.OrganizationId && x.IsActive,
            cancellationToken);
        if (membership is null)
            return Forbid();

        var (roles, permissions) = await ResolveAccess(membership.Id, cancellationToken);
        var accessToken = tokens.Create(user, membership, roles, permissions);
        var refresh = refreshTokens.Create();
        var refreshSession = new RefreshSession
        {
            Id = Guid.NewGuid(),
            OrganizationId = membership.OrganizationId,
            UserId = user.Id,
            MembershipId = membership.Id,
            TokenHash = refresh.Hash,
            JwtId = accessToken.JwtId,
            CreatedAtUtc = now,
            ExpiresAtUtc = now.AddDays(_security.RefreshTokenLifetimeDays),
            CreatedByIp = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown"
        };
        user.FailedLoginCount = 0;
        user.LockedUntilUtc = null;
        user.LastLoginAtUtc = now;
        db.RefreshSessions.Add(refreshSession);
        await db.SaveChangesAsync(cancellationToken);

        return Ok(new LoginResponse(accessToken.Value, refresh.PlainText, "Bearer", accessToken.ExpiresAtUtc,
            user.Id, membership.OrganizationId, roles, permissions));
    }

    [AllowAnonymous]
    [HttpPost("refresh")]
    public async Task<ActionResult<LoginResponse>> Refresh(RefreshRequest request, CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;
        var hash = refreshTokens.Hash(request.RefreshToken);
        var session = await db.RefreshSessions.SingleOrDefaultAsync(x => x.TokenHash == hash, cancellationToken);
        if (session is null || session.RevokedAtUtc is not null || session.ExpiresAtUtc <= now)
            return Unauthorized(new ProblemDetails { Title = "Invalid refresh token" });

        var user = await db.Users.SingleOrDefaultAsync(x => x.Id == session.UserId && x.IsActive, cancellationToken);
        var membership = await db.OrganizationMemberships.SingleOrDefaultAsync(
            x => x.Id == session.MembershipId && x.IsActive, cancellationToken);
        if (user is null || membership is null)
            return Unauthorized(new ProblemDetails { Title = "Session is no longer valid" });

        var (roles, permissions) = await ResolveAccess(membership.Id, cancellationToken);
        var accessToken = tokens.Create(user, membership, roles, permissions);
        var replacement = refreshTokens.Create();

        session.LastUsedAtUtc = now;
        session.RevokedAtUtc = now;
        session.ReplacedByTokenHash = replacement.Hash;
        db.RefreshSessions.Add(new RefreshSession
        {
            Id = Guid.NewGuid(), OrganizationId = session.OrganizationId, UserId = session.UserId,
            MembershipId = session.MembershipId, TokenHash = replacement.Hash, JwtId = accessToken.JwtId,
            CreatedAtUtc = now, ExpiresAtUtc = now.AddDays(_security.RefreshTokenLifetimeDays),
            CreatedByIp = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown"
        });
        await db.SaveChangesAsync(cancellationToken);

        return Ok(new LoginResponse(accessToken.Value, replacement.PlainText, "Bearer", accessToken.ExpiresAtUtc,
            user.Id, membership.OrganizationId, roles, permissions));
    }

    [Authorize]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout(CancellationToken cancellationToken)
    {
        var jwtId = User.FindFirstValue(JwtRegisteredClaimNames.Jti);
        var userId = Guid.Parse(User.FindFirstValue(JwtRegisteredClaimNames.Sub)!);
        var organizationId = Guid.Parse(User.FindFirstValue("organization_id")!);
        var expiration = long.TryParse(User.FindFirstValue(JwtRegisteredClaimNames.Exp), out var seconds)
            ? DateTimeOffset.FromUnixTimeSeconds(seconds)
            : DateTimeOffset.UtcNow.AddHours(1);

        if (!string.IsNullOrWhiteSpace(jwtId) && !await db.RevokedSessions.AnyAsync(x => x.JwtId == jwtId, cancellationToken))
            db.RevokedSessions.Add(new RevokedSession { Id = Guid.NewGuid(), OrganizationId = organizationId, UserId = userId, JwtId = jwtId, ExpiresAtUtc = expiration, RevokedAtUtc = DateTimeOffset.UtcNow });

        var sessions = await db.RefreshSessions
            .Where(x => x.UserId == userId && x.OrganizationId == organizationId && x.RevokedAtUtc == null)
            .ToListAsync(cancellationToken);
        foreach (var session in sessions)
            session.RevokedAtUtc = DateTimeOffset.UtcNow;

        await db.SaveChangesAsync(cancellationToken);
        return NoContent();
    }

    [AllowAnonymous]
    [HttpPost("development/bootstrap")]
    public async Task<ActionResult<DevelopmentBootstrapResponse>> DevelopmentBootstrap(
        DevelopmentBootstrapRequest request,
        CancellationToken cancellationToken)
    {
        if (!environment.IsDevelopment()) return NotFound();
        var validation = passwordPolicy.Validate(request.Password);
        if (validation.IsFailure)
            return BadRequest(new ProblemDetails { Title = validation.Error.Description });

        var now = DateTimeOffset.UtcNow;
        var organization = new Organization(Guid.NewGuid(), request.OrganizationName.Trim(), request.OrganizationSlug.Trim().ToLowerInvariant(), now);
        var user = new AtlasUser { Id = Guid.NewGuid(), Email = request.Email.Trim(), NormalizedEmail = request.Email.Trim().ToUpperInvariant(), DisplayName = request.DisplayName.Trim(), PasswordHash = passwords.Hash(request.Password), PasswordChangedAtUtc = now, CreatedAtUtc = now };
        var membership = new OrganizationMembership { Id = Guid.NewGuid(), OrganizationId = organization.Id, UserId = user.Id, CreatedAtUtc = now };
        var adminRole = new Role { Id = Guid.NewGuid(), OrganizationId = organization.Id, Name = "Organization Administrator", NormalizedName = "ORGANIZATION ADMINISTRATOR", IsSystemRole = false };

        db.Organizations.Add(organization); db.Users.Add(user); db.OrganizationMemberships.Add(membership); db.Roles.Add(adminRole);
        foreach (var code in Security.AtlasPermissions.All)
        {
            var permission = await db.Permissions.SingleOrDefaultAsync(x => x.Code == code, cancellationToken)
                ?? new Permission { Id = Guid.NewGuid(), Code = code, Description = code };
            if (db.Entry(permission).State == EntityState.Detached) db.Permissions.Add(permission);
            db.RolePermissions.Add(new RolePermission { RoleId = adminRole.Id, PermissionId = permission.Id });
        }
        db.MembershipRoles.Add(new MembershipRole { MembershipId = membership.Id, RoleId = adminRole.Id });
        await db.SaveChangesAsync(cancellationToken);
        return Created(string.Empty, new DevelopmentBootstrapResponse(organization.Id, user.Id, request.Email));
    }

    private async Task<(IReadOnlyList<string> Roles, IReadOnlyList<string> Permissions)> ResolveAccess(Guid membershipId, CancellationToken cancellationToken)
    {
        var roleIds = await db.MembershipRoles.Where(x => x.MembershipId == membershipId).Select(x => x.RoleId).ToListAsync(cancellationToken);
        var roles = await db.Roles.Where(x => roleIds.Contains(x.Id)).Select(x => x.Name).ToListAsync(cancellationToken);
        var permissions = await (from rp in db.RolePermissions join p in db.Permissions on rp.PermissionId equals p.Id where roleIds.Contains(rp.RoleId) select p.Code).Distinct().ToListAsync(cancellationToken);
        return (roles, permissions);
    }
}

public sealed record LoginRequest(string Email, string Password, Guid OrganizationId);
public sealed record RefreshRequest(string RefreshToken);
public sealed record LoginResponse(string AccessToken, string RefreshToken, string TokenType, DateTimeOffset ExpiresAtUtc, Guid UserId, Guid OrganizationId, IReadOnlyList<string> Roles, IReadOnlyList<string> Permissions);
public sealed record DevelopmentBootstrapRequest(string OrganizationName, string OrganizationSlug, string DisplayName, string Email, string Password);
public sealed record DevelopmentBootstrapResponse(Guid OrganizationId, Guid UserId, string Email);
