using Atlas.SharedKernel.Errors;
using Atlas.SharedKernel.Results;

namespace Atlas.Api.Auth;

public sealed class PasswordPolicy
{
    public const int MinimumLength = 12;

    public Result Validate(string? password)
    {
        if (string.IsNullOrWhiteSpace(password))
            return Result.Failure(Error.Validation("auth.password.required", "Password is required."));
        if (password.Length < MinimumLength)
            return Result.Failure(Error.Validation("auth.password.length", $"Password must be at least {MinimumLength} characters."));
        if (!password.Any(char.IsUpper))
            return Result.Failure(Error.Validation("auth.password.uppercase", "Password must contain an uppercase letter."));
        if (!password.Any(char.IsLower))
            return Result.Failure(Error.Validation("auth.password.lowercase", "Password must contain a lowercase letter."));
        if (!password.Any(char.IsDigit))
            return Result.Failure(Error.Validation("auth.password.number", "Password must contain a number."));
        if (!password.Any(ch => !char.IsLetterOrDigit(ch)))
            return Result.Failure(Error.Validation("auth.password.symbol", "Password must contain a symbol."));

        return Result.Success();
    }
}
