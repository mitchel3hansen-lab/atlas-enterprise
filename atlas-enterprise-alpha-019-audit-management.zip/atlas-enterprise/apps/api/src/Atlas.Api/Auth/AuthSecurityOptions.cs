namespace Atlas.Api.Auth;

public sealed class AuthSecurityOptions
{
    public const string SectionName = "AuthSecurity";
    public int MaximumFailedAttempts { get; init; } = 5;
    public int LockoutMinutes { get; init; } = 15;
    public int RefreshTokenLifetimeDays { get; init; } = 14;
}
