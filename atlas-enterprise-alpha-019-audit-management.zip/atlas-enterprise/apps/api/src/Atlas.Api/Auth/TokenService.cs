using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Atlas.Api.Domain;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace Atlas.Api.Auth;

public sealed record AccessToken(string Value, string JwtId, DateTimeOffset ExpiresAtUtc);

public sealed class TokenService(IOptions<JwtOptions> options)
{
    private readonly JwtOptions _options = options.Value;

    public AccessToken Create(
        AtlasUser user,
        OrganizationMembership membership,
        IEnumerable<string> roles,
        IEnumerable<string> permissions)
    {
        var jwtId = Guid.NewGuid().ToString("N");
        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Jti, jwtId),
            new(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new(JwtRegisteredClaimNames.Email, user.Email),
            new("name", user.DisplayName),
            new("organization_id", membership.OrganizationId.ToString()),
            new("membership_id", membership.Id.ToString())
        };
        claims.AddRange(roles.Distinct().Select(x => new Claim(ClaimTypes.Role, x)));
        claims.AddRange(permissions.Distinct().Select(x => new Claim("permission", x)));

        var credentials = new SigningCredentials(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_options.SigningKey)),
            SecurityAlgorithms.HmacSha256);
        var now = DateTimeOffset.UtcNow;
        var expires = now.AddMinutes(_options.LifetimeMinutes);
        var token = new JwtSecurityToken(
            _options.Issuer,
            _options.Audience,
            claims,
            notBefore: now.UtcDateTime,
            expires: expires.UtcDateTime,
            signingCredentials: credentials);
        return new AccessToken(new JwtSecurityTokenHandler().WriteToken(token), jwtId, expires);
    }
}
