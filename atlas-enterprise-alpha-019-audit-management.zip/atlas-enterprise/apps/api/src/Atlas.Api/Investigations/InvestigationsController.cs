using System.Security.Claims;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Atlas.Api.Investigations;

[ApiController, Route("api/v1/incidents/{incidentId:guid}/investigation")]
public sealed class InvestigationsController(InvestigationService service,TenantContext tenant):ControllerBase
{
    [HttpGet,Authorize(Policy=AtlasPermissions.IncidentsRead)] public async Task<ActionResult<InvestigationWorkspace>> Get(Guid incidentId,CancellationToken ct)=>Ok(await service.GetAsync(tenant.TenantId,incidentId,ct));
    [HttpPost("start"),Authorize(Policy=AtlasPermissions.IncidentsTransition)] public async Task<ActionResult<InvestigationWorkspace>> Start(Guid incidentId,StartInvestigationRequest r,CancellationToken ct)=>Ok(await service.StartAsync(tenant.TenantId,incidentId,Actor(),User.Identity?.Name,r,HttpContext.TraceIdentifier,ct));
    [HttpPost("notes"),Authorize(Policy=AtlasPermissions.IncidentsManage)] public async Task<ActionResult<InvestigationNoteRecord>> Note(Guid incidentId,AddInvestigationNoteRequest r,CancellationToken ct)=>Ok(await service.AddNoteAsync(tenant.TenantId,incidentId,Actor(),User.Identity?.Name,r,HttpContext.TraceIdentifier,ct));
    [HttpPost("witnesses"),Authorize(Policy=AtlasPermissions.IncidentsManage)] public async Task<ActionResult<WitnessRecord>> Witness(Guid incidentId,AddWitnessRequest r,CancellationToken ct)=>Ok(await service.AddWitnessAsync(tenant.TenantId,incidentId,Actor(),User.Identity?.Name,r,HttpContext.TraceIdentifier,ct));
    [HttpPut("root-cause/five-whys"),Authorize(Policy=AtlasPermissions.IncidentsManage)] public async Task<ActionResult<RootCauseRecord>> FiveWhys(Guid incidentId,SaveFiveWhysRequest r,CancellationToken ct)=>Ok(await service.SaveFiveWhysAsync(tenant.TenantId,incidentId,Actor(),User.Identity?.Name,r,HttpContext.TraceIdentifier,ct));
    [HttpPut("root-cause/fishbone"),Authorize(Policy=AtlasPermissions.IncidentsManage)] public async Task<ActionResult<RootCauseRecord>> Fishbone(Guid incidentId,SaveFishboneRequest r,CancellationToken ct)=>Ok(await service.SaveFishboneAsync(tenant.TenantId,incidentId,Actor(),User.Identity?.Name,r,HttpContext.TraceIdentifier,ct));
    [HttpPost("corrective-actions"),Authorize(Policy=AtlasPermissions.IncidentsManage)] public async Task<ActionResult<CorrectiveActionRecord>> CreateAction(Guid incidentId,CreateCorrectiveActionRequest r,CancellationToken ct)=>Ok(await service.CreateActionAsync(tenant.TenantId,incidentId,Actor(),User.Identity?.Name,r,HttpContext.TraceIdentifier,ct));
    [HttpPut("corrective-actions/{actionId:guid}"),Authorize(Policy=AtlasPermissions.IncidentsManage)] public async Task<ActionResult<CorrectiveActionRecord>> UpdateAction(Guid incidentId,Guid actionId,UpdateCorrectiveActionRequest r,CancellationToken ct)=>Ok(await service.UpdateActionAsync(tenant.TenantId,incidentId,actionId,Actor(),User.Identity?.Name,r,HttpContext.TraceIdentifier,ct));
    [HttpPost("advance"),Authorize(Policy=AtlasPermissions.IncidentsTransition)] public async Task<ActionResult<InvestigationRecord>> Advance(Guid incidentId,AdvanceInvestigationRequest r,CancellationToken ct)=>Ok(await service.AdvanceAsync(tenant.TenantId,incidentId,Actor(),User.Identity?.Name,r,HttpContext.TraceIdentifier,ct));
    private Guid Actor(){var raw=User.FindFirstValue(ClaimTypes.NameIdentifier)??User.FindFirstValue("sub");return Guid.TryParse(raw,out var id)?id:Guid.Empty;}
}
