namespace Atlas.Api.Investigations;

public interface IInvestigationRepository
{
    Task<InvestigationRecord?> GetByIncidentAsync(Guid tenantId, Guid incidentId, CancellationToken ct);
    Task<InvestigationRecord> AddAsync(InvestigationRecord record, CancellationToken ct);
    Task<InvestigationRecord> ReplaceAsync(InvestigationRecord record, long expectedVersion, CancellationToken ct);
    Task AddNoteAsync(InvestigationNoteRecord note, CancellationToken ct);
    Task AddWitnessAsync(WitnessRecord witness, CancellationToken ct);
    Task UpsertRootCauseAsync(RootCauseRecord rootCause, CancellationToken ct);
    Task<CorrectiveActionRecord> AddActionAsync(CorrectiveActionRecord action, CancellationToken ct);
    Task<CorrectiveActionRecord?> GetActionAsync(Guid tenantId, Guid actionId, CancellationToken ct);
    Task<CorrectiveActionRecord> ReplaceActionAsync(CorrectiveActionRecord action, long expectedVersion, CancellationToken ct);
    Task<IReadOnlyList<InvestigationNoteRecord>> GetNotesAsync(Guid tenantId, Guid investigationId, CancellationToken ct);
    Task<IReadOnlyList<WitnessRecord>> GetWitnessesAsync(Guid tenantId, Guid investigationId, CancellationToken ct);
    Task<RootCauseRecord?> GetRootCauseAsync(Guid tenantId, Guid investigationId, CancellationToken ct);
    Task<IReadOnlyList<CorrectiveActionRecord>> GetActionsAsync(Guid tenantId, Guid investigationId, CancellationToken ct);
    Task<int> NextActionSequenceAsync(Guid tenantId, int year, CancellationToken ct);
}
