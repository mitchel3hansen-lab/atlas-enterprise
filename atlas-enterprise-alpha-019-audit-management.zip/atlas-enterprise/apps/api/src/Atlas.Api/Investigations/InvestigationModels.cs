namespace Atlas.Api.Investigations;

public enum InvestigationStage { Assigned, Started, EvidenceCollection, RootCauseAnalysis, CorrectiveActions, Verification, ManagementReview, Completed }
public enum RootCauseMethod { FiveWhys, Fishbone }
public enum CorrectiveActionStatus { Open, InProgress, ReadyForVerification, Verified, Rejected, Closed }
public enum ActionPriority { Low, Moderate, High, Critical }

public sealed record StartInvestigationRequest(Guid LeadInvestigatorId, string? LeadInvestigatorName, IReadOnlyList<Guid>? TeamMemberIds, string? Scope, long ExpectedIncidentVersion);
public sealed record AddInvestigationNoteRequest(string Note, string Category);
public sealed record AddWitnessRequest(string Name, string? Contact, string Statement, DateTimeOffset InterviewedAt);
public sealed record SaveFiveWhysRequest(string Problem, IReadOnlyList<string> Whys, string RootCause);
public sealed record SaveFishboneRequest(IReadOnlyDictionary<string, IReadOnlyList<string>> Causes, string RootCauseSummary);
public sealed record CreateCorrectiveActionRequest(string Title, string Description, Guid OwnerId, string? OwnerName, DateTimeOffset DueAt, ActionPriority Priority, string VerificationMethod);
public sealed record UpdateCorrectiveActionRequest(CorrectiveActionStatus Status, string? CompletionNotes, string? VerificationNotes);
public sealed record AdvanceInvestigationRequest(InvestigationStage TargetStage, string? Comment);

public sealed record InvestigationRecord(Guid Id, Guid TenantId, Guid IncidentId, InvestigationStage Stage, Guid LeadInvestigatorId, string? LeadInvestigatorName,
    IReadOnlyList<Guid> TeamMemberIds, string? Scope, RootCauseMethod? RootCauseMethod, string? RootCauseSummary, int QualityScore,
    DateTimeOffset StartedAt, DateTimeOffset UpdatedAt, DateTimeOffset? CompletedAt, long Version);
public sealed record InvestigationNoteRecord(Guid Id, Guid TenantId, Guid InvestigationId, string Category, string Note, Guid CreatedBy, string? CreatedByName, DateTimeOffset CreatedAt);
public sealed record WitnessRecord(Guid Id, Guid TenantId, Guid InvestigationId, string Name, string? Contact, string Statement, DateTimeOffset InterviewedAt, Guid CreatedBy, DateTimeOffset CreatedAt);
public sealed record RootCauseRecord(Guid Id, Guid TenantId, Guid InvestigationId, RootCauseMethod Method, string Problem, IReadOnlyList<string> Whys,
    IReadOnlyDictionary<string, IReadOnlyList<string>> FishboneCauses, string RootCause, Guid CreatedBy, DateTimeOffset CreatedAt, long Version);
public sealed record CorrectiveActionRecord(Guid Id, Guid TenantId, Guid InvestigationId, Guid IncidentId, string Number, string Title, string Description,
    Guid OwnerId, string? OwnerName, DateTimeOffset DueAt, ActionPriority Priority, CorrectiveActionStatus Status, string VerificationMethod,
    string? CompletionNotes, string? VerificationNotes, Guid CreatedBy, DateTimeOffset CreatedAt, DateTimeOffset UpdatedAt, DateTimeOffset? VerifiedAt, long Version);
public sealed record InvestigationWorkspace(InvestigationRecord Investigation, IReadOnlyList<InvestigationNoteRecord> Notes, IReadOnlyList<WitnessRecord> Witnesses,
    RootCauseRecord? RootCause, IReadOnlyList<CorrectiveActionRecord> CorrectiveActions);
