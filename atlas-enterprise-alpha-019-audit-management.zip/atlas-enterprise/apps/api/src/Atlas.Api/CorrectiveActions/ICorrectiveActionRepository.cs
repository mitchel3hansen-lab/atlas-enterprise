namespace Atlas.Api.CorrectiveActions;

public interface ICorrectiveActionRepository
{
    Task<string> NextNumberAsync(Guid tenantId, CancellationToken ct);
    Task<CorrectiveAction> AddAsync(CorrectiveAction action, CancellationToken ct);
    Task<CorrectiveAction?> GetAsync(Guid tenantId, Guid id, CancellationToken ct);
    Task<CorrectiveAction> UpdateAsync(CorrectiveAction action, CancellationToken ct);
    Task<CorrectiveActionSearchResult> SearchAsync(Guid tenantId, CorrectiveActionSearchQuery query, CancellationToken ct);
    Task<CorrectiveActionDashboard> DashboardAsync(Guid tenantId, DateTimeOffset now, CancellationToken ct);
}
