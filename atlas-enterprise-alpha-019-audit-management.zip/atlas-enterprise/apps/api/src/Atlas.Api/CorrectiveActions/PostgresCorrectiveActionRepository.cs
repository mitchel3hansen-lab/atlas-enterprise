using System.Text.Json;
using Npgsql;
using NpgsqlTypes;

namespace Atlas.Api.CorrectiveActions;

public sealed class PostgresCorrectiveActionRepository(IConfiguration configuration) : ICorrectiveActionRepository
{
    private string ConnectionString => configuration.GetConnectionString("Atlas") ?? throw new InvalidOperationException("ConnectionStrings:Atlas is required.");

    public async Task<string> NextNumberAsync(Guid tenantId, CancellationToken ct)
    {
        await using var c = await OpenAsync(ct);
        await using var cmd = new NpgsqlCommand("SELECT atlas.next_corrective_action_number(@tenant)", c);
        cmd.Parameters.AddWithValue("tenant", tenantId);
        return (string)(await cmd.ExecuteScalarAsync(ct) ?? throw new InvalidOperationException("Unable to allocate corrective action number."));
    }

    public async Task<CorrectiveAction> AddAsync(CorrectiveAction x, CancellationToken ct) { await WriteAsync(x, true, ct); return x; }
    public async Task<CorrectiveAction> UpdateAsync(CorrectiveAction x, CancellationToken ct) { await WriteAsync(x, false, ct); return x; }

    public async Task<CorrectiveAction?> GetAsync(Guid tenantId, Guid id, CancellationToken ct)
    {
        await using var c = await OpenAsync(ct);
        await using var cmd = new NpgsqlCommand("SELECT * FROM atlas.corrective_actions WHERE tenant_id=@tenant AND id=@id", c);
        cmd.Parameters.AddWithValue("tenant", tenantId); cmd.Parameters.AddWithValue("id", id);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        return await r.ReadAsync(ct) ? Map(r) : null;
    }

    public async Task<CorrectiveActionSearchResult> SearchAsync(Guid tenantId, CorrectiveActionSearchQuery q, CancellationToken ct)
    {
        await using var c = await OpenAsync(ct);
        var clauses = new List<string> { "tenant_id=@tenant" };
        await using var cmd = new NpgsqlCommand { Connection = c };
        cmd.Parameters.AddWithValue("tenant", tenantId);
        if (q.Status is not null) { clauses.Add("status=@status"); cmd.Parameters.AddWithValue("status", q.Status.ToString()!); }
        if (q.Priority is not null) { clauses.Add("priority=@priority"); cmd.Parameters.AddWithValue("priority", q.Priority.ToString()!); }
        if (q.OwnerId is not null) { clauses.Add("owner_id=@owner"); cmd.Parameters.AddWithValue("owner", q.OwnerId); }
        if (q.FacilityId is not null) { clauses.Add("facility_id=@facility"); cmd.Parameters.AddWithValue("facility", q.FacilityId); }
        if (q.OverdueOnly == true) clauses.Add("due_at < now() AND status NOT IN ('Closed','Cancelled')");
        if (!string.IsNullOrWhiteSpace(q.Search)) { clauses.Add("search_vector @@ websearch_to_tsquery('english',@search)"); cmd.Parameters.AddWithValue("search", q.Search); }
        cmd.CommandText = $"SELECT *, count(*) OVER()::int total_count FROM atlas.corrective_actions WHERE {string.Join(" AND ", clauses)} ORDER BY CASE priority WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Moderate' THEN 3 ELSE 4 END, due_at NULLS LAST, created_at DESC LIMIT @limit OFFSET @offset";
        cmd.Parameters.AddWithValue("limit", q.Limit); cmd.Parameters.AddWithValue("offset", q.Offset);
        var items = new List<CorrectiveAction>(); var total = 0;
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) { items.Add(Map(r)); total = r.GetInt32(r.GetOrdinal("total_count")); }
        return new(items, total, q.Limit, q.Offset);
    }

    public async Task<CorrectiveActionDashboard> DashboardAsync(Guid tenantId, DateTimeOffset now, CancellationToken ct)
    {
        await using var c = await OpenAsync(ct);
        const string sql = """
        SELECT
          count(*) FILTER (WHERE status NOT IN ('Closed','Cancelled'))::int open,
          count(*) FILTER (WHERE due_at < @now AND status NOT IN ('Closed','Cancelled'))::int overdue,
          count(*) FILTER (WHERE priority='Critical' AND status NOT IN ('Closed','Cancelled'))::int critical,
          count(*) FILTER (WHERE status='PendingVerification')::int awaiting,
          count(*) FILTER (WHERE status='Closed' AND closed_at >= date_trunc('month',@now::timestamptz))::int closed_month,
          coalesce(round(100.0 * count(*) FILTER (WHERE status='Closed' AND closed_at <= due_at) / nullif(count(*) FILTER (WHERE status='Closed'),0),1),0) on_time,
          coalesce(round(100.0 * count(*) FILTER (WHERE verifications @> '[{\"Outcome\":0}]'::jsonb) / nullif(count(*) FILTER (WHERE jsonb_array_length(verifications)>0),0),1),0) effective
        FROM atlas.corrective_actions WHERE tenant_id=@tenant
        """;
        await using var cmd = new NpgsqlCommand(sql, c); cmd.Parameters.AddWithValue("tenant", tenantId); cmd.Parameters.AddWithValue("now", now);
        await using var r = await cmd.ExecuteReaderAsync(ct); await r.ReadAsync(ct);
        return new(r.GetInt32(0), r.GetInt32(1), r.GetInt32(2), r.GetInt32(3), r.GetInt32(4), r.GetDecimal(5), r.GetDecimal(6));
    }

    private async Task WriteAsync(CorrectiveAction x, bool insert, CancellationToken ct)
    {
        await using var c = await OpenAsync(ct);
        var sql = insert
            ? """INSERT INTO atlas.corrective_actions(id,tenant_id,number,title,description,source_type,source_id,priority,status,facility_id,department_id,owner_id,created_by,due_at,implemented_at,closed_at,evidence,verifications,history,created_at,updated_at,version) VALUES(@id,@tenant,@number,@title,@description,@source_type,@source_id,@priority,@status,@facility,@department,@owner,@created_by,@due,@implemented,@closed,@evidence,@verifications,@history,@created,@updated,@version)"""
            : """UPDATE atlas.corrective_actions SET title=@title,description=@description,priority=@priority,status=@status,facility_id=@facility,department_id=@department,owner_id=@owner,due_at=@due,implemented_at=@implemented,closed_at=@closed,evidence=@evidence,verifications=@verifications,history=@history,updated_at=@updated,version=@version WHERE tenant_id=@tenant AND id=@id""";
        await using var cmd = new NpgsqlCommand(sql, c);
        cmd.Parameters.AddWithValue("id", x.Id); cmd.Parameters.AddWithValue("tenant", x.TenantId); cmd.Parameters.AddWithValue("number", x.Number); cmd.Parameters.AddWithValue("title", x.Title); cmd.Parameters.AddWithValue("description", x.Description); cmd.Parameters.AddWithValue("source_type", x.SourceType.ToString()); cmd.Parameters.AddWithValue("source_id", (object?)x.SourceId ?? DBNull.Value); cmd.Parameters.AddWithValue("priority", x.Priority.ToString()); cmd.Parameters.AddWithValue("status", x.Status.ToString()); cmd.Parameters.AddWithValue("facility", (object?)x.FacilityId ?? DBNull.Value); cmd.Parameters.AddWithValue("department", (object?)x.DepartmentId ?? DBNull.Value); cmd.Parameters.AddWithValue("owner", (object?)x.OwnerId ?? DBNull.Value); cmd.Parameters.AddWithValue("created_by", x.CreatedBy); cmd.Parameters.AddWithValue("due", (object?)x.DueAt ?? DBNull.Value); cmd.Parameters.AddWithValue("implemented", (object?)x.ImplementedAt ?? DBNull.Value); cmd.Parameters.AddWithValue("closed", (object?)x.ClosedAt ?? DBNull.Value);
        cmd.Parameters.Add(new NpgsqlParameter("evidence", NpgsqlDbType.Jsonb) { Value = JsonSerializer.Serialize(x.Evidence) }); cmd.Parameters.Add(new NpgsqlParameter("verifications", NpgsqlDbType.Jsonb) { Value = JsonSerializer.Serialize(x.Verifications) }); cmd.Parameters.Add(new NpgsqlParameter("history", NpgsqlDbType.Jsonb) { Value = JsonSerializer.Serialize(x.History) }); cmd.Parameters.AddWithValue("created", x.CreatedAt); cmd.Parameters.AddWithValue("updated", x.UpdatedAt); cmd.Parameters.AddWithValue("version", x.Version);
        var changed = await cmd.ExecuteNonQueryAsync(ct); if (changed != 1) throw new InvalidOperationException("Corrective action update failed or record was not found.");
    }

    private async Task<NpgsqlConnection> OpenAsync(CancellationToken ct) { var c = new NpgsqlConnection(ConnectionString); await c.OpenAsync(ct); return c; }
    private static CorrectiveAction Map(NpgsqlDataReader r) => new(
        r.GetGuid(r.GetOrdinal("id")), r.GetGuid(r.GetOrdinal("tenant_id")), r.GetString(r.GetOrdinal("number")), r.GetString(r.GetOrdinal("title")), r.GetString(r.GetOrdinal("description")), Enum.Parse<CorrectiveActionSourceType>(r.GetString(r.GetOrdinal("source_type")), true), r.IsDBNull(r.GetOrdinal("source_id")) ? null : r.GetGuid(r.GetOrdinal("source_id")), Enum.Parse<CorrectiveActionPriority>(r.GetString(r.GetOrdinal("priority")), true), Enum.Parse<CorrectiveActionStatus>(r.GetString(r.GetOrdinal("status")), true), r.IsDBNull(r.GetOrdinal("facility_id")) ? null : r.GetGuid(r.GetOrdinal("facility_id")), r.IsDBNull(r.GetOrdinal("department_id")) ? null : r.GetGuid(r.GetOrdinal("department_id")), r.IsDBNull(r.GetOrdinal("owner_id")) ? null : r.GetGuid(r.GetOrdinal("owner_id")), r.GetGuid(r.GetOrdinal("created_by")), r.IsDBNull(r.GetOrdinal("due_at")) ? null : r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("due_at")), r.IsDBNull(r.GetOrdinal("implemented_at")) ? null : r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("implemented_at")), r.IsDBNull(r.GetOrdinal("closed_at")) ? null : r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("closed_at")), JsonSerializer.Deserialize<CorrectiveActionEvidence[]>(r.GetString(r.GetOrdinal("evidence"))) ?? Array.Empty<CorrectiveActionEvidence>(), JsonSerializer.Deserialize<CorrectiveActionVerification[]>(r.GetString(r.GetOrdinal("verifications"))) ?? Array.Empty<CorrectiveActionVerification>(), JsonSerializer.Deserialize<CorrectiveActionHistoryEntry[]>(r.GetString(r.GetOrdinal("history"))) ?? Array.Empty<CorrectiveActionHistoryEntry>(), r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("created_at")), r.GetFieldValue<DateTimeOffset>(r.GetOrdinal("updated_at")), r.GetInt64(r.GetOrdinal("version")));
}
