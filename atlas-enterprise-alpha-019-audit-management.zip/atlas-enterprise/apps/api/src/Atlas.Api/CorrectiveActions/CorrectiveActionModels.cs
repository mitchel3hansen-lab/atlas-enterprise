namespace Atlas.Api.CorrectiveActions;

public enum CorrectiveActionStatus
{
    Draft,
    Assigned,
    InProgress,
    EvidenceSubmitted,
    PendingVerification,
    Effective,
    Ineffective,
    Closed,
    Cancelled
}

public enum CorrectiveActionPriority { Low, Moderate, High, Critical }
public enum CorrectiveActionSourceType { Incident, Investigation, Inspection, Audit, NearMiss, Observation, RiskAssessment, Complaint, RegulatoryFinding, ManagementReview, EmployeeSuggestion, Other }
public enum VerificationOutcome { Effective, PartiallyEffective, Ineffective }

public sealed record CorrectiveActionEvidence(
    Guid Id,
    Guid EvidenceId,
    string EvidenceType,
    string Description,
    Guid SubmittedBy,
    DateTimeOffset SubmittedAt);

public sealed record CorrectiveActionVerification(
    Guid Id,
    VerificationOutcome Outcome,
    string Notes,
    Guid VerifiedBy,
    DateTimeOffset VerifiedAt,
    DateTimeOffset? FollowUpDueAt);

public sealed record CorrectiveActionHistoryEntry(
    Guid Id,
    string EventType,
    string Description,
    Guid ActorId,
    DateTimeOffset OccurredAt);

public sealed record CorrectiveAction(
    Guid Id,
    Guid TenantId,
    string Number,
    string Title,
    string Description,
    CorrectiveActionSourceType SourceType,
    Guid? SourceId,
    CorrectiveActionPriority Priority,
    CorrectiveActionStatus Status,
    Guid? FacilityId,
    Guid? DepartmentId,
    Guid? OwnerId,
    Guid CreatedBy,
    DateTimeOffset? DueAt,
    DateTimeOffset? ImplementedAt,
    DateTimeOffset? ClosedAt,
    IReadOnlyList<CorrectiveActionEvidence> Evidence,
    IReadOnlyList<CorrectiveActionVerification> Verifications,
    IReadOnlyList<CorrectiveActionHistoryEntry> History,
    DateTimeOffset CreatedAt,
    DateTimeOffset UpdatedAt,
    long Version);

public sealed record CreateCorrectiveActionRequest(
    string Title,
    string Description,
    CorrectiveActionSourceType SourceType,
    Guid? SourceId,
    CorrectiveActionPriority Priority,
    Guid? FacilityId,
    Guid? DepartmentId,
    Guid? OwnerId,
    DateTimeOffset? DueAt);

public sealed record AssignCorrectiveActionRequest(Guid OwnerId, DateTimeOffset DueAt);
public sealed record SubmitEvidenceRequest(Guid EvidenceId, string EvidenceType, string Description);
public sealed record VerifyCorrectiveActionRequest(VerificationOutcome Outcome, string Notes, DateTimeOffset? FollowUpDueAt);
public sealed record CorrectiveActionSearchQuery(CorrectiveActionStatus? Status, CorrectiveActionPriority? Priority, Guid? OwnerId, Guid? FacilityId, bool? OverdueOnly, string? Search, int Limit = 50, int Offset = 0);
public sealed record CorrectiveActionSearchResult(IReadOnlyList<CorrectiveAction> Items, int Total, int Limit, int Offset);
public sealed record CorrectiveActionDashboard(int Open, int Overdue, int Critical, int AwaitingVerification, int ClosedThisMonth, decimal OnTimeClosurePercent, decimal EffectivenessSuccessPercent);
