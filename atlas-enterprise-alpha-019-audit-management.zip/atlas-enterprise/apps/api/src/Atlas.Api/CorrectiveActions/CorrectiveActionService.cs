namespace Atlas.Api.CorrectiveActions;

public sealed class CorrectiveActionService(ICorrectiveActionRepository repository)
{
    public async Task<CorrectiveAction> CreateAsync(Guid tenantId, Guid actorId, CreateCorrectiveActionRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Title)) throw new ArgumentException("Corrective action title is required.");
        if (string.IsNullOrWhiteSpace(request.Description)) throw new ArgumentException("Corrective action description is required.");
        if (request.DueAt is not null && request.DueAt <= DateTimeOffset.UtcNow) throw new ArgumentException("Due date must be in the future.");

        var now = DateTimeOffset.UtcNow;
        var number = await repository.NextNumberAsync(tenantId, ct);
        var status = request.OwnerId is null ? CorrectiveActionStatus.Draft : CorrectiveActionStatus.Assigned;
        var history = new[] { History("Created", "Corrective action created.", actorId, now) };
        if (request.OwnerId is not null) history = history.Append(History("Assigned", "Owner assigned during creation.", actorId, now)).ToArray();

        return await repository.AddAsync(new(
            Guid.NewGuid(), tenantId, number, request.Title.Trim(), request.Description.Trim(), request.SourceType,
            request.SourceId, request.Priority, status, request.FacilityId, request.DepartmentId, request.OwnerId,
            actorId, request.DueAt, null, null, Array.Empty<CorrectiveActionEvidence>(),
            Array.Empty<CorrectiveActionVerification>(), history, now, now, 1), ct);
    }

    public Task<CorrectiveAction?> GetAsync(Guid tenantId, Guid id, CancellationToken ct) => repository.GetAsync(tenantId, id, ct);

    public Task<CorrectiveActionSearchResult> SearchAsync(Guid tenantId, CorrectiveActionSearchQuery query, CancellationToken ct)
        => repository.SearchAsync(tenantId, query with { Limit = Math.Clamp(query.Limit, 1, 200), Offset = Math.Max(0, query.Offset), Search = query.Search?.Trim() }, ct);

    public Task<CorrectiveActionDashboard> DashboardAsync(Guid tenantId, CancellationToken ct)
        => repository.DashboardAsync(tenantId, DateTimeOffset.UtcNow, ct);

    public async Task<CorrectiveAction> AssignAsync(Guid tenantId, Guid id, Guid actorId, AssignCorrectiveActionRequest request, CancellationToken ct)
    {
        var item = await RequireAsync(tenantId, id, ct);
        EnsureNotTerminal(item);
        if (request.OwnerId == Guid.Empty) throw new ArgumentException("Owner is required.");
        if (request.DueAt <= DateTimeOffset.UtcNow) throw new ArgumentException("Due date must be in the future.");
        var now = DateTimeOffset.UtcNow;
        return await repository.UpdateAsync(item with
        {
            OwnerId = request.OwnerId,
            DueAt = request.DueAt,
            Status = CorrectiveActionStatus.Assigned,
            History = AddHistory(item, "Assigned", "Corrective action assigned or reassigned.", actorId, now),
            UpdatedAt = now,
            Version = item.Version + 1
        }, ct);
    }

    public async Task<CorrectiveAction> StartAsync(Guid tenantId, Guid id, Guid actorId, CancellationToken ct)
    {
        var item = await RequireAsync(tenantId, id, ct);
        if (item.OwnerId is null) throw new InvalidOperationException("Corrective action must have an owner before work begins.");
        if (actorId != Guid.Empty && actorId != item.OwnerId) throw new InvalidOperationException("Only the assigned owner may start this corrective action.");
        if (item.Status is not (CorrectiveActionStatus.Assigned or CorrectiveActionStatus.Ineffective)) throw new InvalidOperationException("Corrective action cannot be started from its current status.");
        var now = DateTimeOffset.UtcNow;
        return await repository.UpdateAsync(item with { Status = CorrectiveActionStatus.InProgress, History = AddHistory(item, "WorkStarted", "Implementation work started.", actorId, now), UpdatedAt = now, Version = item.Version + 1 }, ct);
    }

    public async Task<CorrectiveAction> SubmitEvidenceAsync(Guid tenantId, Guid id, Guid actorId, SubmitEvidenceRequest request, CancellationToken ct)
    {
        var item = await RequireAsync(tenantId, id, ct);
        if (item.Status != CorrectiveActionStatus.InProgress) throw new InvalidOperationException("Evidence may only be submitted while implementation is in progress.");
        if (request.EvidenceId == Guid.Empty) throw new ArgumentException("Evidence identifier is required.");
        if (string.IsNullOrWhiteSpace(request.Description)) throw new ArgumentException("Evidence description is required.");
        var now = DateTimeOffset.UtcNow;
        var evidence = new CorrectiveActionEvidence(Guid.NewGuid(), request.EvidenceId, request.EvidenceType.Trim(), request.Description.Trim(), actorId, now);
        return await repository.UpdateAsync(item with
        {
            Evidence = item.Evidence.Append(evidence).ToArray(),
            Status = CorrectiveActionStatus.EvidenceSubmitted,
            ImplementedAt = now,
            History = AddHistory(item, "EvidenceSubmitted", "Implementation evidence submitted for review.", actorId, now),
            UpdatedAt = now,
            Version = item.Version + 1
        }, ct);
    }

    public async Task<CorrectiveAction> RequestVerificationAsync(Guid tenantId, Guid id, Guid actorId, CancellationToken ct)
    {
        var item = await RequireAsync(tenantId, id, ct);
        if (item.Status != CorrectiveActionStatus.EvidenceSubmitted) throw new InvalidOperationException("Evidence must be submitted before effectiveness verification.");
        if (item.Evidence.Count == 0) throw new InvalidOperationException("At least one evidence record is required.");
        var now = DateTimeOffset.UtcNow;
        return await repository.UpdateAsync(item with { Status = CorrectiveActionStatus.PendingVerification, History = AddHistory(item, "VerificationRequested", "Effectiveness verification requested.", actorId, now), UpdatedAt = now, Version = item.Version + 1 }, ct);
    }

    public async Task<CorrectiveAction> VerifyAsync(Guid tenantId, Guid id, Guid actorId, VerifyCorrectiveActionRequest request, CancellationToken ct)
    {
        var item = await RequireAsync(tenantId, id, ct);
        if (item.Status != CorrectiveActionStatus.PendingVerification) throw new InvalidOperationException("Corrective action is not awaiting verification.");
        if (string.IsNullOrWhiteSpace(request.Notes)) throw new ArgumentException("Verification notes are required.");
        var now = DateTimeOffset.UtcNow;
        var verification = new CorrectiveActionVerification(Guid.NewGuid(), request.Outcome, request.Notes.Trim(), actorId, now, request.FollowUpDueAt);
        var status = request.Outcome == VerificationOutcome.Effective ? CorrectiveActionStatus.Effective : CorrectiveActionStatus.Ineffective;
        return await repository.UpdateAsync(item with
        {
            Verifications = item.Verifications.Append(verification).ToArray(),
            Status = status,
            History = AddHistory(item, "EffectivenessVerified", $"Verification outcome: {request.Outcome}.", actorId, now),
            UpdatedAt = now,
            Version = item.Version + 1
        }, ct);
    }

    public async Task<CorrectiveAction> CloseAsync(Guid tenantId, Guid id, Guid actorId, CancellationToken ct)
    {
        var item = await RequireAsync(tenantId, id, ct);
        if (item.Status != CorrectiveActionStatus.Effective) throw new InvalidOperationException("Only an effective corrective action may be closed.");
        if (!item.Verifications.Any(x => x.Outcome == VerificationOutcome.Effective)) throw new InvalidOperationException("An effective verification record is required before closure.");
        var now = DateTimeOffset.UtcNow;
        return await repository.UpdateAsync(item with { Status = CorrectiveActionStatus.Closed, ClosedAt = now, History = AddHistory(item, "Closed", "Corrective action formally closed after effectiveness verification.", actorId, now), UpdatedAt = now, Version = item.Version + 1 }, ct);
    }

    private async Task<CorrectiveAction> RequireAsync(Guid tenantId, Guid id, CancellationToken ct)
        => await repository.GetAsync(tenantId, id, ct) ?? throw new KeyNotFoundException("Corrective action was not found.");

    private static void EnsureNotTerminal(CorrectiveAction item)
    {
        if (item.Status is CorrectiveActionStatus.Closed or CorrectiveActionStatus.Cancelled)
            throw new InvalidOperationException("Closed or cancelled corrective actions cannot be modified.");
    }

    private static CorrectiveActionHistoryEntry History(string type, string description, Guid actorId, DateTimeOffset at)
        => new(Guid.NewGuid(), type, description, actorId, at);

    private static IReadOnlyList<CorrectiveActionHistoryEntry> AddHistory(CorrectiveAction item, string type, string description, Guid actorId, DateTimeOffset at)
        => item.History.Append(History(type, description, actorId, at)).ToArray();
}
