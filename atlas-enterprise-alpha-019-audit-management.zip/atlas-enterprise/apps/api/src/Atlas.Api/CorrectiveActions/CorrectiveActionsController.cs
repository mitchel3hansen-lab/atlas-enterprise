using System.Security.Claims;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Atlas.Api.CorrectiveActions;

[ApiController]
[Route("api/v1/corrective-actions")]
[Authorize]
public sealed class CorrectiveActionsController(CorrectiveActionService service, TenantContext tenantContext) : ControllerBase
{
    [HttpGet]
    [Authorize(Policy = AtlasPermissions.CorrectiveActionsRead)]
    public async Task<ActionResult<CorrectiveActionSearchResult>> Search([FromQuery] CorrectiveActionStatus? status = null, [FromQuery] CorrectiveActionPriority? priority = null, [FromQuery] Guid? ownerId = null, [FromQuery] Guid? facilityId = null, [FromQuery] bool? overdueOnly = null, [FromQuery] string? search = null, [FromQuery] int limit = 50, [FromQuery] int offset = 0, CancellationToken ct = default)
        => Ok(await service.SearchAsync(tenantContext.TenantId, new(status, priority, ownerId, facilityId, overdueOnly, search, limit, offset), ct));

    [HttpGet("dashboard")]
    [Authorize(Policy = AtlasPermissions.CorrectiveActionsRead)]
    public async Task<ActionResult<CorrectiveActionDashboard>> Dashboard(CancellationToken ct)
        => Ok(await service.DashboardAsync(tenantContext.TenantId, ct));

    [HttpGet("{id:guid}")]
    [Authorize(Policy = AtlasPermissions.CorrectiveActionsRead)]
    public async Task<ActionResult<CorrectiveAction>> Get(Guid id, CancellationToken ct)
        => await service.GetAsync(tenantContext.TenantId, id, ct) is { } item ? Ok(item) : NotFound();

    [HttpPost]
    [Authorize(Policy = AtlasPermissions.CorrectiveActionsManage)]
    public async Task<ActionResult<CorrectiveAction>> Create(CreateCorrectiveActionRequest request, CancellationToken ct)
    {
        var created = await service.CreateAsync(tenantContext.TenantId, ActorId(), request, ct);
        return CreatedAtAction(nameof(Get), new { id = created.Id }, created);
    }

    [HttpPost("{id:guid}/assign")]
    [Authorize(Policy = AtlasPermissions.CorrectiveActionsManage)]
    public async Task<ActionResult<CorrectiveAction>> Assign(Guid id, AssignCorrectiveActionRequest request, CancellationToken ct)
        => Ok(await service.AssignAsync(tenantContext.TenantId, id, ActorId(), request, ct));

    [HttpPost("{id:guid}/start")]
    [Authorize(Policy = AtlasPermissions.CorrectiveActionsExecute)]
    public async Task<ActionResult<CorrectiveAction>> Start(Guid id, CancellationToken ct)
        => Ok(await service.StartAsync(tenantContext.TenantId, id, ActorId(), ct));

    [HttpPost("{id:guid}/evidence")]
    [Authorize(Policy = AtlasPermissions.CorrectiveActionsExecute)]
    public async Task<ActionResult<CorrectiveAction>> SubmitEvidence(Guid id, SubmitEvidenceRequest request, CancellationToken ct)
        => Ok(await service.SubmitEvidenceAsync(tenantContext.TenantId, id, ActorId(), request, ct));

    [HttpPost("{id:guid}/request-verification")]
    [Authorize(Policy = AtlasPermissions.CorrectiveActionsManage)]
    public async Task<ActionResult<CorrectiveAction>> RequestVerification(Guid id, CancellationToken ct)
        => Ok(await service.RequestVerificationAsync(tenantContext.TenantId, id, ActorId(), ct));

    [HttpPost("{id:guid}/verify")]
    [Authorize(Policy = AtlasPermissions.CorrectiveActionsVerify)]
    public async Task<ActionResult<CorrectiveAction>> Verify(Guid id, VerifyCorrectiveActionRequest request, CancellationToken ct)
        => Ok(await service.VerifyAsync(tenantContext.TenantId, id, ActorId(), request, ct));

    [HttpPost("{id:guid}/close")]
    [Authorize(Policy = AtlasPermissions.CorrectiveActionsManage)]
    public async Task<ActionResult<CorrectiveAction>> Close(Guid id, CancellationToken ct)
        => Ok(await service.CloseAsync(tenantContext.TenantId, id, ActorId(), ct));

    private Guid ActorId() { var raw = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub"); return Guid.TryParse(raw, out var id) ? id : Guid.Empty; }
}
