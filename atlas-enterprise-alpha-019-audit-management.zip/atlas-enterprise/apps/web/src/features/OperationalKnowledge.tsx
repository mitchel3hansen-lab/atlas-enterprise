import { useMemo, useState } from 'react';

type SimilarRecord={id:string;title:string;type:string;similarity:number;signals:string[]};
type Lesson={id:string;title:string;summary:string;rootCause:string;controls:string[];status:'Published'|'Draft';sources:number};
const similar:SimilarRecord[]=[
{id:'INC-2026-0041',title:'Forklift struck structural beam',type:'Incident',similarity:92,signals:['Restricted space','Forklift','Warehouse traffic flow']},
{id:'INC-2026-0034',title:'Light fixture impacted between aisles',type:'Incident',similarity:86,signals:['Forklift','Visibility','Delayed reporting']},
{id:'NM-2026-0118',title:'Pedestrian interaction near blind corner',type:'Near miss',similarity:81,signals:['Restricted space','Pedestrian route','Horn use']},
{id:'INSP-2026-0741',title:'Warehouse traffic-flow inspection',type:'Inspection',similarity:74,signals:['Restricted space','Rack clearance']}
];
const lessons:Lesson[]=[
{id:'LL-0042',title:'Restricted-space forklift operations require engineered traffic controls',summary:'Training alone did not sufficiently reduce interaction risk in congested warehouse aisles.',rootCause:'Facility layout and operating clearance were not incorporated into the original traffic-control design.',controls:['Reconfigure aisle clearance','Separate pedestrian travel','Verify controls after 30 days'],status:'Published',sources:6},
{id:'LL-0037',title:'Delayed property-damage reporting weakens corrective-action speed',summary:'Same-shift reporting materially improves evidence quality and repair response.',rootCause:'Reporting expectations were not consistently reinforced.',controls:['Supervisor escalation','QR reporting access','Shift-close verification'],status:'Published',sources:4},
{id:'LL-0048',title:'PAPR pilot reduced heat burden during high-dust blending',summary:'Powered respiratory protection improved comfort while maintaining protection.',rootCause:'Negative-pressure respirators increased user burden during extended blending tasks.',controls:['Standardize PAPR assignment','Track battery rotation','Verify filter service life'],status:'Draft',sources:3}
];

export function OperationalKnowledge(){
 const [query,setQuery]=useState(''); const [selected,setSelected]=useState<Lesson|null>(lessons[0]);
 const filtered=useMemo(()=>lessons.filter(x=>`${x.title} ${x.summary} ${x.rootCause} ${x.controls.join(' ')}`.toLowerCase().includes(query.toLowerCase())),[query]);
 return <div className="knowledge-workspace">
  <header className="knowledge-header"><div><span>Operational Intelligence · Alpha 0.14</span><h2>Operational Knowledge</h2><p>Connect incidents, controls, evidence, and lessons so the organization can learn from experience.</p></div><button>Create lesson</button></header>
  <section className="knowledge-metrics"><article><small>Connected records</small><strong>142</strong><span>Across 9 object types</span></article><article><small>Published lessons</small><strong>24</strong><span>6 added this quarter</span></article><article><small>Recurring signals</small><strong>7</strong><span>3 need leadership review</span></article><article><small>Verified controls</small><strong>68%</strong><span>Effectiveness documented</span></article></section>
  <section className="knowledge-grid"><main>
   <section className="panel"><div className="section-heading"><div><span>Contextual intelligence</span><h3>Related to forklift operational risk</h3></div><strong className="knowledge-confidence">91% confidence</strong></div><div className="knowledge-recommendation"><span>Recommended next step</span><h4>Review recurring restricted-space signals before closing current CAPAs.</h4><p>Four related records connect facility layout, pedestrian routing, and forklift interaction risk. This is decision support and requires human review.</p><div className="knowledge-actions"><button>Review evidence</button><button className="secondary">Open relationship map</button></div></div><div className="similar-list">{similar.map(x=><article key={x.id}><div><span>{x.type} · {x.id}</span><h4>{x.title}</h4><p>{x.signals.join(' · ')}</p></div><strong>{x.similarity}%</strong></article>)}</div></section>
   <section className="panel"><div className="section-heading"><div><span>Searchable memory</span><h3>Lessons learned library</h3></div><input aria-label="Search lessons" placeholder="Search lessons, causes, or controls" value={query} onChange={e=>setQuery(e.target.value)}/></div><div className="lesson-table">{filtered.map(x=><button key={x.id} className={selected?.id===x.id?'active':''} onClick={()=>setSelected(x)}><span>{x.status}</span><strong>{x.title}</strong><small>{x.sources} connected source records</small></button>)}</div></section>
  </main><aside className="panel knowledge-detail">{selected&&<><span>{selected.status} · {selected.id}</span><h3>{selected.title}</h3><p>{selected.summary}</p><h4>Root cause</h4><p>{selected.rootCause}</p><h4>Effective controls</h4><ul>{selected.controls.map(x=><li key={x}>{x}</li>)}</ul><div className="evidence-notice"><strong>Evidence-linked</strong><p>This lesson is connected to {selected.sources} source records and remains subject to human review.</p></div><button className="full-width">Open lesson record</button></>}</aside></section>
 </div>
}
