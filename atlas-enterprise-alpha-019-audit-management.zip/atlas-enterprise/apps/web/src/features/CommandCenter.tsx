import { useMemo, useState } from 'react';

type TaskStatus = 'Overdue' | 'Due today' | 'Upcoming';
type Task = { id: string; title: string; module: string; owner: string; due: string; status: TaskStatus };

type AlertSeverity = 'Critical' | 'High' | 'Moderate';
type Alert = { id: string; severity: AlertSeverity; title: string; context: string; confidence: number; evidence: string[]; actions: string[] };

const tasks: Task[] = [
  { id: 'CAPA-1042', title: 'Verify warehouse traffic-flow controls', module: 'CAPA', owner: 'Mitch Hansen', due: 'Jul 27', status: 'Overdue' },
  { id: 'INV-0288', title: 'Complete root-cause review', module: 'Investigation', owner: 'Mitch Hansen', due: 'Jul 27', status: 'Due today' },
  { id: 'INSP-0741', title: 'Lindon monthly fire inspection', module: 'Inspection', owner: 'Jose Cancel', due: 'Jul 29', status: 'Upcoming' },
  { id: 'TRN-0317', title: 'Renew forklift operator credentials', module: 'Training', owner: 'Warehouse Team', due: 'Jul 31', status: 'Upcoming' },
];

const alerts: Alert[] = [
  {
    id: 'ALT-001', severity: 'High', title: 'Forklift operational risk is rising',
    context: 'Near-miss frequency, overdue verification, and restricted-space observations are converging across warehouse operations.',
    confidence: 91,
    evidence: ['3 recent forklift–pedestrian near misses', '2 overdue facility inspections', '3 operator certifications nearing expiration', 'GEMBA observations link congestion to interaction risk'],
    actions: ['Complete overdue inspections', 'Renew operator certifications', 'Re-evaluate aisle and pedestrian-route spacing', 'Verify control effectiveness in 30 days']
  },
  {
    id: 'ALT-002', severity: 'Moderate', title: 'Corrective-action aging is increasing',
    context: 'Seven actions are overdue, with the largest concentration in warehouse and sanitation workflows.',
    confidence: 84,
    evidence: ['7 overdue CAPAs', 'Median age increased from 12 to 19 days', '4 actions await effectiveness verification'],
    actions: ['Escalate owners', 'Confirm revised due dates', 'Schedule effectiveness reviews']
  }
];

export function CommandCenter() {
  const [period, setPeriod] = useState('Last 30 days');
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [taskFilter, setTaskFilter] = useState<'All' | TaskStatus>('All');
  const filteredTasks = useMemo(() => tasks.filter(t => taskFilter === 'All' || t.status === taskFilter), [taskFilter]);

  return <div className="command-center">
    <header className="command-header">
      <div>
        <span>Operational Intelligence · Alpha 0.13</span>
        <h2>Atlas Command Center</h2>
        <p>Prioritize today’s work, understand operational risk, and verify that actions are producing results.</p>
      </div>
      <div className="command-actions">
        <select aria-label="Reporting period" value={period} onChange={e => setPeriod(e.target.value)}>
          <option>Last 7 days</option><option>Last 30 days</option><option>Quarter to date</option><option>Year to date</option>
        </select>
        <button>Report incident</button>
      </div>
    </header>

    <section className="command-kpis" aria-label="Operational health metrics">
      <Kpi label="Operational health" value="78" detail="+3 from prior period" tone="positive" />
      <Kpi label="Open incidents" value="12" detail="3 require review" tone="neutral" />
      <Kpi label="Overdue CAPAs" value="7" detail="2 high priority" tone="negative" />
      <Kpi label="Training readiness" value="94%" detail="11 renewals due" tone="positive" />
      <Kpi label="Evidence completeness" value="86%" detail="Across active cases" tone="neutral" />
    </section>

    <section className="command-layout">
      <div className="command-primary">
        <section className="panel attention-panel">
          <div className="section-heading"><div><span>Intelligence</span><h3>Needs attention</h3></div><small>{period}</small></div>
          <div className="alert-stack">
            {alerts.map(alert => <article className={`risk-alert ${alert.severity.toLowerCase()}`} key={alert.id}>
              <div className="risk-alert-head"><span className={`severity ${alert.severity.toLowerCase()}`}>{alert.severity}</span><strong>{alert.confidence}% confidence</strong></div>
              <h4>{alert.title}</h4><p>{alert.context}</p>
              <div className="risk-alert-footer"><small>{alert.evidence.length} evidence signals · {alert.actions.length} recommended actions</small><button className="secondary" onClick={() => setSelectedAlert(alert)}>Explain insight</button></div>
            </article>)}
          </div>
        </section>

        <section className="panel trend-panel">
          <div className="section-heading"><div><span>Performance</span><h3>Incident and action trend</h3></div><small>6-month view</small></div>
          <div className="trend-chart" role="img" aria-label="Six month incident and corrective action trend">
            {[{m:'Feb',i:9,c:7},{m:'Mar',i:7,c:8},{m:'Apr',i:11,c:6},{m:'May',i:8,c:9},{m:'Jun',i:6,c:10},{m:'Jul',i:5,c:11}].map(x => <div className="trend-column" key={x.m}>
              <div className="bars"><i style={{height:`${x.i*8}px`}} title={`${x.i} incidents`}></i><b style={{height:`${x.c*8}px`}} title={`${x.c} actions closed`}></b></div><small>{x.m}</small>
            </div>)}
          </div>
          <div className="chart-legend"><span><i></i> Incidents</span><span><b></b> Actions closed</span><strong>Direction: improving</strong></div>
        </section>
      </div>

      <aside className="command-secondary">
        <section className="panel work-panel">
          <div className="section-heading"><div><span>Personal work</span><h3>My priorities</h3></div><strong>{filteredTasks.length}</strong></div>
          <div className="task-filters">{(['All','Overdue','Due today','Upcoming'] as const).map(f => <button key={f} className={taskFilter === f ? 'active' : 'secondary'} onClick={() => setTaskFilter(f)}>{f}</button>)}</div>
          <div className="task-list">{filteredTasks.map(task => <article key={task.id}><div><span>{task.module} · {task.id}</span><h4>{task.title}</h4><small>{task.owner}</small></div><div><span className={`task-status ${task.status.toLowerCase().replace(' ','-')}`}>{task.status}</span><small>{task.due}</small></div></article>)}</div>
        </section>

        <section className="panel snapshot-panel">
          <div className="section-heading"><div><span>Organization</span><h3>Safety snapshot</h3></div></div>
          <dl>
            <div><dt>Investigations active</dt><dd>5</dd></div><div><dt>CAPA closure rate</dt><dd>82%</dd></div><div><dt>Inspections complete</dt><dd>91%</dd></div><div><dt>Recordable cases YTD</dt><dd>8</dd></div>
          </dl>
          <button className="secondary full-width">Open executive dashboard</button>
        </section>
      </aside>
    </section>

    {selectedAlert && <ExplainabilityDrawer alert={selectedAlert} onClose={() => setSelectedAlert(null)} />}
  </div>;
}

function Kpi({label,value,detail,tone}:{label:string;value:string;detail:string;tone:'positive'|'neutral'|'negative'}) {
  return <article className={`command-kpi ${tone}`}><small>{label}</small><strong>{value}</strong><span>{detail}</span></article>;
}

function ExplainabilityDrawer({alert,onClose}:{alert:Alert;onClose:()=>void}) {
  return <div className="why-overlay" role="dialog" aria-modal="true" aria-label="Insight explanation">
    <aside className="why-panel command-drawer">
      <div className="why-head"><div><span>Atlas Explainability Engine</span><h2>{alert.title}</h2></div><button className="icon-button" onClick={onClose} aria-label="Close">×</button></div>
      <div className="confidence"><strong>{alert.confidence}%</strong><div><b>{alert.severity}-priority signal</b><p>Deterministic analysis of verified records and linked operational context.</p></div></div>
      <section><h3>Why Atlas surfaced this</h3><ol className="reason-list">{alert.evidence.map((e,i)=><li key={e}><b>Signal {i+1}</b><span>{e}</span></li>)}</ol></section>
      <section><h3>Recommended actions</h3><ol className="reason-list">{alert.actions.map((a,i)=><li key={a}><b>Action {i+1}</b><span>{a}</span></li>)}</ol></section>
      <section><h3>Governance</h3><div className="evidence-chip">Human review required</div><div className="evidence-chip">Evidence traceable</div><div className="evidence-chip">Outcome verification enabled</div></section>
      <footer><small>Insight {alert.id} · atlas-explainability/0.2</small><button onClick={onClose}>Acknowledge</button></footer>
    </aside>
  </div>;
}
