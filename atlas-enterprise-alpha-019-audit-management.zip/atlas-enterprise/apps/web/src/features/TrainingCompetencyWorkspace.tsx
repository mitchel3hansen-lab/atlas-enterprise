import React, { useMemo, useState } from 'react';

type Status='Assigned'|'In Progress'|'Completed'|'Overdue';
type Assignment={id:string;employee:string;course:string;code:string;site:string;due:string;status:Status;score?:number};
const seed:Assignment[]=[
{id:'1',employee:'Maria Lopez',course:'Forklift Operator Certification',code:'PIT-101',site:'Eagle Eye',due:'Jul 30',status:'Overdue'},
{id:'2',employee:'Alex Rivera',course:'Respiratory Protection — PAPR',code:'RPP-204',site:'Angel',due:'Aug 2',status:'In Progress'},
{id:'3',employee:'Jordan Kim',course:'Lockout/Tagout Authorized',code:'LOTO-301',site:'Lindon',due:'Aug 5',status:'Assigned'},
{id:'4',employee:'Higinio Valencia',course:'Respiratory Protection — PAPR',code:'RPP-204',site:'Angel',due:'Jul 22',status:'Completed',score:96},
{id:'5',employee:'Isamar Rojas',course:'Chemical Handling & Splash Response',code:'CHEM-110',site:'Layton 851',due:'Aug 8',status:'Assigned'}];

export function TrainingCompetencyWorkspace(){
 const [items,setItems]=useState(seed); const [q,setQ]=useState(''); const [status,setStatus]=useState<'All'|Status>('All'); const [selected,setSelected]=useState(items[0]);
 const filtered=useMemo(()=>items.filter(x=>(status==='All'||x.status===status)&&`${x.employee} ${x.course} ${x.code} ${x.site}`.toLowerCase().includes(q.toLowerCase())),[items,q,status]);
 const complete=(id:string)=>setItems(xs=>xs.map(x=>x.id===id?{...x,status:'Completed',score:100}:x));
 const completed=items.filter(x=>x.status==='Completed').length;
 return <><header><div><span>Safety Management Systems · v0.18.0</span><h2>Training & Competency</h2><p>Assign required learning, verify completion, and maintain evidence-backed workforce qualifications.</p></div><button onClick={()=>alert('Course and assignment creation are available through the v0.18 API contract.')}>Assign training</button></header>
 <section className="metrics"><article><small>Open assignments</small><strong>{items.length-completed}</strong></article><article><small>Completed</small><strong>{completed}</strong></article><article><small>Overdue</small><strong>{items.filter(x=>x.status==='Overdue').length}</strong></article><article><small>Completion rate</small><strong>{Math.round(completed/items.length*100)}%</strong></article></section>
 <section className="training-layout"><div className="panel"><div className="toolbar"><div><h3>Assignment queue</h3><p>Prioritized by due date and qualification risk.</p></div><div className="filters"><input placeholder="Search training" value={q} onChange={e=>setQ(e.target.value)}/><select value={status} onChange={e=>setStatus(e.target.value as any)}><option>All</option><option>Assigned</option><option>In Progress</option><option>Completed</option><option>Overdue</option></select></div></div>
 <table><thead><tr><th>Employee</th><th>Course</th><th>Site</th><th>Due</th><th>Status</th></tr></thead><tbody>{filtered.map(x=><tr key={x.id} onClick={()=>setSelected(x)} className={selected.id===x.id?'selected-row':''}><td><strong>{x.employee}</strong></td><td>{x.course}<small>{x.code}</small></td><td>{x.site}</td><td>{x.due}</td><td><span className={`badge ${x.status.toLowerCase().replace(' ','-')}`}>{x.status}</span></td></tr>)}</tbody></table></div>
 <aside className="panel training-detail"><span className="signal">Qualification record</span><h3>{selected.employee}</h3><p>{selected.course}</p><dl><dt>Course code</dt><dd>{selected.code}</dd><dt>Facility</dt><dd>{selected.site}</dd><dt>Due date</dt><dd>{selected.due}</dd><dt>Current status</dt><dd>{selected.status}</dd><dt>Assessment</dt><dd>{selected.score?`${selected.score}% · Passed`:'Pending'}</dd></dl><h4>Competency controls</h4><ul><li>Completion evidence required</li><li>Passing score enforced</li><li>Renewal date generated automatically</li><li>Expiring qualification alerts</li></ul>{selected.status!=='Completed'&&<button onClick={()=>complete(selected.id)}>Record completion</button>}</aside></section></>;
}
