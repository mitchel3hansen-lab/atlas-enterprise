import { useMemo, useState } from 'react';

type Severity = 'Low'|'Moderate'|'High'|'Critical';
type Status = 'Draft'|'Submitted'|'Assigned'|'Investigating'|'Verification'|'Closed';
type Incident = {
  id:string; number:string; title:string; description:string; facility:string; severity:Severity;
  status:Status; riskScore:number; updated:string; version:number; investigator?:string;
};

const seed: Incident[] = [
  {id:'1',number:'INC-2026-00001',title:'Forklift contact with structural support',description:'Forklift contacted a structural beam in a constrained aisle.',facility:'Lindon',severity:'High',status:'Submitted',riskScore:70,updated:'12 minutes ago',version:2},
  {id:'2',number:'INC-2026-00002',title:'Chemical splash during sanitation',description:'Bleach splashed toward an employee during bucket handling.',facility:'Layton 851',severity:'High',status:'Assigned',riskScore:70,updated:'1 hour ago',version:3,investigator:'Mitch Hansen'},
  {id:'3',number:'INC-2026-00003',title:'Wet-floor near miss',description:'Employee regained balance after stepping onto a wet corridor.',facility:'Lindon',severity:'Moderate',status:'Draft',riskScore:45,updated:'Yesterday',version:1}
];

export function IncidentWorkspace(){
  const [items,setItems]=useState(seed);
  const [query,setQuery]=useState('');
  const [selectedId,setSelectedId]=useState(seed[0].id);
  const [dialog,setDialog]=useState<'create'|'edit'|'assign'|null>(null);
  const selected=items.find(x=>x.id===selectedId) ?? items[0];
  const filtered=useMemo(()=>items.filter(x=>`${x.number} ${x.title} ${x.facility} ${x.investigator ?? ''}`.toLowerCase().includes(query.toLowerCase())),[items,query]);
  const risk=(severity:Severity)=>({Low:20,Moderate:45,High:70,Critical:95}[severity]);

  const create=(data:{title:string;description:string;facility:string;severity:Severity})=>{
    const n=items.length+1;
    const incident:Incident={id:crypto.randomUUID(),number:`INC-2026-${String(n).padStart(5,'0')}`,title:data.title,description:data.description,facility:data.facility,severity:data.severity,status:'Draft',riskScore:risk(data.severity),updated:'Just now',version:1};
    setItems([incident,...items]); setSelectedId(incident.id); setDialog(null);
  };
  const edit=(data:{title:string;description:string;facility:string;severity:Severity;expectedVersion:number})=>{
    setItems(items.map(x=>x.id===selected.id?{...x,...data,riskScore:risk(data.severity),updated:'Just now',version:data.expectedVersion+1}:x)); setDialog(null);
  };
  const submit=()=>setItems(items.map(x=>x.id===selected.id&&x.status==='Draft'?{...x,status:'Submitted',version:x.version+1,updated:'Just now'}:x));
  const assign=(investigator:string)=>{
    setItems(items.map(x=>x.id===selected.id&&x.status==='Submitted'?{...x,status:'Assigned',investigator,version:x.version+1,updated:'Just now'}:x)); setDialog(null);
  };

  return <section className="incident-workspace">
    <header><div><span>Atlas Manufacturing · Incident Management</span><h2>Operational incident workspace</h2><p>Create, revise, submit, and assign incidents with version-controlled records and an audit-ready timeline.</p></div><button onClick={()=>setDialog('create')}>Report incident</button></header>
    <div className="metrics"><article><small>Open incidents</small><strong>{items.filter(x=>x.status!=='Closed').length}</strong></article><article><small>Drafts requiring review</small><strong>{items.filter(x=>x.status==='Draft').length}</strong></article><article><small>Awaiting assignment</small><strong>{items.filter(x=>x.status==='Submitted').length}</strong></article><article><small>Assigned investigations</small><strong>{items.filter(x=>x.status==='Assigned').length}</strong></article></div>
    <div className="incident-layout">
      <div className="panel"><div className="toolbar"><div><h3>Incident register</h3><p>Tenant-scoped records with optimistic concurrency.</p></div><input placeholder="Search incidents" value={query} onChange={e=>setQuery(e.target.value)}/></div>
        <table><thead><tr><th>Incident</th><th>Facility</th><th>Severity</th><th>Status</th><th>Investigator</th></tr></thead><tbody>{filtered.map(x=><tr key={x.id} onClick={()=>setSelectedId(x.id)} aria-selected={x.id===selected.id}><td><strong>{x.number}</strong><small>{x.title}</small></td><td>{x.facility}</td><td><span className={`badge ${x.severity.toLowerCase()}`}>{x.severity}</span></td><td>{x.status}</td><td>{x.investigator ?? 'Unassigned'}</td></tr>)}</tbody></table>
      </div>
      <aside className="panel incident-detail"><small>{selected.number}</small><h3>{selected.title}</h3><p>{selected.description}</p><dl><div><dt>Status</dt><dd>{selected.status}</dd></div><div><dt>Risk score</dt><dd>{selected.riskScore}</dd></div><div><dt>Version</dt><dd>{selected.version}</dd></div><div><dt>Investigator</dt><dd>{selected.investigator ?? 'Not assigned'}</dd></div></dl>
        <div className="actions">{selected.status==='Draft'&&<><button className="secondary" onClick={()=>setDialog('edit')}>Edit draft</button><button onClick={submit}>Submit</button></>}{selected.status==='Submitted'&&<button onClick={()=>setDialog('assign')}>Assign investigator</button>}</div>
        <div className="timeline-preview"><h4>Latest activity</h4><p><strong>{selected.updated}</strong> · Record updated</p>{selected.investigator&&<p>Assignment retained in the incident assignment ledger.</p>}</div>
      </aside>
    </div>
    {dialog==='create'&&<IncidentDialog title="Report incident" submitLabel="Create draft" onClose={()=>setDialog(null)} onSubmit={create}/>} 
    {dialog==='edit'&&<IncidentDialog title="Edit draft" submitLabel="Save changes" initial={selected} onClose={()=>setDialog(null)} onSubmit={data=>edit({...data,expectedVersion:selected.version})}/>} 
    {dialog==='assign'&&<AssignDialog incident={selected} onClose={()=>setDialog(null)} onAssign={assign}/>} 
  </section>;
}

function IncidentDialog({title,submitLabel,initial,onClose,onSubmit}:{title:string;submitLabel:string;initial?:Incident;onClose:()=>void;onSubmit:(x:{title:string;description:string;facility:string;severity:Severity})=>void}){
  const [incidentTitle,setIncidentTitle]=useState(initial?.title ?? ''); const [description,setDescription]=useState(initial?.description ?? ''); const [facility,setFacility]=useState(initial?.facility ?? 'Lindon'); const [severity,setSeverity]=useState<Severity>(initial?.severity ?? 'Moderate');
  return <div className="modal"><div className="dialog"><h3>{title}</h3><p>{initial?'Changes use the displayed version to prevent overwriting another user.':'Atlas creates a draft with workflow, timeline, and risk context.'}</p><label>Title<input value={incidentTitle} onChange={e=>setIncidentTitle(e.target.value)}/></label><label>Description<textarea value={description} onChange={e=>setDescription(e.target.value)}/></label><label>Facility<select value={facility} onChange={e=>setFacility(e.target.value)}><option>Lindon</option><option>Layton 851</option><option>Layton 855</option><option>Angel</option><option>Eagle Eye</option></select></label><label>Severity<select value={severity} onChange={e=>setSeverity(e.target.value as Severity)}><option>Low</option><option>Moderate</option><option>High</option><option>Critical</option></select></label><div className="actions"><button className="secondary" onClick={onClose}>Cancel</button><button disabled={!incidentTitle.trim()||!description.trim()} onClick={()=>onSubmit({title:incidentTitle,description,facility,severity})}>{submitLabel}</button></div></div></div>;
}

function AssignDialog({incident,onClose,onAssign}:{incident:Incident;onClose:()=>void;onAssign:(investigator:string)=>void}){
  const [investigator,setInvestigator]=useState(''); const [comment,setComment]=useState('');
  return <div className="modal"><div className="dialog"><h3>Assign investigator</h3><p>{incident.number} will move from Submitted to Assigned. The assignment is retained in an append-only ledger.</p><label>Investigator<input placeholder="Name or directory selection" value={investigator} onChange={e=>setInvestigator(e.target.value)}/></label><label>Assignment note<textarea value={comment} onChange={e=>setComment(e.target.value)}/></label><div className="actions"><button className="secondary" onClick={onClose}>Cancel</button><button disabled={!investigator.trim()} onClick={()=>onAssign(investigator.trim())}>Assign</button></div></div></div>;
}
