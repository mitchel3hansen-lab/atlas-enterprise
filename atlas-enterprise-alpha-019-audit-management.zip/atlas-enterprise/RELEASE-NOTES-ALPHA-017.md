# Atlas Enterprise Alpha 0.17 — Risk Management

This release adds a shared risk assessment engine for risk registers, JHAs, and HIRAs, including inherent and residual scoring, hierarchy-of-controls treatment, control verification, risk acceptance guardrails, dashboard metrics, API endpoints, PostgreSQL migration V031, and a React risk workspace.
