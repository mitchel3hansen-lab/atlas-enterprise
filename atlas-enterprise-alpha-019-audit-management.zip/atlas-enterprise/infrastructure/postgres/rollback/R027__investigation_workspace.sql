DROP TABLE IF EXISTS atlas.corrective_action_sequences;
DROP TABLE IF EXISTS atlas.corrective_actions;
DROP TABLE IF EXISTS atlas.investigation_root_causes;
DROP TABLE IF EXISTS atlas.investigation_witnesses;
DROP TABLE IF EXISTS atlas.investigation_notes;
DROP TABLE IF EXISTS atlas.investigations;
