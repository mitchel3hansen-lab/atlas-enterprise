DROP TABLE IF EXISTS atlas.corrective_actions;
DROP FUNCTION IF EXISTS atlas.next_corrective_action_number(uuid);
DROP TABLE IF EXISTS atlas.corrective_action_counters;
DELETE FROM atlas.permissions WHERE code IN ('corrective_actions.read','corrective_actions.manage','corrective_actions.execute','corrective_actions.verify');
