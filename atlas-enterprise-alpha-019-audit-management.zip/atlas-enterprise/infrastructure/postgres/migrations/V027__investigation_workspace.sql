CREATE TABLE IF NOT EXISTS atlas.investigations (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, incident_id uuid NOT NULL, stage text NOT NULL,
 lead_investigator_id uuid NOT NULL, lead_investigator_name text, team_member_ids uuid[] NOT NULL DEFAULT '{}', scope text,
 root_cause_method text, root_cause_summary text, quality_score integer NOT NULL DEFAULT 0 CHECK(quality_score BETWEEN 0 AND 100),
 started_at timestamptz NOT NULL, updated_at timestamptz NOT NULL, completed_at timestamptz, version bigint NOT NULL DEFAULT 1,
 UNIQUE(tenant_id,incident_id));
CREATE TABLE IF NOT EXISTS atlas.investigation_notes (id uuid PRIMARY KEY,tenant_id uuid NOT NULL,investigation_id uuid NOT NULL,category text NOT NULL,note text NOT NULL,created_by uuid NOT NULL,created_by_name text,created_at timestamptz NOT NULL);
CREATE TABLE IF NOT EXISTS atlas.investigation_witnesses (id uuid PRIMARY KEY,tenant_id uuid NOT NULL,investigation_id uuid NOT NULL,name text NOT NULL,contact text,statement text NOT NULL,interviewed_at timestamptz NOT NULL,created_by uuid NOT NULL,created_at timestamptz NOT NULL);
CREATE TABLE IF NOT EXISTS atlas.investigation_root_causes (id uuid PRIMARY KEY,tenant_id uuid NOT NULL,investigation_id uuid NOT NULL,method text NOT NULL,problem text NOT NULL,whys text[] NOT NULL DEFAULT '{}',fishbone_causes jsonb NOT NULL DEFAULT '{}',root_cause text NOT NULL,created_by uuid NOT NULL,created_at timestamptz NOT NULL,version bigint NOT NULL DEFAULT 1,UNIQUE(tenant_id,investigation_id));
CREATE TABLE IF NOT EXISTS atlas.corrective_actions (id uuid PRIMARY KEY,tenant_id uuid NOT NULL,investigation_id uuid NOT NULL,incident_id uuid NOT NULL,action_number text NOT NULL,title text NOT NULL,description text NOT NULL,owner_id uuid NOT NULL,owner_name text,due_at timestamptz NOT NULL,priority text NOT NULL,status text NOT NULL,verification_method text NOT NULL,completion_notes text,verification_notes text,created_by uuid NOT NULL,created_at timestamptz NOT NULL,updated_at timestamptz NOT NULL,verified_at timestamptz,version bigint NOT NULL DEFAULT 1,UNIQUE(tenant_id,action_number));
CREATE TABLE IF NOT EXISTS atlas.corrective_action_sequences (tenant_id uuid NOT NULL,action_year integer NOT NULL,next_number integer NOT NULL,PRIMARY KEY(tenant_id,action_year));
CREATE INDEX IF NOT EXISTS ix_investigations_tenant_stage ON atlas.investigations(tenant_id,stage);
CREATE INDEX IF NOT EXISTS ix_corrective_actions_tenant_status_due ON atlas.corrective_actions(tenant_id,status,due_at);
