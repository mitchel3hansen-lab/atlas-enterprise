# Atlas Enterprise Alpha 0.15 — Inspection Management

This release adds the first end-to-end inspection workflow to Safety Management Systems.

## Highlights
- Reusable inspection templates
- Scheduled and ad hoc inspection execution
- Field response capture with evidence references
- Risk-ranked findings
- Completion and closure guardrails
- Inspection queue and checklist workspace
- New `inspections.read`, `inspections.manage`, and `inspections.execute` permissions

## Database
Apply `V029__inspection_management.sql` after V028. A matching rollback script is included.
