# Code of Conduct

Atlas Enterprise contributors are expected to communicate professionally, welcome constructive disagreement, protect confidential information, and focus reviews on the work rather than the person.

Harassment, discrimination, threats, doxxing, and deliberately disruptive behavior are not acceptable. Repository maintainers may remove content or restrict participation when necessary to protect the project and its contributors.
