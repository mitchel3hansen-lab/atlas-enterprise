namespace Atlas.SharedKernel.Entities;

/// <summary>Common auditable and tenant-aware aggregate foundation for Atlas domain objects.</summary>
public abstract class AtlasObject : AggregateRoot<Guid>
{
    protected AtlasObject(
        Guid id,
        Guid tenantId,
        Guid organizationId,
        Guid? siteId,
        string createdBy,
        DateTimeOffset createdAt) : base(RequireId(id, nameof(id)))
    {
        TenantId = RequireId(tenantId, nameof(tenantId));
        OrganizationId = RequireId(organizationId, nameof(organizationId));
        SiteId = siteId == Guid.Empty ? null : siteId;
        CreatedBy = RequireActor(createdBy, nameof(createdBy));
        UpdatedBy = CreatedBy;
        CreatedAt = createdAt;
        UpdatedAt = createdAt;
        Version = 1;
    }

    public Guid TenantId { get; }
    public Guid OrganizationId { get; }
    public Guid? SiteId { get; protected set; }
    public DateTimeOffset CreatedAt { get; }
    public DateTimeOffset UpdatedAt { get; private set; }
    public string CreatedBy { get; }
    public string UpdatedBy { get; private set; }
    public long Version { get; private set; }
    public bool IsDeleted { get; private set; }
    public DateTimeOffset? DeletedAt { get; private set; }
    public string? DeletedBy { get; private set; }

    protected void MarkUpdated(string actorId, DateTimeOffset updatedAt)
    {
        if (IsDeleted)
            throw new InvalidOperationException("A deleted object cannot be updated.");
        if (updatedAt < UpdatedAt)
            throw new ArgumentOutOfRangeException(nameof(updatedAt), "Update time cannot precede the prior update.");

        UpdatedBy = RequireActor(actorId, nameof(actorId));
        UpdatedAt = updatedAt;
        Version++;
    }

    public void SoftDelete(string actorId, DateTimeOffset deletedAt)
    {
        if (IsDeleted)
            return;
        if (deletedAt < UpdatedAt)
            throw new ArgumentOutOfRangeException(nameof(deletedAt), "Deletion time cannot precede the prior update.");

        var actor = RequireActor(actorId, nameof(actorId));
        IsDeleted = true;
        DeletedBy = actor;
        DeletedAt = deletedAt;
        UpdatedBy = actor;
        UpdatedAt = deletedAt;
        Version++;
    }

    private static Guid RequireId(Guid value, string parameterName) =>
        value == Guid.Empty
            ? throw new ArgumentException("A non-empty identifier is required.", parameterName)
            : value;

    private static string RequireActor(string value, string parameterName) =>
        string.IsNullOrWhiteSpace(value)
            ? throw new ArgumentException("An actor identifier is required.", parameterName)
            : value.Trim();
}
