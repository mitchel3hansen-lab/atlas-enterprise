namespace Atlas.SharedKernel.Errors;

public enum ErrorType
{
    None = 0,
    Validation,
    NotFound,
    Unauthorized,
    Forbidden,
    Conflict,
    Concurrency,
    BusinessRuleViolation,
    Unexpected
}
