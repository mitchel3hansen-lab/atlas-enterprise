namespace Atlas.SharedKernel.Errors;

/// <summary>Machine-readable failure with a stable code and human-readable description.</summary>
public sealed record Error(string Code, string Description, ErrorType Type)
{
    public static readonly Error None = new(string.Empty, string.Empty, ErrorType.None);

    public static Error Validation(string code, string description) => new(code, description, ErrorType.Validation);
    public static Error NotFound(string code, string description) => new(code, description, ErrorType.NotFound);
    public static Error Unauthorized(string code, string description) => new(code, description, ErrorType.Unauthorized);
    public static Error Forbidden(string code, string description) => new(code, description, ErrorType.Forbidden);
    public static Error Conflict(string code, string description) => new(code, description, ErrorType.Conflict);
    public static Error Concurrency(string code, string description) => new(code, description, ErrorType.Concurrency);
    public static Error BusinessRule(string code, string description) => new(code, description, ErrorType.BusinessRuleViolation);
    public static Error Unexpected(string code, string description) => new(code, description, ErrorType.Unexpected);
}
