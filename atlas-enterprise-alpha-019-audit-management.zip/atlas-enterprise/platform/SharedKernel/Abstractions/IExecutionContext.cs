namespace Atlas.SharedKernel.Abstractions;

public interface IExecutionContext
{
    string CorrelationId { get; }
    string? RequestId { get; }
    string? TraceId { get; }
}
