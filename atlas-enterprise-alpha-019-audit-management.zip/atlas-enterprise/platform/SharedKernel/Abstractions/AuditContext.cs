namespace Atlas.SharedKernel.Abstractions;

public sealed record AuditContext(
    string UserId,
    Guid TenantId,
    Guid OrganizationId,
    Guid? SiteId,
    string CorrelationId,
    string? RequestId,
    string? TraceId);
