namespace Atlas.SharedKernel.Abstractions;

public interface IIdGenerator
{
    Guid NewGuid();
}
