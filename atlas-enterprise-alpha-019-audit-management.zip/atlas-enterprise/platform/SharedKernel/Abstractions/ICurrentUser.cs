namespace Atlas.SharedKernel.Abstractions;

public interface ICurrentUser
{
    string UserId { get; }
    string? DisplayName { get; }
    bool IsAuthenticated { get; }
}
