namespace Atlas.SharedKernel.Abstractions;

public interface ITenantContext
{
    Guid TenantId { get; }
    Guid OrganizationId { get; }
    Guid? SiteId { get; }
}
