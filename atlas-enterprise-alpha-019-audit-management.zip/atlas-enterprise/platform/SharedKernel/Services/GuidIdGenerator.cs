using Atlas.SharedKernel.Abstractions;

namespace Atlas.SharedKernel.Services;

public sealed class GuidIdGenerator : IIdGenerator
{
    public Guid NewGuid() => Guid.NewGuid();
}
