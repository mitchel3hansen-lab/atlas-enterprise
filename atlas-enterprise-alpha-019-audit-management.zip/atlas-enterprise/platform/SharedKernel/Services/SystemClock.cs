using Atlas.SharedKernel.Abstractions;

namespace Atlas.SharedKernel.Services;

public sealed class SystemClock : IClock
{
    public DateTimeOffset UtcNow => DateTimeOffset.UtcNow;
}
