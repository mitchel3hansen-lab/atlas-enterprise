namespace Atlas.SharedKernel.Events;

/// <summary>Marks an immutable fact that occurred in the domain.</summary>
public interface IDomainEvent
{
    Guid EventId { get; }
    DateTimeOffset OccurredAt { get; }
}
