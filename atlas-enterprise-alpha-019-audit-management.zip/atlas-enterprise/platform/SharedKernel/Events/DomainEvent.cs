namespace Atlas.SharedKernel.Events;

/// <summary>Base record for immutable domain events.</summary>
public abstract record DomainEvent : IDomainEvent
{
    protected DomainEvent(Guid eventId, DateTimeOffset occurredAt)
    {
        if (eventId == Guid.Empty)
            throw new ArgumentException("A domain event ID is required.", nameof(eventId));

        EventId = eventId;
        OccurredAt = occurredAt;
    }

    public Guid EventId { get; }
    public DateTimeOffset OccurredAt { get; }
}
