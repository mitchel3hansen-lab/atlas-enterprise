# Contributing to Atlas Enterprise

## Working agreement

Atlas is developed through small, reviewable pull requests. `main` must remain deployable.

## Local setup

```bash
cp .env.example .env
docker compose up --build
```

## Pull-request requirements

A pull request should include:

- A concise problem statement and implementation summary
- Tests for changed behavior
- Documentation for user-facing, API, architecture, or operational changes
- A migration and rollback plan when the database changes
- No committed secrets, generated build output, or local environment files

## Commit style

Use imperative, scoped commit messages where practical:

```text
feat(incidents): add assignment endpoint
fix(timeline): preserve tenant sequence ordering
docs(governance): define release process
```

## Definition of done

Work is complete only when it builds, tests pass, documentation is current, security implications are considered, and the change can be deployed or rolled back safely.
