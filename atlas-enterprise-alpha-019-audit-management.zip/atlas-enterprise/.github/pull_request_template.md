## Purpose

Describe the problem and intended outcome.

## Changes

Summarize the implementation.

## Validation

- [ ] Backend build and tests
- [ ] Frontend build
- [ ] Database migration and rollback reviewed, if applicable
- [ ] Documentation updated
- [ ] Security and tenant-isolation impact reviewed

## Deployment and rollback

Describe operational steps or state that none are required.
