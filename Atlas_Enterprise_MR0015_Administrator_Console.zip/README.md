# Atlas Enterprise

Atlas is an operational intelligence platform with a closed-loop incident workflow, secured work queues, external notifications, automated testing, pilot deployment tooling, and tenant administration.

## Administrator Console

The Administrator role can manage:

- Tenant settings
- Pilot and maintenance modes
- Sites
- Departments
- Users and roles
- Feature flags
- Notification-provider settings

## Local administrator persona

The local development interface includes an `Administrator` persona. Production identity must come from an external OIDC provider.

## Start

```bash
cp .env.example .env
docker compose up --build -d
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger
