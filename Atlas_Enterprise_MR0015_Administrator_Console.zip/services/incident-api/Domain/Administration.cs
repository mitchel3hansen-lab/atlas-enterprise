namespace Atlas.IncidentApi.Domain;

public sealed record TenantSettings(
    Guid TenantId,
    string TenantName,
    string DefaultTimeZone,
    string IncidentPrefix,
    string CapaPrefix,
    bool PilotMode,
    bool MaintenanceMode,
    Guid UpdatedBy,
    DateTimeOffset UpdatedAt);

public sealed record TenantSite(
    Guid Id,
    string Name,
    string Code,
    bool Active);

public sealed record TenantDepartment(
    Guid Id,
    Guid? SiteId,
    string Name,
    string Code,
    bool Active);

public sealed record TenantUser(
    Guid Id,
    string DisplayName,
    string? Email,
    string Role,
    string? DepartmentCode,
    string? SiteCode,
    bool Active);

public sealed record FeatureFlag(
    Guid Id,
    string FlagKey,
    bool Enabled,
    string? Description);

public sealed record ProviderSetting(
    Guid Id,
    string ProviderType,
    bool Enabled,
    string Configuration,
    string? SecretReference);

public sealed record AdministratorConsole(
    TenantSettings Settings,
    IReadOnlyList<TenantSite> Sites,
    IReadOnlyList<TenantDepartment> Departments,
    IReadOnlyList<TenantUser> Users,
    IReadOnlyList<FeatureFlag> FeatureFlags,
    IReadOnlyList<ProviderSetting> Providers);
