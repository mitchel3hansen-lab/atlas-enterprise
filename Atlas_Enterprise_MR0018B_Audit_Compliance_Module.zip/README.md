# Atlas Enterprise

Atlas is a modular operational intelligence platform for incidents, risk, compliance, EHS, and operational resilience.

## Audit and Compliance

MR-0018B adds:

- SMETA, OSHA, and GMP framework foundations
- Dynamic audit templates and questions
- Audit scheduling and execution
- Weighted scoring
- Findings and repeat-finding indicators
- Evidence metadata
- CAPA and risk link fields
- Platform events and universal search indexing
- Audit dashboards

## Start

```bash
cp .env.example .env
docker compose up --build -d
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger
