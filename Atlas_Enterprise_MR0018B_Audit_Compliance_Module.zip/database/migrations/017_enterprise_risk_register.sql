CREATE TABLE IF NOT EXISTS risk_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    name VARCHAR(120) NOT NULL,
    code VARCHAR(40) NOT NULL,
    description TEXT,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (tenant_id, code)
);

CREATE TABLE IF NOT EXISTS risk_register (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    risk_number VARCHAR(40) NOT NULL,
    title VARCHAR(220) NOT NULL,
    description TEXT NOT NULL,
    category_id UUID REFERENCES risk_categories(id),
    site VARCHAR(120),
    department VARCHAR(120),
    process VARCHAR(160),
    owner_id UUID NOT NULL,
    reviewer_id UUID,
    status VARCHAR(40) NOT NULL DEFAULT 'Identified',
    inherent_likelihood INTEGER NOT NULL CHECK (inherent_likelihood BETWEEN 1 AND 5),
    inherent_severity INTEGER NOT NULL CHECK (inherent_severity BETWEEN 1 AND 5),
    residual_likelihood INTEGER NOT NULL CHECK (residual_likelihood BETWEEN 1 AND 5),
    residual_severity INTEGER NOT NULL CHECK (residual_severity BETWEEN 1 AND 5),
    target_likelihood INTEGER CHECK (target_likelihood BETWEEN 1 AND 5),
    target_severity INTEGER CHECK (target_severity BETWEEN 1 AND 5),
    risk_velocity VARCHAR(20) NOT NULL DEFAULT 'Medium',
    trend VARCHAR(20) NOT NULL DEFAULT 'Stable',
    identified_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    next_review_at TIMESTAMPTZ NOT NULL,
    last_reviewed_at TIMESTAMPTZ,
    accepted_by UUID,
    accepted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, risk_number)
);

CREATE TABLE IF NOT EXISTS risk_controls (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    risk_id UUID NOT NULL REFERENCES risk_register(id) ON DELETE CASCADE,
    control_type VARCHAR(60) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    owner_id UUID,
    effectiveness VARCHAR(30) NOT NULL DEFAULT 'NotAssessed',
    verification_method TEXT,
    verified_at TIMESTAMPTZ,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS risk_reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    risk_id UUID NOT NULL REFERENCES risk_register(id) ON DELETE CASCADE,
    reviewer_id UUID NOT NULL,
    previous_likelihood INTEGER NOT NULL,
    previous_severity INTEGER NOT NULL,
    new_likelihood INTEGER NOT NULL,
    new_severity INTEGER NOT NULL,
    decision VARCHAR(40) NOT NULL,
    comments TEXT NOT NULL,
    reviewed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS risk_links (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    risk_id UUID NOT NULL REFERENCES risk_register(id) ON DELETE CASCADE,
    entity_type VARCHAR(80) NOT NULL,
    entity_id UUID NOT NULL,
    relationship VARCHAR(80) NOT NULL,
    linked_by UUID NOT NULL,
    linked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, risk_id, entity_type, entity_id, relationship)
);

CREATE TABLE IF NOT EXISTS risk_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    risk_id UUID NOT NULL REFERENCES risk_register(id) ON DELETE CASCADE,
    event_type VARCHAR(80) NOT NULL,
    actor_id UUID NOT NULL,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_risk_register_owner_status
    ON risk_register (tenant_id, owner_id, status, next_review_at);

CREATE INDEX IF NOT EXISTS ix_risk_register_scores
    ON risk_register (
        tenant_id,
        (residual_likelihood * residual_severity) DESC
    );

CREATE INDEX IF NOT EXISTS ix_risk_reviews_parent
    ON risk_reviews (risk_id, reviewed_at DESC);

CREATE INDEX IF NOT EXISTS ix_risk_links_entity
    ON risk_links (tenant_id, entity_type, entity_id);

INSERT INTO risk_categories (
    id, tenant_id, name, code, description)
VALUES
(
    '17000000-0000-0000-0000-000000000001',
    '11111111-1111-1111-1111-111111111111',
    'Occupational Safety',
    'SAFETY',
    'Worker injury, illness, and workplace hazard risks.'
),
(
    '17000000-0000-0000-0000-000000000002',
    '11111111-1111-1111-1111-111111111111',
    'Operational',
    'OPERATIONS',
    'Production, warehouse, equipment, and process continuity risks.'
),
(
    '17000000-0000-0000-0000-000000000003',
    '11111111-1111-1111-1111-111111111111',
    'Compliance',
    'COMPLIANCE',
    'Regulatory, audit, and management-system risks.'
)
ON CONFLICT (tenant_id, code) DO NOTHING;
