CREATE TABLE IF NOT EXISTS audit_frameworks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    framework_key VARCHAR(100) NOT NULL,
    display_name VARCHAR(180) NOT NULL,
    version VARCHAR(40) NOT NULL,
    description TEXT,
    scoring_model VARCHAR(40) NOT NULL DEFAULT 'PassFail',
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, framework_key, version)
);

CREATE TABLE IF NOT EXISTS audit_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    framework_id UUID NOT NULL REFERENCES audit_frameworks(id),
    name VARCHAR(200) NOT NULL,
    description TEXT,
    version INTEGER NOT NULL DEFAULT 1,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_by UUID NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, framework_id, name, version)
);

CREATE TABLE IF NOT EXISTS audit_questions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    template_id UUID NOT NULL REFERENCES audit_templates(id) ON DELETE CASCADE,
    section VARCHAR(180) NOT NULL,
    requirement_reference VARCHAR(160),
    prompt TEXT NOT NULL,
    response_type VARCHAR(40) NOT NULL DEFAULT 'PassFail',
    weight NUMERIC(8,2) NOT NULL DEFAULT 1,
    critical BOOLEAN NOT NULL DEFAULT FALSE,
    sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS audits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    audit_number VARCHAR(40) NOT NULL,
    template_id UUID NOT NULL REFERENCES audit_templates(id),
    title VARCHAR(220) NOT NULL,
    site VARCHAR(120),
    department VARCHAR(120),
    lead_auditor_id UUID NOT NULL,
    status VARCHAR(40) NOT NULL DEFAULT 'Planned',
    scheduled_start TIMESTAMPTZ NOT NULL,
    scheduled_end TIMESTAMPTZ,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    approved_at TIMESTAMPTZ,
    approved_by UUID,
    score_percent NUMERIC(8,2),
    rating VARCHAR(40),
    summary TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, audit_number)
);

CREATE TABLE IF NOT EXISTS audit_responses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    audit_id UUID NOT NULL REFERENCES audits(id) ON DELETE CASCADE,
    question_id UUID NOT NULL REFERENCES audit_questions(id),
    response VARCHAR(40),
    score NUMERIC(8,2),
    comments TEXT,
    answered_by UUID NOT NULL,
    answered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (audit_id, question_id)
);

CREATE TABLE IF NOT EXISTS audit_findings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    audit_id UUID NOT NULL REFERENCES audits(id) ON DELETE CASCADE,
    finding_number VARCHAR(50) NOT NULL,
    finding_type VARCHAR(40) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    requirement_reference VARCHAR(160),
    title VARCHAR(220) NOT NULL,
    description TEXT NOT NULL,
    owner_id UUID,
    due_at TIMESTAMPTZ,
    status VARCHAR(40) NOT NULL DEFAULT 'Open',
    repeat_finding BOOLEAN NOT NULL DEFAULT FALSE,
    capa_id UUID,
    risk_id UUID,
    closed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, finding_number)
);

CREATE TABLE IF NOT EXISTS audit_evidence (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    audit_id UUID NOT NULL REFERENCES audits(id) ON DELETE CASCADE,
    finding_id UUID REFERENCES audit_findings(id) ON DELETE CASCADE,
    platform_file_id UUID,
    title VARCHAR(220) NOT NULL,
    evidence_type VARCHAR(60) NOT NULL,
    reference_uri TEXT,
    sha256 VARCHAR(64),
    added_by UUID NOT NULL,
    added_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    audit_id UUID NOT NULL REFERENCES audits(id) ON DELETE CASCADE,
    event_type VARCHAR(80) NOT NULL,
    actor_id UUID NOT NULL,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_audits_schedule
    ON audits (tenant_id, status, scheduled_start);

CREATE INDEX IF NOT EXISTS ix_audit_findings_open
    ON audit_findings (tenant_id, status, due_at, severity);

CREATE INDEX IF NOT EXISTS ix_audit_responses_parent
    ON audit_responses (audit_id);

INSERT INTO audit_frameworks (
    id, tenant_id, framework_key, display_name, version,
    description, scoring_model)
VALUES
(
    '19000000-0000-0000-0000-000000000001',
    '11111111-1111-1111-1111-111111111111',
    'SMETA-4P',
    'SMETA 4-Pillar',
    '1.0',
    'Labor Standards, Health and Safety, Environment, and Business Ethics.',
    'Weighted'
),
(
    '19000000-0000-0000-0000-000000000002',
    '11111111-1111-1111-1111-111111111111',
    'OSHA-GENERAL',
    'OSHA General Industry',
    '1.0',
    'Core OSHA 29 CFR 1910 audit framework.',
    'PassFail'
),
(
    '19000000-0000-0000-0000-000000000003',
    '11111111-1111-1111-1111-111111111111',
    'GMP',
    'FDA / GMP Internal Audit',
    '1.0',
    'Internal GMP audit framework for regulated manufacturing.',
    'Weighted'
)
ON CONFLICT (tenant_id, framework_key, version) DO NOTHING;

INSERT INTO platform_modules (
    id, tenant_id, module_key, display_name, version, capabilities)
VALUES
(
    '19000000-0000-0000-0000-000000000010',
    '11111111-1111-1111-1111-111111111111',
    'atlas.audit',
    'Audit and Compliance',
    '1.0.0',
    '["frameworks","templates","questions","audits","findings","evidence","scoring"]'::jsonb
)
ON CONFLICT (tenant_id, module_key) DO NOTHING;
