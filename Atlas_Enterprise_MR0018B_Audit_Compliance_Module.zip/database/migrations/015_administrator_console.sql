CREATE TABLE IF NOT EXISTS tenant_settings (
    tenant_id UUID PRIMARY KEY,
    tenant_name VARCHAR(180) NOT NULL,
    default_time_zone VARCHAR(80) NOT NULL DEFAULT 'America/Denver',
    incident_prefix VARCHAR(20) NOT NULL DEFAULT 'INC',
    capa_prefix VARCHAR(20) NOT NULL DEFAULT 'CAPA',
    pilot_mode BOOLEAN NOT NULL DEFAULT TRUE,
    maintenance_mode BOOLEAN NOT NULL DEFAULT FALSE,
    updated_by UUID NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tenant_sites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    name VARCHAR(160) NOT NULL,
    code VARCHAR(40) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, code)
);

CREATE TABLE IF NOT EXISTS tenant_departments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    site_id UUID REFERENCES tenant_sites(id),
    name VARCHAR(160) NOT NULL,
    code VARCHAR(40) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, code)
);

CREATE TABLE IF NOT EXISTS tenant_users (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL,
    display_name VARCHAR(180) NOT NULL,
    email VARCHAR(240),
    role VARCHAR(60) NOT NULL,
    department_code VARCHAR(40),
    site_code VARCHAR(40),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, email)
);

CREATE TABLE IF NOT EXISTS feature_flags (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    flag_key VARCHAR(120) NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT FALSE,
    description TEXT,
    updated_by UUID NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, flag_key)
);

CREATE TABLE IF NOT EXISTS provider_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    provider_type VARCHAR(60) NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT FALSE,
    configuration JSONB NOT NULL DEFAULT '{}'::jsonb,
    secret_reference VARCHAR(240),
    updated_by UUID NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, provider_type)
);

CREATE INDEX IF NOT EXISTS ix_tenant_users_role
    ON tenant_users (tenant_id, role, active);

CREATE INDEX IF NOT EXISTS ix_tenant_departments_site
    ON tenant_departments (tenant_id, site_id, active);

INSERT INTO tenant_settings (
    tenant_id, tenant_name, default_time_zone,
    incident_prefix, capa_prefix, pilot_mode,
    maintenance_mode, updated_by)
VALUES (
    '11111111-1111-1111-1111-111111111111',
    'Somafina Pilot',
    'America/Denver',
    'INC',
    'CAPA',
    TRUE,
    FALSE,
    '88888888-8888-8888-8888-888888888888'
)
ON CONFLICT (tenant_id) DO NOTHING;

INSERT INTO tenant_sites (id, tenant_id, name, code)
VALUES
('15100000-0000-0000-0000-000000000001',
 '11111111-1111-1111-1111-111111111111',
 'Lindon', 'LINDON'),
('15100000-0000-0000-0000-000000000002',
 '11111111-1111-1111-1111-111111111111',
 'Layton', 'LAYTON')
ON CONFLICT (tenant_id, code) DO NOTHING;

INSERT INTO tenant_departments (
    id, tenant_id, site_id, name, code)
VALUES
('15200000-0000-0000-0000-000000000001',
 '11111111-1111-1111-1111-111111111111',
 '15100000-0000-0000-0000-000000000001',
 'Warehouse', 'WAREHOUSE'),
('15200000-0000-0000-0000-000000000002',
 '11111111-1111-1111-1111-111111111111',
 '15100000-0000-0000-0000-000000000001',
 'Safety', 'SAFETY')
ON CONFLICT (tenant_id, code) DO NOTHING;
