ALTER TABLE tenant_settings
    ADD COLUMN IF NOT EXISTS maintenance_message TEXT,
    ADD COLUMN IF NOT EXISTS emergency_write_lock BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS pilot_banner_message TEXT,
    ADD COLUMN IF NOT EXISTS allow_read_only_access BOOLEAN NOT NULL DEFAULT TRUE;

INSERT INTO feature_flags (
    id, tenant_id, flag_key, enabled, description, updated_by)
VALUES
(
    '16000000-0000-0000-0000-000000000001',
    '11111111-1111-1111-1111-111111111111',
    'incident-creation',
    TRUE,
    'Controls whether new incident drafts can be created.',
    '88888888-8888-8888-8888-888888888888'
),
(
    '16000000-0000-0000-0000-000000000002',
    '11111111-1111-1111-1111-111111111111',
    'external-notifications',
    TRUE,
    'Controls delivery to external notification providers.',
    '88888888-8888-8888-8888-888888888888'
),
(
    '16000000-0000-0000-0000-000000000003',
    '11111111-1111-1111-1111-111111111111',
    'executive-dashboard',
    TRUE,
    'Controls access to the executive dashboard experience.',
    '88888888-8888-8888-8888-888888888888'
)
ON CONFLICT (tenant_id, flag_key) DO NOTHING;
