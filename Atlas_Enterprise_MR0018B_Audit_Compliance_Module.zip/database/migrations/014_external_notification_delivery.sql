CREATE TABLE IF NOT EXISTS notification_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    user_id UUID NOT NULL,
    email_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    teams_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    in_app_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    quiet_hours_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    quiet_hours_start TIME,
    quiet_hours_end TIME,
    time_zone VARCHAR(80) NOT NULL DEFAULT 'America/Denver',
    digest_mode VARCHAR(30) NOT NULL DEFAULT 'Immediate',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, user_id)
);

CREATE TABLE IF NOT EXISTS notification_delivery_attempts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    notification_id UUID NOT NULL REFERENCES notifications(id) ON DELETE CASCADE,
    channel VARCHAR(30) NOT NULL,
    provider VARCHAR(60) NOT NULL,
    destination TEXT,
    status VARCHAR(30) NOT NULL DEFAULT 'Pending',
    attempt_number INTEGER NOT NULL DEFAULT 1,
    provider_message_id TEXT,
    response_code VARCHAR(40),
    response_body TEXT,
    error_message TEXT,
    next_attempt_at TIMESTAMPTZ,
    attempted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notification_dead_letters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    notification_id UUID NOT NULL,
    channel VARCHAR(30) NOT NULL,
    reason TEXT NOT NULL,
    payload JSONB NOT NULL,
    failed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ,
    resolution_notes TEXT
);

CREATE INDEX IF NOT EXISTS ix_notification_preferences_user
    ON notification_preferences (tenant_id, user_id);

CREATE INDEX IF NOT EXISTS ix_delivery_attempts_pending
    ON notification_delivery_attempts (status, next_attempt_at);

CREATE INDEX IF NOT EXISTS ix_delivery_attempts_notification
    ON notification_delivery_attempts (notification_id, attempted_at DESC);

CREATE INDEX IF NOT EXISTS ix_dead_letters_unresolved
    ON notification_dead_letters (tenant_id, resolved_at, failed_at DESC);
