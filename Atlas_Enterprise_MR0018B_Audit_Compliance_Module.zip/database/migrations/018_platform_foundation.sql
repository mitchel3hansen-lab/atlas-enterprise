CREATE TABLE IF NOT EXISTS platform_modules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    module_key VARCHAR(120) NOT NULL,
    display_name VARCHAR(180) NOT NULL,
    version VARCHAR(40) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Installed',
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    capabilities JSONB NOT NULL DEFAULT '[]'::jsonb,
    configuration JSONB NOT NULL DEFAULT '{}'::jsonb,
    installed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, module_key)
);

CREATE TABLE IF NOT EXISTS platform_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    event_name VARCHAR(160) NOT NULL,
    aggregate_type VARCHAR(100) NOT NULL,
    aggregate_id UUID,
    payload JSONB NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    status VARCHAR(30) NOT NULL DEFAULT 'Pending',
    attempt_count INTEGER NOT NULL DEFAULT 0,
    available_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    published_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS platform_event_subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    module_key VARCHAR(120) NOT NULL,
    event_name VARCHAR(160) NOT NULL,
    handler_key VARCHAR(160) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    configuration JSONB NOT NULL DEFAULT '{}'::jsonb,
    UNIQUE (tenant_id, module_key, event_name, handler_key)
);

CREATE TABLE IF NOT EXISTS platform_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    rule_key VARCHAR(140) NOT NULL,
    display_name VARCHAR(180) NOT NULL,
    event_name VARCHAR(160) NOT NULL,
    priority INTEGER NOT NULL DEFAULT 100,
    condition_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    action_json JSONB NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    stop_processing BOOLEAN NOT NULL DEFAULT FALSE,
    created_by UUID NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, rule_key)
);

CREATE TABLE IF NOT EXISTS platform_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    job_type VARCHAR(140) NOT NULL,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    status VARCHAR(30) NOT NULL DEFAULT 'Queued',
    priority INTEGER NOT NULL DEFAULT 100,
    scheduled_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    attempt_count INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 5,
    last_error TEXT,
    correlation_id VARCHAR(100),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS platform_files (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    module_key VARCHAR(120) NOT NULL,
    entity_type VARCHAR(100) NOT NULL,
    entity_id UUID NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    content_type VARCHAR(120) NOT NULL,
    size_bytes BIGINT NOT NULL CHECK (size_bytes >= 0),
    storage_provider VARCHAR(60) NOT NULL,
    storage_key TEXT NOT NULL,
    sha256 VARCHAR(64),
    version INTEGER NOT NULL DEFAULT 1,
    uploaded_by UUID NOT NULL,
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, storage_provider, storage_key, version)
);

CREATE TABLE IF NOT EXISTS platform_search_documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    module_key VARCHAR(120) NOT NULL,
    entity_type VARCHAR(100) NOT NULL,
    entity_id UUID NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    keywords TEXT,
    route TEXT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    search_vector TSVECTOR GENERATED ALWAYS AS (
        setweight(to_tsvector('english', COALESCE(title, '')), 'A') ||
        setweight(to_tsvector('english', COALESCE(body, '')), 'B') ||
        setweight(to_tsvector('english', COALESCE(keywords, '')), 'C')
    ) STORED,
    UNIQUE (tenant_id, module_key, entity_type, entity_id)
);

CREATE INDEX IF NOT EXISTS ix_platform_events_dispatch
    ON platform_events (status, available_at, created_at);

CREATE INDEX IF NOT EXISTS ix_platform_jobs_dispatch
    ON platform_jobs (status, scheduled_at, priority, created_at);

CREATE INDEX IF NOT EXISTS ix_platform_search_vector
    ON platform_search_documents USING GIN (search_vector);

CREATE INDEX IF NOT EXISTS ix_platform_files_entity
    ON platform_files (tenant_id, module_key, entity_type, entity_id);

INSERT INTO platform_modules (
    id, tenant_id, module_key, display_name, version, capabilities)
VALUES
(
    '18000000-0000-0000-0000-000000000001',
    '11111111-1111-1111-1111-111111111111',
    'atlas.incidents',
    'Incident Management',
    '1.0.0',
    '["incidents","investigations","capa","closure"]'::jsonb
),
(
    '18000000-0000-0000-0000-000000000002',
    '11111111-1111-1111-1111-111111111111',
    'atlas.risk',
    'Enterprise Risk',
    '1.0.0',
    '["risk-register","controls","reviews","heat-map"]'::jsonb
),
(
    '18000000-0000-0000-0000-000000000003',
    '11111111-1111-1111-1111-111111111111',
    'atlas.notifications',
    'Notifications and Work Queue',
    '1.0.0',
    '["work-queue","in-app","email","teams"]'::jsonb
)
ON CONFLICT (tenant_id, module_key) DO NOTHING;
