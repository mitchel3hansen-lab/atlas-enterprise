# ADR-007: Tenant Administration

## Status

Accepted

## Decision

Tenant configuration is stored in tenant-scoped administration tables and managed only through Administrator-authorized APIs.

## Rationale

Operational configuration must be changeable without editing application code while remaining isolated by tenant.

## Consequences

- Sites, departments, users, features, and providers are tenant scoped.
- Secret values are not stored directly in provider configuration.
- A future permission engine may replace fixed administrator-only access.
