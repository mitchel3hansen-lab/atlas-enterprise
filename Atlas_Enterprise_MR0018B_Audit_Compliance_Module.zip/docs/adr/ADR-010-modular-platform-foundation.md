# ADR-010: Modular Platform Foundation

## Status

Accepted

## Decision

Atlas uses explicit module contracts and shared platform services for durable events, rules, jobs, files, and search.

## Rationale

Each domain module needs the same operational capabilities. Reimplementing them within Audit, Training, Industrial Hygiene, and other modules would create inconsistent behavior and unnecessary coupling.

## Consequences

- Modules depend on stable interfaces rather than storage details.
- Tenant installation status is stored separately from runtime module registration.
- Events are persisted before asynchronous processing.
- Physical file storage remains replaceable.
- Universal search uses a normalized cross-module document model.
