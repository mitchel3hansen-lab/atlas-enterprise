# ADR-006: External Notification Delivery

## Status

Accepted

## Decision

Atlas keeps in-app notifications as the durable source and records each external delivery attempt separately.

## Rationale

Email and webhook delivery can fail independently of operational workflow state. Delivery failures must not remove or corrupt the source notification.

## Consequences

- External providers are adapters, not the system of record.
- Every attempt is traceable.
- Dead-letter handling is explicit.
- User quiet hours and channel preferences are applied before delivery.
