# ADR-009: Enterprise Risk Model

## Status

Accepted

## Decision

Atlas uses a shared enterprise risk entity with inherent, residual, and target 5×5 scoring. Operational records connect to risks through typed links.

## Rationale

Incidents, CAPAs, audits, Gemba findings, and hazards should contribute to one risk picture without duplicating risk records.

## Consequences

- Risks become a cross-module parent entity.
- Links preserve source-system context.
- Risk reviews retain score history.
- Future scoring models can extend the current 5×5 foundation.
