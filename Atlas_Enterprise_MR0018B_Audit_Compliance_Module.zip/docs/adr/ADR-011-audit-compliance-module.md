# ADR-011: Audit and Compliance Module

## Status

Accepted

## Decision

Audit frameworks, templates, and questions are data-driven and versioned. Audits publish platform events and index records through shared platform contracts.

## Rationale

OSHA, SMETA, ISO, GMP, and internal audits share the same operational lifecycle but require different question sets and scoring models.

## Consequences

- Framework changes do not require application code.
- Templates retain version history.
- Findings can connect to shared CAPA and risk workflows.
- Platform events enable future automation without direct cross-module writes.
