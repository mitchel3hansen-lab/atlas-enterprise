# ADR-008: Live System Controls

## Status

Accepted

## Decision

Atlas enforces tenant-level feature flags, maintenance mode, and emergency write lock through server-side middleware and endpoint filters.

## Rationale

Operational shutdown and controlled rollout must remain effective even when clients are outdated or bypass the user interface.

## Consequences

- Administrators retain emergency recovery access.
- Controls are cached briefly to reduce database traffic.
- Administrator updates invalidate the tenant cache.
- Feature flags are explicit endpoint dependencies.
