# Atlas Platform Extension Guide

## Creating a module

Implement `IAtlasModule` and register the implementation with dependency injection.

```csharp
public sealed class AuditModule : IAtlasModule
{
    public string Key => "atlas.audit";
    public string DisplayName => "Audit and Compliance";
    public Version Version => new(1, 0, 0);
    public IReadOnlyCollection<string> Capabilities =>
        ["audits", "findings", "evidence", "scoring"];
}
```

## Publishing an event

Implement `IPlatformEvent` and publish it through `IPlatformEventPublisher`.

Examples:

- `IncidentClosed`
- `RiskCreated`
- `AuditFindingIssued`
- `TrainingExpired`
- `ExposureLimitExceeded`

## Indexing searchable records

Use `IPlatformSearchIndexer` with a normalized `SearchDocument`.

## Registering files

Use `IPlatformFileStore` to register provider-neutral metadata after the physical file has been stored.

## Queuing background work

Use `PlatformJobService` for exports, digest generation, evidence processing, or other retryable tasks.

## Module rules

Rules should react to platform events instead of directly modifying another module's private tables.
