namespace Atlas.IncidentApi.Domain;

public sealed record AuditFramework(
    Guid Id,
    string FrameworkKey,
    string DisplayName,
    string Version,
    string? Description,
    string ScoringModel,
    bool Active);

public sealed record AuditTemplate(
    Guid Id,
    Guid FrameworkId,
    string Name,
    string? Description,
    int Version,
    bool Active);

public sealed record AuditQuestion(
    Guid Id,
    Guid TemplateId,
    string Section,
    string? RequirementReference,
    string Prompt,
    string ResponseType,
    decimal Weight,
    bool Critical,
    int SortOrder);

public sealed record ComplianceAudit(
    Guid Id,
    string AuditNumber,
    Guid TemplateId,
    string Title,
    string? Site,
    string? Department,
    Guid LeadAuditorId,
    string Status,
    DateTimeOffset ScheduledStart,
    DateTimeOffset? ScheduledEnd,
    DateTimeOffset? StartedAt,
    DateTimeOffset? CompletedAt,
    decimal? ScorePercent,
    string? Rating,
    string? Summary);

public sealed record AuditFinding(
    Guid Id,
    string FindingNumber,
    string FindingType,
    string Severity,
    string? RequirementReference,
    string Title,
    string Description,
    Guid? OwnerId,
    DateTimeOffset? DueAt,
    string Status,
    bool RepeatFinding,
    Guid? CapaId,
    Guid? RiskId);

public sealed record AuditWorkspace(
    ComplianceAudit Audit,
    IReadOnlyList<AuditQuestion> Questions,
    IReadOnlyList<AuditFinding> Findings);

public sealed record AuditDashboard(
    int Planned,
    int InProgress,
    int Completed,
    int Overdue,
    int OpenFindings,
    int HighSeverityFindings,
    int RepeatFindings,
    decimal AverageScore);
