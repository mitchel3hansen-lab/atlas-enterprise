namespace Atlas.IncidentApi.Domain;

public sealed record SystemControlState(
    Guid TenantId,
    bool PilotMode,
    bool MaintenanceMode,
    bool EmergencyWriteLock,
    bool AllowReadOnlyAccess,
    string? MaintenanceMessage,
    string? PilotBannerMessage,
    IReadOnlyDictionary<string, bool> FeatureFlags,
    DateTimeOffset RefreshedAt);
