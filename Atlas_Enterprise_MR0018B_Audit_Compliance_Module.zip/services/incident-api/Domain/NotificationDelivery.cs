namespace Atlas.IncidentApi.Domain;

public sealed record NotificationPreference(
    Guid UserId,
    bool EmailEnabled,
    bool TeamsEnabled,
    bool InAppEnabled,
    bool QuietHoursEnabled,
    TimeOnly? QuietHoursStart,
    TimeOnly? QuietHoursEnd,
    string TimeZone,
    string DigestMode,
    DateTimeOffset UpdatedAt);

public sealed record NotificationDeliveryAttempt(
    Guid Id,
    Guid NotificationId,
    string Channel,
    string Provider,
    string? Destination,
    string Status,
    int AttemptNumber,
    string? ProviderMessageId,
    string? ResponseCode,
    string? ErrorMessage,
    DateTimeOffset? NextAttemptAt,
    DateTimeOffset AttemptedAt);
