namespace Atlas.IncidentApi.Domain;

public sealed record EnterpriseRisk(
    Guid Id,
    string RiskNumber,
    string Title,
    string Description,
    Guid? CategoryId,
    string? CategoryName,
    string? Site,
    string? Department,
    string? Process,
    Guid OwnerId,
    Guid? ReviewerId,
    string Status,
    int InherentLikelihood,
    int InherentSeverity,
    int InherentScore,
    int ResidualLikelihood,
    int ResidualSeverity,
    int ResidualScore,
    int? TargetLikelihood,
    int? TargetSeverity,
    int? TargetScore,
    string RiskVelocity,
    string Trend,
    DateTimeOffset IdentifiedAt,
    DateTimeOffset NextReviewAt,
    DateTimeOffset? LastReviewedAt,
    DateTimeOffset UpdatedAt);

public sealed record RiskControl(
    Guid Id,
    string ControlType,
    string Title,
    string Description,
    Guid? OwnerId,
    string Effectiveness,
    string? VerificationMethod,
    DateTimeOffset? VerifiedAt,
    bool Active);

public sealed record RiskReview(
    Guid Id,
    Guid ReviewerId,
    int PreviousLikelihood,
    int PreviousSeverity,
    int NewLikelihood,
    int NewSeverity,
    string Decision,
    string Comments,
    DateTimeOffset ReviewedAt);

public sealed record RiskLink(
    Guid Id,
    string EntityType,
    Guid EntityId,
    string Relationship,
    Guid LinkedBy,
    DateTimeOffset LinkedAt);

public sealed record RiskWorkspace(
    EnterpriseRisk Risk,
    IReadOnlyList<RiskControl> Controls,
    IReadOnlyList<RiskReview> Reviews,
    IReadOnlyList<RiskLink> Links);

public sealed record RiskHeatMapCell(
    int Likelihood,
    int Severity,
    int Count);

public sealed record RiskDashboard(
    int TotalRisks,
    int CriticalRisks,
    int HighRisks,
    int OverdueReviews,
    decimal AverageResidualScore,
    IReadOnlyList<RiskHeatMapCell> HeatMap,
    IReadOnlyList<EnterpriseRisk> TopRisks);
