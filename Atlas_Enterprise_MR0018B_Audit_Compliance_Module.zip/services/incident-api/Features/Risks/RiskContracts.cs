namespace Atlas.IncidentApi.Features.Risks;

public sealed record CreateRiskRequest(
    string Title,
    string Description,
    Guid? CategoryId,
    string? Site,
    string? Department,
    string? Process,
    Guid OwnerId,
    Guid? ReviewerId,
    int InherentLikelihood,
    int InherentSeverity,
    int ResidualLikelihood,
    int ResidualSeverity,
    int? TargetLikelihood,
    int? TargetSeverity,
    string RiskVelocity,
    DateTimeOffset NextReviewAt);

public sealed record AddRiskControlRequest(
    string ControlType,
    string Title,
    string Description,
    Guid? OwnerId,
    string Effectiveness,
    string? VerificationMethod);

public sealed record ReviewRiskRequest(
    int NewLikelihood,
    int NewSeverity,
    string Decision,
    string Comments,
    DateTimeOffset NextReviewAt);

public sealed record LinkRiskRecordRequest(
    string EntityType,
    Guid EntityId,
    string Relationship);
