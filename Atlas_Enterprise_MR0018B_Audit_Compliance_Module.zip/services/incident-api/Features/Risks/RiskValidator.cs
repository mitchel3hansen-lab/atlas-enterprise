namespace Atlas.IncidentApi.Features.Risks;

public static class RiskValidator
{
    public static Dictionary<string, string[]> Validate(
        CreateRiskRequest request)
    {
        var errors = new Dictionary<string, string[]>();

        if (string.IsNullOrWhiteSpace(request.Title))
            errors["title"] = ["Title is required."];
        if (string.IsNullOrWhiteSpace(request.Description))
            errors["description"] = ["Description is required."];
        if (request.OwnerId == Guid.Empty)
            errors["ownerId"] = ["Owner is required."];
        if (!IsScore(request.InherentLikelihood))
            errors["inherentLikelihood"] = ["Likelihood must be 1 through 5."];
        if (!IsScore(request.InherentSeverity))
            errors["inherentSeverity"] = ["Severity must be 1 through 5."];
        if (!IsScore(request.ResidualLikelihood))
            errors["residualLikelihood"] = ["Likelihood must be 1 through 5."];
        if (!IsScore(request.ResidualSeverity))
            errors["residualSeverity"] = ["Severity must be 1 through 5."];
        if (request.NextReviewAt <= DateTimeOffset.UtcNow)
            errors["nextReviewAt"] = ["Next review date must be in the future."];

        return errors;
    }

    public static bool IsScore(int value) => value is >= 1 and <= 5;

    public static string Rating(int score) => score switch
    {
        >= 20 => "Critical",
        >= 12 => "High",
        >= 6 => "Medium",
        _ => "Low"
    };
}
