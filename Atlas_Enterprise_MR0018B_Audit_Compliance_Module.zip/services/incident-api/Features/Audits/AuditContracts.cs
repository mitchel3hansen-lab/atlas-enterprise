namespace Atlas.IncidentApi.Features.Audits;

public sealed record CreateAuditTemplateRequest(
    Guid FrameworkId,
    string Name,
    string? Description);

public sealed record AddAuditQuestionRequest(
    string Section,
    string? RequirementReference,
    string Prompt,
    string ResponseType,
    decimal Weight,
    bool Critical,
    int SortOrder);

public sealed record ScheduleAuditRequest(
    Guid TemplateId,
    string Title,
    string? Site,
    string? Department,
    Guid LeadAuditorId,
    DateTimeOffset ScheduledStart,
    DateTimeOffset? ScheduledEnd);

public sealed record RecordAuditResponseRequest(
    Guid QuestionId,
    string Response,
    decimal? Score,
    string? Comments);

public sealed record CreateAuditFindingRequest(
    string FindingType,
    string Severity,
    string? RequirementReference,
    string Title,
    string Description,
    Guid? OwnerId,
    DateTimeOffset? DueAt,
    bool RepeatFinding);

public sealed record CompleteAuditRequest(
    string Summary);
