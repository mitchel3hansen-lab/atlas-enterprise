using Atlas.IncidentApi.Platform.Contracts;

namespace Atlas.IncidentApi.Features.Audits;

public sealed record AuditScheduledEvent(
    Guid AuditId,
    string AuditNumber,
    DateTimeOffset ScheduledStart)
    : IPlatformEvent
{
    public string EventName => "AuditScheduled";
    public string AggregateType => "Audit";
    public Guid? AggregateId => AuditId;
}

public sealed record AuditFindingIssuedEvent(
    Guid AuditId,
    Guid FindingId,
    string Severity,
    string FindingType)
    : IPlatformEvent
{
    public string EventName => "AuditFindingIssued";
    public string AggregateType => "AuditFinding";
    public Guid? AggregateId => FindingId;
}

public sealed record AuditCompletedEvent(
    Guid AuditId,
    decimal ScorePercent,
    string Rating)
    : IPlatformEvent
{
    public string EventName => "AuditCompleted";
    public string AggregateType => "Audit";
    public Guid? AggregateId => AuditId;
}
