namespace Atlas.IncidentApi.Features.Notifications;

public sealed record UpdateNotificationPreferenceRequest(
    bool EmailEnabled,
    bool TeamsEnabled,
    bool InAppEnabled,
    bool QuietHoursEnabled,
    TimeOnly? QuietHoursStart,
    TimeOnly? QuietHoursEnd,
    string TimeZone,
    string DigestMode);

public sealed record TestNotificationRequest(
    string Channel,
    string Destination,
    string Message);
