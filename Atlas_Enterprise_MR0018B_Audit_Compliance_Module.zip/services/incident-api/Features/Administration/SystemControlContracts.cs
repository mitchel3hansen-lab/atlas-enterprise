namespace Atlas.IncidentApi.Features.Administration;

public sealed record UpdateSystemControlsRequest(
    bool PilotMode,
    bool MaintenanceMode,
    bool EmergencyWriteLock,
    bool AllowReadOnlyAccess,
    string? MaintenanceMessage,
    string? PilotBannerMessage);
