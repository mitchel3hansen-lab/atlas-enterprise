namespace Atlas.IncidentApi.Features.Administration;

public sealed record UpdateTenantSettingsRequest(
    string TenantName,
    string DefaultTimeZone,
    string IncidentPrefix,
    string CapaPrefix,
    bool PilotMode,
    bool MaintenanceMode);

public sealed record UpsertSiteRequest(
    Guid? Id,
    string Name,
    string Code,
    bool Active);

public sealed record UpsertDepartmentRequest(
    Guid? Id,
    Guid? SiteId,
    string Name,
    string Code,
    bool Active);

public sealed record UpsertTenantUserRequest(
    Guid Id,
    string DisplayName,
    string? Email,
    string Role,
    string? DepartmentCode,
    string? SiteCode,
    bool Active);

public sealed record UpsertFeatureFlagRequest(
    string FlagKey,
    bool Enabled,
    string? Description);

public sealed record UpsertProviderSettingRequest(
    string ProviderType,
    bool Enabled,
    string Configuration,
    string? SecretReference);
