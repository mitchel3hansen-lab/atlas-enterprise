using System.Text.Json;
using Atlas.IncidentApi.Platform.Contracts;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Platform.Events;

public sealed class PlatformEventPublisher(
    IConfiguration configuration)
    : IPlatformEventPublisher
{
    public async Task<Guid> PublishAsync<TEvent>(
        Guid tenantId,
        TEvent platformEvent,
        Guid actorId,
        string correlationId,
        CancellationToken cancellationToken)
        where TEvent : IPlatformEvent
    {
        const string sql = """
        INSERT INTO platform_events (
            id, tenant_id, event_name, aggregate_type,
            aggregate_id, payload, metadata, status,
            available_at, created_at)
        VALUES (
            @Id, @TenantId, @EventName, @AggregateType,
            @AggregateId, CAST(@Payload AS jsonb), CAST(@Metadata AS jsonb),
            'Pending', NOW(), NOW());
        """;

        var id = Guid.NewGuid();

        await using var connection = new NpgsqlConnection(
            configuration.GetConnectionString("Atlas"));

        await connection.ExecuteAsync(new CommandDefinition(
            sql,
            new
            {
                Id = id,
                TenantId = tenantId,
                platformEvent.EventName,
                platformEvent.AggregateType,
                platformEvent.AggregateId,
                Payload = JsonSerializer.Serialize(platformEvent),
                Metadata = JsonSerializer.Serialize(new
                {
                    actorId,
                    correlationId
                })
            },
            cancellationToken: cancellationToken));

        return id;
    }
}
