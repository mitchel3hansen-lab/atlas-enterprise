using Atlas.IncidentApi.Platform.Contracts;

namespace Atlas.IncidentApi.Platform.Modules;

public sealed class AuditModule : IAtlasModule
{
    public string Key => "atlas.audit";
    public string DisplayName => "Audit and Compliance";
    public Version Version => new(1, 0, 0);
    public IReadOnlyCollection<string> Capabilities =>
        ["frameworks", "templates", "questions", "audits", "findings", "evidence", "scoring"];
}
