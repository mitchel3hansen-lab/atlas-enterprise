using Atlas.IncidentApi.Platform.Contracts;

namespace Atlas.IncidentApi.Platform.Modules;

public sealed class ModuleRegistry(
    IEnumerable<IAtlasModule> modules)
{
    private readonly IReadOnlyDictionary<string, IAtlasModule> _modules =
        modules.ToDictionary(
            module => module.Key,
            StringComparer.OrdinalIgnoreCase);

    public IReadOnlyCollection<IAtlasModule> All =>
        _modules.Values.ToArray();

    public IAtlasModule? Find(string key) =>
        _modules.GetValueOrDefault(key);
}

public sealed class IncidentModule : IAtlasModule
{
    public string Key => "atlas.incidents";
    public string DisplayName => "Incident Management";
    public Version Version => new(1, 0, 0);
    public IReadOnlyCollection<string> Capabilities =>
        ["incidents", "investigations", "capa", "closure"];
}

public sealed class RiskModule : IAtlasModule
{
    public string Key => "atlas.risk";
    public string DisplayName => "Enterprise Risk";
    public Version Version => new(1, 0, 0);
    public IReadOnlyCollection<string> Capabilities =>
        ["risk-register", "controls", "reviews", "heat-map"];
}

public sealed class NotificationModule : IAtlasModule
{
    public string Key => "atlas.notifications";
    public string DisplayName => "Notifications and Work Queue";
    public Version Version => new(1, 0, 0);
    public IReadOnlyCollection<string> Capabilities =>
        ["work-queue", "in-app", "email", "teams"];
}
