using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Platform.Modules;

public sealed record InstalledModule(
    Guid Id,
    string ModuleKey,
    string DisplayName,
    string Version,
    string Status,
    bool Enabled,
    string Capabilities,
    string Configuration,
    DateTimeOffset InstalledAt,
    DateTimeOffset UpdatedAt);

public sealed class PlatformModuleRepository(
    IConfiguration configuration)
{
    public async Task<IReadOnlyList<InstalledModule>> ListAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        const string sql = """
        SELECT
            id AS Id,
            module_key AS ModuleKey,
            display_name AS DisplayName,
            version AS Version,
            status AS Status,
            enabled AS Enabled,
            capabilities::text AS Capabilities,
            configuration::text AS Configuration,
            installed_at AS InstalledAt,
            updated_at AS UpdatedAt
        FROM platform_modules
        WHERE tenant_id = @TenantId
        ORDER BY display_name;
        """;

        await using var connection = new NpgsqlConnection(
            configuration.GetConnectionString("Atlas"));

        return (await connection.QueryAsync<InstalledModule>(
            new CommandDefinition(
                sql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken))).AsList();
    }
}
