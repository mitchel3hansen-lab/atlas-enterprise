namespace Atlas.IncidentApi.Platform.Contracts;

public interface IAtlasModule
{
    string Key { get; }
    string DisplayName { get; }
    Version Version { get; }
    IReadOnlyCollection<string> Capabilities { get; }
}

public interface IPlatformEvent
{
    string EventName { get; }
    string AggregateType { get; }
    Guid? AggregateId { get; }
}

public interface IPlatformEventPublisher
{
    Task<Guid> PublishAsync<TEvent>(
        Guid tenantId,
        TEvent platformEvent,
        Guid actorId,
        string correlationId,
        CancellationToken cancellationToken)
        where TEvent : IPlatformEvent;
}

public interface IPlatformFileStore
{
    Task<StoredFileReference> RegisterAsync(
        Guid tenantId,
        Guid actorId,
        string moduleKey,
        string entityType,
        Guid entityId,
        FileRegistration registration,
        CancellationToken cancellationToken);
}

public interface IPlatformSearchIndexer
{
    Task IndexAsync(
        Guid tenantId,
        SearchDocument document,
        CancellationToken cancellationToken);
}

public sealed record FileRegistration(
    string FileName,
    string ContentType,
    long SizeBytes,
    string StorageProvider,
    string StorageKey,
    string? Sha256);

public sealed record StoredFileReference(
    Guid Id,
    string StorageProvider,
    string StorageKey,
    int Version);

public sealed record SearchDocument(
    string ModuleKey,
    string EntityType,
    Guid EntityId,
    string Title,
    string Body,
    string? Keywords,
    string? Route);
