using Atlas.IncidentApi.Platform.Contracts;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Platform.Files;

public sealed class DatabaseFileRegistry(
    IConfiguration configuration)
    : IPlatformFileStore
{
    public async Task<StoredFileReference> RegisterAsync(
        Guid tenantId,
        Guid actorId,
        string moduleKey,
        string entityType,
        Guid entityId,
        FileRegistration registration,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO platform_files (
            id, tenant_id, module_key, entity_type, entity_id,
            file_name, content_type, size_bytes, storage_provider,
            storage_key, sha256, version, uploaded_by)
        VALUES (
            @Id, @TenantId, @ModuleKey, @EntityType, @EntityId,
            @FileName, @ContentType, @SizeBytes, @StorageProvider,
            @StorageKey, @Sha256,
            COALESCE((
                SELECT MAX(version) + 1
                FROM platform_files
                WHERE tenant_id = @TenantId
                  AND storage_provider = @StorageProvider
                  AND storage_key = @StorageKey
            ), 1),
            @ActorId)
        RETURNING id, storage_provider, storage_key, version;
        """;

        await using var connection = new NpgsqlConnection(
            configuration.GetConnectionString("Atlas"));

        var row = await connection.QuerySingleAsync<dynamic>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    TenantId = tenantId,
                    ActorId = actorId,
                    ModuleKey = moduleKey,
                    EntityType = entityType,
                    EntityId = entityId,
                    registration.FileName,
                    registration.ContentType,
                    registration.SizeBytes,
                    registration.StorageProvider,
                    registration.StorageKey,
                    registration.Sha256
                },
                cancellationToken: cancellationToken));

        return new StoredFileReference(
            (Guid)row.id,
            (string)row.storage_provider,
            (string)row.storage_key,
            (int)row.version);
    }
}
