using Atlas.IncidentApi.Platform.Contracts;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Platform.Search;

public sealed class PostgresSearchIndexer(
    IConfiguration configuration)
    : IPlatformSearchIndexer
{
    public async Task IndexAsync(
        Guid tenantId,
        SearchDocument document,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO platform_search_documents (
            id, tenant_id, module_key, entity_type, entity_id,
            title, body, keywords, route, updated_at)
        VALUES (
            gen_random_uuid(), @TenantId, @ModuleKey, @EntityType, @EntityId,
            @Title, @Body, @Keywords, @Route, NOW())
        ON CONFLICT (tenant_id, module_key, entity_type, entity_id)
        DO UPDATE SET
            title = EXCLUDED.title,
            body = EXCLUDED.body,
            keywords = EXCLUDED.keywords,
            route = EXCLUDED.route,
            updated_at = NOW();
        """;

        await using var connection = new NpgsqlConnection(
            configuration.GetConnectionString("Atlas"));

        await connection.ExecuteAsync(new CommandDefinition(
            sql,
            new
            {
                TenantId = tenantId,
                document.ModuleKey,
                document.EntityType,
                document.EntityId,
                document.Title,
                document.Body,
                document.Keywords,
                document.Route
            },
            cancellationToken: cancellationToken));
    }
}

public sealed class PlatformSearchService(IConfiguration configuration)
{
    public async Task<IReadOnlyList<object>> SearchAsync(
        Guid tenantId,
        string query,
        int limit,
        CancellationToken cancellationToken)
    {
        const string sql = """
        SELECT
            module_key AS "moduleKey",
            entity_type AS "entityType",
            entity_id AS "entityId",
            title,
            ts_headline(
                'english',
                body,
                plainto_tsquery('english', @Query)
            ) AS snippet,
            route,
            ts_rank(
                search_vector,
                plainto_tsquery('english', @Query)
            ) AS rank
        FROM platform_search_documents
        WHERE tenant_id = @TenantId
          AND search_vector @@ plainto_tsquery('english', @Query)
        ORDER BY rank DESC, updated_at DESC
        LIMIT @Limit;
        """;

        await using var connection = new NpgsqlConnection(
            configuration.GetConnectionString("Atlas"));

        var rows = await connection.QueryAsync(
            new CommandDefinition(
                sql,
                new
                {
                    TenantId = tenantId,
                    Query = query,
                    Limit = Math.Clamp(limit, 1, 100)
                },
                cancellationToken: cancellationToken));

        return rows.Cast<object>().ToArray();
    }
}
