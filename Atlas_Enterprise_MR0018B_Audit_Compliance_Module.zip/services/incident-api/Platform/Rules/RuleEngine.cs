using System.Text.Json;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Platform.Rules;

public sealed record RuleEvaluationContext(
    Guid TenantId,
    string EventName,
    JsonElement Payload);

public sealed record RuleEvaluationResult(
    Guid RuleId,
    string RuleKey,
    bool Matched,
    JsonElement Action,
    bool StopProcessing);

public sealed class RuleEngine(IConfiguration configuration)
{
    public async Task<IReadOnlyList<RuleEvaluationResult>> EvaluateAsync(
        RuleEvaluationContext context,
        CancellationToken cancellationToken)
    {
        const string sql = """
        SELECT
            id,
            rule_key,
            condition_json::text,
            action_json::text,
            stop_processing
        FROM platform_rules
        WHERE tenant_id = @TenantId
          AND event_name = @EventName
          AND enabled = TRUE
        ORDER BY priority, created_at;
        """;

        await using var connection = new NpgsqlConnection(
            configuration.GetConnectionString("Atlas"));

        var rows = await connection.QueryAsync<dynamic>(
            new CommandDefinition(
                sql,
                new
                {
                    context.TenantId,
                    context.EventName
                },
                cancellationToken: cancellationToken));

        var results = new List<RuleEvaluationResult>();

        foreach (var row in rows)
        {
            using var conditionDocument =
                JsonDocument.Parse((string)row.condition_json);
            using var actionDocument =
                JsonDocument.Parse((string)row.action_json);

            var matched = Matches(
                conditionDocument.RootElement,
                context.Payload);

            results.Add(new RuleEvaluationResult(
                (Guid)row.id,
                (string)row.rule_key,
                matched,
                actionDocument.RootElement.Clone(),
                (bool)row.stop_processing));

            if (matched && (bool)row.stop_processing)
                break;
        }

        return results;
    }

    internal static bool Matches(
        JsonElement condition,
        JsonElement payload)
    {
        if (condition.ValueKind != JsonValueKind.Object ||
            !condition.EnumerateObject().Any())
            return true;

        foreach (var property in condition.EnumerateObject())
        {
            if (!payload.TryGetProperty(
                    property.Name,
                    out var payloadValue))
                return false;

            if (payloadValue.ToString() != property.Value.ToString())
                return false;
        }

        return true;
    }
}
