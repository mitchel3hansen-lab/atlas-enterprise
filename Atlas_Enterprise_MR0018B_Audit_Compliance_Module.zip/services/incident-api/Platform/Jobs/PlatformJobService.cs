using System.Text.Json;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Platform.Jobs;

public sealed class PlatformJobService(IConfiguration configuration)
{
    public async Task<Guid> EnqueueAsync(
        Guid tenantId,
        string jobType,
        object payload,
        int priority,
        DateTimeOffset? scheduledAt,
        string? correlationId,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO platform_jobs (
            id, tenant_id, job_type, payload, status,
            priority, scheduled_at, correlation_id, created_at)
        VALUES (
            @Id, @TenantId, @JobType, CAST(@Payload AS jsonb), 'Queued',
            @Priority, @ScheduledAt, @CorrelationId, NOW());
        """;

        var id = Guid.NewGuid();

        await using var connection = new NpgsqlConnection(
            configuration.GetConnectionString("Atlas"));

        await connection.ExecuteAsync(new CommandDefinition(
            sql,
            new
            {
                Id = id,
                TenantId = tenantId,
                JobType = jobType,
                Payload = JsonSerializer.Serialize(payload),
                Priority = priority,
                ScheduledAt = scheduledAt ?? DateTimeOffset.UtcNow,
                CorrelationId = correlationId
            },
            cancellationToken: cancellationToken));

        return id;
    }
}
