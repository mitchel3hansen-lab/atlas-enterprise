using Atlas.IncidentApi.Infrastructure;

namespace Atlas.IncidentApi.Security;

public sealed class FeatureFlagEndpointFilter(
    string featureFlag)
    : IEndpointFilter
{
    public async ValueTask<object?> InvokeAsync(
        EndpointFilterInvocationContext context,
        EndpointFilterDelegate next)
    {
        var currentUser = CurrentUser.From(
            context.HttpContext.User);

        var controls = context.HttpContext.RequestServices
            .GetRequiredService<SystemControlCache>();

        var state = await controls.GetAsync(
            currentUser.TenantId,
            context.HttpContext.RequestAborted);

        if (!state.FeatureFlags.TryGetValue(
                featureFlag,
                out var enabled) ||
            !enabled)
        {
            return Results.NotFound(new
            {
                message = $"Feature '{featureFlag}' is not enabled."
            });
        }

        return await next(context);
    }
}
