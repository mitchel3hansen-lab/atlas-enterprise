using Atlas.IncidentApi.Infrastructure;

namespace Atlas.IncidentApi.Security;

public sealed class SystemControlMiddleware(
    RequestDelegate next,
    ILogger<SystemControlMiddleware> logger)
{
    private static readonly HashSet<string> SafeMethods =
        new(StringComparer.OrdinalIgnoreCase)
        {
            HttpMethods.Get,
            HttpMethods.Head,
            HttpMethods.Options
        };

    public async Task InvokeAsync(
        HttpContext context,
        SystemControlCache controls)
    {
        if (context.User.Identity?.IsAuthenticated != true ||
            context.Request.Path.StartsWithSegments("/health") ||
            context.Request.Path.StartsWithSegments("/api/auth"))
        {
            await next(context);
            return;
        }

        var user = CurrentUser.From(context.User);
        var state = await controls.GetAsync(
            user.TenantId,
            context.RequestAborted);

        context.Response.Headers["X-Atlas-Pilot-Mode"] =
            state.PilotMode ? "true" : "false";
        context.Response.Headers["X-Atlas-Maintenance-Mode"] =
            state.MaintenanceMode ? "true" : "false";
        context.Response.Headers["X-Atlas-Write-Lock"] =
            state.EmergencyWriteLock ? "true" : "false";

        var isAdministrator = string.Equals(
            user.Role,
            AtlasRoles.Administrator,
            StringComparison.OrdinalIgnoreCase);

        var isSafeMethod = SafeMethods.Contains(context.Request.Method);

        if (state.MaintenanceMode &&
            !isAdministrator &&
            (!state.AllowReadOnlyAccess || !isSafeMethod))
        {
            logger.LogWarning(
                "Request blocked by maintenance mode. Tenant={TenantId} User={UserId} Path={Path}",
                user.TenantId,
                user.UserId,
                context.Request.Path);

            await WriteUnavailable(
                context,
                state.MaintenanceMessage ??
                "Atlas is temporarily unavailable for maintenance.");
            return;
        }

        if (state.EmergencyWriteLock &&
            !isAdministrator &&
            !isSafeMethod)
        {
            logger.LogWarning(
                "Write request blocked by emergency lock. Tenant={TenantId} User={UserId} Path={Path}",
                user.TenantId,
                user.UserId,
                context.Request.Path);

            await WriteLocked(
                context,
                "Atlas is in emergency read-only mode.");
            return;
        }

        await next(context);
    }

    private static Task WriteUnavailable(
        HttpContext context,
        string detail)
    {
        context.Response.StatusCode =
            StatusCodes.Status503ServiceUnavailable;

        return context.Response.WriteAsJsonAsync(new
        {
            type = "about:blank",
            title = "Maintenance mode",
            status = StatusCodes.Status503ServiceUnavailable,
            detail,
            correlationId = context.TraceIdentifier
        });
    }

    private static Task WriteLocked(
        HttpContext context,
        string detail)
    {
        context.Response.StatusCode = StatusCodes.Status423Locked;

        return context.Response.WriteAsJsonAsync(new
        {
            type = "about:blank",
            title = "Write operations locked",
            status = StatusCodes.Status423Locked,
            detail,
            correlationId = context.TraceIdentifier
        });
    }
}
