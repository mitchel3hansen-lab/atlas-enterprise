using Atlas.IncidentApi.Domain;
using Atlas.IncidentApi.Features.Administration;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class AdministrationRepository(IConfiguration configuration)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    public async Task<AdministratorConsole> GetAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        await using var connection = CreateConnection();

        var settings = await connection.QuerySingleAsync<TenantSettings>(
            new CommandDefinition(
                """
                SELECT
                    tenant_id AS TenantId,
                    tenant_name AS TenantName,
                    default_time_zone AS DefaultTimeZone,
                    incident_prefix AS IncidentPrefix,
                    capa_prefix AS CapaPrefix,
                    pilot_mode AS PilotMode,
                    maintenance_mode AS MaintenanceMode,
                    emergency_write_lock AS EmergencyWriteLock,
                    allow_read_only_access AS AllowReadOnlyAccess,
                    maintenance_message AS MaintenanceMessage,
                    pilot_banner_message AS PilotBannerMessage,
                    updated_by AS UpdatedBy,
                    updated_at AS UpdatedAt
                FROM tenant_settings
                WHERE tenant_id = @TenantId;
                """,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken));

        var sites = (await connection.QueryAsync<TenantSite>(
            new CommandDefinition(
                """
                SELECT id AS Id, name AS Name, code AS Code, active AS Active
                FROM tenant_sites
                WHERE tenant_id = @TenantId
                ORDER BY name;
                """,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken))).AsList();

        var departments = (await connection.QueryAsync<TenantDepartment>(
            new CommandDefinition(
                """
                SELECT
                    id AS Id,
                    site_id AS SiteId,
                    name AS Name,
                    code AS Code,
                    active AS Active
                FROM tenant_departments
                WHERE tenant_id = @TenantId
                ORDER BY name;
                """,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken))).AsList();

        var users = (await connection.QueryAsync<TenantUser>(
            new CommandDefinition(
                """
                SELECT
                    id AS Id,
                    display_name AS DisplayName,
                    email AS Email,
                    role AS Role,
                    department_code AS DepartmentCode,
                    site_code AS SiteCode,
                    active AS Active
                FROM tenant_users
                WHERE tenant_id = @TenantId
                ORDER BY display_name;
                """,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken))).AsList();

        var flags = (await connection.QueryAsync<FeatureFlag>(
            new CommandDefinition(
                """
                SELECT
                    id AS Id,
                    flag_key AS FlagKey,
                    enabled AS Enabled,
                    description AS Description
                FROM feature_flags
                WHERE tenant_id = @TenantId
                ORDER BY flag_key;
                """,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken))).AsList();

        var providers = (await connection.QueryAsync<ProviderSetting>(
            new CommandDefinition(
                """
                SELECT
                    id AS Id,
                    provider_type AS ProviderType,
                    enabled AS Enabled,
                    configuration::text AS Configuration,
                    secret_reference AS SecretReference
                FROM provider_settings
                WHERE tenant_id = @TenantId
                ORDER BY provider_type;
                """,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken))).AsList();

        return new AdministratorConsole(
            settings, sites, departments, users, flags, providers);
    }

    public async Task UpdateSettingsAsync(
        Guid tenantId,
        Guid actorId,
        UpdateTenantSettingsRequest request,
        CancellationToken cancellationToken)
    {
        await using var connection = CreateConnection();
        await connection.ExecuteAsync(new CommandDefinition(
            """
            INSERT INTO tenant_settings (
                tenant_id, tenant_name, default_time_zone,
                incident_prefix, capa_prefix, pilot_mode,
                maintenance_mode, updated_by, updated_at)
            VALUES (
                @TenantId, @TenantName, @DefaultTimeZone,
                @IncidentPrefix, @CapaPrefix, @PilotMode,
                @MaintenanceMode, @ActorId, NOW())
            ON CONFLICT (tenant_id)
            DO UPDATE SET
                tenant_name = EXCLUDED.tenant_name,
                default_time_zone = EXCLUDED.default_time_zone,
                incident_prefix = EXCLUDED.incident_prefix,
                capa_prefix = EXCLUDED.capa_prefix,
                pilot_mode = EXCLUDED.pilot_mode,
                maintenance_mode = EXCLUDED.maintenance_mode,
                updated_by = EXCLUDED.updated_by,
                updated_at = NOW();
            """,
            new
            {
                TenantId = tenantId,
                ActorId = actorId,
                request.TenantName,
                request.DefaultTimeZone,
                request.IncidentPrefix,
                request.CapaPrefix,
                request.PilotMode,
                request.MaintenanceMode
            },
            cancellationToken: cancellationToken));
    }

    public async Task<Guid> UpsertSiteAsync(
        Guid tenantId,
        UpsertSiteRequest request,
        CancellationToken cancellationToken)
    {
        var id = request.Id ?? Guid.NewGuid();
        await using var connection = CreateConnection();
        return await connection.ExecuteScalarAsync<Guid>(
            new CommandDefinition(
                """
                INSERT INTO tenant_sites (
                    id, tenant_id, name, code, active)
                VALUES (
                    @Id, @TenantId, @Name, @Code, @Active)
                ON CONFLICT (tenant_id, code)
                DO UPDATE SET
                    name = EXCLUDED.name,
                    active = EXCLUDED.active
                RETURNING id;
                """,
                new
                {
                    Id = id,
                    TenantId = tenantId,
                    request.Name,
                    Code = request.Code.ToUpperInvariant(),
                    request.Active
                },
                cancellationToken: cancellationToken));
    }

    public async Task<Guid> UpsertDepartmentAsync(
        Guid tenantId,
        UpsertDepartmentRequest request,
        CancellationToken cancellationToken)
    {
        var id = request.Id ?? Guid.NewGuid();
        await using var connection = CreateConnection();
        return await connection.ExecuteScalarAsync<Guid>(
            new CommandDefinition(
                """
                INSERT INTO tenant_departments (
                    id, tenant_id, site_id, name, code, active)
                VALUES (
                    @Id, @TenantId, @SiteId, @Name, @Code, @Active)
                ON CONFLICT (tenant_id, code)
                DO UPDATE SET
                    site_id = EXCLUDED.site_id,
                    name = EXCLUDED.name,
                    active = EXCLUDED.active
                RETURNING id;
                """,
                new
                {
                    Id = id,
                    TenantId = tenantId,
                    request.SiteId,
                    request.Name,
                    Code = request.Code.ToUpperInvariant(),
                    request.Active
                },
                cancellationToken: cancellationToken));
    }

    public async Task UpsertUserAsync(
        Guid tenantId,
        UpsertTenantUserRequest request,
        CancellationToken cancellationToken)
    {
        await using var connection = CreateConnection();
        await connection.ExecuteAsync(new CommandDefinition(
            """
            INSERT INTO tenant_users (
                id, tenant_id, display_name, email, role,
                department_code, site_code, active)
            VALUES (
                @Id, @TenantId, @DisplayName, @Email, @Role,
                @DepartmentCode, @SiteCode, @Active)
            ON CONFLICT (id)
            DO UPDATE SET
                display_name = EXCLUDED.display_name,
                email = EXCLUDED.email,
                role = EXCLUDED.role,
                department_code = EXCLUDED.department_code,
                site_code = EXCLUDED.site_code,
                active = EXCLUDED.active,
                updated_at = NOW();
            """,
            new
            {
                request.Id,
                TenantId = tenantId,
                request.DisplayName,
                request.Email,
                request.Role,
                request.DepartmentCode,
                request.SiteCode,
                request.Active
            },
            cancellationToken: cancellationToken));
    }

    public async Task UpsertFeatureFlagAsync(
        Guid tenantId,
        Guid actorId,
        UpsertFeatureFlagRequest request,
        CancellationToken cancellationToken)
    {
        await using var connection = CreateConnection();
        await connection.ExecuteAsync(new CommandDefinition(
            """
            INSERT INTO feature_flags (
                id, tenant_id, flag_key, enabled,
                description, updated_by)
            VALUES (
                gen_random_uuid(), @TenantId, @FlagKey, @Enabled,
                @Description, @ActorId)
            ON CONFLICT (tenant_id, flag_key)
            DO UPDATE SET
                enabled = EXCLUDED.enabled,
                description = EXCLUDED.description,
                updated_by = EXCLUDED.updated_by,
                updated_at = NOW();
            """,
            new
            {
                TenantId = tenantId,
                ActorId = actorId,
                request.FlagKey,
                request.Enabled,
                request.Description
            },
            cancellationToken: cancellationToken));
    }

    public async Task UpsertProviderAsync(
        Guid tenantId,
        Guid actorId,
        UpsertProviderSettingRequest request,
        CancellationToken cancellationToken)
    {
        await using var connection = CreateConnection();
        await connection.ExecuteAsync(new CommandDefinition(
            """
            INSERT INTO provider_settings (
                id, tenant_id, provider_type, enabled,
                configuration, secret_reference, updated_by)
            VALUES (
                gen_random_uuid(), @TenantId, @ProviderType, @Enabled,
                CAST(@Configuration AS jsonb), @SecretReference, @ActorId)
            ON CONFLICT (tenant_id, provider_type)
            DO UPDATE SET
                enabled = EXCLUDED.enabled,
                configuration = EXCLUDED.configuration,
                secret_reference = EXCLUDED.secret_reference,
                updated_by = EXCLUDED.updated_by,
                updated_at = NOW();
            """,
            new
            {
                TenantId = tenantId,
                ActorId = actorId,
                request.ProviderType,
                request.Enabled,
                request.Configuration,
                request.SecretReference
            },
            cancellationToken: cancellationToken));
    }

    public async Task UpdateSystemControlsAsync(
        Guid tenantId,
        Guid actorId,
        UpdateSystemControlsRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        UPDATE tenant_settings
        SET pilot_mode = @PilotMode,
            maintenance_mode = @MaintenanceMode,
            emergency_write_lock = @EmergencyWriteLock,
            allow_read_only_access = @AllowReadOnlyAccess,
            maintenance_message = @MaintenanceMessage,
            pilot_banner_message = @PilotBannerMessage,
            updated_by = @ActorId,
            updated_at = NOW()
        WHERE tenant_id = @TenantId;
        """;

        await using var connection = CreateConnection();
        await connection.ExecuteAsync(
            new CommandDefinition(
                sql,
                new
                {
                    TenantId = tenantId,
                    ActorId = actorId,
                    request.PilotMode,
                    request.MaintenanceMode,
                    request.EmergencyWriteLock,
                    request.AllowReadOnlyAccess,
                    request.MaintenanceMessage,
                    request.PilotBannerMessage
                },
                cancellationToken: cancellationToken));
    }

}
