using Atlas.IncidentApi.Domain;
using Atlas.IncidentApi.Features.Audits;
using Atlas.IncidentApi.Platform.Contracts;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class AuditComplianceRepository(
    IConfiguration configuration,
    IPlatformEventPublisher eventPublisher,
    IPlatformSearchIndexer searchIndexer)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    public async Task<IReadOnlyList<AuditFramework>> FrameworksAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        const string sql = """
        SELECT
            id AS Id,
            framework_key AS FrameworkKey,
            display_name AS DisplayName,
            version AS Version,
            description AS Description,
            scoring_model AS ScoringModel,
            active AS Active
        FROM audit_frameworks
        WHERE tenant_id = @TenantId
        ORDER BY display_name, version;
        """;

        await using var connection = CreateConnection();
        return (await connection.QueryAsync<AuditFramework>(
            new CommandDefinition(sql, new { TenantId = tenantId },
                cancellationToken: cancellationToken))).AsList();
    }

    public async Task<AuditTemplate> CreateTemplateAsync(
        Guid tenantId,
        Guid actorId,
        CreateAuditTemplateRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO audit_templates (
            id, tenant_id, framework_id, name, description,
            version, active, created_by)
        VALUES (
            @Id, @TenantId, @FrameworkId, @Name, @Description,
            1, TRUE, @ActorId)
        RETURNING
            id AS Id,
            framework_id AS FrameworkId,
            name AS Name,
            description AS Description,
            version AS Version,
            active AS Active;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleAsync<AuditTemplate>(
            new CommandDefinition(sql, new
            {
                Id = Guid.NewGuid(),
                TenantId = tenantId,
                ActorId = actorId,
                request.FrameworkId,
                request.Name,
                request.Description
            }, cancellationToken: cancellationToken));
    }

    public async Task<Guid?> AddQuestionAsync(
        Guid tenantId,
        Guid templateId,
        AddAuditQuestionRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO audit_questions (
            id, tenant_id, template_id, section,
            requirement_reference, prompt, response_type,
            weight, critical, sort_order)
        SELECT
            @Id, @TenantId, t.id, @Section,
            @RequirementReference, @Prompt, @ResponseType,
            @Weight, @Critical, @SortOrder
        FROM audit_templates t
        WHERE t.tenant_id = @TenantId AND t.id = @TemplateId
        RETURNING id;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<Guid?>(
            new CommandDefinition(sql, new
            {
                Id = Guid.NewGuid(),
                TenantId = tenantId,
                TemplateId = templateId,
                request.Section,
                request.RequirementReference,
                request.Prompt,
                request.ResponseType,
                request.Weight,
                request.Critical,
                request.SortOrder
            }, cancellationToken: cancellationToken));
    }

    public async Task<ComplianceAudit> ScheduleAsync(
        Guid tenantId,
        Guid actorId,
        ScheduleAuditRequest request,
        string correlationId,
        CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;
        var number = $"AUD-{now:yyyy}-{now:MMddHHmmss}-{Random.Shared.Next(100,999)}";

        const string sql = """
        INSERT INTO audits (
            id, tenant_id, audit_number, template_id, title,
            site, department, lead_auditor_id, status,
            scheduled_start, scheduled_end, created_at, updated_at)
        VALUES (
            @Id, @TenantId, @AuditNumber, @TemplateId, @Title,
            @Site, @Department, @LeadAuditorId, 'Planned',
            @ScheduledStart, @ScheduledEnd, NOW(), NOW())
        RETURNING
            id AS Id,
            audit_number AS AuditNumber,
            template_id AS TemplateId,
            title AS Title,
            site AS Site,
            department AS Department,
            lead_auditor_id AS LeadAuditorId,
            status AS Status,
            scheduled_start AS ScheduledStart,
            scheduled_end AS ScheduledEnd,
            started_at AS StartedAt,
            completed_at AS CompletedAt,
            score_percent AS ScorePercent,
            rating AS Rating,
            summary AS Summary;
        """;

        await using var connection = CreateConnection();
        var audit = await connection.QuerySingleAsync<ComplianceAudit>(
            new CommandDefinition(sql, new
            {
                Id = Guid.NewGuid(),
                TenantId = tenantId,
                AuditNumber = number,
                request.TemplateId,
                request.Title,
                request.Site,
                request.Department,
                request.LeadAuditorId,
                request.ScheduledStart,
                request.ScheduledEnd
            }, cancellationToken: cancellationToken));

        await eventPublisher.PublishAsync(
            tenantId,
            new AuditScheduledEvent(audit.Id, audit.AuditNumber, audit.ScheduledStart),
            actorId,
            correlationId,
            cancellationToken);

        await searchIndexer.IndexAsync(
            tenantId,
            new SearchDocument(
                "atlas.audit",
                "Audit",
                audit.Id,
                audit.Title,
                $"Audit {audit.AuditNumber} scheduled for {audit.Site} {audit.Department}",
                $"{audit.AuditNumber} audit compliance",
                $"/audits/{audit.Id}"),
            cancellationToken);

        return audit;
    }


    public async Task<AuditWorkspace?> GetAsync(
        Guid tenantId,
        Guid auditId,
        CancellationToken cancellationToken)
    {
        const string auditSql = """
        SELECT
            id AS Id,
            audit_number AS AuditNumber,
            template_id AS TemplateId,
            title AS Title,
            site AS Site,
            department AS Department,
            lead_auditor_id AS LeadAuditorId,
            status AS Status,
            scheduled_start AS ScheduledStart,
            scheduled_end AS ScheduledEnd,
            started_at AS StartedAt,
            completed_at AS CompletedAt,
            score_percent AS ScorePercent,
            rating AS Rating,
            summary AS Summary
        FROM audits
        WHERE tenant_id = @TenantId AND id = @AuditId;
        """;

        const string questionsSql = """
        SELECT
            q.id AS Id,
            q.template_id AS TemplateId,
            q.section AS Section,
            q.requirement_reference AS RequirementReference,
            q.prompt AS Prompt,
            q.response_type AS ResponseType,
            q.weight AS Weight,
            q.critical AS Critical,
            q.sort_order AS SortOrder
        FROM audit_questions q
        JOIN audits a ON a.template_id = q.template_id
        WHERE a.tenant_id = @TenantId AND a.id = @AuditId
        ORDER BY q.section, q.sort_order;
        """;

        const string findingsSql = """
        SELECT
            id AS Id,
            finding_number AS FindingNumber,
            finding_type AS FindingType,
            severity AS Severity,
            requirement_reference AS RequirementReference,
            title AS Title,
            description AS Description,
            owner_id AS OwnerId,
            due_at AS DueAt,
            status AS Status,
            repeat_finding AS RepeatFinding,
            capa_id AS CapaId,
            risk_id AS RiskId
        FROM audit_findings
        WHERE tenant_id = @TenantId AND audit_id = @AuditId
        ORDER BY created_at;
        """;

        await using var connection = CreateConnection();
        var args = new { TenantId = tenantId, AuditId = auditId };

        var audit = await connection.QuerySingleOrDefaultAsync<ComplianceAudit>(
            new CommandDefinition(auditSql, args, cancellationToken: cancellationToken));

        if (audit is null) return null;

        var questions = (await connection.QueryAsync<AuditQuestion>(
            new CommandDefinition(questionsSql, args, cancellationToken: cancellationToken))).AsList();

        var findings = (await connection.QueryAsync<AuditFinding>(
            new CommandDefinition(findingsSql, args, cancellationToken: cancellationToken))).AsList();

        return new AuditWorkspace(audit, questions, findings);
    }

    public async Task RecordResponseAsync(
        Guid tenantId,
        Guid auditId,
        Guid actorId,
        RecordAuditResponseRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO audit_responses (
            id, tenant_id, audit_id, question_id,
            response, score, comments, answered_by)
        VALUES (
            gen_random_uuid(), @TenantId, @AuditId, @QuestionId,
            @Response, @Score, @Comments, @ActorId)
        ON CONFLICT (audit_id, question_id)
        DO UPDATE SET
            response = EXCLUDED.response,
            score = EXCLUDED.score,
            comments = EXCLUDED.comments,
            answered_by = EXCLUDED.answered_by,
            answered_at = NOW();

        UPDATE audits
        SET status = CASE WHEN status = 'Planned' THEN 'InProgress' ELSE status END,
            started_at = COALESCE(started_at, NOW()),
            updated_at = NOW()
        WHERE tenant_id = @TenantId AND id = @AuditId;
        """;

        await using var connection = CreateConnection();
        await connection.ExecuteAsync(new CommandDefinition(sql, new
        {
            TenantId = tenantId,
            AuditId = auditId,
            ActorId = actorId,
            request.QuestionId,
            request.Response,
            request.Score,
            request.Comments
        }, cancellationToken: cancellationToken));
    }

    public async Task<AuditFinding?> CreateFindingAsync(
        Guid tenantId,
        Guid auditId,
        Guid actorId,
        CreateAuditFindingRequest request,
        string correlationId,
        CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;
        var number = $"FND-{now:yyyy}-{now:MMddHHmmss}-{Random.Shared.Next(100,999)}";

        const string sql = """
        INSERT INTO audit_findings (
            id, tenant_id, audit_id, finding_number,
            finding_type, severity, requirement_reference,
            title, description, owner_id, due_at,
            status, repeat_finding)
        SELECT
            @Id, @TenantId, a.id, @FindingNumber,
            @FindingType, @Severity, @RequirementReference,
            @Title, @Description, @OwnerId, @DueAt,
            'Open', @RepeatFinding
        FROM audits a
        WHERE a.tenant_id = @TenantId AND a.id = @AuditId
        RETURNING
            id AS Id,
            finding_number AS FindingNumber,
            finding_type AS FindingType,
            severity AS Severity,
            requirement_reference AS RequirementReference,
            title AS Title,
            description AS Description,
            owner_id AS OwnerId,
            due_at AS DueAt,
            status AS Status,
            repeat_finding AS RepeatFinding,
            capa_id AS CapaId,
            risk_id AS RiskId;
        """;

        await using var connection = CreateConnection();
        var finding = await connection.QuerySingleOrDefaultAsync<AuditFinding>(
            new CommandDefinition(sql, new
            {
                Id = Guid.NewGuid(),
                TenantId = tenantId,
                AuditId = auditId,
                FindingNumber = number,
                request.FindingType,
                request.Severity,
                request.RequirementReference,
                request.Title,
                request.Description,
                request.OwnerId,
                request.DueAt,
                request.RepeatFinding
            }, cancellationToken: cancellationToken));

        if (finding is null) return null;

        await eventPublisher.PublishAsync(
            tenantId,
            new AuditFindingIssuedEvent(
                auditId,
                finding.Id,
                finding.Severity,
                finding.FindingType),
            actorId,
            correlationId,
            cancellationToken);

        await searchIndexer.IndexAsync(
            tenantId,
            new SearchDocument(
                "atlas.audit",
                "AuditFinding",
                finding.Id,
                finding.Title,
                finding.Description,
                $"{finding.FindingNumber} {finding.RequirementReference} {finding.Severity}",
                $"/audits/{auditId}/findings/{finding.Id}"),
            cancellationToken);

        return finding;
    }

    public async Task<(decimal Score, string Rating)> CompleteAsync(
        Guid tenantId,
        Guid auditId,
        Guid actorId,
        CompleteAuditRequest request,
        string correlationId,
        CancellationToken cancellationToken)
    {
        const string scoreSql = """
        SELECT
            COALESCE(
                100.0 * SUM(COALESCE(r.score, 0) * q.weight) /
                NULLIF(SUM(100 * q.weight), 0),
                0
            )::numeric(8,2)
        FROM audit_questions q
        LEFT JOIN audit_responses r
          ON r.question_id = q.id
         AND r.audit_id = @AuditId
        JOIN audits a ON a.template_id = q.template_id
        WHERE a.tenant_id = @TenantId
          AND a.id = @AuditId;
        """;

        await using var connection = CreateConnection();
        var score = await connection.ExecuteScalarAsync<decimal>(
            new CommandDefinition(scoreSql, new
            {
                TenantId = tenantId,
                AuditId = auditId
            }, cancellationToken: cancellationToken));

        var rating = score switch
        {
            >= 90 => "Excellent",
            >= 80 => "Compliant",
            >= 70 => "NeedsImprovement",
            _ => "Unsatisfactory"
        };

        const string updateSql = """
        UPDATE audits
        SET status = 'Completed',
            completed_at = NOW(),
            score_percent = @Score,
            rating = @Rating,
            summary = @Summary,
            updated_at = NOW()
        WHERE tenant_id = @TenantId AND id = @AuditId;

        INSERT INTO audit_history (
            id, tenant_id, audit_id, event_type, actor_id, details)
        VALUES (
            gen_random_uuid(), @TenantId, @AuditId, 'AuditCompleted',
            @ActorId, jsonb_build_object('score', @Score, 'rating', @Rating));
        """;

        await connection.ExecuteAsync(new CommandDefinition(updateSql, new
        {
            TenantId = tenantId,
            AuditId = auditId,
            ActorId = actorId,
            Score = score,
            Rating = rating,
            request.Summary
        }, cancellationToken: cancellationToken));

        await eventPublisher.PublishAsync(
            tenantId,
            new AuditCompletedEvent(auditId, score, rating),
            actorId,
            correlationId,
            cancellationToken);

        return (score, rating);
    }

    public async Task<AuditDashboard> DashboardAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        const string sql = """
        SELECT
            COUNT(*) FILTER (WHERE status = 'Planned')::int AS planned,
            COUNT(*) FILTER (WHERE status = 'InProgress')::int AS in_progress,
            COUNT(*) FILTER (WHERE status = 'Completed')::int AS completed,
            COUNT(*) FILTER (
                WHERE status NOT IN ('Completed','Closed')
                  AND scheduled_start < NOW()
            )::int AS overdue,
            COALESCE(AVG(score_percent) FILTER (
                WHERE status = 'Completed'
            ), 0)::numeric(8,2) AS average_score
        FROM audits
        WHERE tenant_id = @TenantId;
        """;

        const string findingSql = """
        SELECT
            COUNT(*) FILTER (WHERE status <> 'Closed')::int AS open_findings,
            COUNT(*) FILTER (
                WHERE status <> 'Closed'
                  AND severity IN ('High','Critical')
            )::int AS high_findings,
            COUNT(*) FILTER (
                WHERE repeat_finding = TRUE
            )::int AS repeat_findings
        FROM audit_findings
        WHERE tenant_id = @TenantId;
        """;

        await using var connection = CreateConnection();
        var a = await connection.QuerySingleAsync<dynamic>(
            new CommandDefinition(sql, new { TenantId = tenantId },
                cancellationToken: cancellationToken));
        var f = await connection.QuerySingleAsync<dynamic>(
            new CommandDefinition(findingSql, new { TenantId = tenantId },
                cancellationToken: cancellationToken));

        return new AuditDashboard(
            (int)a.planned,
            (int)a.in_progress,
            (int)a.completed,
            (int)a.overdue,
            (int)f.open_findings,
            (int)f.high_findings,
            (int)f.repeat_findings,
            (decimal)a.average_score);
    }
}
