using Atlas.IncidentApi.Domain;
using Microsoft.Extensions.Caching.Memory;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class SystemControlCache(
    IMemoryCache memoryCache,
    SystemControlRepository repository)
{
    public async Task<SystemControlState> GetAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        var key = $"system-control:{tenantId}";

        if (memoryCache.TryGetValue<SystemControlState>(key, out var cached) &&
            cached is not null)
            return cached;

        var state = await repository.GetAsync(
            tenantId,
            cancellationToken);

        memoryCache.Set(
            key,
            state,
            TimeSpan.FromSeconds(30));

        return state;
    }

    public void Invalidate(Guid tenantId) =>
        memoryCache.Remove($"system-control:{tenantId}");
}
