using Atlas.IncidentApi.Domain;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class SystemControlRepository(IConfiguration configuration)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    public async Task<SystemControlState> GetAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        const string settingsSql = """
        SELECT
            tenant_id AS TenantId,
            pilot_mode AS PilotMode,
            maintenance_mode AS MaintenanceMode,
            emergency_write_lock AS EmergencyWriteLock,
            allow_read_only_access AS AllowReadOnlyAccess,
            maintenance_message AS MaintenanceMessage,
            pilot_banner_message AS PilotBannerMessage
        FROM tenant_settings
        WHERE tenant_id = @TenantId;
        """;

        const string flagsSql = """
        SELECT flag_key, enabled
        FROM feature_flags
        WHERE tenant_id = @TenantId;
        """;

        await using var connection = CreateConnection();

        var settings = await connection.QuerySingleAsync<dynamic>(
            new CommandDefinition(
                settingsSql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken));

        var flags = await connection.QueryAsync<(string FlagKey, bool Enabled)>(
            new CommandDefinition(
                flagsSql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken));

        return new SystemControlState(
            (Guid)settings.tenantid,
            (bool)settings.pilotmode,
            (bool)settings.maintenancemode,
            (bool)settings.emergencywritelock,
            (bool)settings.allowreadonlyaccess,
            (string?)settings.maintenancemessage,
            (string?)settings.pilotbannermessage,
            flags.ToDictionary(x => x.FlagKey, x => x.Enabled,
                StringComparer.OrdinalIgnoreCase),
            DateTimeOffset.UtcNow);
    }
}
