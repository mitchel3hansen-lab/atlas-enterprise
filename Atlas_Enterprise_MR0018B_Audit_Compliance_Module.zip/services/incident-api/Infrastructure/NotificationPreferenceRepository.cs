using Atlas.IncidentApi.Domain;
using Atlas.IncidentApi.Features.Notifications;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class NotificationPreferenceRepository(IConfiguration configuration)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    public async Task<NotificationPreference> GetAsync(
        Guid tenantId,
        Guid userId,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO notification_preferences (
            id, tenant_id, user_id)
        VALUES (
            @Id, @TenantId, @UserId)
        ON CONFLICT (tenant_id, user_id) DO NOTHING;

        SELECT
            user_id AS UserId,
            email_enabled AS EmailEnabled,
            teams_enabled AS TeamsEnabled,
            in_app_enabled AS InAppEnabled,
            quiet_hours_enabled AS QuietHoursEnabled,
            quiet_hours_start AS QuietHoursStart,
            quiet_hours_end AS QuietHoursEnd,
            time_zone AS TimeZone,
            digest_mode AS DigestMode,
            updated_at AS UpdatedAt
        FROM notification_preferences
        WHERE tenant_id = @TenantId AND user_id = @UserId;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleAsync<NotificationPreference>(
            new CommandDefinition(
                sql,
                new { Id = Guid.NewGuid(), TenantId = tenantId, UserId = userId },
                cancellationToken: cancellationToken));
    }

    public async Task<NotificationPreference> UpdateAsync(
        Guid tenantId,
        Guid userId,
        UpdateNotificationPreferenceRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO notification_preferences (
            id, tenant_id, user_id, email_enabled, teams_enabled,
            in_app_enabled, quiet_hours_enabled, quiet_hours_start,
            quiet_hours_end, time_zone, digest_mode, updated_at)
        VALUES (
            @Id, @TenantId, @UserId, @EmailEnabled, @TeamsEnabled,
            @InAppEnabled, @QuietHoursEnabled, @QuietHoursStart,
            @QuietHoursEnd, @TimeZone, @DigestMode, NOW())
        ON CONFLICT (tenant_id, user_id)
        DO UPDATE SET
            email_enabled = EXCLUDED.email_enabled,
            teams_enabled = EXCLUDED.teams_enabled,
            in_app_enabled = EXCLUDED.in_app_enabled,
            quiet_hours_enabled = EXCLUDED.quiet_hours_enabled,
            quiet_hours_start = EXCLUDED.quiet_hours_start,
            quiet_hours_end = EXCLUDED.quiet_hours_end,
            time_zone = EXCLUDED.time_zone,
            digest_mode = EXCLUDED.digest_mode,
            updated_at = NOW()
        RETURNING
            user_id AS UserId,
            email_enabled AS EmailEnabled,
            teams_enabled AS TeamsEnabled,
            in_app_enabled AS InAppEnabled,
            quiet_hours_enabled AS QuietHoursEnabled,
            quiet_hours_start AS QuietHoursStart,
            quiet_hours_end AS QuietHoursEnd,
            time_zone AS TimeZone,
            digest_mode AS DigestMode,
            updated_at AS UpdatedAt;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleAsync<NotificationPreference>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    TenantId = tenantId,
                    UserId = userId,
                    request.EmailEnabled,
                    request.TeamsEnabled,
                    request.InAppEnabled,
                    request.QuietHoursEnabled,
                    request.QuietHoursStart,
                    request.QuietHoursEnd,
                    request.TimeZone,
                    request.DigestMode
                },
                cancellationToken: cancellationToken));
    }
}
