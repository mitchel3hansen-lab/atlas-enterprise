using System.Net.Http.Json;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class NotificationDeliveryService(
    IConfiguration configuration,
    IHttpClientFactory httpClientFactory,
    ILogger<NotificationDeliveryService> logger)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    public async Task<int> DeliverPendingAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        const string sql = """
        SELECT
            n.id,
            n.recipient_id,
            n.title,
            n.body,
            n.severity,
            p.email_enabled,
            p.teams_enabled,
            p.in_app_enabled,
            p.quiet_hours_enabled,
            p.quiet_hours_start,
            p.quiet_hours_end,
            p.time_zone
        FROM notifications n
        LEFT JOIN notification_preferences p
          ON p.tenant_id = n.tenant_id
         AND p.user_id = n.recipient_id
        WHERE n.tenant_id = @TenantId
          AND n.status = 'Unread'
          AND n.sent_at IS NULL
          AND n.scheduled_at <= NOW()
        ORDER BY n.created_at
        LIMIT 100;
        """;

        await using var connection = CreateConnection();
        var rows = await connection.QueryAsync<dynamic>(
            new CommandDefinition(
                sql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken));

        var delivered = 0;

        foreach (var row in rows)
        {
            if (IsQuietHours(row))
                continue;

            if ((bool?)(row.email_enabled) ?? true)
            {
                await AttemptChannelAsync(
                    tenantId,
                    (Guid)row.id,
                    "Email",
                    configuration["Notifications:Email:Provider"] ?? "LogOnly",
                    configuration["Notifications:Email:DefaultDestination"],
                    (string)row.title,
                    (string)row.body,
                    cancellationToken);
            }

            if ((bool?)(row.teams_enabled) ?? false)
            {
                await AttemptChannelAsync(
                    tenantId,
                    (Guid)row.id,
                    "Teams",
                    "Webhook",
                    configuration["Notifications:Teams:WebhookUrl"],
                    (string)row.title,
                    (string)row.body,
                    cancellationToken);
            }

            const string markSentSql = """
            UPDATE notifications
            SET sent_at = NOW()
            WHERE tenant_id = @TenantId AND id = @NotificationId;
            """;

            await connection.ExecuteAsync(
                new CommandDefinition(
                    markSentSql,
                    new { TenantId = tenantId, NotificationId = (Guid)row.id },
                    cancellationToken: cancellationToken));

            delivered++;
        }

        return delivered;
    }

    private async Task AttemptChannelAsync(
        Guid tenantId,
        Guid notificationId,
        string channel,
        string provider,
        string? destination,
        string title,
        string body,
        CancellationToken cancellationToken)
    {
        var attemptNumber = await GetNextAttemptNumberAsync(
            tenantId, notificationId, channel, cancellationToken);

        try
        {
            string? providerMessageId = null;
            string responseCode = "200";

            if (channel == "Teams" && !string.IsNullOrWhiteSpace(destination))
            {
                var client = httpClientFactory.CreateClient("notification-provider");
                var response = await client.PostAsJsonAsync(
                    destination,
                    new { title, text = body },
                    cancellationToken);

                responseCode = ((int)response.StatusCode).ToString();
                response.EnsureSuccessStatusCode();
            }
            else
            {
                logger.LogInformation(
                    "Notification delivered via {Channel}. Notification={NotificationId} Destination={Destination} Title={Title}",
                    channel,
                    notificationId,
                    destination ?? "not-configured",
                    title);

                providerMessageId = Guid.NewGuid().ToString("N");
            }

            await WriteAttemptAsync(
                tenantId, notificationId, channel, provider, destination,
                "Delivered", attemptNumber, providerMessageId, responseCode,
                null, null, cancellationToken);
        }
        catch (Exception ex)
        {
            var nextAttempt = attemptNumber >= 5
                ? null
                : DateTimeOffset.UtcNow.AddMinutes(Math.Pow(2, attemptNumber));

            await WriteAttemptAsync(
                tenantId, notificationId, channel, provider, destination,
                attemptNumber >= 5 ? "DeadLettered" : "Failed",
                attemptNumber, null, null, ex.Message, nextAttempt,
                cancellationToken);

            if (attemptNumber >= 5)
                await WriteDeadLetterAsync(
                    tenantId, notificationId, channel, ex.Message,
                    title, body, cancellationToken);
        }
    }

    private async Task<int> GetNextAttemptNumberAsync(
        Guid tenantId,
        Guid notificationId,
        string channel,
        CancellationToken cancellationToken)
    {
        const string sql = """
        SELECT COALESCE(MAX(attempt_number), 0) + 1
        FROM notification_delivery_attempts
        WHERE tenant_id = @TenantId
          AND notification_id = @NotificationId
          AND channel = @Channel;
        """;

        await using var connection = CreateConnection();
        return await connection.ExecuteScalarAsync<int>(
            new CommandDefinition(
                sql,
                new { TenantId = tenantId, NotificationId = notificationId, Channel = channel },
                cancellationToken: cancellationToken));
    }

    private async Task WriteAttemptAsync(
        Guid tenantId,
        Guid notificationId,
        string channel,
        string provider,
        string? destination,
        string status,
        int attemptNumber,
        string? providerMessageId,
        string? responseCode,
        string? errorMessage,
        DateTimeOffset? nextAttemptAt,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO notification_delivery_attempts (
            id, tenant_id, notification_id, channel, provider,
            destination, status, attempt_number, provider_message_id,
            response_code, error_message, next_attempt_at, attempted_at)
        VALUES (
            @Id, @TenantId, @NotificationId, @Channel, @Provider,
            @Destination, @Status, @AttemptNumber, @ProviderMessageId,
            @ResponseCode, @ErrorMessage, @NextAttemptAt, NOW());
        """;

        await using var connection = CreateConnection();
        await connection.ExecuteAsync(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    TenantId = tenantId,
                    NotificationId = notificationId,
                    Channel = channel,
                    Provider = provider,
                    Destination = destination,
                    Status = status,
                    AttemptNumber = attemptNumber,
                    ProviderMessageId = providerMessageId,
                    ResponseCode = responseCode,
                    ErrorMessage = errorMessage,
                    NextAttemptAt = nextAttemptAt
                },
                cancellationToken: cancellationToken));
    }

    private async Task WriteDeadLetterAsync(
        Guid tenantId,
        Guid notificationId,
        string channel,
        string reason,
        string title,
        string body,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO notification_dead_letters (
            id, tenant_id, notification_id, channel, reason, payload)
        VALUES (
            @Id, @TenantId, @NotificationId, @Channel, @Reason,
            jsonb_build_object('title', @Title, 'body', @Body));
        """;

        await using var connection = CreateConnection();
        await connection.ExecuteAsync(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    TenantId = tenantId,
                    NotificationId = notificationId,
                    Channel = channel,
                    Reason = reason,
                    Title = title,
                    Body = body
                },
                cancellationToken: cancellationToken));
    }

    private static bool IsQuietHours(dynamic row)
    {
        if (!((bool?)(row.quiet_hours_enabled) ?? false))
            return false;

        if (row.quiet_hours_start is null || row.quiet_hours_end is null)
            return false;

        var now = TimeOnly.FromDateTime(DateTime.UtcNow);
        TimeOnly start = row.quiet_hours_start;
        TimeOnly end = row.quiet_hours_end;

        return start <= end
            ? now >= start && now < end
            : now >= start || now < end;
    }
}
