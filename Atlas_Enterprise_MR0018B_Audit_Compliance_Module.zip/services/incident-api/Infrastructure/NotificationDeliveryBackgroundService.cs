namespace Atlas.IncidentApi.Infrastructure;

public sealed class NotificationDeliveryBackgroundService(
    IServiceProvider serviceProvider,
    IConfiguration configuration,
    ILogger<NotificationDeliveryBackgroundService> logger)
    : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var intervalMinutes = configuration.GetValue(
            "Notifications:DeliveryIntervalMinutes",
            5);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = serviceProvider.CreateScope();
                var service = scope.ServiceProvider
                    .GetRequiredService<NotificationDeliveryService>();

                if (Guid.TryParse(
                    configuration["Notifications:DefaultTenantId"],
                    out var tenantId))
                {
                    var count = await service.DeliverPendingAsync(
                        tenantId,
                        stoppingToken);

                    logger.LogInformation(
                        "External notification delivery cycle completed. Delivered={Delivered}",
                        count);
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "External notification delivery cycle failed.");
            }

            await Task.Delay(
                TimeSpan.FromMinutes(intervalMinutes),
                stoppingToken);
        }
    }
}
