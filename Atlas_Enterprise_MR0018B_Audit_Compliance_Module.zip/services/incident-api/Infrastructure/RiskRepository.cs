using System.Text.Json;
using Atlas.IncidentApi.Domain;
using Atlas.IncidentApi.Features.Risks;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class RiskRepository(IConfiguration configuration)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    private const string Projection = """
        r.id AS Id,
        r.risk_number AS RiskNumber,
        r.title AS Title,
        r.description AS Description,
        r.category_id AS CategoryId,
        c.name AS CategoryName,
        r.site AS Site,
        r.department AS Department,
        r.process AS Process,
        r.owner_id AS OwnerId,
        r.reviewer_id AS ReviewerId,
        r.status AS Status,
        r.inherent_likelihood AS InherentLikelihood,
        r.inherent_severity AS InherentSeverity,
        (r.inherent_likelihood * r.inherent_severity) AS InherentScore,
        r.residual_likelihood AS ResidualLikelihood,
        r.residual_severity AS ResidualSeverity,
        (r.residual_likelihood * r.residual_severity) AS ResidualScore,
        r.target_likelihood AS TargetLikelihood,
        r.target_severity AS TargetSeverity,
        CASE
            WHEN r.target_likelihood IS NULL OR r.target_severity IS NULL
                THEN NULL
            ELSE r.target_likelihood * r.target_severity
        END AS TargetScore,
        r.risk_velocity AS RiskVelocity,
        r.trend AS Trend,
        r.identified_at AS IdentifiedAt,
        r.next_review_at AS NextReviewAt,
        r.last_reviewed_at AS LastReviewedAt,
        r.updated_at AS UpdatedAt
        """;

    public async Task<IReadOnlyList<EnterpriseRisk>> ListAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        var sql = $"""
        SELECT {Projection}
        FROM risk_register r
        LEFT JOIN risk_categories c ON c.id = r.category_id
        WHERE r.tenant_id = @TenantId
        ORDER BY
            (r.residual_likelihood * r.residual_severity) DESC,
            r.next_review_at;
        """;

        await using var connection = CreateConnection();
        return (await connection.QueryAsync<EnterpriseRisk>(
            new CommandDefinition(
                sql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken))).AsList();
    }

    public async Task<EnterpriseRisk> CreateAsync(
        Guid tenantId,
        Guid actorId,
        CreateRiskRequest request,
        CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;
        var number =
            $"RISK-{now:yyyy}-{now:MMddHHmmss}-{Random.Shared.Next(100, 999)}";

        var sql = $"""
        INSERT INTO risk_register (
            id, tenant_id, risk_number, title, description, category_id,
            site, department, process, owner_id, reviewer_id, status,
            inherent_likelihood, inherent_severity,
            residual_likelihood, residual_severity,
            target_likelihood, target_severity, risk_velocity,
            trend, identified_at, next_review_at, created_at, updated_at)
        VALUES (
            @Id, @TenantId, @RiskNumber, @Title, @Description, @CategoryId,
            @Site, @Department, @Process, @OwnerId, @ReviewerId, 'Assessed',
            @InherentLikelihood, @InherentSeverity,
            @ResidualLikelihood, @ResidualSeverity,
            @TargetLikelihood, @TargetSeverity, @RiskVelocity,
            'Stable', @Now, @NextReviewAt, @Now, @Now);

        INSERT INTO risk_history (
            id, tenant_id, risk_id, event_type, actor_id, details)
        VALUES (
            gen_random_uuid(), @TenantId, @Id, 'RiskCreated', @ActorId,
            CAST(@History AS jsonb));

        SELECT {Projection}
        FROM risk_register r
        LEFT JOIN risk_categories c ON c.id = r.category_id
        WHERE r.id = @Id;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleAsync<EnterpriseRisk>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    TenantId = tenantId,
                    RiskNumber = number,
                    ActorId = actorId,
                    request.Title,
                    request.Description,
                    request.CategoryId,
                    request.Site,
                    request.Department,
                    request.Process,
                    request.OwnerId,
                    request.ReviewerId,
                    request.InherentLikelihood,
                    request.InherentSeverity,
                    request.ResidualLikelihood,
                    request.ResidualSeverity,
                    request.TargetLikelihood,
                    request.TargetSeverity,
                    request.RiskVelocity,
                    request.NextReviewAt,
                    Now = now,
                    History = JsonSerializer.Serialize(new
                    {
                        request.InherentLikelihood,
                        request.InherentSeverity,
                        request.ResidualLikelihood,
                        request.ResidualSeverity
                    })
                },
                cancellationToken: cancellationToken));
    }

    public async Task<RiskWorkspace?> GetAsync(
        Guid tenantId,
        Guid riskId,
        CancellationToken cancellationToken)
    {
        var riskSql = $"""
        SELECT {Projection}
        FROM risk_register r
        LEFT JOIN risk_categories c ON c.id = r.category_id
        WHERE r.tenant_id = @TenantId AND r.id = @RiskId;
        """;

        const string controlSql = """
        SELECT
            id AS Id,
            control_type AS ControlType,
            title AS Title,
            description AS Description,
            owner_id AS OwnerId,
            effectiveness AS Effectiveness,
            verification_method AS VerificationMethod,
            verified_at AS VerifiedAt,
            active AS Active
        FROM risk_controls
        WHERE tenant_id = @TenantId AND risk_id = @RiskId
        ORDER BY created_at;
        """;

        const string reviewSql = """
        SELECT
            id AS Id,
            reviewer_id AS ReviewerId,
            previous_likelihood AS PreviousLikelihood,
            previous_severity AS PreviousSeverity,
            new_likelihood AS NewLikelihood,
            new_severity AS NewSeverity,
            decision AS Decision,
            comments AS Comments,
            reviewed_at AS ReviewedAt
        FROM risk_reviews
        WHERE tenant_id = @TenantId AND risk_id = @RiskId
        ORDER BY reviewed_at DESC;
        """;

        const string linkSql = """
        SELECT
            id AS Id,
            entity_type AS EntityType,
            entity_id AS EntityId,
            relationship AS Relationship,
            linked_by AS LinkedBy,
            linked_at AS LinkedAt
        FROM risk_links
        WHERE tenant_id = @TenantId AND risk_id = @RiskId
        ORDER BY linked_at DESC;
        """;

        await using var connection = CreateConnection();
        var args = new { TenantId = tenantId, RiskId = riskId };

        var risk = await connection.QuerySingleOrDefaultAsync<EnterpriseRisk>(
            new CommandDefinition(riskSql, args, cancellationToken: cancellationToken));

        if (risk is null)
            return null;

        var controls = (await connection.QueryAsync<RiskControl>(
            new CommandDefinition(controlSql, args, cancellationToken: cancellationToken))).AsList();
        var reviews = (await connection.QueryAsync<RiskReview>(
            new CommandDefinition(reviewSql, args, cancellationToken: cancellationToken))).AsList();
        var links = (await connection.QueryAsync<RiskLink>(
            new CommandDefinition(linkSql, args, cancellationToken: cancellationToken))).AsList();

        return new RiskWorkspace(risk, controls, reviews, links);
    }

    public async Task<Guid?> AddControlAsync(
        Guid tenantId,
        Guid riskId,
        AddRiskControlRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO risk_controls (
            id, tenant_id, risk_id, control_type, title, description,
            owner_id, effectiveness, verification_method)
        SELECT
            @Id, @TenantId, r.id, @ControlType, @Title, @Description,
            @OwnerId, @Effectiveness, @VerificationMethod
        FROM risk_register r
        WHERE r.tenant_id = @TenantId AND r.id = @RiskId
        RETURNING id;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<Guid?>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    TenantId = tenantId,
                    RiskId = riskId,
                    request.ControlType,
                    request.Title,
                    request.Description,
                    request.OwnerId,
                    request.Effectiveness,
                    request.VerificationMethod
                },
                cancellationToken: cancellationToken));
    }

    public async Task<bool> ReviewAsync(
        Guid tenantId,
        Guid riskId,
        Guid reviewerId,
        ReviewRiskRequest request,
        CancellationToken cancellationToken)
    {
        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        const string currentSql = """
        SELECT residual_likelihood, residual_severity
        FROM risk_register
        WHERE tenant_id = @TenantId AND id = @RiskId
        FOR UPDATE;
        """;

        var current = await connection.QuerySingleOrDefaultAsync<dynamic>(
            new CommandDefinition(
                currentSql,
                new { TenantId = tenantId, RiskId = riskId },
                transaction,
                cancellationToken: cancellationToken));

        if (current is null)
        {
            await transaction.RollbackAsync(cancellationToken);
            return false;
        }

        const string updateSql = """
        UPDATE risk_register
        SET residual_likelihood = @NewLikelihood,
            residual_severity = @NewSeverity,
            trend = CASE
                WHEN (@NewLikelihood * @NewSeverity) <
                     (residual_likelihood * residual_severity) THEN 'Improving'
                WHEN (@NewLikelihood * @NewSeverity) >
                     (residual_likelihood * residual_severity) THEN 'Worsening'
                ELSE 'Stable'
            END,
            status = @Decision,
            reviewer_id = @ReviewerId,
            last_reviewed_at = NOW(),
            next_review_at = @NextReviewAt,
            updated_at = NOW()
        WHERE tenant_id = @TenantId AND id = @RiskId;

        INSERT INTO risk_reviews (
            id, tenant_id, risk_id, reviewer_id,
            previous_likelihood, previous_severity,
            new_likelihood, new_severity, decision, comments)
        VALUES (
            gen_random_uuid(), @TenantId, @RiskId, @ReviewerId,
            @PreviousLikelihood, @PreviousSeverity,
            @NewLikelihood, @NewSeverity, @Decision, @Comments);

        INSERT INTO risk_history (
            id, tenant_id, risk_id, event_type, actor_id, details)
        VALUES (
            gen_random_uuid(), @TenantId, @RiskId, 'RiskReviewed',
            @ReviewerId, CAST(@History AS jsonb));
        """;

        await connection.ExecuteAsync(
            new CommandDefinition(
                updateSql,
                new
                {
                    TenantId = tenantId,
                    RiskId = riskId,
                    ReviewerId = reviewerId,
                    PreviousLikelihood = (int)current.residual_likelihood,
                    PreviousSeverity = (int)current.residual_severity,
                    request.NewLikelihood,
                    request.NewSeverity,
                    request.Decision,
                    request.Comments,
                    request.NextReviewAt,
                    History = JsonSerializer.Serialize(request)
                },
                transaction,
                cancellationToken: cancellationToken));

        await transaction.CommitAsync(cancellationToken);
        return true;
    }

    public async Task<Guid?> LinkAsync(
        Guid tenantId,
        Guid riskId,
        Guid actorId,
        LinkRiskRecordRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO risk_links (
            id, tenant_id, risk_id, entity_type,
            entity_id, relationship, linked_by)
        SELECT
            @Id, @TenantId, r.id, @EntityType,
            @EntityId, @Relationship, @ActorId
        FROM risk_register r
        WHERE r.tenant_id = @TenantId AND r.id = @RiskId
        ON CONFLICT (
            tenant_id, risk_id, entity_type, entity_id, relationship
        ) DO UPDATE SET linked_at = NOW()
        RETURNING id;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<Guid?>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    TenantId = tenantId,
                    RiskId = riskId,
                    ActorId = actorId,
                    request.EntityType,
                    request.EntityId,
                    request.Relationship
                },
                cancellationToken: cancellationToken));
    }

    public async Task<RiskDashboard> DashboardAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        const string summarySql = """
        SELECT
            COUNT(*)::int AS total_risks,
            COUNT(*) FILTER (
                WHERE residual_likelihood * residual_severity >= 20
            )::int AS critical_risks,
            COUNT(*) FILTER (
                WHERE residual_likelihood * residual_severity BETWEEN 12 AND 19
            )::int AS high_risks,
            COUNT(*) FILTER (
                WHERE next_review_at < NOW()
                  AND status NOT IN ('Closed', 'Accepted')
            )::int AS overdue_reviews,
            COALESCE(AVG(
                residual_likelihood * residual_severity
            ), 0)::numeric(12,2) AS average_residual_score
        FROM risk_register
        WHERE tenant_id = @TenantId;
        """;

        const string heatSql = """
        SELECT
            residual_likelihood AS Likelihood,
            residual_severity AS Severity,
            COUNT(*)::int AS Count
        FROM risk_register
        WHERE tenant_id = @TenantId
        GROUP BY residual_likelihood, residual_severity;
        """;

        var topSql = $"""
        SELECT {Projection}
        FROM risk_register r
        LEFT JOIN risk_categories c ON c.id = r.category_id
        WHERE r.tenant_id = @TenantId
        ORDER BY
            (r.residual_likelihood * r.residual_severity) DESC,
            r.next_review_at
        LIMIT 10;
        """;

        await using var connection = CreateConnection();
        var summary = await connection.QuerySingleAsync<dynamic>(
            new CommandDefinition(
                summarySql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken));

        var heat = (await connection.QueryAsync<RiskHeatMapCell>(
            new CommandDefinition(
                heatSql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken))).AsList();

        var top = (await connection.QueryAsync<EnterpriseRisk>(
            new CommandDefinition(
                topSql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken))).AsList();

        return new RiskDashboard(
            (int)summary.total_risks,
            (int)summary.critical_risks,
            (int)summary.high_risks,
            (int)summary.overdue_reviews,
            (decimal)summary.average_residual_score,
            heat,
            top);
    }
}
