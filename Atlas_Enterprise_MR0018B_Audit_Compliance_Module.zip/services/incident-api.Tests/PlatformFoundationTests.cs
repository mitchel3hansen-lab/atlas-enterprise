using System.Text.Json;
using Atlas.IncidentApi.Platform.Modules;
using Atlas.IncidentApi.Platform.Rules;

namespace Atlas.IncidentApi.Tests;

public sealed class PlatformFoundationTests
{
    [Fact]
    public void Module_registry_resolves_registered_module()
    {
        var registry = new ModuleRegistry(
            new IAtlasModule[]
            {
                new IncidentModule(),
                new RiskModule()
            });

        Assert.NotNull(registry.Find("atlas.incidents"));
        Assert.Null(registry.Find("atlas.unknown"));
    }

    [Fact]
    public void Empty_condition_matches_any_payload()
    {
        using var condition = JsonDocument.Parse("{}");
        using var payload = JsonDocument.Parse("""{"severity":"High"}""");

        Assert.True(RuleEngine.Matches(
            condition.RootElement,
            payload.RootElement));
    }

    [Fact]
    public void Exact_condition_matches_payload_property()
    {
        using var condition =
            JsonDocument.Parse("""{"severity":"High"}""");
        using var payload =
            JsonDocument.Parse("""{"severity":"High","site":"Lindon"}""");

        Assert.True(RuleEngine.Matches(
            condition.RootElement,
            payload.RootElement));
    }
}
