using Atlas.IncidentApi.Features.Administration;

namespace Atlas.IncidentApi.Tests;

public sealed class AdministrationContractTests
{
    [Fact]
    public void Pilot_and_maintenance_modes_are_independent()
    {
        var request = new UpdateTenantSettingsRequest(
            "Somafina Pilot",
            "America/Denver",
            "INC",
            "CAPA",
            PilotMode: true,
            MaintenanceMode: false);

        Assert.True(request.PilotMode);
        Assert.False(request.MaintenanceMode);
    }

    [Fact]
    public void Site_codes_can_be_normalized()
    {
        var request = new UpsertSiteRequest(
            null, "Lindon", "lindon", true);

        Assert.Equal("LINDON", request.Code.ToUpperInvariant());
    }
}
