using Atlas.IncidentApi.Features.Notifications;

namespace Atlas.IncidentApi.Tests;

public sealed class NotificationPreferenceContractTests
{
    [Fact]
    public void Quiet_hours_can_span_midnight()
    {
        var request = new UpdateNotificationPreferenceRequest(
            EmailEnabled: true,
            TeamsEnabled: false,
            InAppEnabled: true,
            QuietHoursEnabled: true,
            QuietHoursStart: new TimeOnly(22, 0),
            QuietHoursEnd: new TimeOnly(6, 0),
            TimeZone: "America/Denver",
            DigestMode: "Immediate");

        Assert.True(request.QuietHoursEnabled);
        Assert.True(request.QuietHoursStart > request.QuietHoursEnd);
    }
}
