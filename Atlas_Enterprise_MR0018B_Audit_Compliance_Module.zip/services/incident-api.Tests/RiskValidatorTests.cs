using Atlas.IncidentApi.Features.Risks;

namespace Atlas.IncidentApi.Tests;

public sealed class RiskValidatorTests
{
    [Theory]
    [InlineData(25, "Critical")]
    [InlineData(20, "Critical")]
    [InlineData(12, "High")]
    [InlineData(6, "Medium")]
    [InlineData(1, "Low")]
    public void Risk_score_maps_to_rating(int score, string expected)
    {
        Assert.Equal(expected, RiskValidator.Rating(score));
    }

    [Fact]
    public void Valid_risk_has_no_errors()
    {
        var request = new CreateRiskRequest(
            "Forklift aisle conflict",
            "Long pallets and pedestrian routing constrain maneuvering.",
            null,
            "Lindon",
            "Warehouse",
            "Material Handling",
            Guid.NewGuid(),
            Guid.NewGuid(),
            4,
            4,
            3,
            4,
            2,
            3,
            "Fast",
            DateTimeOffset.UtcNow.AddDays(90));

        Assert.Empty(RiskValidator.Validate(request));
    }
}
