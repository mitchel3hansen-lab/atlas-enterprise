using Atlas.IncidentApi.Platform.Modules;

namespace Atlas.IncidentApi.Tests;

public sealed class AuditComplianceTests
{
    [Fact]
    public void Audit_module_exposes_expected_capabilities()
    {
        var module = new AuditModule();

        Assert.Equal("atlas.audit", module.Key);
        Assert.Contains("findings", module.Capabilities);
        Assert.Contains("scoring", module.Capabilities);
    }

    [Theory]
    [InlineData(95, "Excellent")]
    [InlineData(85, "Compliant")]
    [InlineData(75, "NeedsImprovement")]
    [InlineData(60, "Unsatisfactory")]
    public void Audit_rating_thresholds_are_stable(
        decimal score,
        string expected)
    {
        var rating = score switch
        {
            >= 90 => "Excellent",
            >= 80 => "Compliant",
            >= 70 => "NeedsImprovement",
            _ => "Unsatisfactory"
        };

        Assert.Equal(expected, rating);
    }
}
