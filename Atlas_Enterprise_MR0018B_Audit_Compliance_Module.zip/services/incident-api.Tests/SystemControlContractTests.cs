using Atlas.IncidentApi.Domain;

namespace Atlas.IncidentApi.Tests;

public sealed class SystemControlContractTests
{
    [Fact]
    public void Emergency_lock_and_maintenance_are_separate_controls()
    {
        var state = new SystemControlState(
            Guid.NewGuid(),
            PilotMode: true,
            MaintenanceMode: false,
            EmergencyWriteLock: true,
            AllowReadOnlyAccess: true,
            MaintenanceMessage: null,
            PilotBannerMessage: "Controlled pilot.",
            FeatureFlags: new Dictionary<string, bool>
            {
                ["incident-creation"] = true
            },
            RefreshedAt: DateTimeOffset.UtcNow);

        Assert.False(state.MaintenanceMode);
        Assert.True(state.EmergencyWriteLock);
        Assert.True(state.AllowReadOnlyAccess);
    }
}
