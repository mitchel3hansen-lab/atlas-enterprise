using System.Net;
using System.Net.Http.Json;

namespace Atlas.IntegrationTests;

public sealed class AdministratorConsoleIntegrationTests(PostgresFixture database)
    : IClassFixture<PostgresFixture>
{
    [Fact]
    public async Task Administrator_can_open_console()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory, "Administrator", "Administration");

        var response = await client.GetAsync("/api/admin/console");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    [Fact]
    public async Task Safety_cannot_open_console()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory, "Safety", "Safety");

        var response = await client.GetAsync("/api/admin/console");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Administrator_can_update_feature_flag()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory, "Administrator", "Administration");

        var response = await client.PutAsJsonAsync(
            "/api/admin/feature-flags/new-dashboard",
            new
            {
                flagKey = "ignored-by-route",
                enabled = true,
                description = "Enable next dashboard iteration."
            });

        Assert.Equal(HttpStatusCode.NoContent, response.StatusCode);
    }
}
