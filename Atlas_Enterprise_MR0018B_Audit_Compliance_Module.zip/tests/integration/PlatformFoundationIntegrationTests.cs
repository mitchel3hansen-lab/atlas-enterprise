using System.Net;

namespace Atlas.IntegrationTests;

public sealed class PlatformFoundationIntegrationTests(
    PostgresFixture database)
    : IClassFixture<PostgresFixture>
{
    [Fact]
    public async Task Authenticated_user_can_list_platform_modules()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory,
            "Safety",
            "Safety");

        var response = await client.GetAsync(
            "/api/platform/modules");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    [Fact]
    public async Task Empty_search_query_is_rejected()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory,
            "Employee",
            "Warehouse");

        var response = await client.GetAsync(
            "/api/platform/search?q=");

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }
}
