using System.Net;
using System.Net.Http.Json;

namespace Atlas.IntegrationTests;

public sealed class SystemControlIntegrationTests(PostgresFixture database)
    : IClassFixture<PostgresFixture>
{
    [Fact]
    public async Task Administrator_can_update_system_controls()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory,
            "Administrator",
            "Administration");

        var response = await client.PutAsJsonAsync(
            "/api/admin/system-controls",
            new
            {
                pilotMode = true,
                maintenanceMode = false,
                emergencyWriteLock = true,
                allowReadOnlyAccess = true,
                maintenanceMessage = (string?)null,
                pilotBannerMessage = "Controlled integration test pilot."
            });

        Assert.Equal(HttpStatusCode.NoContent, response.StatusCode);

        var status = await client.GetAsync("/api/system/status");
        Assert.Equal(HttpStatusCode.OK, status.StatusCode);
    }

    [Fact]
    public async Task Safety_cannot_change_system_controls()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory,
            "Safety",
            "Safety");

        var response = await client.PutAsJsonAsync(
            "/api/admin/system-controls",
            new
            {
                pilotMode = true,
                maintenanceMode = false,
                emergencyWriteLock = false,
                allowReadOnlyAccess = true,
                maintenanceMessage = (string?)null,
                pilotBannerMessage = "Pilot"
            });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}
