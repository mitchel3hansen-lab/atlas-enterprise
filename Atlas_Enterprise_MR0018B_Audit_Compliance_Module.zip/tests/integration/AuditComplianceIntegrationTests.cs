using System.Net;
using System.Net.Http.Json;

namespace Atlas.IntegrationTests;

public sealed class AuditComplianceIntegrationTests(PostgresFixture database)
    : IClassFixture<PostgresFixture>
{
    [Fact]
    public async Task Safety_can_list_frameworks()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory, "Safety", "Safety");

        var response = await client.GetAsync("/api/audit-frameworks");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    [Fact]
    public async Task Employee_cannot_create_template()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory, "Employee", "Warehouse");

        var response = await client.PostAsJsonAsync(
            "/api/audit-templates",
            new
            {
                frameworkId = Guid.NewGuid(),
                name = "Unauthorized",
                description = "Should fail."
            });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}
