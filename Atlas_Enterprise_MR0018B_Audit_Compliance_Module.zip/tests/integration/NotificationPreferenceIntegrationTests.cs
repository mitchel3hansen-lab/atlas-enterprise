using System.Net;
using System.Net.Http.Json;

namespace Atlas.IntegrationTests;

public sealed class NotificationPreferenceIntegrationTests(PostgresFixture database)
    : IClassFixture<PostgresFixture>
{
    [Fact]
    public async Task User_can_update_personal_notification_preferences()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory,
            "Employee");

        var response = await client.PutAsJsonAsync(
            "/api/notification-preferences",
            new
            {
                emailEnabled = true,
                teamsEnabled = true,
                inAppEnabled = true,
                quietHoursEnabled = true,
                quietHoursStart = "22:00:00",
                quietHoursEnd = "06:00:00",
                timeZone = "America/Denver",
                digestMode = "Immediate"
            });

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var getResponse = await client.GetAsync(
            "/api/notification-preferences");

        Assert.Equal(HttpStatusCode.OK, getResponse.StatusCode);
    }
}
