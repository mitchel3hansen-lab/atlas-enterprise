using System.Net;
using System.Net.Http.Json;

namespace Atlas.IntegrationTests;

public sealed class RiskRegisterIntegrationTests(PostgresFixture database)
    : IClassFixture<PostgresFixture>
{
    [Fact]
    public async Task Safety_can_create_and_list_risk()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory, "Safety", "Safety");

        var response = await client.PostAsJsonAsync(
            "/api/risks",
            new
            {
                title = "Integration test risk",
                description = "A test operational risk.",
                categoryId = (Guid?)null,
                site = "Lindon",
                department = "Warehouse",
                process = "Material Handling",
                ownerId = Guid.NewGuid(),
                reviewerId = Guid.NewGuid(),
                inherentLikelihood = 4,
                inherentSeverity = 4,
                residualLikelihood = 3,
                residualSeverity = 4,
                targetLikelihood = 2,
                targetSeverity = 3,
                riskVelocity = "Fast",
                nextReviewAt = DateTimeOffset.UtcNow.AddDays(90)
            });

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);

        var list = await client.GetAsync("/api/risks");
        Assert.Equal(HttpStatusCode.OK, list.StatusCode);
    }

    [Fact]
    public async Task Employee_cannot_create_risk()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory, "Employee", "Warehouse");

        var response = await client.PostAsJsonAsync(
            "/api/risks",
            new
            {
                title = "Unauthorized risk",
                description = "Should be rejected.",
                ownerId = Guid.NewGuid(),
                inherentLikelihood = 2,
                inherentSeverity = 2,
                residualLikelihood = 2,
                residualSeverity = 2,
                riskVelocity = "Medium",
                nextReviewAt = DateTimeOffset.UtcNow.AddDays(30)
            });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}
