# Atlas Enterprise

Atlas is an operational intelligence platform with a complete closed-loop incident workflow.

## Complete workflow

```text
Draft
→ SupervisorReview
→ SafetyReview
→ Investigation
→ CAPA
→ Verification
→ Closed
```

## Current capabilities

- Incident creation and submission
- Supervisor and Safety review
- Investigator assignment
- Structured investigations
- Findings and evidence
- Root-cause analysis
- CAPA ownership, evidence, verification, and effectiveness
- OSHA classification review
- Residual-risk review
- Lessons learned
- SMETA evidence links
- Management closure approval
- Controlled final closure

## Start locally

```bash
docker compose down -v
docker compose up --build
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger
