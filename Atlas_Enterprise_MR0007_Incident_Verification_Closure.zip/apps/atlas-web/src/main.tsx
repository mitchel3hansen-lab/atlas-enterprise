import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const apiUrl = import.meta.env.VITE_INCIDENT_API_URL ?? "http://localhost:8085";
const tenantId = "11111111-1111-1111-1111-111111111111";
const employeeId = "22222222-2222-2222-2222-222222222222";
const supervisorId = "33333333-3333-3333-3333-333333333333";
const safetyId = "44444444-4444-4444-4444-444444444444";
const investigatorId = "55555555-5555-5555-5555-555555555555";
const capaOwnerId = "66666666-6666-6666-6666-666666666666";
const supervisorDepartment = "Warehouse";

type Incident = {
  id: string;
  incidentNumber: string;
  title: string;
  severity: string;
  status: string;
  workflowState: string;
  site: string;
  department: string;
};

type Capa = {
  id: string;
  capaNumber: string;
  title: string;
  priority: string;
  status: string;
};

function App() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [capas, setCapas] = useState<Record<string, Capa[]>>({});
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function load() {
    const response = await fetch(`${apiUrl}/api/incidents?tenantId=${tenantId}`);
    if (!response.ok) return;
    const rows: Incident[] = await response.json();
    setIncidents(rows);

    const entries = await Promise.all(rows.map(async (incident) => {
      const capaResponse = await fetch(
        `${apiUrl}/api/incidents/${incident.id}/capas?tenantId=${tenantId}`);
      return [incident.id, capaResponse.ok ? await capaResponse.json() : []] as const;
    }));
    setCapas(Object.fromEntries(entries));
  }

  useEffect(() => {
    load().catch(() => setMessage("Unable to load Atlas data."));
  }, []);

  async function send(
    url: string,
    method: "POST" | "PUT",
    body: unknown,
    success: string
  ) {
    setBusy(true);
    setMessage("");
    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message ?? result.title ?? "Action failed.");
      setMessage(success);
      await load();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unexpected error.");
    } finally {
      setBusy(false);
    }
  }

  async function createIncident(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    await send(`${apiUrl}/api/incidents`, "POST", {
      tenantId,
      reporterId: employeeId,
      title: String(form.get("title") ?? ""),
      description: String(form.get("description") ?? ""),
      incidentType: "Property Damage",
      severity: "High",
      occurredAt: new Date(String(form.get("occurredAt"))).toISOString(),
      site: "Lindon",
      department: "Warehouse"
    }, "Incident draft created.");
    event.currentTarget.reset();
  }

  async function advanceToCapa(incident: Incident) {
    if (incident.status === "Draft") {
      return send(`${apiUrl}/api/incidents/${incident.id}/submit`, "POST",
        { tenantId, actorId: employeeId }, "Submitted.");
    }
    if (incident.workflowState === "SupervisorReview") {
      return send(`${apiUrl}/api/incidents/${incident.id}/supervisor-review`, "POST", {
        tenantId,
        reviewerId: supervisorId,
        reviewerRole: "Supervisor",
        reviewerDepartment: supervisorDepartment,
        decision: "Approve",
        comment: "Initial review complete."
      }, "Routed to Safety Review.");
    }
    if (incident.workflowState === "SafetyReview") {
      return send(`${apiUrl}/api/incidents/${incident.id}/safety-review`, "POST", {
        tenantId,
        safetyReviewerId: safetyId,
        reviewerRole: "Safety",
        confirmedSeverity: incident.severity,
        oshaReviewRequired: true,
        medicalFollowUpRequired: false,
        immediateControlsReviewed: true,
        investigatorId,
        investigationDueAt: new Date(Date.now() + 5 * 86400000).toISOString(),
        comment: "Safety review complete."
      }, "Investigator assigned.");
    }
    if (incident.workflowState === "Investigation") {
      await send(`${apiUrl}/api/incidents/${incident.id}/investigation`, "PUT", {
        tenantId,
        investigatorId,
        executiveSummary: "Investigation completed using interviews and evidence.",
        eventAnalysis: "The work sequence and conditions were reconstructed.",
        immediateCauses: "Clearance and visibility limitations.",
        rootCauseCategory: "Environment",
        rootCauseDetail: "The work-area layout constrained safe maneuvering.",
        contributingFactors: "Long pallet and adjacent storage.",
        recommendations: "Reconfigure aisle controls and retrain the operator."
      }, "Investigation saved.");
      await send(`${apiUrl}/api/incidents/${incident.id}/investigation/findings`, "POST", {
        tenantId,
        findingType: "ConfirmedFact",
        statement: "Aisle clearance reduced the safe turning envelope.",
        evidenceReference: "Measurements and photographs"
      }, "Finding saved.");
      await send(`${apiUrl}/api/incidents/${incident.id}/investigation/evidence`, "POST", {
        tenantId,
        addedBy: investigatorId,
        evidenceType: "Photograph",
        title: "Aisle and rack photographs",
        referenceUri: "atlas://demo/rack-photos",
        description: "Demonstration evidence."
      }, "Evidence saved.");
      return send(`${apiUrl}/api/incidents/${incident.id}/investigation/complete`, "POST",
        { tenantId, investigatorId }, "Investigation routed to CAPA.");
    }
  }

  async function createCapa(incident: Incident) {
    return send(`${apiUrl}/api/incidents/${incident.id}/capas`, "POST", {
      tenantId,
      actionType: "Corrective",
      title: "Reconfigure warehouse aisle controls",
      description: "Increase clearance and remove the walking-path conflict.",
      ownerId: capaOwnerId,
      department: "Warehouse",
      priority: "High",
      targetDate: new Date(Date.now() + 30 * 86400000).toISOString(),
      estimatedCost: 4500
    }, "CAPA created.");
  }

  async function progressCapa(capa: Capa) {
    if (capa.status === "Open" || capa.status === "Reopened") {
      await send(`${apiUrl}/api/capas/${capa.id}/evidence`, "POST", {
        tenantId,
        uploadedBy: capaOwnerId,
        evidenceType: "Photograph",
        title: "Completed aisle modification",
        referenceUri: "atlas://demo/capa-completion"
      }, "Evidence added.");
      return send(`${apiUrl}/api/capas/${capa.id}/complete`, "POST", {
        tenantId,
        actorId: capaOwnerId,
        completionNotes: "Aisle controls were reconfigured.",
        actualCost: 4200
      }, "CAPA completed.");
    }
    if (capa.status === "Completed") {
      return send(`${apiUrl}/api/capas/${capa.id}/verify`, "POST", {
        tenantId,
        verifierId: safetyId,
        result: "Passed",
        notes: "Implementation matches the approved plan."
      }, "CAPA verified.");
    }
    if (capa.status === "Verified") {
      return send(`${apiUrl}/api/capas/${capa.id}/effectiveness`, "POST", {
        tenantId,
        reviewerId: safetyId,
        result: "Effective",
        recurrenceFound: false,
        comments: "No recurrence observed."
      }, "CAPA effective; incident routed to Verification.");
    }
  }

  async function closeIncident(incident: Incident) {
    await send(`${apiUrl}/api/incidents/${incident.id}/closure/smeta-evidence`, "POST", {
      tenantId,
      linkedBy: safetyId,
      pillar: "Health and Safety",
      requirementReference: "SMETA 4-Pillar H&S corrective action evidence",
      evidenceTitle: "Closed-loop incident and CAPA package",
      evidenceUri: `atlas://incidents/${incident.id}/closure-package`
    }, "SMETA evidence linked.");

    await send(`${apiUrl}/api/incidents/${incident.id}/closure`, "PUT", {
      tenantId,
      reviewerId: safetyId,
      reviewerRole: "Safety",
      capaVerified: true,
      evidenceReviewed: true,
      sopUpdated: true,
      trainingCompleted: true,
      equipmentControlsVerified: true,
      riskRegisterUpdated: true,
      supervisorApproved: true,
      oshaRecordable: false,
      daysAway: 0,
      restrictedDays: 0,
      residualRisk: "Low",
      lessonsLearned: "Aisle geometry and pedestrian routing must be reviewed for long-pallet movements.",
      managementDecision: "ApproveClosure",
      managementNotes: "Corrective actions were verified and remained effective."
    }, "Closure review approved.");

    return send(`${apiUrl}/api/incidents/${incident.id}/close`, "POST", {
      tenantId,
      reviewerId: safetyId
    }, "Incident formally closed.");
  }

  return (
    <main>
      <header>
        <span className="eyebrow">ATLAS ENTERPRISE</span>
        <h1>Closed-Loop Incident Operations</h1>
        <p>Move a case from report through investigation, CAPA, verification, and closure.</p>
      </header>

      <section className="panel">
        <h2>Report an Incident</h2>
        <form onSubmit={createIncident}>
          <label>Incident title<input name="title" required /></label>
          <label>Description<textarea name="description" required rows={4} /></label>
          <label>Occurred at<input name="occurredAt" type="datetime-local" required /></label>
          <button disabled={busy}>Save Incident Draft</button>
        </form>
      </section>

      <section className="panel">
        <h2>Operational Queue</h2>
        <div className="incident-list">
          {incidents.map((incident) => (
            <article key={incident.id}>
              <div className="incident-summary">
                <span className="number">{incident.incidentNumber}</span>
                <h3>{incident.title}</h3>
                <p>{incident.site} · {incident.department}</p>
                <div className="badges">
                  <span className={`badge ${incident.severity.toLowerCase()}`}>
                    {incident.severity}
                  </span>
                  <span className="badge">{incident.workflowState}</span>
                </div>
              </div>

              <div className="incident-actions">
                {!["CAPA", "Verification", "Closed"].includes(incident.workflowState) && (
                  <button disabled={busy} onClick={() => advanceToCapa(incident)}>
                    Advance {incident.workflowState}
                  </button>
                )}

                {incident.workflowState === "CAPA" && (capas[incident.id]?.length ?? 0) === 0 && (
                  <button disabled={busy} onClick={() => createCapa(incident)}>
                    Create CAPA
                  </button>
                )}

                {(capas[incident.id] ?? []).map((capa) => (
                  <div className="review-box" key={capa.id}>
                    <strong>{capa.capaNumber}</strong>
                    <h4>{capa.title}</h4>
                    <span className="badge">{capa.status}</span>
                    {capa.status !== "Closed" && (
                      <button disabled={busy} onClick={() => progressCapa(capa)}>
                        {capa.status === "Completed"
                          ? "Verify"
                          : capa.status === "Verified"
                          ? "Review Effectiveness"
                          : "Complete with Evidence"}
                      </button>
                    )}
                  </div>
                ))}

                {incident.workflowState === "Verification" && (
                  <div className="review-box">
                    <strong>Verification & Closure</strong>
                    <p>Confirm evidence, OSHA review, risk update, lessons learned, and management approval.</p>
                    <button disabled={busy} onClick={() => closeIncident(incident)}>
                      Complete Closure Review
                    </button>
                  </div>
                )}

                {incident.workflowState === "Closed" && (
                  <div className="review-box">
                    <strong>Case Closed</strong>
                    <p>Final verification and management approval are complete.</p>
                  </div>
                )}
              </div>
            </article>
          ))}
        </div>
      </section>

      {message && <output>{message}</output>}
    </main>
  );
}

createRoot(document.getElementById("root")!).render(
  <React.StrictMode><App /></React.StrictMode>
);
