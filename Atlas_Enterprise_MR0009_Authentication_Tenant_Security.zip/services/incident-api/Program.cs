using System.Text;
using Atlas.IncidentApi.Features.Incidents.Create;
using Atlas.IncidentApi.Features.Incidents.Review;
using Atlas.IncidentApi.Features.Incidents.Submit;
using Atlas.IncidentApi.Features.Incidents.SafetyReview;
using Atlas.IncidentApi.Infrastructure;
using Atlas.IncidentApi.Features.Investigations;
using Atlas.IncidentApi.Features.Capas;
using Atlas.IncidentApi.Features.Closure;
using Atlas.IncidentApi.Security;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<IncidentRepository>();
builder.Services.AddSingleton<InvestigationRepository>();
builder.Services.AddSingleton<CapaRepository>();
builder.Services.AddSingleton<ClosureRepository>();
builder.Services.AddSingleton<DashboardRepository>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton<DevTokenService>();

var signingKey = builder.Configuration["Authentication:DevSigningKey"]
    ?? throw new InvalidOperationException("Authentication signing key is missing.");
var issuer = builder.Configuration["Authentication:Issuer"] ?? "atlas-dev";
var audience = builder.Configuration["Authentication:Audience"] ?? "atlas-api";

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = issuer,
            ValidateAudience = true,
            ValidAudience = audience,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(signingKey)),
            ClockSkew = TimeSpan.FromMinutes(1),
            NameClaimType = System.Security.Claims.ClaimTypes.NameIdentifier,
            RoleClaimType = System.Security.Claims.ClaimTypes.Role
        };
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("EmployeeOrAbove", policy =>
        policy.RequireRole(
            AtlasRoles.Employee,
            AtlasRoles.Supervisor,
            AtlasRoles.Safety,
            AtlasRoles.Executive,
            AtlasRoles.Administrator));

    options.AddPolicy("Supervisor", policy =>
        policy.RequireRole(AtlasRoles.Supervisor, AtlasRoles.Administrator));

    options.AddPolicy("Safety", policy =>
        policy.RequireRole(AtlasRoles.Safety, AtlasRoles.Administrator));

    options.AddPolicy("SafetyOrExecutive", policy =>
        policy.RequireRole(
            AtlasRoles.Safety,
            AtlasRoles.Executive,
            AtlasRoles.Administrator));

    options.AddPolicy("Dashboard", policy =>
        policy.RequireRole(
            AtlasRoles.Supervisor,
            AtlasRoles.Safety,
            AtlasRoles.Executive,
            AtlasRoles.Administrator));
});

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
});

var app = builder.Build();

app.UseCors();
app.UseAuthentication();
app.UseAuthorization();
app.UseSwagger();
app.UseSwaggerUI();

app.MapPost("/api/auth/dev-token", (
    DevTokenRequest request,
    DevTokenService tokenService,
    IWebHostEnvironment environment) =>
{
    if (!environment.IsDevelopment())
        return Results.NotFound();

    if (request.UserId == Guid.Empty || request.TenantId == Guid.Empty)
        return Results.BadRequest(new { message = "User and tenant are required." });

    var allowedRoles = new[]
    {
        AtlasRoles.Employee,
        AtlasRoles.Supervisor,
        AtlasRoles.Safety,
        AtlasRoles.Executive,
        AtlasRoles.Administrator
    };

    if (!allowedRoles.Contains(request.Role, StringComparer.OrdinalIgnoreCase))
        return Results.BadRequest(new { message = "Unsupported role." });

    var token = tokenService.Create(
        request.UserId,
        request.TenantId,
        request.Role,
        request.Department);

    return Results.Ok(new { accessToken = token });
})
.AllowAnonymous()
.WithName("CreateDevelopmentToken")
.WithOpenApi();


app.MapGet("/health", () => Results.Ok(new
{
    service = "incident-api",
    status = "healthy",
    timestamp = DateTimeOffset.UtcNow
}));

app.MapPost("/api/incidents", async (
    CreateIncidentRequest request,
    HttpContext httpContext,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    request = request with
    {
        TenantId = user.TenantId,
        ReporterId = user.UserId
    };

    var errors = CreateIncidentValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var incident = await repository.CreateAsync(request, cancellationToken);
    return Results.Created($"/api/incidents/{incident.Id}", incident);
})
.WithName("CreateIncident")
.RequireAuthorization("EmployeeOrAbove")
.WithOpenApi();

app.MapGet("/api/incidents", async (
    string? department,
    HttpContext httpContext,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    if (string.Equals(user.Role, AtlasRoles.Employee, StringComparison.OrdinalIgnoreCase))
        department = user.Department;

    return Results.Ok(await repository.ListAsync(
        user.TenantId, department, cancellationToken));
})
.WithName("ListIncidents")
.RequireAuthorization("EmployeeOrAbove")
.WithOpenApi();

app.MapGet("/api/incidents/{incidentId:guid}", async (
    Guid incidentId,
    HttpContext httpContext,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    var incident = await repository.GetAsync(
        user.TenantId, incidentId, cancellationToken);

    return incident is null ? Results.NotFound() : Results.Ok(incident);
})
.WithName("GetIncident")
.RequireAuthorization("EmployeeOrAbove")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/submit", async (
    Guid incidentId,
    HttpContext httpContext,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    var incident = await repository.SubmitAsync(
        user.TenantId,
        incidentId,
        user.UserId,
        cancellationToken);

    return incident is null
        ? Results.Conflict(new
        {
            message = "Incident was not found or is no longer a draft."
        })
        : Results.Ok(incident);
})
.WithName("SubmitIncident")
.RequireAuthorization("EmployeeOrAbove")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/supervisor-review", async (
    Guid incidentId,
    ReviewIncidentRequest request,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = ReviewIncidentValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var result = await repository.ReviewAsync(
        incidentId, request, cancellationToken);

    return result.Incident is null
        ? Results.Conflict(new { message = result.Error })
        : Results.Ok(result.Incident);
})
.WithName("SupervisorReviewIncident")
.RequireAuthorization("Supervisor")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/safety-review", async (
    Guid incidentId,
    SafetyReviewRequest request,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = SafetyReviewValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var result = await repository.SafetyReviewAsync(
        incidentId, request, cancellationToken);

    return result.Incident is null
        ? Results.Conflict(new { message = result.Error })
        : Results.Ok(result.Incident);
})
.WithName("SafetyReviewAndAssignInvestigator")
.RequireAuthorization("Safety")
.WithOpenApi();


app.MapGet("/api/incidents/{incidentId:guid}/investigation", async (
    Guid incidentId,
    Guid tenantId,
    InvestigationRepository repository,
    CancellationToken cancellationToken) =>
{
    var workspace = await repository.GetAsync(
        tenantId, incidentId, cancellationToken);

    return workspace is null ? Results.NotFound() : Results.Ok(workspace);
})
.WithName("GetInvestigationWorkspace")
.RequireAuthorization("Safety")
.WithOpenApi();

app.MapPut("/api/incidents/{incidentId:guid}/investigation", async (
    Guid incidentId,
    UpsertInvestigationRequest request,
    InvestigationRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = InvestigationValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    return Results.Ok(await repository.UpsertAsync(
        incidentId, request, cancellationToken));
})
.WithName("UpsertInvestigation")
.RequireAuthorization("Safety")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/investigation/interviews", async (
    Guid incidentId,
    AddInterviewRequest request,
    InvestigationRepository repository,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.IntervieweeName) ||
        string.IsNullOrWhiteSpace(request.Summary))
        return Results.BadRequest(new { message = "Interviewee name and summary are required." });

    var id = await repository.AddInterviewAsync(
        incidentId, request, cancellationToken);

    return id is null ? Results.NotFound() : Results.Created($"/api/investigation-interviews/{id}", new { id });
})
.WithName("AddInvestigationInterview")
.RequireAuthorization("Safety")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/investigation/findings", async (
    Guid incidentId,
    AddFindingRequest request,
    InvestigationRepository repository,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.FindingType) ||
        string.IsNullOrWhiteSpace(request.Statement))
        return Results.BadRequest(new { message = "Finding type and statement are required." });

    var id = await repository.AddFindingAsync(
        incidentId, request, cancellationToken);

    return id is null ? Results.NotFound() : Results.Created($"/api/investigation-findings/{id}", new { id });
})
.WithName("AddInvestigationFinding")
.RequireAuthorization("Safety")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/investigation/evidence", async (
    Guid incidentId,
    AddEvidenceRequest request,
    InvestigationRepository repository,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.Title) ||
        string.IsNullOrWhiteSpace(request.ReferenceUri))
        return Results.BadRequest(new { message = "Evidence title and reference are required." });

    var id = await repository.AddEvidenceAsync(
        incidentId, request, cancellationToken);

    return id is null ? Results.NotFound() : Results.Created($"/api/investigation-evidence/{id}", new { id });
})
.WithName("AddInvestigationEvidence")
.RequireAuthorization("Safety")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/investigation/complete", async (
    Guid incidentId,
    CompleteInvestigationRequest request,
    InvestigationRepository repository,
    CancellationToken cancellationToken) =>
{
    var result = await repository.CompleteAsync(
        incidentId, request, cancellationToken);

    return result.Completed
        ? Results.Ok(new { status = "Completed", workflowState = "CAPA" })
        : Results.Conflict(new { message = result.Error });
})
.WithName("CompleteInvestigation")
.RequireAuthorization("Safety")
.WithOpenApi();


app.MapGet("/api/incidents/{incidentId:guid}/capas", async (
    Guid incidentId,
    Guid tenantId,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    return Results.Ok(await repository.ListForIncidentAsync(
        tenantId, incidentId, cancellationToken));
})
.WithName("ListIncidentCapas")
.RequireAuthorization("EmployeeOrAbove")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/capas", async (
    Guid incidentId,
    CreateCapaRequest request,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = CapaValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var action = await repository.CreateAsync(
        incidentId, request, cancellationToken);

    return action is null
        ? Results.Conflict(new { message = "Incident must be in CAPA before actions can be created." })
        : Results.Created($"/api/capas/{action.Id}", action);
})
.WithName("CreateCapa")
.RequireAuthorization("Safety")
.WithOpenApi();

app.MapGet("/api/capas/{capaId:guid}", async (
    Guid capaId,
    Guid tenantId,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    var workspace = await repository.GetAsync(
        tenantId, capaId, cancellationToken);

    return workspace is null ? Results.NotFound() : Results.Ok(workspace);
})
.WithName("GetCapa")
.RequireAuthorization("EmployeeOrAbove")
.WithOpenApi();

app.MapPost("/api/capas/{capaId:guid}/evidence", async (
    Guid capaId,
    AddCapaEvidenceRequest request,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.Title) ||
        string.IsNullOrWhiteSpace(request.ReferenceUri))
        return Results.BadRequest(new { message = "Evidence title and reference are required." });

    var id = await repository.AddEvidenceAsync(
        capaId, request, cancellationToken);

    return id is null ? Results.NotFound() : Results.Created($"/api/capa-evidence/{id}", new { id });
})
.WithName("AddCapaEvidence")
.RequireAuthorization("EmployeeOrAbove")
.WithOpenApi();

app.MapPost("/api/capas/{capaId:guid}/complete", async (
    Guid capaId,
    CompleteCapaRequest request,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    var result = await repository.CompleteAsync(
        capaId, request, cancellationToken);

    return result.Completed
        ? Results.Ok(new { status = "Completed" })
        : Results.Conflict(new { message = result.Error });
})
.WithName("CompleteCapa")
.RequireAuthorization("EmployeeOrAbove")
.WithOpenApi();

app.MapPost("/api/capas/{capaId:guid}/verify", async (
    Guid capaId,
    VerifyCapaRequest request,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    if (request.Result is not ("Passed" or "Failed"))
        return Results.BadRequest(new { message = "Result must be Passed or Failed." });

    var result = await repository.VerifyAsync(
        capaId, request, cancellationToken);

    return result.Verified
        ? Results.Ok(new { status = request.Result == "Passed" ? "Verified" : "Reopened" })
        : Results.Conflict(new { message = result.Error });
})
.WithName("VerifyCapa")
.RequireAuthorization("Safety")
.WithOpenApi();

app.MapPost("/api/capas/{capaId:guid}/effectiveness", async (
    Guid capaId,
    ReviewCapaEffectivenessRequest request,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    if (request.Result is not ("Effective" or "Ineffective"))
        return Results.BadRequest(new { message = "Result must be Effective or Ineffective." });

    var result = await repository.ReviewEffectivenessAsync(
        capaId, request, cancellationToken);

    return result.Reviewed
        ? Results.Ok(new { status = request.Result == "Effective" && !request.RecurrenceFound ? "Closed" : "Reopened" })
        : Results.Conflict(new { message = result.Error });
})
.WithName("ReviewCapaEffectiveness")
.RequireAuthorization("Safety")
.WithOpenApi();

app.MapPost("/api/capas/{capaId:guid}/reopen", async (
    Guid capaId,
    ReopenCapaRequest request,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.Reason))
        return Results.BadRequest(new { message = "Reason is required." });

    return await repository.ReopenAsync(capaId, request, cancellationToken)
        ? Results.Ok(new { status = "Reopened" })
        : Results.NotFound();
})
.WithName("ReopenCapa")
.RequireAuthorization("Safety")
.WithOpenApi();


app.MapGet("/api/incidents/{incidentId:guid}/closure", async (
    Guid incidentId,
    Guid tenantId,
    ClosureRepository repository,
    CancellationToken cancellationToken) =>
{
    return Results.Ok(await repository.GetAsync(
        tenantId, incidentId, cancellationToken));
})
.WithName("GetIncidentClosureWorkspace")
.RequireAuthorization("SafetyOrExecutive")
.WithOpenApi();

app.MapPut("/api/incidents/{incidentId:guid}/closure", async (
    Guid incidentId,
    UpsertClosureReviewRequest request,
    ClosureRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = ClosureValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var gateError = ClosureValidator.ClosureGateError(request);
    if (gateError is not null &&
        string.Equals(
            request.ManagementDecision,
            "ApproveClosure",
            StringComparison.OrdinalIgnoreCase))
        return Results.Conflict(new { message = gateError });

    var review = await repository.UpsertAsync(
        incidentId, request, cancellationToken);

    return review is null
        ? Results.Conflict(new { message = "Incident must be in Verification before closure review." })
        : Results.Ok(review);
})
.WithName("UpsertIncidentClosureReview")
.RequireAuthorization("SafetyOrExecutive")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/closure/smeta-evidence", async (
    Guid incidentId,
    AddSmetaEvidenceRequest request,
    ClosureRepository repository,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.Pillar) ||
        string.IsNullOrWhiteSpace(request.RequirementReference) ||
        string.IsNullOrWhiteSpace(request.EvidenceTitle) ||
        string.IsNullOrWhiteSpace(request.EvidenceUri))
        return Results.BadRequest(new { message = "Complete SMETA evidence metadata is required." });

    var id = await repository.AddSmetaEvidenceAsync(
        incidentId, request, cancellationToken);

    return id is null
        ? Results.NotFound()
        : Results.Created($"/api/incident-smeta-evidence/{id}", new { id });
})
.WithName("AddIncidentSmetaEvidence")
.RequireAuthorization("Safety")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/close", async (
    Guid incidentId,
    CloseIncidentRequest request,
    ClosureRepository repository,
    CancellationToken cancellationToken) =>
{
    if (request.TenantId == Guid.Empty || request.ReviewerId == Guid.Empty)
        return Results.BadRequest(new { message = "Tenant and reviewer are required." });

    var result = await repository.CloseAsync(
        incidentId, request, cancellationToken);

    return result.Closed
        ? Results.Ok(new { status = "Closed", workflowState = "Closed" })
        : Results.Conflict(new { message = result.Error });
})
.WithName("CloseIncident")
.RequireAuthorization("SafetyOrExecutive")
.WithOpenApi();


app.MapGet("/api/dashboard/summary", async (
    HttpContext httpContext,
    DashboardRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    return Results.Ok(await repository.GetAsync(
        user.TenantId, cancellationToken));
})
.WithName("GetDashboardSummary")
.RequireAuthorization("Dashboard")
.WithOpenApi();

app.Run();


public partial class Program;
