# Atlas Enterprise

Atlas is an operational intelligence platform with a closed-loop incident workflow, command center, and server-enforced identity boundary.

## Security added in MR-0009

- JWT bearer authentication
- Tenant-scoped API access
- Role-based authorization
- Department-limited employee visibility
- Protected dashboards and workflow actions
- Signed development tokens for local testing

## Local development

```bash
docker compose down -v
docker compose up --build
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger

The web application automatically requests a development token and allows switching among Employee, Supervisor, Safety, and Executive roles.

## Production warning

The development-token endpoint and development signing key are for local use only. A production OIDC identity provider and managed secrets are required before pilot deployment.
