var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

app.MapPost("/api/incidents", (object request) =>
{
    return Results.Created("/api/incidents/1", new { message = "Incident created (stub)" });
});

app.Run();
