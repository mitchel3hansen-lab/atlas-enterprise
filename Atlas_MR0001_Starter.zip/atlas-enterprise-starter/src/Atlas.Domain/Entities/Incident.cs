namespace Atlas.Domain.Entities;

public class Incident
{
    public Guid Id { get; set; }
    public string IncidentNumber { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string IncidentType { get; set; } = string.Empty;
    public string Severity { get; set; } = "Medium";
    public string Status { get; set; } = "Draft";
    public DateTimeOffset OccurredAt { get; set; }
}
