namespace Atlas.Features.Incident.Create;

public record CreateIncidentCommand(
    string Title,
    string? Description,
    string IncidentType,
    string Severity,
    DateTimeOffset OccurredAt
);
