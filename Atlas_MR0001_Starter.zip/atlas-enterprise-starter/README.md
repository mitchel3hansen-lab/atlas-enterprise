# Atlas Enterprise

Starter repository for the Atlas Enterprise platform.

## Initial Vertical Slice
- Incident Create

Next steps:
1. Create database migration
2. Implement API
3. Implement React UI
4. Add tests
