# Atlas Enterprise

Atlas Enterprise is an enterprise operational-intelligence platform. Manufacturing and Safety Management Systems are the first reference product and implementation.

## Current engineering milestone

The repository is being converted from a sequence of release packages into one durable source-of-truth repository. The current baseline includes the API, web application, PostgreSQL persistence, workflow, rules, evidence, timeline, knowledge graph, incident management, and transactional-outbox foundations.

## Prerequisites

- Docker Desktop or Docker Engine with Compose
- Git

A local .NET or Node installation is optional when using containers.

## Start the development environment

```bash
cp .env.example .env
docker compose up --build
```

Services:

- Web: http://localhost:5173
- API: http://localhost:8080
- API health: http://localhost:8080/health
- PostgreSQL: localhost:5432
- Redis: localhost:6379
- Mailpit: http://localhost:8025

## Repository layout

```text
apps/api                 ASP.NET Core API and database migrations
apps/web                 React and TypeScript web application
platform                 Reusable Atlas platform modules
products/manufacturing   Manufacturing product configuration and features
tests                    Automated tests and SQL smoke tests
docs                     Architecture, product, operations, and governance
infrastructure           Container and deployment resources
scripts                  Developer automation
```

## Engineering workflow

1. Create a short-lived branch from `main`.
2. Make one coherent change.
3. Add or update tests and documentation.
4. Open a pull request.
5. Merge only after required checks pass.

See [CONTRIBUTING.md](CONTRIBUTING.md), [SECURITY.md](SECURITY.md), and [docs/governance/BRANCHING.md](docs/governance/BRANCHING.md).

## License

Licensed under the Apache License 2.0. This was selected for permissive commercial and open-source use with an explicit patent grant.

## Shared Kernel

The foundational domain primitives are maintained in `platform/SharedKernel`. See [`docs/architecture/SHARED-KERNEL.md`](docs/architecture/SHARED-KERNEL.md) and [`ADR-0002`](docs/architecture/decisions/ADR-0002-shared-kernel.md).

## Current build status

- Sprint 001: Shared Kernel complete
- Sprint 002: Identity and Tenant Security implemented
- Next: Incident Management vertical-slice alignment with the Shared Kernel
