# Changelog

## [0.2.0] - 2026-07-17

### Added
- PostgreSQL/EF Core persistence for organizations and facilities.
- Tenant header middleware and tenant-scoped repository queries.
- Facility API endpoints and application service.
- Automatic entity audit-entry capture.
- V002 forward and rollback database scripts.
- Tenant isolation architecture and migration runbook.
- ADR-0011 and ADR-0012.

### Changed
- Organization names now use tenant-scoped normalized uniqueness.
- API failures use RFC-style Problem Details responses.

## [0.1.0] - 2026-07-17
- Initial Genesis foundation.
