namespace Atlas.Platform.Api.Contracts;

public sealed record CreateOrganizationRequest(string Name, Guid? ActorId);
public sealed record CreateFacilityRequest(string Name, string? Code, Guid? ActorId);
