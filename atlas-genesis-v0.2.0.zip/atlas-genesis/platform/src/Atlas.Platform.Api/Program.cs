using Atlas.Platform.Api.Contracts;
using Atlas.Platform.Api.Middleware;
using Atlas.Platform.Application;
using Atlas.Platform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
var connectionString = builder.Configuration.GetConnectionString("AtlasDatabase")
    ?? throw new InvalidOperationException("ConnectionStrings:AtlasDatabase is required.");

builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddDbContext<AtlasDbContext>(options => options.UseNpgsql(connectionString));
builder.Services.AddScoped<IOrganizationRepository, PostgresOrganizationRepository>();
builder.Services.AddScoped<IFacilityRepository, PostgresFacilityRepository>();
builder.Services.AddScoped<OrganizationService>();
builder.Services.AddScoped<FacilityService>();
builder.Services.AddHealthChecks().AddNpgSql(connectionString);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddOpenApi();

var app = builder.Build();
app.UseMiddleware<ExceptionMiddleware>();
app.UseMiddleware<TenantMiddleware>();
app.MapHealthChecks("/health");
app.MapOpenApi();

var api = app.MapGroup("/api/v1");

api.MapGet("/organizations", async (HttpContext context, OrganizationService service, CancellationToken ct) =>
    Results.Ok(await service.ListAsync(GetTenantId(context), ct)));

api.MapGet("/organizations/{organizationId:guid}", async (Guid organizationId, HttpContext context, OrganizationService service, CancellationToken ct) =>
    await service.GetAsync(GetTenantId(context), organizationId, ct) is { } organization
        ? Results.Ok(organization) : Results.NotFound());

api.MapPost("/organizations", async (CreateOrganizationRequest request, HttpContext context, OrganizationService service, CancellationToken ct) =>
{
    var organization = await service.CreateAsync(GetTenantId(context), request.Name, request.ActorId, ct);
    return Results.Created($"/api/v1/organizations/{organization.Id}", organization);
});

api.MapGet("/organizations/{organizationId:guid}/facilities", async (Guid organizationId, HttpContext context, FacilityService service, CancellationToken ct) =>
    Results.Ok(await service.ListAsync(GetTenantId(context), organizationId, ct)));

api.MapPost("/organizations/{organizationId:guid}/facilities", async (Guid organizationId, CreateFacilityRequest request, HttpContext context, FacilityService service, CancellationToken ct) =>
{
    var facility = await service.CreateAsync(GetTenantId(context), organizationId, request.Name, request.Code, request.ActorId, ct);
    return Results.Created($"/api/v1/facilities/{facility.Id}", facility);
});

api.MapGet("/facilities/{facilityId:guid}", async (Guid facilityId, HttpContext context, FacilityService service, CancellationToken ct) =>
    await service.GetAsync(GetTenantId(context), facilityId, ct) is { } facility
        ? Results.Ok(facility) : Results.NotFound());

app.Run();

static Guid GetTenantId(HttpContext context) => (Guid)context.Items["TenantId"]!;
public partial class Program;
