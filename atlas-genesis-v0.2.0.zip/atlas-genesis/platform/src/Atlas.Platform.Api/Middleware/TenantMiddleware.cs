namespace Atlas.Platform.Api.Middleware;

public sealed class TenantMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        if (!context.Request.Path.StartsWithSegments("/api"))
        {
            await next(context);
            return;
        }

        if (!Guid.TryParse(context.Request.Headers["X-Atlas-Tenant-Id"], out var tenantId) || tenantId == Guid.Empty)
        {
            context.Response.StatusCode = StatusCodes.Status400BadRequest;
            await context.Response.WriteAsJsonAsync(new ProblemDetails
            {
                Status = 400, Title = "Tenant header required",
                Detail = "Supply a valid X-Atlas-Tenant-Id header."
            });
            return;
        }

        context.Items["TenantId"] = tenantId;
        await next(context);
    }
}
