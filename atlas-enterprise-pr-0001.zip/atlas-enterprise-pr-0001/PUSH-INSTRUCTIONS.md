# Push PR-0001 to GitHub

This package is a real Git repository snapshot containing the Atlas Enterprise platform baseline.

## Option A — Push this repository directly

```bash
git remote add origin https://github.com/mitchel3hansen-lab/atlas-enterprise-2.git
git push -u origin main
```

If `origin` already exists:

```bash
git remote set-url origin https://github.com/mitchel3hansen-lab/atlas-enterprise-2.git
git push -u origin main
```

## Option B — Import from the Git bundle

```bash
git clone atlas-enterprise-pr-0001.bundle atlas-enterprise-2
cd atlas-enterprise-2
git remote set-url origin https://github.com/mitchel3hansen-lab/atlas-enterprise-2.git
git push -u origin main
```

## Recommended verification

```bash
git log --oneline --decorate -5
git status
docker compose config
npm --prefix apps/web install
npm --prefix apps/web run build
```

Backend build and tests require the .NET SDK specified by the repository configuration.
