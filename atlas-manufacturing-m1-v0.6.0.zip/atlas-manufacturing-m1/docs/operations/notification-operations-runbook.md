# Notification Operations Runbook

Monitor pending/retry counts, oldest due message, dead-message count, and provider error rate. Investigate a growing queue before replaying messages. Correct configuration or provider failures first, then reset selected dead messages to `retry` with a current `next_attempt_at` under a controlled administrative procedure.

Genesis email and in-app adapters log delivery only. Before production, configure an approved email provider, secret storage, rate limiting, opt-out handling, sender-domain controls, and delivery telemetry. Do not include sensitive record details in message bodies unless the channel and recipient are approved for that data classification.
