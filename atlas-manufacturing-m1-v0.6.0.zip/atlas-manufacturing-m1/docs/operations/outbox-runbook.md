# Transactional Outbox Operations Runbook

## Monitoring
Alert on pending messages older than five minutes, rapidly increasing attempt counts, and any dead-letter insertion.

## Recovery
1. Confirm the external broker or publisher is healthy.
2. Review `last_error` and payload classification without exposing sensitive data.
3. Correct the underlying fault.
4. For a retryable dead-letter, create a new outbox message with a new ID and retain the dead-letter record as evidence.
5. Never directly delete failed records without an approved retention procedure.

## Scaling
Run one or more dispatchers using PostgreSQL row-locking/skip-locked semantics before horizontal production scaling. The v0.4 reference worker is suitable for a single dispatcher instance.
