# Atlas Manufacturing Edition — M1

M1 is the first pilot-ready vertical slice of ATLAS. It combines tenant-aware platform services with a focused safety command center.

## Included
- Executive safety dashboard and six-month activity trend
- Incident, near-miss, and hazard records
- Severity and facility filters
- Corrective/preventive action tracking
- Tenant-isolated PostgreSQL persistence
- JWT and permission-based API controls
- Responsive pilot UI and Docker deployment

## Pilot acceptance criteria
A safety leader can sign in, review current risk, submit a record, create a corrective action, track due dates, and close the record without leaving the application.
