# Notifications and Scheduling Architecture

ATLAS treats notification delivery as durable work rather than an inline side effect. API requests create tenant-scoped notification messages. A background dispatcher claims due messages, resolves the configured channel, records delivery, and applies bounded exponential retries before marking a message dead.

Supported reference channels are `in_app` and `email`. Both use logging adapters in Genesis; production adapters must integrate an approved provider without changing application contracts. User preferences control channel and escalation eligibility. Templates are tenant-scoped and versioned through the canonical entity audit model.

Scheduled jobs provide a durable foundation for overdue workflow detection, escalation, reminders, and future recurring platform work. Production deployments should add distributed leases before running more than one scheduler replica.
