# Workflow and Event Architecture v0.4

## Scope
The Workflow Platform supplies reusable lifecycle definitions, runtime instances, human tasks, SLA due dates, and durable event delivery.

## Execution model
1. A tenant administrator creates and validates a definition.
2. The definition is published.
3. Products start an instance against a subject record.
4. The application service validates requested transitions against the published definition.
5. State changes and outbox events commit together.
6. The dispatcher publishes events with retry and dead-letter handling.

## Deliberate v0.4 limits
- Transition conditions are declarative metadata only; no arbitrary code execution.
- Approval votes, timer-triggered transitions, definition cloning, and broker adapters are scheduled for later increments.
- Event consumers must use message IDs as idempotency keys.
