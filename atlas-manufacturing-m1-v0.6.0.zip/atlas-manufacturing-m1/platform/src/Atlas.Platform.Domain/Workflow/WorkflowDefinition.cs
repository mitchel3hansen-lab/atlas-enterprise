using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain.Workflow;

public sealed class WorkflowDefinition : AtlasEntity
{
    private WorkflowDefinition() { }
    public string Key { get; private set; } = string.Empty;
    public string Name { get; private set; } = string.Empty;
    public int DefinitionVersion { get; private set; }
    public string InitialState { get; private set; } = string.Empty;
    public string StatesJson { get; private set; } = "[]";
    public string TransitionsJson { get; private set; } = "[]";
    public bool IsPublished { get; private set; }

    public static WorkflowDefinition Create(Guid tenantId, string key, string name, string initialState,
        string statesJson, string transitionsJson, Guid actorId, DateTimeOffset now)
    {
        if (string.IsNullOrWhiteSpace(key)) throw new ArgumentException("Workflow key is required.", nameof(key));
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Workflow name is required.", nameof(name));
        if (string.IsNullOrWhiteSpace(initialState)) throw new ArgumentException("Initial state is required.", nameof(initialState));
        return new WorkflowDefinition { Id=Guid.NewGuid(), TenantId=tenantId, Key=key.Trim().ToLowerInvariant(), Name=name.Trim(),
            DefinitionVersion=1, InitialState=initialState.Trim(), StatesJson=statesJson, TransitionsJson=transitionsJson,
            CreatedAt=now, UpdatedAt=now, CreatedBy=actorId, UpdatedBy=actorId, Status="draft" };
    }

    public void Publish(Guid actorId, DateTimeOffset now)
    { IsPublished=true; Status="published"; UpdatedBy=actorId; UpdatedAt=now; Version++; }
}
