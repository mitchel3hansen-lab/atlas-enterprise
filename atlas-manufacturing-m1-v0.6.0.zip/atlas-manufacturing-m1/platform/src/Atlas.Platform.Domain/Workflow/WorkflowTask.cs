using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain.Workflow;

public sealed class WorkflowTask : AtlasEntity
{
    private WorkflowTask() { }
    public Guid WorkflowInstanceId { get; private set; }
    public string Title { get; private set; } = string.Empty;
    public Guid? AssigneeUserId { get; private set; }
    public Guid? AssigneeRoleId { get; private set; }
    public DateTimeOffset? DueAt { get; private set; }
    public DateTimeOffset? CompletedAt { get; private set; }

    public static WorkflowTask Create(Guid tenantId, Guid instanceId, string title, Guid? assigneeUserId,
        Guid? assigneeRoleId, DateTimeOffset? dueAt, Guid actorId, DateTimeOffset now)
    {
        if (string.IsNullOrWhiteSpace(title)) throw new ArgumentException("Task title is required.", nameof(title));
        if (assigneeUserId is null && assigneeRoleId is null) throw new ArgumentException("A user or role assignee is required.");
        return new WorkflowTask { Id=Guid.NewGuid(), TenantId=tenantId, WorkflowInstanceId=instanceId, Title=title.Trim(),
            AssigneeUserId=assigneeUserId, AssigneeRoleId=assigneeRoleId, DueAt=dueAt, CreatedAt=now, UpdatedAt=now,
            CreatedBy=actorId, UpdatedBy=actorId, Status="open" };
    }
    public void Complete(Guid actorId, DateTimeOffset now)
    { if(Status=="completed") return; Status="completed"; CompletedAt=now; UpdatedAt=now; UpdatedBy=actorId; Version++; }
}
