using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain.Workflow;

public sealed class WorkflowInstance : AtlasEntity
{
    private WorkflowInstance() { }
    public Guid DefinitionId { get; private set; }
    public string DefinitionKey { get; private set; } = string.Empty;
    public int DefinitionVersion { get; private set; }
    public string CurrentState { get; private set; } = string.Empty;
    public string SubjectType { get; private set; } = string.Empty;
    public Guid SubjectId { get; private set; }
    public DateTimeOffset? DueAt { get; private set; }
    public DateTimeOffset? CompletedAt { get; private set; }

    public static WorkflowInstance Start(Guid tenantId, WorkflowDefinition definition, string subjectType, Guid subjectId,
        DateTimeOffset? dueAt, Guid actorId, DateTimeOffset now)
    {
        if (!definition.IsPublished) throw new InvalidOperationException("Only published workflow definitions can be started.");
        if (string.IsNullOrWhiteSpace(subjectType)) throw new ArgumentException("Subject type is required.", nameof(subjectType));
        return new WorkflowInstance { Id=Guid.NewGuid(), TenantId=tenantId, DefinitionId=definition.Id,
            DefinitionKey=definition.Key, DefinitionVersion=definition.DefinitionVersion, CurrentState=definition.InitialState,
            SubjectType=subjectType.Trim(), SubjectId=subjectId, DueAt=dueAt, CreatedAt=now, UpdatedAt=now,
            CreatedBy=actorId, UpdatedBy=actorId, Status="active" };
    }

    public void TransitionTo(string targetState, bool isTerminal, Guid actorId, DateTimeOffset now)
    {
        if (Status == "completed") throw new InvalidOperationException("Completed workflows cannot transition.");
        CurrentState=targetState; UpdatedBy=actorId; UpdatedAt=now; Version++;
        if (isTerminal) { Status="completed"; CompletedAt=now; }
    }
}
