namespace Atlas.Platform.Domain.Workflow;

public sealed record WorkflowTransitionRule(string Name, string From, string To, bool IsTerminal = false,
    bool RequiresApproval = false, string? RequiredPermission = null);
