using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain.Notifications;

public sealed class NotificationTemplate : AtlasEntity
{
    private NotificationTemplate() { }
    public string Key { get; private set; } = string.Empty;
    public string Name { get; private set; } = string.Empty;
    public string SubjectTemplate { get; private set; } = string.Empty;
    public string BodyTemplate { get; private set; } = string.Empty;
    public string DefaultChannel { get; private set; } = "in_app";

    public static NotificationTemplate Create(Guid tenantId, string key, string name, string subject, string body, string channel, Guid actorId, DateTimeOffset now)
    {
        if (string.IsNullOrWhiteSpace(key) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(body))
            throw new ArgumentException("Template key, name, and body are required.");
        channel = NormalizeChannel(channel);
        return new NotificationTemplate { Id = Guid.NewGuid(), TenantId = tenantId, Key = key.Trim().ToLowerInvariant(), Name = name.Trim(),
            SubjectTemplate = subject?.Trim() ?? string.Empty, BodyTemplate = body.Trim(), DefaultChannel = channel,
            CreatedAt = now, UpdatedAt = now, CreatedBy = actorId, UpdatedBy = actorId };
    }

    public static string NormalizeChannel(string channel) => channel.Trim().ToLowerInvariant() switch
    { "email" => "email", "in_app" or "in-app" => "in_app", _ => throw new ArgumentException("Channel must be email or in_app.") };
}
