using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain.Notifications;

public sealed class NotificationPreference : AtlasEntity
{
    private NotificationPreference() { }
    public Guid UserId { get; private set; }
    public bool EmailEnabled { get; private set; }
    public bool InAppEnabled { get; private set; }
    public bool EscalationsEnabled { get; private set; }

    public static NotificationPreference Create(Guid tenantId, Guid userId, bool email, bool inApp, bool escalations, Guid actorId, DateTimeOffset now) =>
        new() { Id=Guid.NewGuid(), TenantId=tenantId, UserId=userId, EmailEnabled=email, InAppEnabled=inApp, EscalationsEnabled=escalations,
            CreatedAt=now, UpdatedAt=now, CreatedBy=actorId, UpdatedBy=actorId };

    public void Update(bool email, bool inApp, bool escalations, Guid actorId, DateTimeOffset now)
    { EmailEnabled=email; InAppEnabled=inApp; EscalationsEnabled=escalations; UpdatedAt=now; UpdatedBy=actorId; Version++; }
}
