using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain.Notifications;

public sealed class NotificationMessage : AtlasEntity
{
    private NotificationMessage() { }
    public Guid? TemplateId { get; private set; }
    public Guid RecipientUserId { get; private set; }
    public string Channel { get; private set; } = "in_app";
    public string Subject { get; private set; } = string.Empty;
    public string Body { get; private set; } = string.Empty;
    public DateTimeOffset? ScheduledAt { get; private set; }
    public DateTimeOffset? SentAt { get; private set; }
    public DateTimeOffset? ReadAt { get; private set; }
    public int AttemptCount { get; private set; }
    public DateTimeOffset? NextAttemptAt { get; private set; }
    public string? LastError { get; private set; }

    public static NotificationMessage Create(Guid tenantId, Guid? templateId, Guid recipientUserId, string channel, string subject, string body, DateTimeOffset? scheduledAt, Guid actorId, DateTimeOffset now) =>
        new() { Id=Guid.NewGuid(), TenantId=tenantId, TemplateId=templateId, RecipientUserId=recipientUserId,
            Channel=NotificationTemplate.NormalizeChannel(channel), Subject=subject.Trim(), Body=body.Trim(), ScheduledAt=scheduledAt ?? now,
            NextAttemptAt=scheduledAt ?? now, CreatedAt=now, UpdatedAt=now, CreatedBy=actorId, UpdatedBy=actorId, Status="pending" };

    public void MarkSent(DateTimeOffset now) { Status="sent"; SentAt=now; NextAttemptAt=null; UpdatedAt=now; Version++; }
    public void MarkFailed(string error, DateTimeOffset nextAttempt, DateTimeOffset now) { Status="retry"; AttemptCount++; LastError=error[..Math.Min(error.Length,2000)]; NextAttemptAt=nextAttempt; UpdatedAt=now; Version++; }
    public void MarkDead(string error, DateTimeOffset now) { Status="dead"; AttemptCount++; LastError=error[..Math.Min(error.Length,2000)]; NextAttemptAt=null; UpdatedAt=now; Version++; }
    public void MarkRead(DateTimeOffset now) { ReadAt=now; UpdatedAt=now; Version++; }
}
