using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain.Notifications;

public sealed class ScheduledJob : AtlasEntity
{
    private ScheduledJob() { }
    public string JobType { get; private set; } = string.Empty;
    public string PayloadJson { get; private set; } = "{}";
    public DateTimeOffset RunAt { get; private set; }
    public DateTimeOffset? CompletedAt { get; private set; }
    public int AttemptCount { get; private set; }
    public string? LastError { get; private set; }

    public static ScheduledJob Create(Guid tenantId, string jobType, string payloadJson, DateTimeOffset runAt, Guid actorId, DateTimeOffset now) =>
        new() { Id=Guid.NewGuid(), TenantId=tenantId, JobType=jobType.Trim(), PayloadJson=payloadJson, RunAt=runAt,
            CreatedAt=now, UpdatedAt=now, CreatedBy=actorId, UpdatedBy=actorId, Status="scheduled" };
    public void Complete(DateTimeOffset now) { Status="completed"; CompletedAt=now; UpdatedAt=now; Version++; }
    public void Retry(string error, DateTimeOffset next, DateTimeOffset now) { Status="scheduled"; AttemptCount++; LastError=error; RunAt=next; UpdatedAt=now; Version++; }
}
