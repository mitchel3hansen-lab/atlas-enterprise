using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain.Safety;

public enum SafetyRecordType { Incident, NearMiss, Hazard }
public enum RiskSeverity { Low, Medium, High, Critical }

public sealed class SafetyRecord : AtlasEntity
{
    private SafetyRecord() { }
    public Guid FacilityId { get; private set; }
    public SafetyRecordType RecordType { get; private set; }
    public string ReferenceNumber { get; private set; } = string.Empty;
    public string Title { get; private set; } = string.Empty;
    public string Description { get; private set; } = string.Empty;
    public RiskSeverity Severity { get; private set; }
    public DateTimeOffset OccurredAt { get; private set; }
    public string Location { get; private set; } = string.Empty;
    public Guid? OwnerUserId { get; private set; }
    public DateTimeOffset? ClosedAt { get; private set; }

    public static SafetyRecord Create(Guid tenantId, Guid facilityId, SafetyRecordType type, string referenceNumber,
        string title, string description, RiskSeverity severity, DateTimeOffset occurredAt, string location, Guid actorId)
    {
        if (string.IsNullOrWhiteSpace(title)) throw new ArgumentException("Title is required.", nameof(title));
        return new SafetyRecord {
            Id=Guid.NewGuid(), TenantId=tenantId, FacilityId=facilityId, RecordType=type,
            ReferenceNumber=referenceNumber.Trim().ToUpperInvariant(), Title=title.Trim(),
            Description=description.Trim(), Severity=severity, OccurredAt=occurredAt,
            Location=location.Trim(), Status="open", CreatedAt=DateTimeOffset.UtcNow,
            UpdatedAt=DateTimeOffset.UtcNow, CreatedBy=actorId, UpdatedBy=actorId
        };
    }

    public void Assign(Guid ownerUserId, Guid actorId) { OwnerUserId=ownerUserId; Touch(actorId); }
    public void Close(Guid actorId) { Status="closed"; ClosedAt=DateTimeOffset.UtcNow; Touch(actorId); }
    private void Touch(Guid actorId) { UpdatedAt=DateTimeOffset.UtcNow; UpdatedBy=actorId; Version++; }
}
