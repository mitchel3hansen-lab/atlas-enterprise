using Atlas.Sdk.Core;
namespace Atlas.Platform.Domain.Safety;

public sealed class CorrectiveAction : AtlasEntity
{
    private CorrectiveAction() { }
    public Guid SafetyRecordId { get; private set; }
    public string Action { get; private set; } = string.Empty;
    public Guid? OwnerUserId { get; private set; }
    public DateTimeOffset DueAt { get; private set; }
    public DateTimeOffset? CompletedAt { get; private set; }
    public string EffectivenessNotes { get; private set; } = string.Empty;

    public static CorrectiveAction Create(Guid tenantId, Guid recordId, string action, Guid? owner, DateTimeOffset dueAt, Guid actorId)
    {
        if (string.IsNullOrWhiteSpace(action)) throw new ArgumentException("Action is required.", nameof(action));
        return new CorrectiveAction { Id=Guid.NewGuid(), TenantId=tenantId, SafetyRecordId=recordId,
            Action=action.Trim(), OwnerUserId=owner, DueAt=dueAt, Status="open",
            CreatedAt=DateTimeOffset.UtcNow, UpdatedAt=DateTimeOffset.UtcNow, CreatedBy=actorId, UpdatedBy=actorId };
    }
    public void Complete(string notes, Guid actorId) { Status="completed"; CompletedAt=DateTimeOffset.UtcNow;
        EffectivenessNotes=notes.Trim(); UpdatedAt=DateTimeOffset.UtcNow; UpdatedBy=actorId; Version++; }
}
