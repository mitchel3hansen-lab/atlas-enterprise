namespace Atlas.Platform.Api.Contracts;

public sealed record CreateNotificationTemplateRequest(string Key,string Name,string SubjectTemplate,string BodyTemplate,string DefaultChannel);
public sealed record QueueNotificationRequest(Guid? TemplateId,Guid RecipientUserId,string Channel,string Subject,string Body,DateTimeOffset? ScheduledAt);
public sealed record SetNotificationPreferenceRequest(bool EmailEnabled,bool InAppEnabled,bool EscalationsEnabled);
