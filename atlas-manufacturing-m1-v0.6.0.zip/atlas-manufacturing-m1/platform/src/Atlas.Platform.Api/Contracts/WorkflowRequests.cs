using Atlas.Platform.Domain.Workflow;
namespace Atlas.Platform.Api.Contracts;
public sealed record CreateWorkflowDefinitionRequest(string Key,string Name,string InitialState,IReadOnlyCollection<string> States,IReadOnlyCollection<WorkflowTransitionRule> Transitions);
public sealed record StartWorkflowRequest(Guid DefinitionId,string SubjectType,Guid SubjectId,DateTimeOffset? DueAt);
public sealed record TransitionWorkflowRequest(string Transition);
public sealed record CreateWorkflowTaskRequest(string Title,Guid? AssigneeUserId,Guid? AssigneeRoleId,DateTimeOffset? DueAt);
