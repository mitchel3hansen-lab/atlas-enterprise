using Atlas.Platform.Domain.Safety;
namespace Atlas.Platform.Api.Contracts;
public sealed record CreateSafetyRecordRequest(Guid FacilityId,SafetyRecordType RecordType,string Title,string Description,RiskSeverity Severity,DateTimeOffset OccurredAt,string Location);
public sealed record CreateCorrectiveActionRequest(string Action,Guid? OwnerUserId,DateTimeOffset DueAt);
public sealed record CompleteCorrectiveActionRequest(string EffectivenessNotes);
