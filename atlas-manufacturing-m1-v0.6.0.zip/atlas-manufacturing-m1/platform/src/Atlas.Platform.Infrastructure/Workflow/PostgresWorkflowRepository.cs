using Atlas.Platform.Application.Workflow;
using Atlas.Platform.Domain.Workflow;
using Atlas.Platform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Platform.Infrastructure.Workflow;

public sealed class PostgresWorkflowRepository(AtlasDbContext db, TimeProvider timeProvider) : IWorkflowRepository
{
    public Task<bool> DefinitionKeyExistsAsync(Guid t,string key,CancellationToken ct)=>db.WorkflowDefinitions.AnyAsync(x=>x.TenantId==t&&x.Key==key,ct);
    public async Task AddDefinitionAsync(WorkflowDefinition x,CancellationToken ct){db.WorkflowDefinitions.Add(x);await db.SaveChangesAsync(ct);}
    public Task<WorkflowDefinition?> GetDefinitionAsync(Guid t,Guid id,CancellationToken ct)=>db.WorkflowDefinitions.SingleOrDefaultAsync(x=>x.TenantId==t&&x.Id==id,ct);
    public async Task<IReadOnlyCollection<WorkflowDefinition>> ListDefinitionsAsync(Guid t,CancellationToken ct)=>await db.WorkflowDefinitions.AsNoTracking().Where(x=>x.TenantId==t).OrderBy(x=>x.Name).ToArrayAsync(ct);
    public async Task UpdateDefinitionAsync(WorkflowDefinition x,string et,string p,CancellationToken ct){AddOutbox(x.TenantId,et,p);await db.SaveChangesAsync(ct);}
    public async Task AddInstanceAsync(WorkflowInstance x,string et,string p,CancellationToken ct){db.WorkflowInstances.Add(x);AddOutbox(x.TenantId,et,p);await db.SaveChangesAsync(ct);}
    public Task<WorkflowInstance?> GetInstanceAsync(Guid t,Guid id,CancellationToken ct)=>db.WorkflowInstances.SingleOrDefaultAsync(x=>x.TenantId==t&&x.Id==id,ct);
    public async Task<IReadOnlyCollection<WorkflowInstance>> ListInstancesAsync(Guid t,CancellationToken ct)=>await db.WorkflowInstances.AsNoTracking().Where(x=>x.TenantId==t).OrderByDescending(x=>x.CreatedAt).ToArrayAsync(ct);
    public async Task UpdateInstanceAsync(WorkflowInstance x,string et,string p,CancellationToken ct){AddOutbox(x.TenantId,et,p);await db.SaveChangesAsync(ct);}
    public async Task AddTaskAsync(WorkflowTask x,string et,string p,CancellationToken ct){db.WorkflowTasks.Add(x);AddOutbox(x.TenantId,et,p);await db.SaveChangesAsync(ct);}
    public Task<WorkflowTask?> GetTaskAsync(Guid t,Guid id,CancellationToken ct)=>db.WorkflowTasks.SingleOrDefaultAsync(x=>x.TenantId==t&&x.Id==id,ct);
    public async Task<IReadOnlyCollection<WorkflowTask>> ListTasksAsync(Guid t,Guid? i,CancellationToken ct)=>await db.WorkflowTasks.AsNoTracking().Where(x=>x.TenantId==t&&(!i.HasValue||x.WorkflowInstanceId==i)).OrderBy(x=>x.DueAt).ToArrayAsync(ct);
    public async Task UpdateTaskAsync(WorkflowTask x,string et,string p,CancellationToken ct){AddOutbox(x.TenantId,et,p);await db.SaveChangesAsync(ct);}
    private void AddOutbox(Guid tenant,string type,string payload)=>db.OutboxMessages.Add(new OutboxMessage{Id=Guid.NewGuid(),TenantId=tenant,EventType=type,PayloadJson=payload,OccurredAt=timeProvider.GetUtcNow()});
}
