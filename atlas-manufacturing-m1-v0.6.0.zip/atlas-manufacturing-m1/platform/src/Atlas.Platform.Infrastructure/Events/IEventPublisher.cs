using Microsoft.Extensions.Logging;
namespace Atlas.Platform.Infrastructure.Events;
public interface IEventPublisher { Task PublishAsync(string eventType, string payloadJson, CancellationToken cancellationToken); }
public sealed class LoggingEventPublisher(ILogger<LoggingEventPublisher> logger) : IEventPublisher
{ public Task PublishAsync(string eventType,string payloadJson,CancellationToken ct){logger.LogInformation("Publishing {EventType}: {Payload}",eventType,payloadJson);return Task.CompletedTask;} }
