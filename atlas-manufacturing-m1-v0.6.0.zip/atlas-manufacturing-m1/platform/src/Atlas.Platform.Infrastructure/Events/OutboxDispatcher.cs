using Atlas.Platform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Atlas.Platform.Infrastructure.Events;

public sealed class OutboxDispatcher(IServiceScopeFactory scopes, TimeProvider timeProvider, ILogger<OutboxDispatcher> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while(!stoppingToken.IsCancellationRequested)
        {
            try { await DispatchBatchAsync(stoppingToken); }
            catch(Exception ex){ logger.LogError(ex,"Outbox dispatch cycle failed."); }
            await Task.Delay(TimeSpan.FromSeconds(5),stoppingToken);
        }
    }
    private async Task DispatchBatchAsync(CancellationToken ct)
    {
        using var scope=scopes.CreateScope(); var db=scope.ServiceProvider.GetRequiredService<AtlasDbContext>();
        var publisher=scope.ServiceProvider.GetRequiredService<IEventPublisher>(); var now=timeProvider.GetUtcNow();
        var batch=await db.OutboxMessages.Where(x=>x.PublishedAt==null&&(x.NextAttemptAt==null||x.NextAttemptAt<=now)).OrderBy(x=>x.OccurredAt).Take(50).ToArrayAsync(ct);
        foreach(var message in batch)
        {
            try { await publisher.PublishAsync(message.EventType,message.PayloadJson,ct); message.PublishedAt=now; message.LastError=null; }
            catch(Exception ex)
            {
                message.AttemptCount++; message.LastError=ex.Message[..Math.Min(ex.Message.Length,2000)];
                if(message.AttemptCount>=5){ db.DeadLetterMessages.Add(new DeadLetterMessage{Id=Guid.NewGuid(),TenantId=message.TenantId,OutboxMessageId=message.Id,EventType=message.EventType,PayloadJson=message.PayloadJson,Error=message.LastError,FailedAt=now}); message.PublishedAt=now; }
                else message.NextAttemptAt=now.AddSeconds(Math.Pow(2,message.AttemptCount)*5);
            }
        }
        if(batch.Length>0) await db.SaveChangesAsync(ct);
    }
}
