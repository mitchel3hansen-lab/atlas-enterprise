namespace Atlas.Platform.Infrastructure.Persistence;

public sealed class DeadLetterMessage
{
    public Guid Id { get; init; }
    public Guid TenantId { get; init; }
    public Guid OutboxMessageId { get; init; }
    public string EventType { get; init; } = string.Empty;
    public string PayloadJson { get; init; } = "{}";
    public string Error { get; init; } = string.Empty;
    public DateTimeOffset FailedAt { get; init; }
}
