using System.Text.Json;
using Atlas.Platform.Domain;
using Atlas.Platform.Domain.Identity;
using Atlas.Platform.Domain.Workflow;
using Atlas.Platform.Domain.Safety;
using Atlas.Platform.Domain.Notifications;
using Atlas.Sdk.Core;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Platform.Infrastructure.Persistence;

public sealed class AtlasDbContext(DbContextOptions<AtlasDbContext> options, TimeProvider timeProvider) : DbContext(options)
{
    public DbSet<Organization> Organizations => Set<Organization>();
    public DbSet<Facility> Facilities => Set<Facility>();
    public DbSet<AuditEntry> AuditEntries => Set<AuditEntry>();
    public DbSet<User> Users => Set<User>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<WorkflowDefinition> WorkflowDefinitions => Set<WorkflowDefinition>();
    public DbSet<WorkflowInstance> WorkflowInstances => Set<WorkflowInstance>();
    public DbSet<WorkflowTask> WorkflowTasks => Set<WorkflowTask>();
    public DbSet<OutboxMessage> OutboxMessages => Set<OutboxMessage>();
    public DbSet<DeadLetterMessage> DeadLetterMessages => Set<DeadLetterMessage>();
    public DbSet<NotificationTemplate> NotificationTemplates => Set<NotificationTemplate>();
    public DbSet<NotificationPreference> NotificationPreferences => Set<NotificationPreference>();
    public DbSet<NotificationMessage> NotificationMessages => Set<NotificationMessage>();
    public DbSet<ScheduledJob> ScheduledJobs => Set<ScheduledJob>();


    public DbSet<SafetyRecord> SafetyRecords => Set<SafetyRecord>();
    public DbSet<CorrectiveAction> CorrectiveActions => Set<CorrectiveAction>();
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Organization>(entity =>
        {
            entity.ToTable("organizations");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Name).HasMaxLength(200).IsRequired();
            entity.Property(x => x.NormalizedName).HasColumnName("normalized_name").HasMaxLength(200).IsRequired();
            entity.HasIndex(x => new { x.TenantId, x.NormalizedName }).IsUnique();
            ConfigureAtlasEntity(entity);
        });

        modelBuilder.Entity<Facility>(entity =>
        {
            entity.ToTable("facilities");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Name).HasMaxLength(200).IsRequired();
            entity.Property(x => x.Code).HasMaxLength(32);
            entity.HasIndex(x => new { x.TenantId, x.OrganizationId });
            entity.HasIndex(x => new { x.OrganizationId, x.Code }).IsUnique().HasFilter("code IS NOT NULL");
            ConfigureAtlasEntity(entity);
        });


        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("users");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Email).HasColumnName("email").HasMaxLength(320).IsRequired();
            entity.Property(x => x.NormalizedEmail).HasColumnName("normalized_email").HasMaxLength(320).IsRequired();
            entity.Property(x => x.DisplayName).HasColumnName("display_name").HasMaxLength(200).IsRequired();
            entity.Property(x => x.IsEnabled).HasColumnName("is_enabled");
            entity.HasIndex(x => new { x.TenantId, x.NormalizedEmail }).IsUnique();
            ConfigureAtlasEntity(entity);
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.ToTable("roles");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Name).HasColumnName("name").HasMaxLength(100).IsRequired();
            entity.Property(x => x.NormalizedName).HasColumnName("normalized_name").HasMaxLength(100).IsRequired();
            entity.Property(x => x.Description).HasColumnName("description").HasMaxLength(500).IsRequired();
            entity.Property(x => x.IsSystemRole).HasColumnName("is_system_role");
            entity.HasIndex(x => new { x.TenantId, x.NormalizedName }).IsUnique();
            ConfigureAtlasEntity(entity);
        });

        modelBuilder.Entity<Permission>(entity =>
        {
            entity.ToTable("permissions");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Key).HasColumnName("permission_key").HasMaxLength(150).IsRequired();
            entity.Property(x => x.Description).HasColumnName("description").HasMaxLength(500).IsRequired();
            entity.HasIndex(x => x.Key).IsUnique();
        });

        modelBuilder.Entity<UserRole>(entity =>
        {
            entity.ToTable("user_roles");
            entity.HasKey(x => new { x.TenantId, x.UserId, x.RoleId });
            entity.Property(x => x.TenantId).HasColumnName("tenant_id");
            entity.Property(x => x.UserId).HasColumnName("user_id");
            entity.Property(x => x.RoleId).HasColumnName("role_id");
            entity.Property(x => x.AssignedAt).HasColumnName("assigned_at");
            entity.Property(x => x.AssignedBy).HasColumnName("assigned_by");
        });

        modelBuilder.Entity<RolePermission>(entity =>
        {
            entity.ToTable("role_permissions");
            entity.HasKey(x => new { x.RoleId, x.PermissionId });
            entity.Property(x => x.RoleId).HasColumnName("role_id");
            entity.Property(x => x.PermissionId).HasColumnName("permission_id");
        });


        modelBuilder.Entity<WorkflowDefinition>(entity =>
        {
            entity.ToTable("workflow_definitions"); entity.HasKey(x => x.Id);
            entity.Property(x => x.Key).HasColumnName("key").HasMaxLength(100).IsRequired();
            entity.Property(x => x.Name).HasColumnName("name").HasMaxLength(200).IsRequired();
            entity.Property(x => x.DefinitionVersion).HasColumnName("definition_version");
            entity.Property(x => x.InitialState).HasColumnName("initial_state").HasMaxLength(100).IsRequired();
            entity.Property(x => x.StatesJson).HasColumnName("states_json").HasColumnType("jsonb").IsRequired();
            entity.Property(x => x.TransitionsJson).HasColumnName("transitions_json").HasColumnType("jsonb").IsRequired();
            entity.Property(x => x.IsPublished).HasColumnName("is_published");
            entity.HasIndex(x => new { x.TenantId, x.Key, x.DefinitionVersion }).IsUnique(); ConfigureAtlasEntity(entity);
        });
        modelBuilder.Entity<WorkflowInstance>(entity =>
        {
            entity.ToTable("workflow_instances"); entity.HasKey(x => x.Id);
            entity.Property(x => x.DefinitionId).HasColumnName("definition_id");
            entity.Property(x => x.DefinitionKey).HasColumnName("definition_key").HasMaxLength(100).IsRequired();
            entity.Property(x => x.DefinitionVersion).HasColumnName("definition_version");
            entity.Property(x => x.CurrentState).HasColumnName("current_state").HasMaxLength(100).IsRequired();
            entity.Property(x => x.SubjectType).HasColumnName("subject_type").HasMaxLength(100).IsRequired();
            entity.Property(x => x.SubjectId).HasColumnName("subject_id"); entity.Property(x => x.DueAt).HasColumnName("due_at");
            entity.Property(x => x.CompletedAt).HasColumnName("completed_at"); ConfigureAtlasEntity(entity);
        });
        modelBuilder.Entity<WorkflowTask>(entity =>
        {
            entity.ToTable("workflow_tasks"); entity.HasKey(x => x.Id);
            entity.Property(x => x.WorkflowInstanceId).HasColumnName("workflow_instance_id");
            entity.Property(x => x.Title).HasColumnName("title").HasMaxLength(300).IsRequired();
            entity.Property(x => x.AssigneeUserId).HasColumnName("assignee_user_id");
            entity.Property(x => x.AssigneeRoleId).HasColumnName("assignee_role_id");
            entity.Property(x => x.DueAt).HasColumnName("due_at"); entity.Property(x => x.CompletedAt).HasColumnName("completed_at");
            ConfigureAtlasEntity(entity);
        });
        modelBuilder.Entity<OutboxMessage>(entity =>
        {
            entity.ToTable("outbox_messages"); entity.HasKey(x => x.Id);
            entity.Property(x => x.TenantId).HasColumnName("tenant_id"); entity.Property(x => x.EventType).HasColumnName("event_type").HasMaxLength(200).IsRequired();
            entity.Property(x => x.PayloadJson).HasColumnName("payload_json").HasColumnType("jsonb").IsRequired(); entity.Property(x => x.OccurredAt).HasColumnName("occurred_at");
            entity.Property(x => x.PublishedAt).HasColumnName("published_at"); entity.Property(x => x.AttemptCount).HasColumnName("attempt_count");
            entity.Property(x => x.NextAttemptAt).HasColumnName("next_attempt_at"); entity.Property(x => x.LastError).HasColumnName("last_error").HasMaxLength(2000);
        });
        modelBuilder.Entity<DeadLetterMessage>(entity =>
        {
            entity.ToTable("dead_letter_messages"); entity.HasKey(x => x.Id);
            entity.Property(x => x.TenantId).HasColumnName("tenant_id"); entity.Property(x => x.OutboxMessageId).HasColumnName("outbox_message_id");
            entity.Property(x => x.EventType).HasColumnName("event_type").HasMaxLength(200).IsRequired(); entity.Property(x => x.PayloadJson).HasColumnName("payload_json").HasColumnType("jsonb").IsRequired();
            entity.Property(x => x.Error).HasColumnName("error").HasMaxLength(2000).IsRequired(); entity.Property(x => x.FailedAt).HasColumnName("failed_at");
        });


        modelBuilder.Entity<NotificationTemplate>(entity =>
        {
            entity.ToTable("notification_templates"); entity.HasKey(x => x.Id);
            entity.Property(x => x.Key).HasColumnName("key").HasMaxLength(100).IsRequired();
            entity.Property(x => x.Name).HasColumnName("name").HasMaxLength(200).IsRequired();
            entity.Property(x => x.SubjectTemplate).HasColumnName("subject_template").HasMaxLength(500).IsRequired();
            entity.Property(x => x.BodyTemplate).HasColumnName("body_template").HasColumnType("text").IsRequired();
            entity.Property(x => x.DefaultChannel).HasColumnName("default_channel").HasMaxLength(32).IsRequired();
            entity.HasIndex(x => new { x.TenantId, x.Key }).IsUnique(); ConfigureAtlasEntity(entity);
        });
        modelBuilder.Entity<NotificationPreference>(entity =>
        {
            entity.ToTable("notification_preferences"); entity.HasKey(x => x.Id);
            entity.Property(x => x.UserId).HasColumnName("user_id"); entity.Property(x => x.EmailEnabled).HasColumnName("email_enabled");
            entity.Property(x => x.InAppEnabled).HasColumnName("in_app_enabled"); entity.Property(x => x.EscalationsEnabled).HasColumnName("escalations_enabled");
            entity.HasIndex(x => new { x.TenantId, x.UserId }).IsUnique(); ConfigureAtlasEntity(entity);
        });
        modelBuilder.Entity<NotificationMessage>(entity =>
        {
            entity.ToTable("notification_messages"); entity.HasKey(x => x.Id);
            entity.Property(x => x.TemplateId).HasColumnName("template_id"); entity.Property(x => x.RecipientUserId).HasColumnName("recipient_user_id");
            entity.Property(x => x.Channel).HasColumnName("channel").HasMaxLength(32).IsRequired(); entity.Property(x => x.Subject).HasColumnName("subject").HasMaxLength(500).IsRequired();
            entity.Property(x => x.Body).HasColumnName("body").HasColumnType("text").IsRequired(); entity.Property(x => x.ScheduledAt).HasColumnName("scheduled_at");
            entity.Property(x => x.SentAt).HasColumnName("sent_at"); entity.Property(x => x.ReadAt).HasColumnName("read_at");
            entity.Property(x => x.AttemptCount).HasColumnName("attempt_count"); entity.Property(x => x.NextAttemptAt).HasColumnName("next_attempt_at");
            entity.Property(x => x.LastError).HasColumnName("last_error").HasMaxLength(2000);
            entity.HasIndex(x => new { x.Status, x.NextAttemptAt }); entity.HasIndex(x => new { x.TenantId, x.RecipientUserId, x.CreatedAt }); ConfigureAtlasEntity(entity);
        });
        modelBuilder.Entity<ScheduledJob>(entity =>
        {
            entity.ToTable("scheduled_jobs"); entity.HasKey(x => x.Id);
            entity.Property(x => x.JobType).HasColumnName("job_type").HasMaxLength(100).IsRequired(); entity.Property(x => x.PayloadJson).HasColumnName("payload_json").HasColumnType("jsonb").IsRequired();
            entity.Property(x => x.RunAt).HasColumnName("run_at"); entity.Property(x => x.CompletedAt).HasColumnName("completed_at");
            entity.Property(x => x.AttemptCount).HasColumnName("attempt_count"); entity.Property(x => x.LastError).HasColumnName("last_error").HasMaxLength(2000);
            entity.HasIndex(x => new { x.Status, x.RunAt }); ConfigureAtlasEntity(entity);
        });


        modelBuilder.Entity<SafetyRecord>(entity =>
        {
            entity.ToTable("safety_records"); entity.HasKey(x => x.Id);
            entity.Property(x=>x.FacilityId).HasColumnName("facility_id");
            entity.Property(x=>x.RecordType).HasColumnName("record_type").HasConversion<string>().HasMaxLength(32);
            entity.Property(x=>x.ReferenceNumber).HasColumnName("reference_number").HasMaxLength(40).IsRequired();
            entity.Property(x=>x.Title).HasColumnName("title").HasMaxLength(250).IsRequired();
            entity.Property(x=>x.Description).HasColumnName("description").HasColumnType("text");
            entity.Property(x=>x.Severity).HasColumnName("severity").HasConversion<string>().HasMaxLength(20);
            entity.Property(x=>x.OccurredAt).HasColumnName("occurred_at"); entity.Property(x=>x.Location).HasColumnName("location").HasMaxLength(250);
            entity.Property(x=>x.OwnerUserId).HasColumnName("owner_user_id"); entity.Property(x=>x.ClosedAt).HasColumnName("closed_at");
            entity.HasIndex(x=>new{x.TenantId,x.ReferenceNumber}).IsUnique(); entity.HasIndex(x=>new{x.TenantId,x.FacilityId,x.Status}); ConfigureAtlasEntity(entity);
        });
        modelBuilder.Entity<CorrectiveAction>(entity =>
        {
            entity.ToTable("corrective_actions"); entity.HasKey(x=>x.Id);
            entity.Property(x=>x.SafetyRecordId).HasColumnName("safety_record_id"); entity.Property(x=>x.Action).HasColumnName("action").HasColumnType("text");
            entity.Property(x=>x.OwnerUserId).HasColumnName("owner_user_id"); entity.Property(x=>x.DueAt).HasColumnName("due_at");
            entity.Property(x=>x.CompletedAt).HasColumnName("completed_at"); entity.Property(x=>x.EffectivenessNotes).HasColumnName("effectiveness_notes").HasColumnType("text");
            entity.HasIndex(x=>new{x.TenantId,x.Status,x.DueAt}); ConfigureAtlasEntity(entity);
        });
        modelBuilder.Entity<AuditEntry>(entity =>
        {
            entity.ToTable("audit_entries");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.EntityType).HasMaxLength(200).IsRequired();
            entity.Property(x => x.Action).HasMaxLength(32).IsRequired();
            entity.Property(x => x.ChangesJson).HasColumnType("jsonb").IsRequired();
            entity.HasIndex(x => new { x.TenantId, x.OccurredAt });
            entity.HasIndex(x => new { x.EntityType, x.EntityId });
        });
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        var now = timeProvider.GetUtcNow();
        var audits = ChangeTracker.Entries<AtlasEntity>()
            .Where(x => x.State is EntityState.Added or EntityState.Modified or EntityState.Deleted)
            .Select(entry => new AuditEntry
            {
                Id = Guid.NewGuid(), TenantId = entry.Entity.TenantId,
                EntityType = entry.Metadata.ClrType.Name, EntityId = entry.Entity.Id,
                Action = entry.State.ToString().ToLowerInvariant(), OccurredAt = now,
                ActorId = entry.Entity.UpdatedBy ?? entry.Entity.CreatedBy,
                ChangesJson = JsonSerializer.Serialize(entry.Properties
                    .Where(p => entry.State == EntityState.Added || p.IsModified)
                    .ToDictionary(p => p.Metadata.Name, p => p.CurrentValue))
            }).ToArray();

        if (audits.Length > 0) AuditEntries.AddRange(audits);
        return await base.SaveChangesAsync(cancellationToken);
    }

    private static void ConfigureAtlasEntity<TEntity>(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<TEntity> entity)
        where TEntity : AtlasEntity
    {
        entity.Property(x => x.Id).HasColumnName("id");
        entity.Property(x => x.TenantId).HasColumnName("tenant_id");
        entity.Property(x => x.Status).HasColumnName("status").HasMaxLength(32).IsRequired();
        entity.Property(x => x.Version).HasColumnName("version").IsConcurrencyToken();
        entity.Property(x => x.CreatedAt).HasColumnName("created_at");
        entity.Property(x => x.CreatedBy).HasColumnName("created_by");
        entity.Property(x => x.UpdatedAt).HasColumnName("updated_at");
        entity.Property(x => x.UpdatedBy).HasColumnName("updated_by");
    }
}
