using Atlas.Platform.Application.Notifications;
using Atlas.Platform.Domain.Notifications;
using Atlas.Platform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Platform.Infrastructure.Notifications;

public sealed class PostgresNotificationRepository(AtlasDbContext db) : INotificationRepository
{
    public async Task<IReadOnlyList<NotificationTemplate>> ListTemplatesAsync(Guid tenantId,CancellationToken ct)=>await db.NotificationTemplates.AsNoTracking().Where(x=>x.TenantId==tenantId).OrderBy(x=>x.Name).ToListAsync(ct);
    public Task AddTemplateAsync(NotificationTemplate item,CancellationToken ct)=>db.NotificationTemplates.AddAsync(item,ct).AsTask();
    public Task<NotificationTemplate?> GetTemplateAsync(Guid tenantId,Guid id,CancellationToken ct)=>db.NotificationTemplates.SingleOrDefaultAsync(x=>x.TenantId==tenantId&&x.Id==id,ct);
    public Task<NotificationPreference?> GetPreferenceAsync(Guid tenantId,Guid userId,CancellationToken ct)=>db.NotificationPreferences.SingleOrDefaultAsync(x=>x.TenantId==tenantId&&x.UserId==userId,ct);
    public Task AddPreferenceAsync(NotificationPreference item,CancellationToken ct)=>db.NotificationPreferences.AddAsync(item,ct).AsTask();
    public async Task<IReadOnlyList<NotificationMessage>> ListMessagesAsync(Guid tenantId,Guid userId,CancellationToken ct)=>await db.NotificationMessages.AsNoTracking().Where(x=>x.TenantId==tenantId&&x.RecipientUserId==userId).OrderByDescending(x=>x.CreatedAt).Take(200).ToListAsync(ct);
    public Task AddMessageAsync(NotificationMessage item,CancellationToken ct)=>db.NotificationMessages.AddAsync(item,ct).AsTask();
    public Task<NotificationMessage?> GetMessageAsync(Guid tenantId,Guid id,CancellationToken ct)=>db.NotificationMessages.SingleOrDefaultAsync(x=>x.TenantId==tenantId&&x.Id==id,ct);
    public Task SaveAsync(CancellationToken ct)=>db.SaveChangesAsync(ct);
}
