using Atlas.Platform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Platform.Infrastructure.Notifications;

public interface INotificationChannel { string Name { get; } Task SendAsync(Guid tenantId,Guid userId,string subject,string body,CancellationToken ct); }
public sealed class LoggingInAppChannel(ILogger<LoggingInAppChannel> logger):INotificationChannel { public string Name=>"in_app"; public Task SendAsync(Guid tenantId,Guid userId,string subject,string body,CancellationToken ct){logger.LogInformation("In-app notification for {UserId}: {Subject}",userId,subject);return Task.CompletedTask;} }
public sealed class LoggingEmailChannel(ILogger<LoggingEmailChannel> logger):INotificationChannel { public string Name=>"email"; public Task SendAsync(Guid tenantId,Guid userId,string subject,string body,CancellationToken ct){logger.LogInformation("Email notification for {UserId}: {Subject}",userId,subject);return Task.CompletedTask;} }

public sealed class NotificationDispatcher(IServiceScopeFactory scopes,TimeProvider timeProvider,ILogger<NotificationDispatcher> logger):BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while(!stoppingToken.IsCancellationRequested)
        {
            try { await DispatchAsync(stoppingToken); } catch(Exception ex){logger.LogError(ex,"Notification dispatch cycle failed.");}
            await Task.Delay(TimeSpan.FromSeconds(15),stoppingToken);
        }
    }
    private async Task DispatchAsync(CancellationToken ct)
    {
        await using var scope=scopes.CreateAsyncScope(); var db=scope.ServiceProvider.GetRequiredService<AtlasDbContext>(); var channels=scope.ServiceProvider.GetServices<INotificationChannel>().ToDictionary(x=>x.Name);
        var now=timeProvider.GetUtcNow(); var messages=await db.NotificationMessages.Where(x=>(x.Status=="pending"||x.Status=="retry")&&x.NextAttemptAt<=now).OrderBy(x=>x.NextAttemptAt).Take(50).ToListAsync(ct);
        foreach(var message in messages)
        {
            try { if(!channels.TryGetValue(message.Channel,out var channel)) throw new InvalidOperationException($"No notification channel '{message.Channel}' is registered."); await channel.SendAsync(message.TenantId,message.RecipientUserId,message.Subject,message.Body,ct); message.MarkSent(now); }
            catch(Exception ex) { if(message.AttemptCount>=4) message.MarkDead(ex.Message,now); else message.MarkFailed(ex.Message,now.AddMinutes(Math.Pow(2,message.AttemptCount+1)),now); }
        }
        if(messages.Count>0) await db.SaveChangesAsync(ct);
    }
}
