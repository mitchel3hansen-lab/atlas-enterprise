using Atlas.Platform.Application.Safety;
using Atlas.Platform.Domain.Safety;
using Atlas.Platform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
namespace Atlas.Platform.Infrastructure.Safety;
public sealed class PostgresSafetyRepository(AtlasDbContext db) : ISafetyRepository
{
    public async Task<IReadOnlyList<SafetyRecord>> ListAsync(Guid tenantId,Guid? facilityId,string? status,CancellationToken ct)
    { var q=db.SafetyRecords.AsNoTracking().Where(x=>x.TenantId==tenantId);
      if(facilityId.HasValue) q=q.Where(x=>x.FacilityId==facilityId); if(!string.IsNullOrWhiteSpace(status)) q=q.Where(x=>x.Status==status);
      return await q.OrderByDescending(x=>x.OccurredAt).ToListAsync(ct); }
    public Task<SafetyRecord?> GetAsync(Guid tenantId,Guid id,CancellationToken ct)=>db.SafetyRecords.FirstOrDefaultAsync(x=>x.TenantId==tenantId&&x.Id==id,ct);
    public async Task AddAsync(SafetyRecord item,CancellationToken ct){db.SafetyRecords.Add(item);await db.SaveChangesAsync(ct);}
    public async Task UpdateAsync(SafetyRecord item,CancellationToken ct){db.SafetyRecords.Update(item);await db.SaveChangesAsync(ct);}
    public async Task<IReadOnlyList<CorrectiveAction>> ListActionsAsync(Guid tenantId,Guid? recordId,CancellationToken ct)
    {var q=db.CorrectiveActions.AsNoTracking().Where(x=>x.TenantId==tenantId);if(recordId.HasValue)q=q.Where(x=>x.SafetyRecordId==recordId);return await q.OrderBy(x=>x.DueAt).ToListAsync(ct);}
    public Task<CorrectiveAction?> GetActionAsync(Guid tenantId,Guid id,CancellationToken ct)=>db.CorrectiveActions.FirstOrDefaultAsync(x=>x.TenantId==tenantId&&x.Id==id,ct);
    public async Task AddActionAsync(CorrectiveAction item,CancellationToken ct){db.CorrectiveActions.Add(item);await db.SaveChangesAsync(ct);}
    public async Task UpdateActionAsync(CorrectiveAction item,CancellationToken ct){db.CorrectiveActions.Update(item);await db.SaveChangesAsync(ct);}
    public async Task<SafetyDashboard> GetDashboardAsync(Guid tenantId,Guid? facilityId,CancellationToken ct)
    {var records=db.SafetyRecords.AsNoTracking().Where(x=>x.TenantId==tenantId);if(facilityId.HasValue)records=records.Where(x=>x.FacilityId==facilityId);
     var actions=db.CorrectiveActions.AsNoTracking().Where(x=>x.TenantId==tenantId); var now=DateTimeOffset.UtcNow;
     var openInc=await records.CountAsync(x=>x.RecordType==SafetyRecordType.Incident&&x.Status=="open",ct);
     var openNm=await records.CountAsync(x=>x.RecordType==SafetyRecordType.NearMiss&&x.Status=="open",ct);
     var openHz=await records.CountAsync(x=>x.RecordType==SafetyRecordType.Hazard&&x.Status=="open",ct);
     var critical=await records.CountAsync(x=>x.Severity==RiskSeverity.Critical&&x.Status=="open",ct);
     var overdue=await actions.CountAsync(x=>x.Status=="open"&&x.DueAt<now,ct); var complete=await actions.CountAsync(x=>x.Status=="completed",ct); var total=await actions.CountAsync(ct);
     var raw=await records.Where(x=>x.OccurredAt>=now.AddMonths(-6)).ToListAsync(ct);
     var trend=Enumerable.Range(0,6).Select(i=>now.AddMonths(i-5)).Select(m=>new MonthlyTrend(m.ToString("MMM"),raw.Count(x=>x.RecordType==SafetyRecordType.Incident&&x.OccurredAt.Year==m.Year&&x.OccurredAt.Month==m.Month),raw.Count(x=>x.RecordType==SafetyRecordType.NearMiss&&x.OccurredAt.Year==m.Year&&x.OccurredAt.Month==m.Month),raw.Count(x=>x.RecordType==SafetyRecordType.Hazard&&x.OccurredAt.Year==m.Year&&x.OccurredAt.Month==m.Month))).ToList();
     return new(openInc,openNm,openHz,critical,overdue,complete,total==0?0:Math.Round((decimal)complete/total*100,1),trend);}
}
