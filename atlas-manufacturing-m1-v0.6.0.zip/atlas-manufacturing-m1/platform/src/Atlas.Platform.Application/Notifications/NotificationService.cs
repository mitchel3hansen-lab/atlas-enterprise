using System.Text.Json;
using Atlas.Platform.Domain.Notifications;

namespace Atlas.Platform.Application.Notifications;

public sealed class NotificationService(INotificationRepository repository, TimeProvider timeProvider)
{
    public Task<IReadOnlyList<NotificationTemplate>> ListTemplatesAsync(Guid tenantId, CancellationToken ct) => repository.ListTemplatesAsync(tenantId, ct);
    public async Task<NotificationTemplate> CreateTemplateAsync(Guid tenantId,string key,string name,string subject,string body,string channel,Guid actorId,CancellationToken ct)
    { var item=NotificationTemplate.Create(tenantId,key,name,subject,body,channel,actorId,timeProvider.GetUtcNow()); await repository.AddTemplateAsync(item,ct); await repository.SaveAsync(ct); return item; }
    public async Task<NotificationMessage> QueueAsync(Guid tenantId,Guid? templateId,Guid recipientUserId,string channel,string subject,string body,DateTimeOffset? scheduledAt,Guid actorId,CancellationToken ct)
    {
        if(templateId is not null)
        {
            var template=await repository.GetTemplateAsync(tenantId,templateId.Value,ct) ?? throw new NotFoundException("Notification template was not found.");
            channel=string.IsNullOrWhiteSpace(channel)?template.DefaultChannel:channel;
            subject=string.IsNullOrWhiteSpace(subject)?template.SubjectTemplate:subject;
            body=string.IsNullOrWhiteSpace(body)?template.BodyTemplate:body;
        }
        if(string.IsNullOrWhiteSpace(body)) throw new ValidationException("Notification body is required.");
        var item=NotificationMessage.Create(tenantId,templateId,recipientUserId,channel,subject,body,scheduledAt,actorId,timeProvider.GetUtcNow());
        await repository.AddMessageAsync(item,ct); await repository.SaveAsync(ct); return item;
    }
    public Task<IReadOnlyList<NotificationMessage>> ListAsync(Guid tenantId,Guid userId,CancellationToken ct)=>repository.ListMessagesAsync(tenantId,userId,ct);
    public async Task<NotificationMessage> MarkReadAsync(Guid tenantId,Guid id,Guid userId,CancellationToken ct)
    { var item=await repository.GetMessageAsync(tenantId,id,ct) ?? throw new NotFoundException("Notification was not found."); if(item.RecipientUserId!=userId) throw new NotFoundException("Notification was not found."); item.MarkRead(timeProvider.GetUtcNow()); await repository.SaveAsync(ct); return item; }
    public async Task<NotificationPreference> SetPreferenceAsync(Guid tenantId,Guid userId,bool email,bool inApp,bool escalations,Guid actorId,CancellationToken ct)
    { var item=await repository.GetPreferenceAsync(tenantId,userId,ct); if(item is null){item=NotificationPreference.Create(tenantId,userId,email,inApp,escalations,actorId,timeProvider.GetUtcNow());await repository.AddPreferenceAsync(item,ct);}else item.Update(email,inApp,escalations,actorId,timeProvider.GetUtcNow()); await repository.SaveAsync(ct);return item; }
}
