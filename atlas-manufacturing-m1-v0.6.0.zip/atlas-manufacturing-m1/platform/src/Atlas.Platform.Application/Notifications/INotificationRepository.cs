using Atlas.Platform.Domain.Notifications;

namespace Atlas.Platform.Application.Notifications;

public interface INotificationRepository
{
    Task<IReadOnlyList<NotificationTemplate>> ListTemplatesAsync(Guid tenantId, CancellationToken ct);
    Task AddTemplateAsync(NotificationTemplate template, CancellationToken ct);
    Task<NotificationTemplate?> GetTemplateAsync(Guid tenantId, Guid id, CancellationToken ct);
    Task<NotificationPreference?> GetPreferenceAsync(Guid tenantId, Guid userId, CancellationToken ct);
    Task AddPreferenceAsync(NotificationPreference preference, CancellationToken ct);
    Task<IReadOnlyList<NotificationMessage>> ListMessagesAsync(Guid tenantId, Guid userId, CancellationToken ct);
    Task AddMessageAsync(NotificationMessage message, CancellationToken ct);
    Task<NotificationMessage?> GetMessageAsync(Guid tenantId, Guid id, CancellationToken ct);
    Task SaveAsync(CancellationToken ct);
}
