namespace Atlas.Platform.Application.Identity;

public static class AtlasPermissions
{
    public const string OrganizationsRead = "organizations.read";
    public const string OrganizationsWrite = "organizations.write";
    public const string FacilitiesRead = "facilities.read";
    public const string FacilitiesWrite = "facilities.write";
    public const string UsersRead = "users.read";
    public const string UsersWrite = "users.write";
    public const string TenantAdmin = "tenant.admin";
    public const string WorkflowsRead = "workflows.read";
    public const string WorkflowsWrite = "workflows.write";
    public const string WorkflowsAdmin = "workflows.admin";
    public const string NotificationsRead = "notifications.read";
    public const string NotificationsWrite = "notifications.write";
    public const string NotificationsAdmin = "notifications.admin";

    public static readonly string[] All =
    [OrganizationsRead, OrganizationsWrite, FacilitiesRead, FacilitiesWrite, UsersRead, UsersWrite, TenantAdmin, WorkflowsRead, WorkflowsWrite, WorkflowsAdmin, NotificationsRead, NotificationsWrite, NotificationsAdmin];
}
