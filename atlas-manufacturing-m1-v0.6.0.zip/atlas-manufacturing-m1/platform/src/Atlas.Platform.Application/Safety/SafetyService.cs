using Atlas.Platform.Domain.Safety;
namespace Atlas.Platform.Application.Safety;
public sealed class SafetyService(ISafetyRepository repository, TimeProvider timeProvider)
{
    public Task<IReadOnlyList<SafetyRecord>> ListAsync(Guid tenantId, Guid? facilityId, string? status, CancellationToken ct)
        => repository.ListAsync(tenantId, facilityId, status, ct);
    public Task<SafetyRecord?> GetAsync(Guid tenantId, Guid id, CancellationToken ct) => repository.GetAsync(tenantId,id,ct);
    public async Task<SafetyRecord> CreateAsync(Guid tenantId, Guid facilityId, SafetyRecordType type, string title,
        string description, RiskSeverity severity, DateTimeOffset occurredAt, string location, Guid actorId, CancellationToken ct)
    {
        var prefix = type switch { SafetyRecordType.Incident=>"INC", SafetyRecordType.NearMiss=>"NM", _=>"HZD" };
        var reference = $"{prefix}-{timeProvider.GetUtcNow():yyyy}-{Random.Shared.Next(10000,99999)}";
        var item=SafetyRecord.Create(tenantId,facilityId,type,reference,title,description,severity,occurredAt,location,actorId);
        await repository.AddAsync(item,ct); return item;
    }
    public async Task<SafetyRecord> CloseAsync(Guid tenantId, Guid id, Guid actorId, CancellationToken ct)
    { var item=await repository.GetAsync(tenantId,id,ct) ?? throw new NotFoundException("Safety record not found.");
      item.Close(actorId); await repository.UpdateAsync(item,ct); return item; }
    public Task<IReadOnlyList<CorrectiveAction>> ListActionsAsync(Guid tenantId, Guid? recordId, CancellationToken ct)
        => repository.ListActionsAsync(tenantId,recordId,ct);
    public async Task<CorrectiveAction> AddActionAsync(Guid tenantId,Guid recordId,string action,Guid? owner,DateTimeOffset dueAt,Guid actorId,CancellationToken ct)
    { _=await repository.GetAsync(tenantId,recordId,ct) ?? throw new NotFoundException("Safety record not found.");
      var item=CorrectiveAction.Create(tenantId,recordId,action,owner,dueAt,actorId); await repository.AddActionAsync(item,ct); return item; }
    public async Task<CorrectiveAction> CompleteActionAsync(Guid tenantId,Guid id,string notes,Guid actorId,CancellationToken ct)
    { var item=await repository.GetActionAsync(tenantId,id,ct) ?? throw new NotFoundException("Corrective action not found.");
      item.Complete(notes,actorId); await repository.UpdateActionAsync(item,ct); return item; }
    public Task<SafetyDashboard> DashboardAsync(Guid tenantId, Guid? facilityId, CancellationToken ct)
        => repository.GetDashboardAsync(tenantId,facilityId,ct);
}
