using Atlas.Platform.Domain.Safety;
namespace Atlas.Platform.Application.Safety;
public interface ISafetyRepository
{
    Task<IReadOnlyList<SafetyRecord>> ListAsync(Guid tenantId, Guid? facilityId, string? status, CancellationToken ct);
    Task<SafetyRecord?> GetAsync(Guid tenantId, Guid id, CancellationToken ct);
    Task AddAsync(SafetyRecord record, CancellationToken ct);
    Task UpdateAsync(SafetyRecord record, CancellationToken ct);
    Task<IReadOnlyList<CorrectiveAction>> ListActionsAsync(Guid tenantId, Guid? recordId, CancellationToken ct);
    Task<CorrectiveAction?> GetActionAsync(Guid tenantId, Guid id, CancellationToken ct);
    Task AddActionAsync(CorrectiveAction action, CancellationToken ct);
    Task UpdateActionAsync(CorrectiveAction action, CancellationToken ct);
    Task<SafetyDashboard> GetDashboardAsync(Guid tenantId, Guid? facilityId, CancellationToken ct);
}
public sealed record SafetyDashboard(int OpenIncidents, int OpenNearMisses, int OpenHazards, int CriticalRisks,
    int OverdueActions, int CompletedActions, decimal ActionCompletionRate, IReadOnlyList<MonthlyTrend> Trend);
public sealed record MonthlyTrend(string Month, int Incidents, int NearMisses, int Hazards);
