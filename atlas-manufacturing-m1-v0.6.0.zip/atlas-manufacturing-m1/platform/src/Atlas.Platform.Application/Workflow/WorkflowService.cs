using System.Text.Json;
using Atlas.Platform.Domain.Workflow;

namespace Atlas.Platform.Application.Workflow;

public sealed class WorkflowService(IWorkflowRepository repository, TimeProvider timeProvider)
{
    public Task<IReadOnlyCollection<WorkflowDefinition>> ListDefinitionsAsync(Guid tenantId, CancellationToken ct) => repository.ListDefinitionsAsync(tenantId, ct);
    public Task<IReadOnlyCollection<WorkflowInstance>> ListInstancesAsync(Guid tenantId, CancellationToken ct) => repository.ListInstancesAsync(tenantId, ct);
    public Task<IReadOnlyCollection<WorkflowTask>> ListTasksAsync(Guid tenantId, Guid? instanceId, CancellationToken ct) => repository.ListTasksAsync(tenantId, instanceId, ct);

    public async Task<WorkflowDefinition> CreateDefinitionAsync(Guid tenantId, string key, string name, string initialState,
        IReadOnlyCollection<string> states, IReadOnlyCollection<WorkflowTransitionRule> transitions, Guid actorId, CancellationToken ct)
    {
        var normalizedKey=key.Trim().ToLowerInvariant();
        if (await repository.DefinitionKeyExistsAsync(tenantId, normalizedKey, ct)) throw new ConflictException("Workflow key already exists.");
        if (!states.Contains(initialState, StringComparer.OrdinalIgnoreCase)) throw new ValidationException("Initial state must exist in states.");
        ValidateTransitions(states, transitions);
        var definition=WorkflowDefinition.Create(tenantId, normalizedKey, name, initialState,
            JsonSerializer.Serialize(states), JsonSerializer.Serialize(transitions), actorId, timeProvider.GetUtcNow());
        await repository.AddDefinitionAsync(definition, ct); return definition;
    }

    public async Task<WorkflowDefinition> PublishDefinitionAsync(Guid tenantId, Guid id, Guid actorId, CancellationToken ct)
    {
        var definition=await repository.GetDefinitionAsync(tenantId,id,ct) ?? throw new NotFoundException("Workflow definition not found.");
        definition.Publish(actorId,timeProvider.GetUtcNow());
        await repository.UpdateDefinitionAsync(definition,"workflow.definition.published",JsonSerializer.Serialize(new { definition.Id, definition.Key }),ct);
        return definition;
    }

    public async Task<WorkflowInstance> StartAsync(Guid tenantId, Guid definitionId, string subjectType, Guid subjectId,
        DateTimeOffset? dueAt, Guid actorId, CancellationToken ct)
    {
        var definition=await repository.GetDefinitionAsync(tenantId,definitionId,ct) ?? throw new NotFoundException("Workflow definition not found.");
        var instance=WorkflowInstance.Start(tenantId,definition,subjectType,subjectId,dueAt,actorId,timeProvider.GetUtcNow());
        await repository.AddInstanceAsync(instance,"workflow.instance.started",JsonSerializer.Serialize(new { instance.Id, instance.DefinitionKey, instance.SubjectType, instance.SubjectId }),ct);
        return instance;
    }

    public async Task<WorkflowInstance> TransitionAsync(Guid tenantId, Guid instanceId, string transitionName, Guid actorId, CancellationToken ct)
    {
        var instance=await repository.GetInstanceAsync(tenantId,instanceId,ct) ?? throw new NotFoundException("Workflow instance not found.");
        var definition=await repository.GetDefinitionAsync(tenantId,instance.DefinitionId,ct) ?? throw new NotFoundException("Workflow definition not found.");
        var rules=JsonSerializer.Deserialize<WorkflowTransitionRule[]>(definition.TransitionsJson) ?? [];
        var rule=rules.SingleOrDefault(x => x.Name.Equals(transitionName,StringComparison.OrdinalIgnoreCase) && x.From.Equals(instance.CurrentState,StringComparison.OrdinalIgnoreCase))
            ?? throw new ValidationException($"Transition '{transitionName}' is not valid from state '{instance.CurrentState}'.");
        var from=instance.CurrentState; instance.TransitionTo(rule.To,rule.IsTerminal,actorId,timeProvider.GetUtcNow());
        await repository.UpdateInstanceAsync(instance,"workflow.instance.transitioned",JsonSerializer.Serialize(new { instance.Id, From=from, To=rule.To, Transition=rule.Name }),ct);
        return instance;
    }

    public async Task<WorkflowTask> CreateTaskAsync(Guid tenantId, Guid instanceId, string title, Guid? assigneeUserId,
        Guid? assigneeRoleId, DateTimeOffset? dueAt, Guid actorId, CancellationToken ct)
    {
        _=await repository.GetInstanceAsync(tenantId,instanceId,ct) ?? throw new NotFoundException("Workflow instance not found.");
        var task=WorkflowTask.Create(tenantId,instanceId,title,assigneeUserId,assigneeRoleId,dueAt,actorId,timeProvider.GetUtcNow());
        await repository.AddTaskAsync(task,"workflow.task.created",JsonSerializer.Serialize(new { task.Id, task.WorkflowInstanceId, task.AssigneeUserId, task.AssigneeRoleId }),ct);
        return task;
    }

    public async Task<WorkflowTask> CompleteTaskAsync(Guid tenantId, Guid taskId, Guid actorId, CancellationToken ct)
    {
        var task=await repository.GetTaskAsync(tenantId,taskId,ct) ?? throw new NotFoundException("Workflow task not found.");
        task.Complete(actorId,timeProvider.GetUtcNow());
        await repository.UpdateTaskAsync(task,"workflow.task.completed",JsonSerializer.Serialize(new { task.Id, task.WorkflowInstanceId }),ct);
        return task;
    }

    private static void ValidateTransitions(IReadOnlyCollection<string> states, IReadOnlyCollection<WorkflowTransitionRule> transitions)
    {
        var set=states.ToHashSet(StringComparer.OrdinalIgnoreCase);
        if(states.Count==0) throw new ValidationException("At least one state is required.");
        foreach(var t in transitions)
            if(string.IsNullOrWhiteSpace(t.Name)||!set.Contains(t.From)||!set.Contains(t.To))
                throw new ValidationException("Every transition requires a name and valid from/to states.");
    }
}
