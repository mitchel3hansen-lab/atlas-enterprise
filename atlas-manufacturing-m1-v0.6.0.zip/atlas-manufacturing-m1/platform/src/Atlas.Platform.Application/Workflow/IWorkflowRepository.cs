using Atlas.Platform.Domain.Workflow;

namespace Atlas.Platform.Application.Workflow;

public interface IWorkflowRepository
{
    Task<bool> DefinitionKeyExistsAsync(Guid tenantId, string key, CancellationToken ct);
    Task AddDefinitionAsync(WorkflowDefinition definition, CancellationToken ct);
    Task<WorkflowDefinition?> GetDefinitionAsync(Guid tenantId, Guid id, CancellationToken ct);
    Task<IReadOnlyCollection<WorkflowDefinition>> ListDefinitionsAsync(Guid tenantId, CancellationToken ct);
    Task UpdateDefinitionAsync(WorkflowDefinition definition, string eventType, string payloadJson, CancellationToken ct);
    Task AddInstanceAsync(WorkflowInstance instance, string eventType, string payloadJson, CancellationToken ct);
    Task<WorkflowInstance?> GetInstanceAsync(Guid tenantId, Guid id, CancellationToken ct);
    Task<IReadOnlyCollection<WorkflowInstance>> ListInstancesAsync(Guid tenantId, CancellationToken ct);
    Task UpdateInstanceAsync(WorkflowInstance instance, string eventType, string payloadJson, CancellationToken ct);
    Task AddTaskAsync(WorkflowTask task, string eventType, string payloadJson, CancellationToken ct);
    Task<WorkflowTask?> GetTaskAsync(Guid tenantId, Guid taskId, CancellationToken ct);
    Task<IReadOnlyCollection<WorkflowTask>> ListTasksAsync(Guid tenantId, Guid? instanceId, CancellationToken ct);
    Task UpdateTaskAsync(WorkflowTask task, string eventType, string payloadJson, CancellationToken ct);
}
