using Atlas.Platform.Domain.Workflow;
using Xunit;

namespace Atlas.Platform.UnitTests;

public sealed class WorkflowTests
{
    private readonly Guid tenant=Guid.NewGuid(); private readonly Guid actor=Guid.NewGuid();
    [Fact]
    public void Published_definition_can_start_and_complete_instance()
    {
        var now=DateTimeOffset.UtcNow;
        var d=WorkflowDefinition.Create(tenant,"incident","Incident","draft","[\"draft\",\"closed\"]","[]",actor,now);
        d.Publish(actor,now);
        var i=WorkflowInstance.Start(tenant,d,"incident",Guid.NewGuid(),null,actor,now);
        i.TransitionTo("closed",true,actor,now.AddMinutes(1));
        Assert.Equal("completed",i.Status); Assert.NotNull(i.CompletedAt);
    }
    [Fact]
    public void Draft_definition_cannot_start_instance()
    {
        var d=WorkflowDefinition.Create(tenant,"incident","Incident","draft","[]","[]",actor,DateTimeOffset.UtcNow);
        Assert.Throws<InvalidOperationException>(()=>WorkflowInstance.Start(tenant,d,"incident",Guid.NewGuid(),null,actor,DateTimeOffset.UtcNow));
    }
    [Fact]
    public void Task_requires_an_assignee() => Assert.Throws<ArgumentException>(()=>WorkflowTask.Create(tenant,Guid.NewGuid(),"Review",null,null,null,actor,DateTimeOffset.UtcNow));
}
