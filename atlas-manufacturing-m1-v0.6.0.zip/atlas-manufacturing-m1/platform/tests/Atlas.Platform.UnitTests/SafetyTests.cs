using Atlas.Platform.Domain.Safety;
namespace Atlas.Platform.UnitTests;
public sealed class SafetyTests
{
 [Fact] public void Create_normalizes_reference_and_sets_open_status(){var item=SafetyRecord.Create(Guid.NewGuid(),Guid.NewGuid(),SafetyRecordType.Incident,"inc-2026-1","  Test event ","details",RiskSeverity.High,DateTimeOffset.UtcNow,"Line 1",Guid.NewGuid());Assert.Equal("INC-2026-1",item.ReferenceNumber);Assert.Equal("open",item.Status);Assert.Equal("Test event",item.Title);}
 [Fact] public void Close_sets_closed_timestamp(){var actor=Guid.NewGuid();var item=SafetyRecord.Create(Guid.NewGuid(),Guid.NewGuid(),SafetyRecordType.Hazard,"HZD-1","Hazard","details",RiskSeverity.Medium,DateTimeOffset.UtcNow,"Warehouse",actor);item.Close(actor);Assert.Equal("closed",item.Status);Assert.NotNull(item.ClosedAt);}
}
