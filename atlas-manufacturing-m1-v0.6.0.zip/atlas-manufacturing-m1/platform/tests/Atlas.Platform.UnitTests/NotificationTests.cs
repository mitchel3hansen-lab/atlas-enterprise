using Atlas.Platform.Domain.Notifications;

namespace Atlas.Platform.UnitTests;

public sealed class NotificationTests
{
    [Fact]
    public void Template_rejects_unknown_channel()
    {
        Assert.Throws<ArgumentException>(() => NotificationTemplate.Create(Guid.NewGuid(),"task.due","Task Due","Due","Act now","sms",Guid.NewGuid(),DateTimeOffset.UtcNow));
    }

    [Fact]
    public void Message_tracks_delivery_and_read_state()
    {
        var now=DateTimeOffset.UtcNow;
        var message=NotificationMessage.Create(Guid.NewGuid(),null,Guid.NewGuid(),"in_app","Test","Body",null,Guid.NewGuid(),now);
        message.MarkSent(now.AddMinutes(1)); message.MarkRead(now.AddMinutes(2));
        Assert.Equal("sent",message.Status); Assert.NotNull(message.SentAt); Assert.NotNull(message.ReadAt);
    }
}
