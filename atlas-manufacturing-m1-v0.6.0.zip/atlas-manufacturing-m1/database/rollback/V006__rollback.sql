DROP TABLE IF EXISTS corrective_actions;
DROP TABLE IF EXISTS safety_records;
DELETE FROM permissions WHERE code IN ('safety.read','safety.write','safety.admin');
