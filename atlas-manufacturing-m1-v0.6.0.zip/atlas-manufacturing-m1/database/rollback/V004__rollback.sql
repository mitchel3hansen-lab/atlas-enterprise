BEGIN;
DROP TABLE IF EXISTS dead_letter_messages;
DROP TABLE IF EXISTS outbox_messages;
DROP TABLE IF EXISTS workflow_tasks;
DROP TABLE IF EXISTS workflow_instances;
DROP TABLE IF EXISTS workflow_definitions;
DELETE FROM permissions WHERE permission_key IN ('workflows.read','workflows.write','workflows.admin');
COMMIT;
