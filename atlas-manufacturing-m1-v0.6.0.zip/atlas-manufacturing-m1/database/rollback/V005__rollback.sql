BEGIN;
DROP TABLE IF EXISTS scheduled_jobs;
DROP TABLE IF EXISTS notification_messages;
DROP TABLE IF EXISTS notification_preferences;
DROP TABLE IF EXISTS notification_templates;
DELETE FROM permissions WHERE permission_key IN ('notifications.read','notifications.write','notifications.admin');
COMMIT;
