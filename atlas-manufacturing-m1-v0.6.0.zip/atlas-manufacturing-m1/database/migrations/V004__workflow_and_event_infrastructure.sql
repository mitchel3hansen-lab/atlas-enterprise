BEGIN;

CREATE TABLE workflow_definitions (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, key varchar(100) NOT NULL, name varchar(200) NOT NULL,
 definition_version integer NOT NULL DEFAULT 1, initial_state varchar(100) NOT NULL, states_json jsonb NOT NULL,
 transitions_json jsonb NOT NULL, is_published boolean NOT NULL DEFAULT false, status varchar(32) NOT NULL,
 version bigint NOT NULL DEFAULT 1, created_at timestamptz NOT NULL, created_by uuid, updated_at timestamptz NOT NULL, updated_by uuid,
 UNIQUE (tenant_id,key,definition_version));
CREATE INDEX ix_workflow_definitions_tenant ON workflow_definitions(tenant_id);

CREATE TABLE workflow_instances (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, definition_id uuid NOT NULL REFERENCES workflow_definitions(id),
 definition_key varchar(100) NOT NULL, definition_version integer NOT NULL, current_state varchar(100) NOT NULL,
 subject_type varchar(100) NOT NULL, subject_id uuid NOT NULL, due_at timestamptz, completed_at timestamptz,
 status varchar(32) NOT NULL, version bigint NOT NULL DEFAULT 1, created_at timestamptz NOT NULL, created_by uuid,
 updated_at timestamptz NOT NULL, updated_by uuid);
CREATE INDEX ix_workflow_instances_tenant_subject ON workflow_instances(tenant_id,subject_type,subject_id);
CREATE INDEX ix_workflow_instances_due ON workflow_instances(tenant_id,due_at) WHERE completed_at IS NULL;

CREATE TABLE workflow_tasks (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, workflow_instance_id uuid NOT NULL REFERENCES workflow_instances(id),
 title varchar(300) NOT NULL, assignee_user_id uuid, assignee_role_id uuid, due_at timestamptz, completed_at timestamptz,
 status varchar(32) NOT NULL, version bigint NOT NULL DEFAULT 1, created_at timestamptz NOT NULL, created_by uuid,
 updated_at timestamptz NOT NULL, updated_by uuid,
 CHECK (assignee_user_id IS NOT NULL OR assignee_role_id IS NOT NULL));
CREATE INDEX ix_workflow_tasks_assignee ON workflow_tasks(tenant_id,assignee_user_id,status);
CREATE INDEX ix_workflow_tasks_due ON workflow_tasks(tenant_id,due_at) WHERE completed_at IS NULL;

CREATE TABLE outbox_messages (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, event_type varchar(200) NOT NULL, payload_json jsonb NOT NULL,
 occurred_at timestamptz NOT NULL, published_at timestamptz, attempt_count integer NOT NULL DEFAULT 0,
 next_attempt_at timestamptz, last_error varchar(2000));
CREATE INDEX ix_outbox_pending ON outbox_messages(next_attempt_at,occurred_at) WHERE published_at IS NULL;

CREATE TABLE dead_letter_messages (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, outbox_message_id uuid NOT NULL, event_type varchar(200) NOT NULL,
 payload_json jsonb NOT NULL, error varchar(2000) NOT NULL, failed_at timestamptz NOT NULL);
CREATE INDEX ix_dead_letter_tenant ON dead_letter_messages(tenant_id,failed_at DESC);

INSERT INTO permissions (id, permission_key, description) VALUES
 ('10000000-0000-0000-0000-000000000008','workflows.read','Read workflow definitions, instances, and tasks'),
 ('10000000-0000-0000-0000-000000000009','workflows.write','Start and transition workflows and manage tasks'),
 ('10000000-0000-0000-0000-000000000010','workflows.admin','Create and publish workflow definitions')
ON CONFLICT (permission_key) DO NOTHING;

COMMIT;
