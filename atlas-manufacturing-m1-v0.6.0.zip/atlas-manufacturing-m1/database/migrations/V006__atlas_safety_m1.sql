CREATE TABLE safety_records (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, facility_id uuid NOT NULL REFERENCES facilities(id),
 record_type varchar(32) NOT NULL, reference_number varchar(40) NOT NULL, title varchar(250) NOT NULL,
 description text NOT NULL DEFAULT '', severity varchar(20) NOT NULL, occurred_at timestamptz NOT NULL,
 location varchar(250) NOT NULL DEFAULT '', owner_user_id uuid NULL REFERENCES users(id), closed_at timestamptz NULL,
 status varchar(32) NOT NULL, version bigint NOT NULL DEFAULT 1, created_at timestamptz NOT NULL,
 created_by uuid NULL, updated_at timestamptz NOT NULL, updated_by uuid NULL,
 UNIQUE(tenant_id, reference_number));
CREATE INDEX ix_safety_records_tenant_facility_status ON safety_records(tenant_id,facility_id,status);
CREATE TABLE corrective_actions (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, safety_record_id uuid NOT NULL REFERENCES safety_records(id) ON DELETE CASCADE,
 action text NOT NULL, owner_user_id uuid NULL REFERENCES users(id), due_at timestamptz NOT NULL,
 completed_at timestamptz NULL, effectiveness_notes text NOT NULL DEFAULT '', status varchar(32) NOT NULL,
 version bigint NOT NULL DEFAULT 1, created_at timestamptz NOT NULL, created_by uuid NULL,
 updated_at timestamptz NOT NULL, updated_by uuid NULL);
CREATE INDEX ix_corrective_actions_tenant_status_due ON corrective_actions(tenant_id,status,due_at);
INSERT INTO permissions(id,code,description) VALUES
(gen_random_uuid(),'safety.read','View Atlas Safety records and dashboards'),
(gen_random_uuid(),'safety.write','Create and update Atlas Safety records'),
(gen_random_uuid(),'safety.admin','Administer Atlas Safety') ON CONFLICT(code) DO NOTHING;
