BEGIN;
CREATE TABLE notification_templates (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, key varchar(100) NOT NULL, name varchar(200) NOT NULL,
 subject_template varchar(500) NOT NULL DEFAULT '', body_template text NOT NULL, default_channel varchar(32) NOT NULL,
 status varchar(32) NOT NULL, version bigint NOT NULL DEFAULT 1, created_at timestamptz NOT NULL, created_by uuid,
 updated_at timestamptz NOT NULL, updated_by uuid, UNIQUE(tenant_id,key), CHECK(default_channel IN ('email','in_app')));
CREATE TABLE notification_preferences (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, user_id uuid NOT NULL, email_enabled boolean NOT NULL DEFAULT true,
 in_app_enabled boolean NOT NULL DEFAULT true, escalations_enabled boolean NOT NULL DEFAULT true,
 status varchar(32) NOT NULL, version bigint NOT NULL DEFAULT 1, created_at timestamptz NOT NULL, created_by uuid,
 updated_at timestamptz NOT NULL, updated_by uuid, UNIQUE(tenant_id,user_id));
CREATE TABLE notification_messages (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, template_id uuid NULL REFERENCES notification_templates(id), recipient_user_id uuid NOT NULL,
 channel varchar(32) NOT NULL, subject varchar(500) NOT NULL DEFAULT '', body text NOT NULL, scheduled_at timestamptz,
 sent_at timestamptz, read_at timestamptz, attempt_count integer NOT NULL DEFAULT 0, next_attempt_at timestamptz, last_error varchar(2000),
 status varchar(32) NOT NULL, version bigint NOT NULL DEFAULT 1, created_at timestamptz NOT NULL, created_by uuid,
 updated_at timestamptz NOT NULL, updated_by uuid, CHECK(channel IN ('email','in_app')));
CREATE INDEX ix_notification_dispatch ON notification_messages(status,next_attempt_at);
CREATE INDEX ix_notification_inbox ON notification_messages(tenant_id,recipient_user_id,created_at DESC);
CREATE TABLE scheduled_jobs (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, job_type varchar(100) NOT NULL, payload_json jsonb NOT NULL,
 run_at timestamptz NOT NULL, completed_at timestamptz, attempt_count integer NOT NULL DEFAULT 0, last_error varchar(2000),
 status varchar(32) NOT NULL, version bigint NOT NULL DEFAULT 1, created_at timestamptz NOT NULL, created_by uuid,
 updated_at timestamptz NOT NULL, updated_by uuid);
CREATE INDEX ix_scheduled_jobs_due ON scheduled_jobs(status,run_at);
INSERT INTO permissions(id,permission_key,description) VALUES
(gen_random_uuid(),'notifications.read','Read notification templates and personal notifications'),
(gen_random_uuid(),'notifications.write','Queue notifications and manage personal preferences'),
(gen_random_uuid(),'notifications.admin','Administer notification templates and delivery settings') ON CONFLICT(permission_key) DO NOTHING;
COMMIT;
