# Atlas Safety

The first flagship ATLAS product. The `web` directory is a responsive executable pilot UI. Serve it with any static web server or run the full stack through Docker Compose.
