using System.Text;
using Atlas.Api.Auth;
using Atlas.Api.Infrastructure;
using Atlas.Api.KnowledgeGraph;
using Atlas.Api.Explainability;
using Atlas.Api.Middleware;
using Atlas.Api.Security;
using Atlas.Api.Rules;
using Atlas.Api.Evidence;
using Atlas.Api.Timeline;
using Atlas.Api.Incidents;
using Atlas.Api.Runtime;
using Atlas.Api.OperationalKnowledge;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        Description = "Paste an ATLAS access token."
    });
    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        [new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }] = Array.Empty<string>()
    });
});
builder.Services.AddHealthChecks();
builder.Services.AddDbContext<AtlasDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("Atlas")));
builder.Services.AddScoped<TenantContext>();
builder.Services.AddScoped<ExplainabilityService>();
builder.Services.AddScoped<IKnowledgeGraphRepository, PostgresKnowledgeGraphRepository>();
builder.Services.AddScoped<KnowledgeGraphService>();
builder.Services.AddScoped<IRuleRepository, PostgresRuleRepository>();
builder.Services.AddScoped<IEvidenceRepository, PostgresEvidenceRepository>();
builder.Services.AddScoped<ITimelineRepository, PostgresTimelineRepository>();
builder.Services.AddScoped<IIncidentRepository, PostgresIncidentRepository>();
builder.Services.AddScoped<IncidentService>();
builder.Services.AddScoped<IOperationalKnowledgeRepository, PostgresOperationalKnowledgeRepository>();
builder.Services.AddScoped<OperationalKnowledgeService>();
builder.Services.AddScoped<Atlas.Api.Investigations.IInvestigationRepository, Atlas.Api.Investigations.PostgresInvestigationRepository>();
builder.Services.AddScoped<Atlas.Api.Investigations.InvestigationService>();
builder.Services.AddScoped<TimelineService>();
builder.Services.Configure<OutboxOptions>(builder.Configuration.GetSection(OutboxOptions.SectionName));
builder.Services.AddScoped<IOutboxStore, PostgresOutboxStore>();
builder.Services.AddScoped<IOutboxWriter>(sp => sp.GetRequiredService<IOutboxStore>());
builder.Services.AddScoped<IAtlasEventPublisher, LoggingAtlasEventPublisher>();
builder.Services.AddHostedService<OutboxDispatcher>();
builder.Services.AddSingleton<IEvidenceStorage, FileSystemEvidenceStorage>();
builder.Services.AddScoped<EvidenceService>();
builder.Services.AddScoped<RuleConditionEvaluator>();
builder.Services.AddScoped<IRuleActionHandler, AuditActionHandler>();
builder.Services.AddScoped<RuleActionDispatcher>();
builder.Services.AddScoped<RulesEngine>();
builder.Services.AddSingleton<PasswordService>();
builder.Services.AddSingleton<PasswordPolicy>();
builder.Services.AddSingleton<RefreshTokenService>();
builder.Services.Configure<AuthSecurityOptions>(builder.Configuration.GetSection(AuthSecurityOptions.SectionName));
builder.Services.AddSingleton<InvitationTokenService>();
builder.Services.Configure<JwtOptions>(builder.Configuration.GetSection(JwtOptions.SectionName));
builder.Services.AddSingleton<TokenService>();
builder.Services.AddSingleton<IAuthorizationHandler, PermissionAuthorizationHandler>();

var jwt = builder.Configuration.GetSection(JwtOptions.SectionName).Get<JwtOptions>()
    ?? throw new InvalidOperationException("JWT configuration is required.");
if (Encoding.UTF8.GetByteCount(jwt.SigningKey) < 32)
    throw new InvalidOperationException("JWT signing key must be at least 32 bytes.");

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwt.Issuer,
            ValidateAudience = true,
            ValidAudience = jwt.Audience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.SigningKey)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1)
        };
        options.Events = new JwtBearerEvents
        {
            OnTokenValidated = async context =>
            {
                var jwtId = context.Principal?.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Jti)?.Value;
                if (string.IsNullOrWhiteSpace(jwtId))
                {
                    context.Fail("Missing token identifier.");
                    return;
                }

                var db = context.HttpContext.RequestServices.GetRequiredService<AtlasDbContext>();
                if (await db.RevokedSessions.AnyAsync(x => x.JwtId == jwtId && x.ExpiresAtUtc > DateTimeOffset.UtcNow))
                    context.Fail("Session has been revoked.");
            }
        };
    });

builder.Services.AddAuthorization(options =>
{
    foreach (var permission in AtlasPermissions.All)
        options.AddPolicy(permission, policy => policy.Requirements.Add(new PermissionRequirement(permission)));
});

var app = builder.Build();

app.UseMiddleware<CorrelationIdMiddleware>();
app.UseAuthentication();
app.UseMiddleware<TenantContextMiddleware>();
app.UseAuthorization();
app.UseSwagger();
app.UseSwaggerUI();
app.MapHealthChecks("/health");
app.MapControllers();

app.Run();

public partial class Program;
