import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const apiUrl = import.meta.env.VITE_INCIDENT_API_URL ?? "http://localhost:8085";
const tenantId = "11111111-1111-1111-1111-111111111111";
const employeeId = "22222222-2222-2222-2222-222222222222";
const supervisorId = "33333333-3333-3333-3333-333333333333";
const safetyId = "44444444-4444-4444-4444-444444444444";
const investigatorId = "55555555-5555-5555-5555-555555555555";
const supervisorDepartment = "Warehouse";

type Incident = {
  id: string;
  incidentNumber: string;
  title: string;
  severity: string;
  status: string;
  workflowState: string;
  site: string;
  department: string;
  investigationDueAt?: string | null;
};

function App() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [comments, setComments] = useState<Record<string, string>>({});

  async function loadIncidents() {
    const response = await fetch(`${apiUrl}/api/incidents?tenantId=${tenantId}`);
    if (response.ok) setIncidents(await response.json());
  }

  useEffect(() => {
    loadIncidents().catch(() => setMessage("Unable to load incidents."));
  }, []);

  async function post(url: string, body: unknown, success: string) {
    setBusy(true);
    setMessage("");
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message ?? result.title ?? "Action failed.");
      setMessage(success);
      await loadIncidents();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unexpected error.");
    } finally {
      setBusy(false);
    }
  }

  async function create(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    await post(`${apiUrl}/api/incidents`, {
      tenantId,
      reporterId: employeeId,
      title: String(form.get("title") ?? ""),
      description: String(form.get("description") ?? ""),
      incidentType: String(form.get("incidentType") ?? ""),
      severity: String(form.get("severity") ?? "Medium"),
      occurredAt: new Date(String(form.get("occurredAt"))).toISOString(),
      site: String(form.get("site") ?? ""),
      department: String(form.get("department") ?? "")
    }, "Incident draft created.");
    event.currentTarget.reset();
  }

  async function supervisorReview(incident: Incident, decision: string) {
    await post(`${apiUrl}/api/incidents/${incident.id}/supervisor-review`, {
      tenantId,
      reviewerId: supervisorId,
      reviewerRole: "Supervisor",
      reviewerDepartment: supervisorDepartment,
      decision,
      comment: comments[incident.id] || "Initial supervisor review completed."
    }, decision === "Approve"
      ? "Incident routed to Safety Review."
      : "Incident returned for correction.");
  }

  async function safetyReview(incident: Incident) {
    await post(`${apiUrl}/api/incidents/${incident.id}/safety-review`, {
      tenantId,
      safetyReviewerId: safetyId,
      reviewerRole: "Safety",
      confirmedSeverity: incident.severity,
      oshaReviewRequired: incident.severity === "High" || incident.severity === "Critical",
      medicalFollowUpRequired: false,
      immediateControlsReviewed: true,
      investigatorId,
      investigationDueAt: new Date(Date.now() + 5 * 86400000).toISOString(),
      comment: comments[incident.id] || "Safety screening completed and investigator assigned."
    }, "Safety review complete. Investigation assigned.");
  }

  return (
    <main>
      <header>
        <span className="eyebrow">ATLAS ENTERPRISE</span>
        <h1>Incident Operations</h1>
        <p>Report, review, screen, and assign incidents through one controlled workflow.</p>
      </header>

      <section className="panel">
        <h2>Report an Incident</h2>
        <form onSubmit={create}>
          <label>Incident title<input name="title" required maxLength={200} /></label>
          <div className="grid">
            <label>Incident type
              <select name="incidentType" required defaultValue="">
                <option value="" disabled>Select type</option>
                <option>Near Miss</option>
                <option>First Aid</option>
                <option>Recordable</option>
                <option>Property Damage</option>
                <option>Chemical Exposure</option>
              </select>
            </label>
            <label>Severity
              <select name="severity" defaultValue="Medium">
                <option>Low</option><option>Medium</option>
                <option>High</option><option>Critical</option>
              </select>
            </label>
          </div>
          <label>What happened?<textarea name="description" required rows={4} /></label>
          <div className="grid">
            <label>Occurred at<input name="occurredAt" type="datetime-local" required /></label>
            <label>Site<input name="site" required defaultValue="Lindon" /></label>
            <label>Department<input name="department" required defaultValue="Warehouse" /></label>
          </div>
          <button disabled={busy}>{busy ? "Working…" : "Save Incident Draft"}</button>
        </form>
      </section>

      <section className="panel">
        <h2>Incident Queue</h2>
        <div className="incident-list">
          {incidents.map((incident) => (
            <article key={incident.id}>
              <div className="incident-summary">
                <span className="number">{incident.incidentNumber}</span>
                <h3>{incident.title}</h3>
                <p>{incident.site} · {incident.department}</p>
                <div className="badges">
                  <span className={`badge ${incident.severity.toLowerCase()}`}>{incident.severity}</span>
                  <span className="badge">{incident.workflowState}</span>
                </div>
              </div>

              <div className="incident-actions">
                {incident.status === "Draft" && (
                  <button disabled={busy} onClick={() =>
                    post(`${apiUrl}/api/incidents/${incident.id}/submit`,
                      { tenantId, actorId: employeeId },
                      "Incident submitted to Supervisor Review.")}>
                    Submit
                  </button>
                )}

                {incident.workflowState === "SupervisorReview" && (
                  <div className="review-box">
                    <strong>Supervisor Review</strong>
                    <textarea
                      rows={3}
                      placeholder="Supervisor review comment"
                      value={comments[incident.id] ?? ""}
                      onChange={(e) => setComments({ ...comments, [incident.id]: e.target.value })}
                    />
                    <div className="review-actions">
                      <button disabled={busy} onClick={() => supervisorReview(incident, "Approve")}>
                        Approve for Safety
                      </button>
                      <button className="secondary" disabled={busy}
                        onClick={() => supervisorReview(incident, "ReturnForCorrection")}>
                        Return
                      </button>
                    </div>
                  </div>
                )}

                {incident.workflowState === "SafetyReview" && (
                  <div className="review-box">
                    <strong>Safety Review & Assignment</strong>
                    <p>Confirm severity, screen regulatory needs, verify immediate controls, and assign an investigator.</p>
                    <textarea
                      rows={3}
                      placeholder="Safety review comment"
                      value={comments[incident.id] ?? ""}
                      onChange={(e) => setComments({ ...comments, [incident.id]: e.target.value })}
                    />
                    <button disabled={busy} onClick={() => safetyReview(incident)}>
                      Assign Investigator
                    </button>
                  </div>
                )}

                {incident.workflowState === "Investigation" && (
                  <div className="review-box">
                    <strong>Investigation Assigned</strong>
                    <p>Due {incident.investigationDueAt
                      ? new Date(incident.investigationDueAt).toLocaleDateString()
                      : "Not set"}</p>
                  </div>
                )}
              </div>
            </article>
          ))}
        </div>
      </section>

      {message && <output>{message}</output>}
    </main>
  );
}

createRoot(document.getElementById("root")!).render(
  <React.StrictMode><App /></React.StrictMode>
);
