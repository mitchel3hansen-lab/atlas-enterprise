# Atlas Enterprise

Atlas is an operational intelligence platform beginning with a complete incident-management vertical slice.

## Current workflow

```text
Draft
→ SupervisorReview
→ SafetyReview
→ Investigation
```

Alternative:

```text
SupervisorReview
→ CorrectionRequested
```

## Current capabilities

- Create and list incident drafts
- Submit for supervisor review
- Approve or return for correction
- Perform Safety screening
- Confirm severity
- Flag OSHA and medical follow-up
- Verify immediate controls
- Assign an investigator and due date
- Persist comments and timeline events

## Start locally

```bash
docker compose down -v
docker compose up --build
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger
