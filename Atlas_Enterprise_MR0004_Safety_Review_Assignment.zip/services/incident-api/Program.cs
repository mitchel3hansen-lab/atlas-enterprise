using Atlas.IncidentApi.Features.Incidents.Create;
using Atlas.IncidentApi.Features.Incidents.Review;
using Atlas.IncidentApi.Features.Incidents.Submit;
using Atlas.IncidentApi.Features.Incidents.SafetyReview;
using Atlas.IncidentApi.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<IncidentRepository>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
});

var app = builder.Build();

app.UseCors();
app.UseSwagger();
app.UseSwaggerUI();

app.MapGet("/health", () => Results.Ok(new
{
    service = "incident-api",
    status = "healthy",
    timestamp = DateTimeOffset.UtcNow
}));

app.MapPost("/api/incidents", async (
    CreateIncidentRequest request,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = CreateIncidentValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var incident = await repository.CreateAsync(request, cancellationToken);
    return Results.Created($"/api/incidents/{incident.Id}", incident);
})
.WithName("CreateIncident")
.WithOpenApi();

app.MapGet("/api/incidents", async (
    Guid tenantId,
    string? department,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    if (tenantId == Guid.Empty)
        return Results.BadRequest(new { message = "tenantId is required." });

    return Results.Ok(await repository.ListAsync(
        tenantId, department, cancellationToken));
})
.WithName("ListIncidents")
.WithOpenApi();

app.MapGet("/api/incidents/{incidentId:guid}", async (
    Guid incidentId,
    Guid tenantId,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var incident = await repository.GetAsync(
        tenantId, incidentId, cancellationToken);

    return incident is null ? Results.NotFound() : Results.Ok(incident);
})
.WithName("GetIncident")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/submit", async (
    Guid incidentId,
    SubmitIncidentRequest request,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    if (request.TenantId == Guid.Empty || request.ActorId == Guid.Empty)
        return Results.BadRequest(new
        {
            message = "Tenant and actor are required."
        });

    var incident = await repository.SubmitAsync(
        request.TenantId,
        incidentId,
        request.ActorId,
        cancellationToken);

    return incident is null
        ? Results.Conflict(new
        {
            message = "Incident was not found or is no longer a draft."
        })
        : Results.Ok(incident);
})
.WithName("SubmitIncident")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/supervisor-review", async (
    Guid incidentId,
    ReviewIncidentRequest request,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = ReviewIncidentValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var result = await repository.ReviewAsync(
        incidentId, request, cancellationToken);

    return result.Incident is null
        ? Results.Conflict(new { message = result.Error })
        : Results.Ok(result.Incident);
})
.WithName("SupervisorReviewIncident")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/safety-review", async (
    Guid incidentId,
    SafetyReviewRequest request,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = SafetyReviewValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var result = await repository.SafetyReviewAsync(
        incidentId, request, cancellationToken);

    return result.Incident is null
        ? Results.Conflict(new { message = result.Error })
        : Results.Ok(result.Incident);
})
.WithName("SafetyReviewAndAssignInvestigator")
.WithOpenApi();

app.Run();


public partial class Program;
