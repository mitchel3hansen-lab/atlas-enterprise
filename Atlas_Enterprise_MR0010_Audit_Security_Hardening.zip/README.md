# Atlas Enterprise

Atlas is an operational intelligence platform with a complete closed-loop incident workflow, role-based security, operational dashboards, and auditable API activity.

## Security capabilities

- JWT authentication
- Tenant and department isolation
- Role-based authorization
- Append-only audit events
- Correlation IDs
- Structured error handling
- Rate limiting
- Security headers
- Protected audit review

## Local development

```bash
docker compose down -v
docker compose up --build
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger

## Important

The development token endpoint, development signing key, and permissive CORS policy are local-development features only. Production deployment requires an external OIDC provider, managed secrets, HTTPS, and restrictive CORS.
