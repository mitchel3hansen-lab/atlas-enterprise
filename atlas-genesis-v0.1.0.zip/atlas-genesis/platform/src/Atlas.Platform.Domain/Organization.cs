using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain;

public sealed class Organization : AtlasEntity
{
    private Organization() { }

    public string Name { get; private set; } = string.Empty;

    public static Organization Create(Guid tenantId, string name, Guid? actorId, DateTimeOffset now)
    {
        if (tenantId == Guid.Empty) throw new ArgumentException("Tenant is required.", nameof(tenantId));
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Name is required.", nameof(name));

        return new Organization
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId,
            Name = name.Trim(),
            CreatedAt = now,
            UpdatedAt = now,
            CreatedBy = actorId,
            UpdatedBy = actorId
        };
    }
}
