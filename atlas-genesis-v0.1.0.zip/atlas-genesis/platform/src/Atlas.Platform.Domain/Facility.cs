using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain;

public sealed class Facility : AtlasEntity
{
    private Facility() { }

    public Guid OrganizationId { get; private init; }
    public string Name { get; private set; } = string.Empty;

    public static Facility Create(Guid tenantId, Guid organizationId, string name, Guid? actorId, DateTimeOffset now)
    {
        if (organizationId == Guid.Empty) throw new ArgumentException("Organization is required.", nameof(organizationId));
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Name is required.", nameof(name));

        return new Facility
        {
            Id = Guid.NewGuid(), TenantId = tenantId, OrganizationId = organizationId,
            Name = name.Trim(), CreatedAt = now, UpdatedAt = now, CreatedBy = actorId, UpdatedBy = actorId
        };
    }
}
