using System.Collections.Concurrent;
using Atlas.Platform.Application;
using Atlas.Platform.Domain;

namespace Atlas.Platform.Infrastructure;

public sealed class InMemoryOrganizationRepository : IOrganizationRepository
{
    private readonly ConcurrentDictionary<Guid, Organization> _organizations = new();

    public Task<IReadOnlyCollection<Organization>> ListAsync(Guid tenantId, CancellationToken cancellationToken)
    {
        IReadOnlyCollection<Organization> result = _organizations.Values
            .Where(x => x.TenantId == tenantId)
            .OrderBy(x => x.Name)
            .ToArray();
        return Task.FromResult(result);
    }

    public Task AddAsync(Organization organization, CancellationToken cancellationToken)
    {
        if (!_organizations.TryAdd(organization.Id, organization))
            throw new InvalidOperationException("Organization already exists.");
        return Task.CompletedTask;
    }
}
