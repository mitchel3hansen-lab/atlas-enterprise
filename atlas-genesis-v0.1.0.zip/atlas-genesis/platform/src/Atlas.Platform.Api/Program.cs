using Atlas.Platform.Application;
using Atlas.Platform.Infrastructure;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddSingleton<IOrganizationRepository, InMemoryOrganizationRepository>();
builder.Services.AddScoped<OrganizationService>();
builder.Services.AddHealthChecks();

var app = builder.Build();
app.MapHealthChecks("/health");

var api = app.MapGroup("/api/v1");

api.MapGet("/organizations", async (
    Guid tenantId,
    OrganizationService service,
    CancellationToken cancellationToken) =>
    Results.Ok(await service.ListAsync(tenantId, cancellationToken)));

api.MapPost("/organizations", async (
    CreateOrganizationRequest request,
    OrganizationService service,
    CancellationToken cancellationToken) =>
{
    var organization = await service.CreateAsync(request.TenantId, request.Name, request.ActorId, cancellationToken);
    return Results.Created($"/api/v1/organizations/{organization.Id}", organization);
});

app.Run();

public sealed record CreateOrganizationRequest(Guid TenantId, string Name, Guid? ActorId);
