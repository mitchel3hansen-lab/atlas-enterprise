using Atlas.Platform.Domain;

namespace Atlas.Platform.Application;

public interface IOrganizationRepository
{
    Task<IReadOnlyCollection<Organization>> ListAsync(Guid tenantId, CancellationToken cancellationToken);
    Task AddAsync(Organization organization, CancellationToken cancellationToken);
}
