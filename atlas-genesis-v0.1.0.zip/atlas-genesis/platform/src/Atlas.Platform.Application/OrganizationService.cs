using Atlas.Platform.Domain;

namespace Atlas.Platform.Application;

public sealed class OrganizationService(IOrganizationRepository repository, TimeProvider timeProvider)
{
    public Task<IReadOnlyCollection<Organization>> ListAsync(Guid tenantId, CancellationToken cancellationToken) =>
        repository.ListAsync(tenantId, cancellationToken);

    public async Task<Organization> CreateAsync(Guid tenantId, string name, Guid? actorId, CancellationToken cancellationToken)
    {
        var organization = Organization.Create(tenantId, name, actorId, timeProvider.GetUtcNow());
        await repository.AddAsync(organization, cancellationToken);
        return organization;
    }
}
