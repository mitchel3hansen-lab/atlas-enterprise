# ATLAS Genesis

ATLAS is a modular operational-intelligence platform for safety, risk, compliance, emergency management, quality, industrial hygiene, and future operational domains.

## Genesis scope

This repository establishes the first executable platform foundation:

- engineering governance and architecture decision records;
- canonical entity and domain-event contracts;
- tenant-aware organization and facility models;
- a minimal ASP.NET Core Platform API skeleton;
- an OpenAPI-first contract;
- initial PostgreSQL migration;
- Atlas Safety product boundary;
- CI, container, security, and contribution templates.

## Repository map

```text
platform/           Shared runtime services and application infrastructure
sdk/                Reusable contracts and developer-facing abstractions
domain/             Canonical domain definitions and bounded-context records
products/           Commercial products built on the platform
infrastructure/     Docker, Terraform, deployment, and operations assets
docs/               Handbook, architecture, ADRs, product, and API documentation
database/           Versioned database migrations
```

## Local start

Prerequisites: .NET 8 SDK and Docker.

```bash
docker compose -f infrastructure/docker/docker-compose.yml up -d
dotnet restore Atlas.sln
dotnet build Atlas.sln --configuration Release
dotnet run --project platform/src/Atlas.Platform.Api
```

The API exposes health endpoints and the first organization/facility routes. The authoritative contract is in `docs/api/platform-core.openapi.yaml`.

## Current maturity

**Release:** Genesis 0.1.0  
**Status:** Foundation skeleton  
**Next vertical slice:** persistent tenant-aware Organization and Facility management.
