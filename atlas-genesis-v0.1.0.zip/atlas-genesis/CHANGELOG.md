# Changelog

## 0.1.0 - 2026-07-17

### Added
- Genesis modular-monorepo structure.
- Engineering Constitution and first ten ADRs.
- Canonical Foundation and Safety domain model documentation.
- Platform Core OpenAPI contract and PostgreSQL migration.
- Initial .NET domain, application, infrastructure, API, and unit-test projects.
- Docker Compose and GitHub Actions CI skeleton.
