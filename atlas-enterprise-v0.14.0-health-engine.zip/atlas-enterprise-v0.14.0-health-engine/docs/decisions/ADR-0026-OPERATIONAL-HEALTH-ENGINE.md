# ADR-0026 — Operational Health as a Shared, Versioned Engine
Status: Accepted for v0.14.0.

Operational Health is tenant-aware and shared. Models are versioned; published versions,
snapshots, and contributions are immutable. Score and confidence are separate. Missing,
stale, unreliable, or unlinked evidence reduces confidence. Calculations produce a
deterministic SHA-256 hash and expose every contribution and evidence gap.
