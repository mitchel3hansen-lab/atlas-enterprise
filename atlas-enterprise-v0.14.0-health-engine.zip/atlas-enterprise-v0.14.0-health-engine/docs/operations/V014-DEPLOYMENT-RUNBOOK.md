# v0.14 Deployment Runbook
1. Back up database.
2. Verify v0.13.0 baseline.
3. Apply V014 in staging.
4. Register health permissions/services.
5. Deploy API/web.
6. Publish a nonproduction model.
7. Record measurements and calculate.
8. Verify tenant isolation.
9. Verify snapshot update/delete fail.
10. Complete UAT before production.
