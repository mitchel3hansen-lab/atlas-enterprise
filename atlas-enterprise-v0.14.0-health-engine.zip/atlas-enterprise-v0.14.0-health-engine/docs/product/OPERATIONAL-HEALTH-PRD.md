# Operational Health Engine PRD
Objective: one trustworthy method for measuring, trending, and explaining operational health.

Acceptance criteria:
1. Scores remain 0–100.
2. Normalized weights total 1.
3. Missing required evidence reduces confidence.
4. Stale measurements reduce confidence.
5. Snapshots cannot be updated or deleted.
6. Historical snapshots identify model version.
7. Every score exposes all contributions.
8. Latest score is retrievable by subject.
9. Identical inputs produce the same hash.
10. Tenant boundaries are enforced.
