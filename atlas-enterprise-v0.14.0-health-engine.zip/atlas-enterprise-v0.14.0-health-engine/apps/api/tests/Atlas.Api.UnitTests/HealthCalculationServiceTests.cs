using Atlas.Api.Health;
using Xunit;
namespace Atlas.Api.UnitTests;
public sealed class HealthCalculationServiceTests
{
 [Fact]
 public void ScoreRemainsWithinRange()
 {
  var i = new HealthIndicator(Guid.NewGuid(),"training","Training",HealthDirection.HigherIsBetter,1,0,100,100,null,1,true,null);
  var model = new HealthModelVersion(Guid.NewGuid(),Guid.NewGuid(),1,new[]{i});
  var m = new HealthMeasurement(Guid.NewGuid(),Guid.NewGuid(),"Facility",Guid.NewGuid(),"training",125,DateTimeOffset.UtcNow,"Test",null,Guid.NewGuid(),1);
  var result = new HealthCalculationService().Calculate(model,new[]{m},null,DateTimeOffset.UtcNow);
  Assert.InRange(result.Score,0,100);
 }
 [Fact]
 public void MissingEvidenceReducesConfidence()
 {
  var a = new HealthIndicator(Guid.NewGuid(),"a","A",HealthDirection.HigherIsBetter,1,0,100,100,null,1,true,null);
  var b = new HealthIndicator(Guid.NewGuid(),"b","B",HealthDirection.HigherIsBetter,1,0,100,100,null,1,true,null);
  var model = new HealthModelVersion(Guid.NewGuid(),Guid.NewGuid(),1,new[]{a,b});
  var m = new HealthMeasurement(Guid.NewGuid(),Guid.NewGuid(),"Facility",Guid.NewGuid(),"a",100,DateTimeOffset.UtcNow,"Test",null,Guid.NewGuid(),1);
  var result = new HealthCalculationService().Calculate(model,new[]{m},null,DateTimeOffset.UtcNow);
  Assert.Contains("b",result.MissingEvidence);
  Assert.True(result.Confidence < .75m);
 }
}
