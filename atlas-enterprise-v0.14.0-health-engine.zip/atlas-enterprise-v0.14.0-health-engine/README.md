# Atlas Enterprise v0.14.0 — Operational Health Engine

Implementation increment for the Atlas Enterprise v0.13.0 baseline.

Included: PostgreSQL migration and rollback, C# domain/calculation/API scaffolding, unit tests, React Mission Control card, OpenAPI, ADR, PRD, runbook, UAT checklist, release notes, manifest, and checksums.
