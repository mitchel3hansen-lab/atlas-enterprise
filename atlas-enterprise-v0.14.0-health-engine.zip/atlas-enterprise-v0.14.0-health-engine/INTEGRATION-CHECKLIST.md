# v0.13 → v0.14 Integration Checklist
- [ ] Add migration and rollback.
- [ ] Add health domain/calculation service.
- [ ] Implement tenant-scoped repository.
- [ ] Register permissions.
- [ ] Merge OpenAPI paths.
- [ ] Add Mission Control data hook.
- [ ] Run unit, integration, tenant-boundary, migration, accessibility tests.
- [ ] Complete UAT.
- [ ] Tag v0.14.0.
