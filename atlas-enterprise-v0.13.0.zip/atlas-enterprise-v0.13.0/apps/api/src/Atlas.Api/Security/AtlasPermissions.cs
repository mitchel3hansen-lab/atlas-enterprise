namespace Atlas.Api.Security;

public static class AtlasPermissions
{
    public const string OrganizationsRead = "organizations.read";
    public const string OrganizationsManage = "organizations.manage";
    public const string FacilitiesRead = "facilities.read";
    public const string FacilitiesManage = "facilities.manage";
    public const string UsersRead = "users.read";
    public const string UsersManage = "users.manage";
    public const string SafetyRead = "safety.read";
    public const string SafetyManage = "safety.manage";
    public const string ExplainabilityRead = "explainability.read";
    public const string ExplainabilityManage = "explainability.manage";

    public static readonly string[] All =
    [
        OrganizationsRead,
        OrganizationsManage,
        FacilitiesRead,
        FacilitiesManage,
        UsersRead,
        UsersManage,
        SafetyRead,
        SafetyManage,
        ExplainabilityRead,
        ExplainabilityManage
    ];
}
