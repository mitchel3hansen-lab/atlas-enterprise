# Inspection Management — M1.1

This increment adds scheduled inspections, completion scoring, overdue visibility, and action-required tracking. Initial templates represented in the pilot are Daily Safety Walk, GMP Area Inspection, Forklift Pre-Use Audit, Fire Protection Check, and Warehouse Rack Inspection.

## Acceptance criteria
- Users can schedule a facility inspection.
- Users can list and filter inspections.
- Completion records item totals and score.
- Failed items place the inspection into `action-required`.
- Dashboard exposes scheduled, overdue, action-required, average score, and completion rate.
- All queries enforce tenant boundaries.
