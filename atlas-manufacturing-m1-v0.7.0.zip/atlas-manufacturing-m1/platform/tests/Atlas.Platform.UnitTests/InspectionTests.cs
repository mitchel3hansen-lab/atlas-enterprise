using Atlas.Platform.Domain.Inspections;
namespace Atlas.Platform.UnitTests;
public sealed class InspectionTests
{
 [Fact] public void Complete_calculates_score_and_requires_action_when_items_fail(){var actor=Guid.NewGuid();var item=Inspection.Create(Guid.NewGuid(),Guid.NewGuid(),"INSP-2026-10001","Daily Safety Walk","Warehouse",actor,DateTimeOffset.UtcNow,actor);item.Complete(20,18,2,actor);Assert.Equal(90m,item.Score);Assert.Equal("action-required",item.Status);Assert.Equal(2,item.FailedItems);}
}
