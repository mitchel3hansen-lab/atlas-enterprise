using Atlas.Sdk.Core;
namespace Atlas.Platform.Domain.Inspections;
public enum InspectionResult { Pass, Attention, Fail, NotApplicable }
public sealed class Inspection : AtlasEntity
{
    private Inspection() { }
    public Guid FacilityId { get; private set; }
    public string ReferenceNumber { get; private set; } = string.Empty;
    public string TemplateName { get; private set; } = string.Empty;
    public string Area { get; private set; } = string.Empty;
    public Guid InspectorUserId { get; private set; }
    public DateTimeOffset ScheduledAt { get; private set; }
    public DateTimeOffset? CompletedAt { get; private set; }
    public int TotalItems { get; private set; }
    public int PassedItems { get; private set; }
    public int FailedItems { get; private set; }
    public decimal Score { get; private set; }
    public static Inspection Create(Guid tenantId,Guid facilityId,string reference,string template,string area,Guid inspector,DateTimeOffset scheduledAt,Guid actor)
    {
        if(string.IsNullOrWhiteSpace(template)) throw new ArgumentException("Template name is required.",nameof(template));
        return new Inspection{Id=Guid.NewGuid(),TenantId=tenantId,FacilityId=facilityId,ReferenceNumber=reference,TemplateName=template.Trim(),Area=area.Trim(),InspectorUserId=inspector,ScheduledAt=scheduledAt,Status="scheduled",CreatedAt=DateTimeOffset.UtcNow,UpdatedAt=DateTimeOffset.UtcNow,CreatedBy=actor,UpdatedBy=actor};
    }
    public void Complete(int total,int passed,int failed,Guid actor)
    {
        if(total<=0||passed<0||failed<0||passed+failed>total) throw new ArgumentException("Inspection totals are invalid.");
        TotalItems=total;PassedItems=passed;FailedItems=failed;Score=Math.Round((decimal)passed/total*100,1);Status=failed==0?"completed":"action-required";CompletedAt=DateTimeOffset.UtcNow;UpdatedAt=DateTimeOffset.UtcNow;UpdatedBy=actor;Version++;
    }
}
