namespace Atlas.Platform.Api.Contracts;
public sealed record ScheduleInspectionRequest(Guid FacilityId,string TemplateName,string Area,Guid InspectorUserId,DateTimeOffset ScheduledAt);
public sealed record CompleteInspectionRequest(int TotalItems,int PassedItems,int FailedItems);
