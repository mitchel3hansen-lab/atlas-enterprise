using Atlas.Platform.Application.Inspections;
using Atlas.Platform.Domain.Inspections;
using Atlas.Platform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
namespace Atlas.Platform.Infrastructure.Inspections;
public sealed class PostgresInspectionRepository(AtlasDbContext db):IInspectionRepository
{
 public async Task<IReadOnlyList<Inspection>> ListAsync(Guid tenantId,Guid? facilityId,string? status,CancellationToken ct){var q=db.Inspections.AsNoTracking().Where(x=>x.TenantId==tenantId);if(facilityId.HasValue)q=q.Where(x=>x.FacilityId==facilityId);if(!string.IsNullOrWhiteSpace(status))q=q.Where(x=>x.Status==status);return await q.OrderByDescending(x=>x.ScheduledAt).ToListAsync(ct);}
 public Task<Inspection?> GetAsync(Guid tenantId,Guid id,CancellationToken ct)=>db.Inspections.FirstOrDefaultAsync(x=>x.TenantId==tenantId&&x.Id==id,ct);
 public async Task AddAsync(Inspection item,CancellationToken ct){db.Inspections.Add(item);await db.SaveChangesAsync(ct);} public async Task UpdateAsync(Inspection item,CancellationToken ct){db.Inspections.Update(item);await db.SaveChangesAsync(ct);}
 public async Task<InspectionDashboard> DashboardAsync(Guid tenantId,Guid? facilityId,CancellationToken ct){var q=db.Inspections.AsNoTracking().Where(x=>x.TenantId==tenantId);if(facilityId.HasValue)q=q.Where(x=>x.FacilityId==facilityId);var now=DateTimeOffset.UtcNow;var all=await q.ToListAsync(ct);var scheduled=all.Count(x=>x.Status=="scheduled"&&x.ScheduledAt>=now);var overdue=all.Count(x=>x.Status=="scheduled"&&x.ScheduledAt<now);var action=all.Count(x=>x.Status=="action-required");var completed=all.Where(x=>x.CompletedAt.HasValue).ToList();var avg=completed.Count==0?0:Math.Round(completed.Average(x=>x.Score),1);var rate=all.Count==0?0:Math.Round((decimal)completed.Count/all.Count*100,1);return new(scheduled,overdue,action,avg,rate);}
}
