using Atlas.Platform.Domain.Inspections;
namespace Atlas.Platform.Application.Inspections;
public interface IInspectionRepository
{
 Task<IReadOnlyList<Inspection>> ListAsync(Guid tenantId,Guid? facilityId,string? status,CancellationToken ct);
 Task<Inspection?> GetAsync(Guid tenantId,Guid id,CancellationToken ct);
 Task AddAsync(Inspection item,CancellationToken ct);
 Task UpdateAsync(Inspection item,CancellationToken ct);
 Task<InspectionDashboard> DashboardAsync(Guid tenantId,Guid? facilityId,CancellationToken ct);
}
public sealed record InspectionDashboard(int Scheduled,int Overdue,int ActionRequired,decimal AverageScore,decimal CompletionRate);
