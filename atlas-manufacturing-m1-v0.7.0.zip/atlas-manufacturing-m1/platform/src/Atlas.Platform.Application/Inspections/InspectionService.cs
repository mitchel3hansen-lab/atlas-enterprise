using Atlas.Platform.Domain.Inspections;
namespace Atlas.Platform.Application.Inspections;
public sealed class InspectionService(IInspectionRepository repository,TimeProvider timeProvider)
{
 public Task<IReadOnlyList<Inspection>> ListAsync(Guid tenantId,Guid? facilityId,string? status,CancellationToken ct)=>repository.ListAsync(tenantId,facilityId,status,ct);
 public Task<InspectionDashboard> DashboardAsync(Guid tenantId,Guid? facilityId,CancellationToken ct)=>repository.DashboardAsync(tenantId,facilityId,ct);
 public async Task<Inspection> ScheduleAsync(Guid tenantId,Guid facilityId,string template,string area,Guid inspector,DateTimeOffset scheduledAt,Guid actor,CancellationToken ct)
 {var reference=$"INSP-{timeProvider.GetUtcNow():yyyy}-{Random.Shared.Next(10000,99999)}";var item=Inspection.Create(tenantId,facilityId,reference,template,area,inspector,scheduledAt,actor);await repository.AddAsync(item,ct);return item;}
 public async Task<Inspection> CompleteAsync(Guid tenantId,Guid id,int total,int passed,int failed,Guid actor,CancellationToken ct)
 {var item=await repository.GetAsync(tenantId,id,ct)??throw new NotFoundException("Inspection not found.");item.Complete(total,passed,failed,actor);await repository.UpdateAsync(item,ct);return item;}
}
