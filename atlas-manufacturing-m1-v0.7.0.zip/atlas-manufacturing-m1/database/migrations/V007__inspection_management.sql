CREATE TABLE inspections (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, facility_id uuid NOT NULL REFERENCES facilities(id), reference_number varchar(40) NOT NULL,
 template_name varchar(200) NOT NULL, area varchar(200) NOT NULL, inspector_user_id uuid NOT NULL, scheduled_at timestamptz NOT NULL,
 completed_at timestamptz NULL, total_items integer NOT NULL DEFAULT 0, passed_items integer NOT NULL DEFAULT 0, failed_items integer NOT NULL DEFAULT 0,
 score numeric(5,1) NOT NULL DEFAULT 0, status varchar(32) NOT NULL, version bigint NOT NULL DEFAULT 1,
 created_at timestamptz NOT NULL, created_by uuid NULL, updated_at timestamptz NOT NULL, updated_by uuid NULL,
 CONSTRAINT uq_inspections_reference UNIQUE(tenant_id,reference_number));
CREATE INDEX ix_inspections_facility_status ON inspections(tenant_id,facility_id,status);
CREATE INDEX ix_inspections_schedule ON inspections(tenant_id,scheduled_at);
