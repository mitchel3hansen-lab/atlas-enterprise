using System.Text;
using Atlas.Platform.Api.Auth;
using Atlas.Platform.Api.Contracts;
using Atlas.Platform.Api.Middleware;
using Atlas.Platform.Application;
using Atlas.Platform.Application.Identity;
using Atlas.Platform.Application.Workflow;
using Atlas.Platform.Infrastructure.Identity;
using Atlas.Platform.Infrastructure.Workflow;
using Atlas.Platform.Infrastructure.Events;
using Atlas.Platform.Infrastructure.Persistence;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);
var connectionString = builder.Configuration.GetConnectionString("AtlasDatabase")
    ?? throw new InvalidOperationException("ConnectionStrings:AtlasDatabase is required.");
var signingKey = builder.Configuration["Authentication:SigningKey"]
    ?? throw new InvalidOperationException("Authentication:SigningKey is required.");
var issuer = builder.Configuration["Authentication:Issuer"] ?? "atlas-platform";
var audience = builder.Configuration["Authentication:Audience"] ?? "atlas-api";

builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentUser, HttpCurrentUser>();
builder.Services.AddDbContext<AtlasDbContext>(options => options.UseNpgsql(connectionString));
builder.Services.AddScoped<IOrganizationRepository, PostgresOrganizationRepository>();
builder.Services.AddScoped<IFacilityRepository, PostgresFacilityRepository>();
builder.Services.AddScoped<IIdentityRepository, PostgresIdentityRepository>();
builder.Services.AddScoped<IWorkflowRepository, PostgresWorkflowRepository>();
builder.Services.AddScoped<IEventPublisher, LoggingEventPublisher>();
builder.Services.AddHostedService<OutboxDispatcher>();
builder.Services.AddScoped<OrganizationService>();
builder.Services.AddScoped<FacilityService>();
builder.Services.AddScoped<IdentityService>();
builder.Services.AddScoped<WorkflowService>();
builder.Services.AddScoped<DevelopmentTokenService>();
builder.Services.AddSingleton<IAuthorizationHandler, PermissionAuthorizationHandler>();
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
{
    options.MapInboundClaims = false;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true, ValidIssuer = issuer,
        ValidateAudience = true, ValidAudience = audience,
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey)),
        ValidateLifetime = true, ClockSkew = TimeSpan.FromMinutes(1)
    };
});
builder.Services.AddAuthorization(options =>
{
    foreach (var permission in AtlasPermissions.All)
        options.AddPolicy(permission, policy => policy.RequireAuthenticatedUser().RequirePermission(permission));
});
builder.Services.AddHealthChecks().AddNpgSql(connectionString);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddOpenApi();

var app = builder.Build();
app.UseMiddleware<ExceptionMiddleware>();
app.UseAuthentication();
app.UseMiddleware<TenantMiddleware>();
app.UseAuthorization();
app.MapHealthChecks("/health");
app.MapOpenApi();

if (app.Environment.IsDevelopment())
{
    app.MapPost("/api/v1/auth/dev-token", (DevelopmentTokenRequest request, DevelopmentTokenService tokens) =>
        Results.Ok(new { accessToken = tokens.Issue(request.UserId, request.TenantId, request.Permissions), tokenType = "Bearer", expiresIn = 3600 }));
}

var api = app.MapGroup("/api/v1").RequireAuthorization();

api.MapGet("/organizations", async (HttpContext context, OrganizationService service, CancellationToken ct) =>
    Results.Ok(await service.ListAsync(GetTenantId(context), ct))).RequireAuthorization(AtlasPermissions.OrganizationsRead);

api.MapGet("/organizations/{organizationId:guid}", async (Guid organizationId, HttpContext context, OrganizationService service, CancellationToken ct) =>
    await service.GetAsync(GetTenantId(context), organizationId, ct) is { } organization
        ? Results.Ok(organization) : Results.NotFound()).RequireAuthorization(AtlasPermissions.OrganizationsRead);

api.MapPost("/organizations", async (CreateOrganizationRequest request, HttpContext context, ICurrentUser currentUser, OrganizationService service, CancellationToken ct) =>
{
    var organization = await service.CreateAsync(GetTenantId(context), request.Name, currentUser.UserId, ct);
    return Results.Created($"/api/v1/organizations/{organization.Id}", organization);
}).RequireAuthorization(AtlasPermissions.OrganizationsWrite);

api.MapGet("/organizations/{organizationId:guid}/facilities", async (Guid organizationId, HttpContext context, FacilityService service, CancellationToken ct) =>
    Results.Ok(await service.ListAsync(GetTenantId(context), organizationId, ct))).RequireAuthorization(AtlasPermissions.FacilitiesRead);

api.MapPost("/organizations/{organizationId:guid}/facilities", async (Guid organizationId, CreateFacilityRequest request, HttpContext context, ICurrentUser currentUser, FacilityService service, CancellationToken ct) =>
{
    var facility = await service.CreateAsync(GetTenantId(context), organizationId, request.Name, request.Code, currentUser.UserId, ct);
    return Results.Created($"/api/v1/facilities/{facility.Id}", facility);
}).RequireAuthorization(AtlasPermissions.FacilitiesWrite);

api.MapGet("/facilities/{facilityId:guid}", async (Guid facilityId, HttpContext context, FacilityService service, CancellationToken ct) =>
    await service.GetAsync(GetTenantId(context), facilityId, ct) is { } facility
        ? Results.Ok(facility) : Results.NotFound()).RequireAuthorization(AtlasPermissions.FacilitiesRead);

api.MapGet("/users", async (HttpContext context, IdentityService service, CancellationToken ct) =>
    Results.Ok(await service.ListUsersAsync(GetTenantId(context), ct))).RequireAuthorization(AtlasPermissions.UsersRead);

api.MapPost("/users", async (CreateUserRequest request, ICurrentUser currentUser, IdentityService service, CancellationToken ct) =>
{
    var user = await service.CreateUserAsync(currentUser.TenantId, request.Email, request.DisplayName, currentUser.UserId, ct);
    return Results.Created($"/api/v1/users/{user.Id}", user);
}).RequireAuthorization(AtlasPermissions.UsersWrite);


api.MapGet("/workflow-definitions", async (HttpContext context, WorkflowService service, CancellationToken ct) =>
    Results.Ok(await service.ListDefinitionsAsync(GetTenantId(context), ct))).RequireAuthorization(AtlasPermissions.WorkflowsRead);
api.MapPost("/workflow-definitions", async (CreateWorkflowDefinitionRequest request, HttpContext context, ICurrentUser user, WorkflowService service, CancellationToken ct) =>
{
    var item=await service.CreateDefinitionAsync(GetTenantId(context),request.Key,request.Name,request.InitialState,request.States,request.Transitions,user.UserId,ct);
    return Results.Created($"/api/v1/workflow-definitions/{item.Id}",item);
}).RequireAuthorization(AtlasPermissions.WorkflowsAdmin);
api.MapPost("/workflow-definitions/{definitionId:guid}/publish", async (Guid definitionId,HttpContext context,ICurrentUser user,WorkflowService service,CancellationToken ct) =>
    Results.Ok(await service.PublishDefinitionAsync(GetTenantId(context),definitionId,user.UserId,ct))).RequireAuthorization(AtlasPermissions.WorkflowsAdmin);
api.MapGet("/workflow-instances", async (HttpContext context,WorkflowService service,CancellationToken ct) =>
    Results.Ok(await service.ListInstancesAsync(GetTenantId(context),ct))).RequireAuthorization(AtlasPermissions.WorkflowsRead);
api.MapPost("/workflow-instances", async (StartWorkflowRequest request,HttpContext context,ICurrentUser user,WorkflowService service,CancellationToken ct) =>
{
    var item=await service.StartAsync(GetTenantId(context),request.DefinitionId,request.SubjectType,request.SubjectId,request.DueAt,user.UserId,ct);
    return Results.Created($"/api/v1/workflow-instances/{item.Id}",item);
}).RequireAuthorization(AtlasPermissions.WorkflowsWrite);
api.MapPost("/workflow-instances/{instanceId:guid}/transitions", async (Guid instanceId,TransitionWorkflowRequest request,HttpContext context,ICurrentUser user,WorkflowService service,CancellationToken ct) =>
    Results.Ok(await service.TransitionAsync(GetTenantId(context),instanceId,request.Transition,user.UserId,ct))).RequireAuthorization(AtlasPermissions.WorkflowsWrite);
api.MapGet("/workflow-tasks", async (Guid? instanceId,HttpContext context,WorkflowService service,CancellationToken ct) =>
    Results.Ok(await service.ListTasksAsync(GetTenantId(context),instanceId,ct))).RequireAuthorization(AtlasPermissions.WorkflowsRead);
api.MapPost("/workflow-instances/{instanceId:guid}/tasks", async (Guid instanceId,CreateWorkflowTaskRequest request,HttpContext context,ICurrentUser user,WorkflowService service,CancellationToken ct) =>
{
    var item=await service.CreateTaskAsync(GetTenantId(context),instanceId,request.Title,request.AssigneeUserId,request.AssigneeRoleId,request.DueAt,user.UserId,ct);
    return Results.Created($"/api/v1/workflow-tasks/{item.Id}",item);
}).RequireAuthorization(AtlasPermissions.WorkflowsWrite);
api.MapPost("/workflow-tasks/{taskId:guid}/complete", async (Guid taskId,HttpContext context,ICurrentUser user,WorkflowService service,CancellationToken ct) =>
    Results.Ok(await service.CompleteTaskAsync(GetTenantId(context),taskId,user.UserId,ct))).RequireAuthorization(AtlasPermissions.WorkflowsWrite);

app.Run();

static Guid GetTenantId(HttpContext context) => (Guid)context.Items["TenantId"]!;
public partial class Program;
