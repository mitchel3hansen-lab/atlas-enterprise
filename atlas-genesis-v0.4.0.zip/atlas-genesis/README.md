# ATLAS Genesis

ATLAS is a modular operational-intelligence platform for safety, risk, compliance, emergency management, quality, industrial hygiene, and future operational domains.

## Genesis scope

This repository establishes the first executable platform foundation:

- engineering governance and architecture decision records;
- canonical entity and domain-event contracts;
- tenant-aware organization and facility models;
- a minimal ASP.NET Core Platform API skeleton;
- an OpenAPI-first contract;
- initial PostgreSQL migration;
- Atlas Safety product boundary;
- CI, container, security, and contribution templates.

## Repository map

```text
platform/           Shared runtime services and application infrastructure
sdk/                Reusable contracts and developer-facing abstractions
domain/             Canonical domain definitions and bounded-context records
products/           Commercial products built on the platform
infrastructure/     Docker, Terraform, deployment, and operations assets
docs/               Handbook, architecture, ADRs, product, and API documentation
database/           Versioned database migrations
```

## Local start

Prerequisites: .NET 8 SDK and Docker.

```bash
docker compose -f infrastructure/docker/docker-compose.yml up -d
dotnet restore Atlas.sln
dotnet build Atlas.sln --configuration Release
dotnet run --project platform/src/Atlas.Platform.Api
```

The API exposes health endpoints and the first organization/facility routes. The authoritative contract is in `docs/api/platform-core.openapi.yaml`.

## Current maturity

**Release:** Genesis 0.3.0  
**Status:** Foundation skeleton  
**Next vertical slice:** workflow and domain-event infrastructure.

## Genesis Sprint 002

Version 0.2.0 adds tenant-aware PostgreSQL persistence, organization and facility APIs, structured validation/conflict responses, audit entries, and migration operations guidance.

### Local start

```bash
docker compose -f infrastructure/docker/docker-compose.yml up -d
psql "postgresql://atlas:atlas_dev_only@localhost:5432/atlas" -f database/migrations/V001__foundation.sql
psql "postgresql://atlas:atlas_dev_only@localhost:5432/atlas" -f database/migrations/V002__tenant_persistence_and_audit.sql
dotnet run --project platform/src/Atlas.Platform.Api
```

## Genesis Sprint 003

Version 0.3.0 replaces the bootstrap tenant header trust model with JWT bearer authentication, tenant claims, named permission policies, tenant users, roles, permission persistence, and identity operations guidance.

After applying V003, obtain a local development token from `/api/v1/auth/dev-token` and send it as a bearer token. The endpoint is disabled outside the Development environment.


## Workflow quick start
Create a definition, publish it, start an instance for a subject record, then invoke named transitions. See `docs/architecture/workflow-and-events.md`.
