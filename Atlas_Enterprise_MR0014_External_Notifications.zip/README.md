# Atlas Enterprise

Atlas is an operational intelligence platform with a closed-loop incident workflow, secured work queues, in-app notifications, and external delivery support.

## Notification channels

- In-app
- Email through a configurable provider
- Microsoft Teams webhook

Local development uses a log-only email provider unless another provider is configured.

## Start Atlas

```bash
cp .env.example .env
docker compose up --build -d
```

## Notification operations

```text
POST /api/notifications/run-cycle
POST /api/notifications/run-delivery
GET  /api/notification-preferences
PUT  /api/notification-preferences
```

## Important

Do not commit SMTP passwords, Graph credentials, webhook URLs, or provider API keys. Store them in environment variables or a managed secrets service.
