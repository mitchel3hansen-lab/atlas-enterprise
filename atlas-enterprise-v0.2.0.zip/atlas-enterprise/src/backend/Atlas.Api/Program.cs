using Atlas.Application;
using Atlas.Infrastructure;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddProblemDetails();
builder.Services.AddOpenApi();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<AtlasDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("Atlas")));
builder.Services.AddScoped<IOrganizationRepository, OrganizationRepository>();
builder.Services.AddScoped<IAuditWriter, AuditWriter>();
builder.Services.AddScoped<OrganizationService>();

var app = builder.Build();

app.UseExceptionHandler(exceptionHandlerApp => exceptionHandlerApp.Run(async context =>
{
    var exception = context.Features.Get<Microsoft.AspNetCore.Diagnostics.IExceptionHandlerFeature>()?.Error;
    var (status, title) = exception switch
    {
        KeyNotFoundException => (StatusCodes.Status404NotFound, "Resource not found"),
        ArgumentException or InvalidOperationException => (StatusCodes.Status400BadRequest, "Request could not be completed"),
        _ => (StatusCodes.Status500InternalServerError, "Unexpected server error")
    };

    await Results.Problem(statusCode: status, title: title, detail: exception?.Message).ExecuteAsync(context);
}));
app.UseSwagger();
app.UseSwaggerUI();

app.MapGet("/health", () => Results.Ok(new { status = "healthy", service = "atlas-api" }));

var organizations = app.MapGroup("/api/v1/organizations").WithTags("Organizations");

organizations.MapGet("/", async (IOrganizationRepository repository, CancellationToken ct) =>
    Results.Ok(await repository.ListAsync(ct)));

organizations.MapGet("/{id:guid}", async (Guid id, IOrganizationRepository repository, CancellationToken ct) =>
{
    var organization = await repository.GetAsync(id, ct);
    return organization is null ? Results.NotFound() : Results.Ok(organization);
});

organizations.MapPost("/", async (CreateOrganizationRequest request, OrganizationService service, CancellationToken ct) =>
{
    var organization = await service.CreateAsync(request.Name, request.Code, ct);
    return Results.Created($"/api/v1/organizations/{organization.Id}", organization);
});

organizations.MapGet("/{organizationId:guid}/facilities", async (
    Guid organizationId,
    HttpRequest request,
    IOrganizationRepository repository,
    CancellationToken ct) =>
{
    if (!TenantMatches(request, organizationId)) return Results.Forbid();
    var organization = await repository.GetAsync(organizationId, ct);
    return organization is null ? Results.NotFound() : Results.Ok(organization.Facilities);
});

organizations.MapPost("/{organizationId:guid}/facilities", async (
    Guid organizationId,
    CreateFacilityRequest body,
    HttpRequest request,
    OrganizationService service,
    CancellationToken ct) =>
{
    if (!TenantMatches(request, organizationId)) return Results.Forbid();
    var facility = await service.AddFacilityAsync(organizationId, body.Name, body.Code, ct);
    return Results.Created($"/api/v1/organizations/{organizationId}/facilities/{facility.Id}", facility);
});

organizations.MapGet("/{organizationId:guid}/departments", async (
    Guid organizationId,
    HttpRequest request,
    IOrganizationRepository repository,
    CancellationToken ct) =>
{
    if (!TenantMatches(request, organizationId)) return Results.Forbid();
    var organization = await repository.GetAsync(organizationId, ct);
    return organization is null ? Results.NotFound() : Results.Ok(organization.Departments);
});

organizations.MapPost("/{organizationId:guid}/departments", async (
    Guid organizationId,
    CreateDepartmentRequest body,
    HttpRequest request,
    OrganizationService service,
    CancellationToken ct) =>
{
    if (!TenantMatches(request, organizationId)) return Results.Forbid();
    var department = await service.AddDepartmentAsync(
        organizationId, body.Name, body.FacilityId, body.ParentDepartmentId, ct);
    return Results.Created($"/api/v1/organizations/{organizationId}/departments/{department.Id}", department);
});

app.Run();

static bool TenantMatches(HttpRequest request, Guid organizationId) =>
    request.Headers.TryGetValue("X-Atlas-Organization-Id", out var header) &&
    Guid.TryParse(header, out var tenantId) &&
    tenantId == organizationId;

public sealed record CreateOrganizationRequest(string Name, string Code);
public sealed record CreateFacilityRequest(string Name, string Code);
public sealed record CreateDepartmentRequest(string Name, Guid? FacilityId, Guid? ParentDepartmentId);

public partial class Program;
