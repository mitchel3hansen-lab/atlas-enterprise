namespace Atlas.Domain;

public abstract class Entity
{
    protected Entity(Guid id) => Id = id;

    public Guid Id { get; }
    public DateTimeOffset CreatedAt { get; protected init; } = DateTimeOffset.UtcNow;
    public DateTimeOffset UpdatedAt { get; protected set; } = DateTimeOffset.UtcNow;
    public bool IsArchived { get; protected set; }

    public void Archive()
    {
        IsArchived = true;
        UpdatedAt = DateTimeOffset.UtcNow;
    }
}
