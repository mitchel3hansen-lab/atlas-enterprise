namespace Atlas.Domain;

public sealed class Department : Entity
{
    private Department(Guid id, Guid organizationId, string name, Guid? facilityId, Guid? parentDepartmentId) : base(id)
    {
        OrganizationId = organizationId;
        Name = string.IsNullOrWhiteSpace(name) ? throw new ArgumentException("Department name is required.") : name.Trim();
        FacilityId = facilityId;
        ParentDepartmentId = parentDepartmentId;
    }

    public Guid OrganizationId { get; }
    public Guid? FacilityId { get; }
    public Guid? ParentDepartmentId { get; }
    public string Name { get; private set; }

    internal static Department Create(Guid organizationId, string name, Guid? facilityId, Guid? parentDepartmentId) =>
        new(Guid.NewGuid(), organizationId, name, facilityId, parentDepartmentId);
}
