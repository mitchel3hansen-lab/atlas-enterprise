namespace Atlas.Domain;

public sealed class Facility : Entity
{
    private Facility(Guid id, Guid organizationId, string name, string code) : base(id)
    {
        OrganizationId = organizationId;
        Name = string.IsNullOrWhiteSpace(name) ? throw new ArgumentException("Facility name is required.") : name.Trim();
        Code = string.IsNullOrWhiteSpace(code) ? throw new ArgumentException("Facility code is required.") : code.Trim().ToUpperInvariant();
    }

    public Guid OrganizationId { get; }
    public string Name { get; private set; }
    public string Code { get; private set; }

    internal static Facility Create(Guid organizationId, string name, string code) =>
        new(Guid.NewGuid(), organizationId, name, code);
}
