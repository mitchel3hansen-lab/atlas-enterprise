using Atlas.Application;
using Atlas.Domain;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Infrastructure;

public sealed class OrganizationRepository(AtlasDbContext dbContext) : IOrganizationRepository
{
    public async Task AddAsync(Organization organization, CancellationToken cancellationToken)
    {
        dbContext.Organizations.Add(organization);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    public Task<Organization?> GetAsync(Guid id, CancellationToken cancellationToken) =>
        dbContext.Organizations
            .Include(x => x.Facilities)
            .Include(x => x.Departments)
            .SingleOrDefaultAsync(x => x.Id == id, cancellationToken);

    public async Task<IReadOnlyList<Organization>> ListAsync(CancellationToken cancellationToken) =>
        await dbContext.Organizations.AsNoTracking().OrderBy(x => x.Name).ToListAsync(cancellationToken);

    public Task SaveChangesAsync(CancellationToken cancellationToken) =>
        dbContext.SaveChangesAsync(cancellationToken);
}
