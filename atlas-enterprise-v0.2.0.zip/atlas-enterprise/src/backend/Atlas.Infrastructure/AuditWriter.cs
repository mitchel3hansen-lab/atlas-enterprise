using System.Text.Json;
using Atlas.Application;

namespace Atlas.Infrastructure;

public sealed class AuditWriter(AtlasDbContext dbContext) : IAuditWriter
{
    public async Task WriteAsync(
        Guid? organizationId,
        string action,
        string resourceType,
        Guid? resourceId,
        object? payload,
        CancellationToken cancellationToken)
    {
        dbContext.AuditEvents.Add(new AuditEvent
        {
            OrganizationId = organizationId,
            Action = action,
            ResourceType = resourceType,
            ResourceId = resourceId,
            Payload = JsonSerializer.Serialize(payload ?? new { })
        });
        await dbContext.SaveChangesAsync(cancellationToken);
    }
}
