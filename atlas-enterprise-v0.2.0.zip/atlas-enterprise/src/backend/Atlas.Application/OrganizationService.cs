using Atlas.Domain;

namespace Atlas.Application;

public sealed class OrganizationService(IOrganizationRepository repository, IAuditWriter auditWriter)
{
    public async Task<Organization> CreateAsync(string name, string code, CancellationToken cancellationToken)
    {
        var organization = Organization.Create(name, code);
        await repository.AddAsync(organization, cancellationToken);
        await auditWriter.WriteAsync(organization.Id, "organization.created", "organization", organization.Id,
            new { organization.Name, organization.Code }, cancellationToken);
        return organization;
    }

    public async Task<Facility> AddFacilityAsync(
        Guid organizationId,
        string name,
        string code,
        CancellationToken cancellationToken)
    {
        var organization = await RequireOrganizationAsync(organizationId, cancellationToken);
        var facility = organization.AddFacility(name, code);
        await repository.SaveChangesAsync(cancellationToken);
        await auditWriter.WriteAsync(organizationId, "facility.created", "facility", facility.Id,
            new { facility.Name, facility.Code }, cancellationToken);
        return facility;
    }

    public async Task<Department> AddDepartmentAsync(
        Guid organizationId,
        string name,
        Guid? facilityId,
        Guid? parentDepartmentId,
        CancellationToken cancellationToken)
    {
        var organization = await RequireOrganizationAsync(organizationId, cancellationToken);
        var department = organization.AddDepartment(name, facilityId, parentDepartmentId);
        await repository.SaveChangesAsync(cancellationToken);
        await auditWriter.WriteAsync(organizationId, "department.created", "department", department.Id,
            new { department.Name, department.FacilityId, department.ParentDepartmentId }, cancellationToken);
        return department;
    }

    private async Task<Organization> RequireOrganizationAsync(Guid organizationId, CancellationToken cancellationToken) =>
        await repository.GetAsync(organizationId, cancellationToken)
        ?? throw new KeyNotFoundException($"Organization '{organizationId}' was not found.");
}
