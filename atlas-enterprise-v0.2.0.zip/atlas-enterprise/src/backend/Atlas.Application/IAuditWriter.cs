namespace Atlas.Application;

public interface IAuditWriter
{
    Task WriteAsync(
        Guid? organizationId,
        string action,
        string resourceType,
        Guid? resourceId,
        object? payload,
        CancellationToken cancellationToken);
}
