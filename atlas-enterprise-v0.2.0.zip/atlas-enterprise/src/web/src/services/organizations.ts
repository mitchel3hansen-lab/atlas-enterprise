export type Organization = {
  id: string;
  name: string;
  code: string;
  isArchived: boolean;
  createdAt: string;
  updatedAt: string;
};

export type CreateOrganization = {
  name: string;
  code: string;
};

const baseUrl = import.meta.env.VITE_ATLAS_API_URL ?? 'http://localhost:5080/api/v1';

async function parseResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const problem = await response.json().catch(() => null) as { detail?: string } | null;
    throw new Error(problem?.detail ?? `Atlas API returned ${response.status}.`);
  }
  return response.json() as Promise<T>;
}

export async function listOrganizations(): Promise<Organization[]> {
  return parseResponse<Organization[]>(await fetch(`${baseUrl}/organizations`));
}

export async function createOrganization(input: CreateOrganization): Promise<Organization> {
  return parseResponse<Organization>(await fetch(`${baseUrl}/organizations`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  }));
}
