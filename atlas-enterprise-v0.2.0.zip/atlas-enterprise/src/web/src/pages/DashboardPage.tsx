const cards = [
  ['Organizations', '1', 'Operational structures'],
  ['Open Actions', '0', 'Workflow readiness'],
  ['Installed Packs', '0', 'Exchange foundation'],
  ['Platform Health', 'Ready', 'Genesis environment'],
];

export function DashboardPage() {
  return (
    <section>
      <header className="page-header">
        <div>
          <p className="eyebrow">Mission Control</p>
          <h1>Atlas Core Genesis</h1>
          <p>One platform for knowledge, workflow, intelligence, and improvement.</p>
        </div>
        <button type="button">Create organization</button>
      </header>
      <div className="card-grid">
        {cards.map(([label, value, note]) => (
          <article className="metric-card" key={label}>
            <p>{label}</p>
            <strong>{value}</strong>
            <span>{note}</span>
          </article>
        ))}
      </div>
      <article className="panel">
        <h2>Genesis milestone</h2>
        <p>Organization → Facility → Department → User → Role → Dashboard</p>
        <div className="progress"><span /></div>
        <small>Foundation repository and first vertical slice established.</small>
      </article>
    </section>
  );
}
