import { NavLink, Route, Routes } from 'react-router-dom';
import { DashboardPage } from './pages/DashboardPage';
import { OrganizationsPage } from './pages/OrganizationsPage';

export function App() {
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">ATLAS</div>
        <div className="brand-subtitle">Operational Intelligence</div>
        <nav aria-label="Primary navigation">
          <NavLink to="/">Mission Control</NavLink>
          <NavLink to="/organizations">Organizations</NavLink>
          <span aria-disabled="true">Risk</span>
          <span aria-disabled="true">Knowledge</span>
          <span aria-disabled="true">Exchange</span>
        </nav>
      </aside>
      <main className="content">
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/organizations" element={<OrganizationsPage />} />
        </Routes>
      </main>
    </div>
  );
}
