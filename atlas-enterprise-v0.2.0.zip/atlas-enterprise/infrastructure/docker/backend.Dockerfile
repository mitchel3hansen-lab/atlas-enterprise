FROM mcr.microsoft.com/dotnet/sdk:9.0 AS build
WORKDIR /src
COPY src/backend ./src/backend
COPY tests ./tests
RUN dotnet restore src/backend/Atlas.sln
RUN dotnet publish src/backend/Atlas.Api/Atlas.Api.csproj -c Release -o /app

FROM mcr.microsoft.com/dotnet/aspnet:9.0
WORKDIR /app
COPY --from=build /app .
EXPOSE 8080
ENTRYPOINT ["dotnet", "Atlas.Api.dll"]
