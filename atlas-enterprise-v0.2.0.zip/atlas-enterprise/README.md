# Atlas Enterprise

Atlas Enterprise is an operational intelligence platform designed to help organizations capture knowledge, execute consistently, improve continuously, and make better decisions.

## Genesis Release

This repository contains the first implementation-ready vertical slice of Atlas Core:

- Organizations
- Facilities
- Departments
- Users and roles (contract placeholders)
- Audit-ready domain foundations
- ASP.NET Core solution skeleton
- React + TypeScript application shell
- PostgreSQL schema
- OpenAPI contract
- Docker development environment
- GitHub Actions validation pipeline

## Repository Map

```text
src/backend       .NET application and domain projects
src/web           React application shell
database          PostgreSQL schema and migrations
openapi           API contract
tests             Automated test projects
docs              Governance, architecture, and product documents
adr               Architecture Decision Records
infrastructure    Docker and deployment assets
```

## Local Development

### Prerequisites

- .NET 9 SDK
- Node.js 22+
- Docker Desktop

### Start PostgreSQL

```bash
docker compose up -d postgres
```

### Backend

```bash
cd src/backend
dotnet restore
dotnet run --project Atlas.Api
```

### Frontend

```bash
cd src/web
npm install
npm run dev
```

The API defaults to `http://localhost:5080`; the web app defaults to `http://localhost:5173`.

## First Vertical Slice

1. Create an organization.
2. Add facilities.
3. Add departments.
4. View the organization structure.
5. Capture an auditable record of changes.

## Status

**Version:** 0.1.0-genesis  
**Lifecycle:** Foundation / active development

## Current Increment — 0.2.0

Sprint 001.2 completes the first organization-management vertical slice: organization creation in the web shell, tenant-scoped facility and department endpoints, aggregate boundary validation, and immutable audit events. See `docs/product/sprint-001-2-organization-vertical-slice.md`.
