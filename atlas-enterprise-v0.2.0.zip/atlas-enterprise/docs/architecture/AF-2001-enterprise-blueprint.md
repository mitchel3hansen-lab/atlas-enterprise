# AF-2001 — Atlas Enterprise Blueprint

- **Version:** 0.1.0
- **Status:** Approved for Genesis implementation

## Platform Identity

Atlas Enterprise is an Operational Intelligence Platform built from four engines:

1. Knowledge Engine
2. Workflow Engine
3. Intelligence Engine
4. Improvement Engine

## Core Capabilities

- Identity and authorization
- Organization hierarchy
- Documents and evidence
- Search
- Notifications
- Audit
- Configuration
- Reporting
- Relationships
- APIs and integrations

## Products

- Atlas Risk
- Atlas Safety
- Atlas Emergency
- Atlas Quality
- Atlas Learning
- Mission Control

## Ecosystem

- Atlas Exchange distributes reusable packs.
- Atlas Studio authors knowledge, workflows, dashboards, and packs.
- Atlas SDK enables extensions and integrations.

## Architectural Rule

A reusable capability used by two or more products belongs in the platform. Domain-specific behavior remains in its product bounded context.
