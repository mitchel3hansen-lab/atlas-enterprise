# Atlas Core Domain Model

## Aggregate: Organization

An Organization is the tenant-level operational entity. It owns facilities, departments, users, and configuration.

### Invariants

- Organization name is required.
- Organization code is unique within the platform.
- Archived organizations cannot receive new facilities.

## Aggregate: Facility

A Facility represents a physical or logical operating location.

### Invariants

- Facility belongs to exactly one organization.
- Facility code is unique within its organization.

## Entity: Department

A Department belongs to an organization and may optionally belong to a facility or parent department.

### Relationships

```text
Organization 1 ── * Facility
Organization 1 ── * Department
Facility     0..1 ── * Department
Department   0..1 ── * Department
```
