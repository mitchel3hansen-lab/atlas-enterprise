# Atlas Engineering Handbook

## Architecture

Atlas uses Domain-Driven Design with a ports-and-adapters structure:

```text
API / Presentation
Application
Domain
Infrastructure
```

The Domain project must not reference infrastructure or web frameworks.

## Engineering Laws

- Platform before product.
- Knowledge before automation.
- Relationships before reports.
- Composition before duplication.
- Documentation before assumptions.
- Quality and traceability over raw speed.

## Required Traceability

Vision → ADR → Specification → Issue → Code → Test → Release

## Review Standard

Every change must address correctness, maintainability, security, accessibility, observability, and customer value.
