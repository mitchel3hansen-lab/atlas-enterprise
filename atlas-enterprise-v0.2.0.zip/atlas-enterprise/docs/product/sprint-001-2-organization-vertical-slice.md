# Sprint 001.2 — Organization Vertical Slice

**Status:** Implemented  
**Release:** 0.2.0

## Scope

This increment turns the Genesis organization model into the first end-to-end Atlas Core workflow.

## Delivered

- Organization creation form in the React shell.
- Facility list/create endpoints scoped to an organization.
- Department list/create endpoints scoped to an organization.
- Tenant-context enforcement using `X-Atlas-Organization-Id` for nested resources.
- Organization aggregate validation for facility and parent-department relationships.
- Immutable audit-event writes for organization, facility, and department creation.
- RFC 7807 error responses.
- OpenAPI 3.1 contract updated to version 0.2.0.
- Domain tests for tenant-boundary rules and archived organizations.

## Security Boundary

The header-based tenant context is an explicit bootstrap mechanism, not production authentication. Sprint 001.3 must replace it with authenticated claims and policy-based authorization while preserving route/tenant matching.

## Acceptance Criteria

1. A user can create an organization from the web shell.
2. Nested facility and department endpoints reject a missing or mismatched tenant header.
3. A department cannot reference a facility or parent department outside its organization aggregate.
4. Create operations emit an audit event.
5. The web application builds successfully.
