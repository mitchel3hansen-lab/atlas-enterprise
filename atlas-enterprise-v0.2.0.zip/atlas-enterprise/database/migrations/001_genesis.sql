CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE SCHEMA IF NOT EXISTS core;
CREATE SCHEMA IF NOT EXISTS audit;

CREATE TABLE core.organizations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name varchar(200) NOT NULL,
    code varchar(50) NOT NULL UNIQUE,
    is_archived boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE core.facilities (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL REFERENCES core.organizations(id),
    name varchar(200) NOT NULL,
    code varchar(50) NOT NULL,
    is_archived boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, code)
);

CREATE TABLE core.departments (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL REFERENCES core.organizations(id),
    facility_id uuid NULL REFERENCES core.facilities(id),
    parent_department_id uuid NULL REFERENCES core.departments(id),
    name varchar(200) NOT NULL,
    is_archived boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE core.users (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL REFERENCES core.organizations(id),
    email varchar(320) NOT NULL,
    display_name varchar(200) NOT NULL,
    status varchar(30) NOT NULL DEFAULT 'invited',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, email)
);

CREATE TABLE core.roles (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NULL REFERENCES core.organizations(id),
    name varchar(100) NOT NULL,
    description text NULL,
    is_system boolean NOT NULL DEFAULT false,
    UNIQUE (organization_id, name)
);

CREATE TABLE core.user_roles (
    user_id uuid NOT NULL REFERENCES core.users(id) ON DELETE CASCADE,
    role_id uuid NOT NULL REFERENCES core.roles(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, role_id)
);

CREATE TABLE audit.events (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NULL,
    actor_id uuid NULL,
    action varchar(100) NOT NULL,
    resource_type varchar(100) NOT NULL,
    resource_id uuid NULL,
    occurred_at timestamptz NOT NULL DEFAULT now(),
    payload jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX ix_facilities_organization ON core.facilities(organization_id);
CREATE INDEX ix_departments_organization ON core.departments(organization_id);
CREATE INDEX ix_users_organization ON core.users(organization_id);
CREATE INDEX ix_audit_events_org_time ON audit.events(organization_id, occurred_at DESC);
