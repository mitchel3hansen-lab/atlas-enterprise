INSERT INTO core.organizations (name, code)
VALUES ('Atlas Technologies', 'ATLAS')
ON CONFLICT (code) DO NOTHING;
