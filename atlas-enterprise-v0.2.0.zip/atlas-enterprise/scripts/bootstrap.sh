#!/usr/bin/env bash
set -euo pipefail

echo "Starting Atlas PostgreSQL..."
docker compose up -d postgres

echo "Atlas Genesis environment is ready."
echo "Backend: cd src/backend && dotnet run --project Atlas.Api"
echo "Frontend: cd src/web && npm install && npm run dev"
