# Sprint 001 — Atlas Core Genesis

## Sprint Goal

Deliver the first runnable organization-management vertical slice.

## Backlog

### Done in repository bootstrap
- [x] Repository governance and templates
- [x] Company charter and enterprise blueprint
- [x] Core domain objects
- [x] PostgreSQL schema
- [x] OpenAPI contract
- [x] Backend API skeleton
- [x] React Mission Control shell
- [x] Docker database environment
- [x] CI pipeline

### Next implementation work
- [ ] Add facility API endpoints
- [ ] Add department API endpoints
- [ ] Add authentication provider and JWT validation
- [ ] Add tenant-scoped authorization policies
- [ ] Add immutable audit event writer
- [ ] Add create-organization UI form
- [ ] Add API integration tests
- [ ] Generate and commit EF Core migration
- [ ] Add observability and structured logging
- [ ] Deploy first development environment
