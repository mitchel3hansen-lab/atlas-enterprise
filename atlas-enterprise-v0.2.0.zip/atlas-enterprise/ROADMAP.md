# Atlas Roadmap

## Milestone 1 — Atlas Core Genesis
- Organization hierarchy
- User identity and role foundations
- Audit trail
- Dashboard shell

## Milestone 2 — Workflow and Knowledge
- Tasks, approvals, notifications
- Knowledge objects and relationships
- Knowledge Pack manifest

## Milestone 3 — Atlas Risk Alpha
- Hazards, risks, controls
- Corrective actions
- Risk heat map
- Mission Control summary

## Milestone 4 — Atlas Exchange
- Pack validation
- Dependency resolution
- Installation lifecycle
- Trust and certification model
