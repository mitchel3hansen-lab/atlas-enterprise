using Atlas.Domain;

namespace Atlas.Domain.Tests;

public sealed class OrganizationTests
{
    [Fact]
    public void Create_NormalizesCode()
    {
        var organization = Organization.Create("Atlas Technologies", " atlas ");
        Assert.Equal("ATLAS", organization.Code);
    }

    [Fact]
    public void AddFacility_RejectsDuplicateCode()
    {
        var organization = Organization.Create("Atlas Technologies", "ATLAS");
        organization.AddFacility("North", "NORTH");
        Assert.Throws<InvalidOperationException>(() => organization.AddFacility("North 2", "north"));
    }

    [Fact]
    public void AddDepartment_RejectsFacilityFromAnotherOrganization()
    {
        var organization = Organization.Create("Atlas", "ATL");
        var exception = Assert.Throws<InvalidOperationException>(
            () => organization.AddDepartment("Safety", Guid.NewGuid()));
        Assert.Contains("facility does not belong", exception.Message);
    }

    [Fact]
    public void ArchivedOrganization_RejectsNewDepartment()
    {
        var organization = Organization.Create("Atlas", "ATL");
        organization.Archive();
        var exception = Assert.Throws<InvalidOperationException>(() => organization.AddDepartment("Safety"));
        Assert.Equal("Archived organizations cannot be modified.", exception.Message);
    }
}
