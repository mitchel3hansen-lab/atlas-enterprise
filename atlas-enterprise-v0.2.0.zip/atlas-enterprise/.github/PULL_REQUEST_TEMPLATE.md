## Purpose

## Linked Requirement / Issue

## Changes

## Validation
- [ ] Tests added or updated
- [ ] OpenAPI updated if applicable
- [ ] Documentation updated
- [ ] Security impact reviewed
- [ ] Accessibility impact reviewed
- [ ] Changelog updated

## Screenshots / Evidence
