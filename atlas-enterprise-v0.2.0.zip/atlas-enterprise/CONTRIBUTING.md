# Contributing to Atlas Enterprise

## Engineering Workflow

1. Link work to a requirement, issue, or ADR.
2. Branch from `main` using `feature/<issue>-<description>`.
3. Keep domain rules inside `Atlas.Domain`.
4. Add or update automated tests.
5. Update OpenAPI and documentation when contracts change.
6. Submit a pull request using the repository template.
7. Obtain review before merge.

## Definition of Done

A change is complete when implementation, tests, documentation, security impact,
accessibility impact, and release notes have been addressed.
