# ADR-003 — UUID Identifiers and Organization Tenancy

- **Status:** Accepted
- **Date:** 2026-07-22

## Decision

All business resources use UUID identifiers. Organization-owned records include `organization_id`; authorization and data access must enforce tenant boundaries.

## Consequences

- Database indexes must include tenant keys where appropriate.
- API routes may use resource IDs, but tenant authorization remains mandatory.
- Future row-level security can reinforce application controls.
