# ADR-001 — Platform-First, Domain-Driven Architecture

- **Status:** Accepted
- **Date:** 2026-07-22

## Context

Atlas will support multiple operational products without duplicating identity, workflow, knowledge, reporting, and audit capabilities.

## Decision

Use Domain-Driven Design and ports-and-adapters architecture. Generic capabilities belong to Atlas Core; product logic belongs to bounded contexts.

## Consequences

- Domain projects remain framework-independent.
- Product modules cannot bypass platform authorization or audit services.
- Shared abstractions must prove reuse before entering Atlas Core.
