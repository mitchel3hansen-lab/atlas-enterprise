# ADR-002 — Genesis Technology Stack

- **Status:** Accepted
- **Date:** 2026-07-22

## Decision

- Backend: ASP.NET Core on .NET 9 and C#
- Frontend: React, TypeScript, and Vite
- Database: PostgreSQL
- Contract: OpenAPI 3.1
- Packaging: Docker
- CI: GitHub Actions
- Initial hosting target: Azure

## Rationale

The stack supports enterprise security, strong typing, testability, portability, and a broad engineering ecosystem.
