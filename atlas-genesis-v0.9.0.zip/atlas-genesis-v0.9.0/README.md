# ATLAS Genesis v0.9.0

ATLAS is a multi-tenant Operational Intelligence Platform. This increment establishes the first enforceable identity, authorization, and tenant-isolation boundary.

## Added in v0.9.0

- JWT bearer authentication with issuer, audience, signature, and expiration validation
- Users and organization memberships
- Configurable roles and stable permission codes
- Permission-based ASP.NET authorization policies
- Tenant context derived from validated token claims—not request headers
- PBKDF2-SHA256 password hashing with per-password salts
- Development-only tenant/admin bootstrap endpoint
- Login endpoint that issues tenant-bound access tokens
- Identity schema migration and security architecture documentation
- Automated tests for anonymous access and header-based tenant override attempts

## Quick start

Prerequisites: Docker Desktop with Docker Compose.

```bash
docker compose up --build
```

Services:

- Web: http://localhost:5173
- API: http://localhost:8080
- Swagger: http://localhost:8080/swagger
- API health: http://localhost:8080/health
- PostgreSQL: localhost:5432

## Development authentication

Apply `apps/api/migrations/V009__identity_and_tenant_security.sql`, then:

1. POST `/api/v1/auth/development/bootstrap`
2. POST `/api/v1/auth/login`
3. Select **Authorize** in Swagger and paste the returned access token

The bootstrap endpoint is unavailable outside the Development environment.

## Production warning

The included signing key is development-only. Production must use a secret manager and should transition to an external OpenID Connect identity provider with asymmetric key rotation.

## Repository map

```text
apps/api        ASP.NET Core API
apps/web        React + TypeScript UI
docs            Product, architecture, governance, ADRs
infrastructure  Deployment and operations assets
tests           Automated security tests and test strategy
```

## Current milestone

Genesis Identity & Tenant Security: authenticated, tenant-bound access with policy-based authorization.
