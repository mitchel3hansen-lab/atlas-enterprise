using Atlas.Api.Domain;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Infrastructure;

public sealed class AtlasDbContext(DbContextOptions<AtlasDbContext> options) : DbContext(options)
{
    public DbSet<Organization> Organizations => Set<Organization>();
    public DbSet<Facility> Facilities => Set<Facility>();
    public DbSet<SafetyRecord> SafetyRecords => Set<SafetyRecord>();
    public DbSet<AtlasUser> Users => Set<AtlasUser>();
    public DbSet<OrganizationMembership> OrganizationMemberships => Set<OrganizationMembership>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<MembershipRole> MembershipRoles => Set<MembershipRole>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Organization>().HasKey(x => x.Id);
        modelBuilder.Entity<Organization>().HasIndex(x => x.Slug).IsUnique();

        modelBuilder.Entity<Facility>().HasKey(x => x.Id);
        modelBuilder.Entity<Facility>()
            .HasOne<Organization>()
            .WithMany()
            .HasForeignKey(x => x.OrganizationId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<SafetyRecord>().HasKey(x => x.Id);
        modelBuilder.Entity<SafetyRecord>()
            .HasIndex(x => new { x.OrganizationId, x.RecordType, x.Status });

        modelBuilder.Entity<AtlasUser>().HasKey(x => x.Id);
        modelBuilder.Entity<AtlasUser>().HasIndex(x => x.NormalizedEmail).IsUnique();
        modelBuilder.Entity<AtlasUser>().Property(x => x.Email).HasMaxLength(320);
        modelBuilder.Entity<AtlasUser>().Property(x => x.NormalizedEmail).HasMaxLength(320);
        modelBuilder.Entity<AtlasUser>().Property(x => x.DisplayName).HasMaxLength(200);

        modelBuilder.Entity<OrganizationMembership>().HasKey(x => x.Id);
        modelBuilder.Entity<OrganizationMembership>()
            .HasIndex(x => new { x.OrganizationId, x.UserId }).IsUnique();
        modelBuilder.Entity<OrganizationMembership>()
            .HasOne<Organization>().WithMany().HasForeignKey(x => x.OrganizationId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<OrganizationMembership>()
            .HasOne<AtlasUser>().WithMany().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Role>().HasKey(x => x.Id);
        modelBuilder.Entity<Role>()
            .HasIndex(x => new { x.OrganizationId, x.NormalizedName }).IsUnique();

        modelBuilder.Entity<Permission>().HasKey(x => x.Id);
        modelBuilder.Entity<Permission>().HasIndex(x => x.Code).IsUnique();

        modelBuilder.Entity<MembershipRole>().HasKey(x => new { x.MembershipId, x.RoleId });
        modelBuilder.Entity<RolePermission>().HasKey(x => new { x.RoleId, x.PermissionId });
    }
}
