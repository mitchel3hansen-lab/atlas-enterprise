namespace Atlas.Api.Domain;

public sealed record Organization(Guid Id, string Name, string Slug, DateTimeOffset CreatedAtUtc);

public sealed record Facility(
    Guid Id,
    Guid OrganizationId,
    string Name,
    string? TimeZone,
    DateTimeOffset CreatedAtUtc);

public sealed record SafetyRecord(
    Guid Id,
    Guid OrganizationId,
    Guid? FacilityId,
    string RecordType,
    string Title,
    string Status,
    string Severity,
    DateTimeOffset OccurredAtUtc,
    DateTimeOffset CreatedAtUtc);

public sealed class AtlasUser
{
    public Guid Id { get; init; }
    public required string Email { get; set; }
    public required string NormalizedEmail { get; set; }
    public required string DisplayName { get; set; }
    public required string PasswordHash { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTimeOffset CreatedAtUtc { get; init; }
}

public sealed class OrganizationMembership
{
    public Guid Id { get; init; }
    public Guid OrganizationId { get; init; }
    public Guid UserId { get; init; }
    public bool IsActive { get; set; } = true;
    public DateTimeOffset CreatedAtUtc { get; init; }
}

public sealed class Role
{
    public Guid Id { get; init; }
    public Guid? OrganizationId { get; init; }
    public required string Name { get; set; }
    public required string NormalizedName { get; set; }
    public bool IsSystemRole { get; init; }
}

public sealed class Permission
{
    public Guid Id { get; init; }
    public required string Code { get; init; }
    public required string Description { get; init; }
}

public sealed class MembershipRole
{
    public Guid MembershipId { get; init; }
    public Guid RoleId { get; init; }
}

public sealed class RolePermission
{
    public Guid RoleId { get; init; }
    public Guid PermissionId { get; init; }
}
