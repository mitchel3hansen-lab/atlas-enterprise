# PRD-020 — Unified Timeline & Audit Alpha

## Problem
Operational history is fragmented across workflow, evidence, rules, risk, health, assignments, notifications, and graph services.

## Objective
Provide a single chronological, explainable, tenant-scoped record for every Atlas object.

## Alpha scope
- Append timeline events
- List object history with pagination
- Filter-ready categories
- Correlation and causation identifiers
- Actor and source-system attribution
- SHA-256 hash chaining
- Integrity verification endpoint
- Permission-controlled redaction
- React timeline component

## Acceptance criteria
1. Two tenants cannot read each other's timeline entries.
2. Entries are ordered by occurrence time and sequence.
3. Integrity verification succeeds for unchanged entries.
4. A redaction requires a reason and preserves the audit event identity.
5. API limits are bounded to 200 entries per page.
6. The component clearly distinguishes system actions from human actions.
