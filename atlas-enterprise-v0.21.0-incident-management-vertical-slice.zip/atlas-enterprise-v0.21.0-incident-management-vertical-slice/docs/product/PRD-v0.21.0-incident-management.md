# Product Requirements — Incident Management Vertical Slice

## Outcome
A tenant user can create, edit, submit, assign, investigate, verify, and close an incident while Atlas automatically records a tamper-evident timeline, evaluates rules, creates a Knowledge Graph node, and exposes correlation identifiers.

## Included
- Draft creation and optimistic concurrency
- Deterministic incident numbering
- Severity-derived initial risk score
- Controlled state transitions
- Assignment requirement
- Rule event publication
- Unified timeline entries
- Knowledge Graph registration
- Tenant-scoped REST API
- React incident workspace

## Acceptance criteria
1. A valid incident returns HTTP 201 and a stable incident number.
2. Only Draft incidents may be edited.
3. Invalid state transitions fail closed.
4. Assignment requires an assignee.
5. Each create and transition returns a correlation ID and timeline entry IDs.
6. High and Critical incidents set `capaRequired=true`.
7. Tenant data cannot be retrieved through another tenant context.
