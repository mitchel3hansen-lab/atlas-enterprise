# V020 Deployment Runbook

1. Back up PostgreSQL.
2. Apply `V020__unified_timeline_audit.sql`.
3. Deploy API with the new timeline permissions.
4. Assign `timeline.read`, `timeline.write`, and `audit.read` to appropriate roles.
5. Restrict `audit.redact` to privacy or compliance administrators.
6. Run the V020 UAT checklist.
7. Monitor append latency, integrity failures, and authorization denials.

Rollback uses `rollback/R020__unified_timeline_audit.sql` and permanently deletes timeline data. Export before rollback.
