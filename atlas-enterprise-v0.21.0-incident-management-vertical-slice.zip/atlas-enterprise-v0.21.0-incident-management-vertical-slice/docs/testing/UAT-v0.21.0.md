# UAT — Incident Management Vertical Slice

1. Create a Moderate incident and confirm Draft status and risk score 45.
2. Edit the draft with its current version and confirm the version increments.
3. Submit the incident and verify a workflow timeline entry.
4. Attempt Draft → Investigating and confirm rejection.
5. Assign without an assignee and confirm rejection.
6. Assign with an assignee and confirm success.
7. Create a Critical incident and confirm risk score 95 and CAPA required.
8. Retrieve the incident timeline and verify hash-chain integrity.
9. Confirm the Knowledge Graph contains the incident node.
10. Confirm rule execution IDs and correlation ID are returned.
