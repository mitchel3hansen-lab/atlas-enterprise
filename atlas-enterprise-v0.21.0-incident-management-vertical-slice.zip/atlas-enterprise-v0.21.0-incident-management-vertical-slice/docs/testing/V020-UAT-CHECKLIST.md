# v0.20.0 UAT Checklist

- [ ] Create an incident timeline entry.
- [ ] Add workflow, evidence, rules, assignment, risk, and CAPA events.
- [ ] Confirm newest entries appear first.
- [ ] Filter the React timeline by category.
- [ ] Confirm a user without `timeline.read` is denied.
- [ ] Confirm another tenant cannot retrieve the stream.
- [ ] Verify integrity returns valid for an unchanged stream.
- [ ] Modify a persisted field in a test database and confirm integrity failure.
- [ ] Redact an entry with `audit.redact` and a reason.
- [ ] Confirm redacted content is not returned to standard readers.
