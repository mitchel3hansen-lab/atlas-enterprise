# ADR-021 — Incident Orchestration as the First Vertical Slice

## Decision
Use an application service to coordinate the incident repository, rules engine, unified timeline, and Knowledge Graph through existing engine contracts. The incident domain remains authoritative for lifecycle state and optimistic concurrency.

## Rationale
A vertical slice validates integration behavior without coupling platform engines to one product. Correlation IDs provide traceability across downstream work. The alpha uses in-memory repositories for demonstrability while providing PostgreSQL schema for production persistence.

## Consequences
- Engine calls are explicit and testable.
- A later transactional outbox is required for guaranteed event delivery.
- CAPA creation remains an automation action extension point rather than embedded incident logic.
