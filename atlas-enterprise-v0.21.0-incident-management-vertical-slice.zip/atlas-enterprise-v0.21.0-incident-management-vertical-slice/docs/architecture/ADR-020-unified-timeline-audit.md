# ADR-020: Unified Timeline and Tamper-Evident Audit Chain

## Status
Accepted for v0.20.0 Alpha.

## Decision
Atlas records material operational events in one tenant-scoped timeline. Entries are append-only by default and linked through SHA-256 hashes. Each hash covers canonical entry content and the preceding entry hash for the same operational object.

## Rationale
Users need one explainable operational story spanning workflow, rules, evidence, assignments, risk, health, graph relationships, notifications, CAPA, and direct user actions. A hash chain provides tamper evidence without claiming that the alpha is a legally immutable ledger.

## Privacy and correction
Authorized redaction removes sensitive presentation fields while retaining the entry identity, event classification, timestamps, original integrity hash, and redaction reason. Corrections should normally be represented by a new event rather than overwriting history.

## Consequences
- Event producers must use stable event names and correlation IDs.
- Timeline storage must preserve ordering within an object stream.
- Integrity verification detects alteration but does not prevent database administrators from deleting an entire stream.
- Production deployments should add external immutable exports or WORM storage where regulatory requirements demand it.
