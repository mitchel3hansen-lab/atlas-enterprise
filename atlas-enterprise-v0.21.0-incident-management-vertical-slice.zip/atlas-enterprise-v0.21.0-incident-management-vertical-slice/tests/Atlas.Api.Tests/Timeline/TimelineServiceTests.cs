using System.Text.Json;
using Atlas.Api.Timeline;
using Xunit;

namespace Atlas.Api.Tests.Timeline;

public sealed class TimelineServiceTests
{
    [Fact]
    public async Task AppendAsync_BuildsVerifiableHashChain()
    {
        var repository = new InMemoryTimelineRepository();
        var service = new TimelineService(repository);
        var tenantId = Guid.NewGuid();
        var objectId = Guid.NewGuid();

        await service.AppendAsync(tenantId, Request(objectId, "Incident.Created", "Incident created"), default);
        await service.AppendAsync(tenantId, Request(objectId, "Workflow.Started", "Workflow started"), default);

        var result = await service.VerifyAsync(tenantId, "incident", objectId, default);

        Assert.True(result.IsValid);
        Assert.Equal(2, result.EntriesChecked);
    }

    [Fact]
    public async Task ListAsync_IsTenantScoped()
    {
        var repository = new InMemoryTimelineRepository();
        var service = new TimelineService(repository);
        var objectId = Guid.NewGuid();
        var tenantA = Guid.NewGuid();
        var tenantB = Guid.NewGuid();

        await service.AppendAsync(tenantA, Request(objectId, "Incident.Created", "A"), default);
        await service.AppendAsync(tenantB, Request(objectId, "Incident.Created", "B"), default);

        var page = await service.ListAsync(tenantA, "incident", objectId, 50, 0, default);

        Assert.Single(page.Items);
        Assert.Equal("A", page.Items[0].Title);
    }

    private static AppendTimelineEntryRequest Request(Guid objectId, string eventType, string title) => new(
        "incident", objectId, eventType, TimelineCategory.System, title, null, null, "Test User", "tests",
        "corr-1", null, DateTimeOffset.UtcNow, new Dictionary<string, JsonElement>());
}
