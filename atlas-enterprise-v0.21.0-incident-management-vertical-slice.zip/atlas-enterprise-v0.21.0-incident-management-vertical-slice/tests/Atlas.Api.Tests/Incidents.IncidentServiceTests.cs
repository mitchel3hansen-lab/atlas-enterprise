using Atlas.Api.Incidents;
using Xunit;

namespace Atlas.Api.Tests.Incidents;

public sealed class IncidentWorkflowContractTests
{
    [Theory]
    [InlineData(IncidentSeverity.Low, 20)]
    [InlineData(IncidentSeverity.Moderate, 45)]
    [InlineData(IncidentSeverity.High, 70)]
    [InlineData(IncidentSeverity.Critical, 95)]
    public void Severity_contract_maps_to_expected_risk(IncidentSeverity severity, int expected)
    {
        var actual = severity switch { IncidentSeverity.Low => 20, IncidentSeverity.Moderate => 45, IncidentSeverity.High => 70, IncidentSeverity.Critical => 95, _ => 0 };
        Assert.Equal(expected, actual);
    }

    [Fact]
    public void Workflow_contract_preserves_required_sequence()
    {
        IncidentStatus[] expected = [IncidentStatus.Draft, IncidentStatus.Submitted, IncidentStatus.Assigned, IncidentStatus.Investigating, IncidentStatus.Verification, IncidentStatus.Closed];
        Assert.Equal(6, expected.Distinct().Count());
        Assert.Equal(IncidentStatus.Closed, expected[^1]);
    }
}
