# Atlas Enterprise v0.21.0 — Incident Management Vertical Slice

This release integrates the first complete product workflow across Atlas platform services.

## Added
- Incident CRUD and controlled lifecycle transitions
- Optimistic concurrency and tenant isolation
- Incident numbering and severity-based risk initialization
- Rules Engine event publication
- Unified Timeline entries with correlation IDs
- Knowledge Graph incident registration
- React incident workspace
- PostgreSQL migration and rollback
- Product requirements, ADR, OpenAPI, UAT, sample request, and tests

## Known alpha limitations
- Incident and Knowledge Graph runtime repositories are in-memory.
- PostgreSQL repository implementation and transactional outbox are scheduled next.
- CAPA generation depends on configured Rules Engine actions.
- Authentication claims must provide a tenant and user identifier.
