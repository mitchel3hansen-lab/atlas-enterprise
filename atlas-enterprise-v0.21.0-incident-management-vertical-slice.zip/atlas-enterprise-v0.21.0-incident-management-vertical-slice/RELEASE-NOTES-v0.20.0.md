# Atlas Enterprise v0.20.0 — Unified Timeline & Audit Alpha

Adds a tenant-scoped operational timeline, category-based event model, correlation and causation IDs, actor attribution, pagination, permission-controlled redaction, and a tamper-evident SHA-256 hash chain with verification endpoint.

This alpha does not claim legal immutability. Production regulatory deployments should pair it with external immutable exports or WORM storage.
