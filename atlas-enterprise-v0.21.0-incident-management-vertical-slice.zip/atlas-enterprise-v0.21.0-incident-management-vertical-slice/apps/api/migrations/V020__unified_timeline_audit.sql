CREATE TABLE IF NOT EXISTS atlas_timeline_entries (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    object_type varchar(128) NOT NULL,
    object_id uuid NOT NULL,
    event_type varchar(160) NOT NULL,
    category varchar(64) NOT NULL,
    title varchar(240) NOT NULL,
    description text NULL,
    actor_id uuid NULL,
    actor_display_name varchar(240) NULL,
    source_system varchar(120) NOT NULL DEFAULT 'atlas',
    correlation_id varchar(128) NULL,
    causation_id varchar(128) NULL,
    occurred_at timestamptz NOT NULL,
    recorded_at timestamptz NOT NULL DEFAULT now(),
    sequence_no bigint GENERATED ALWAYS AS IDENTITY,
    metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    integrity_hash char(64) NOT NULL,
    previous_hash char(64) NULL,
    is_redacted boolean NOT NULL DEFAULT false,
    redaction_reason text NULL,
    redacted_at timestamptz NULL,
    redacted_by uuid NULL
);

CREATE INDEX IF NOT EXISTS ix_timeline_object
    ON atlas_timeline_entries (tenant_id, object_type, object_id, occurred_at DESC, sequence_no DESC);
CREATE INDEX IF NOT EXISTS ix_timeline_correlation
    ON atlas_timeline_entries (tenant_id, correlation_id) WHERE correlation_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_timeline_event_type
    ON atlas_timeline_entries (tenant_id, event_type, occurred_at DESC);

CREATE TABLE IF NOT EXISTS atlas_audit_exports (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    object_type varchar(128) NOT NULL,
    object_id uuid NOT NULL,
    requested_by uuid NULL,
    requested_at timestamptz NOT NULL DEFAULT now(),
    entry_count integer NOT NULL,
    from_occurred_at timestamptz NULL,
    to_occurred_at timestamptz NULL,
    export_hash char(64) NOT NULL,
    format varchar(32) NOT NULL DEFAULT 'json'
);
