DROP TABLE IF EXISTS atlas_incidents;
