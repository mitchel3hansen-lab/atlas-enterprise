using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Atlas.Api.Timeline;

public sealed class TimelineService(ITimelineRepository repository)
{
    private const int MaxTitleLength = 240;

    public async Task<TimelineEntry> AppendAsync(Guid tenantId, AppendTimelineEntryRequest request, CancellationToken cancellationToken)
    {
        Validate(request);
        var previous = await repository.GetLastAsync(tenantId, request.ObjectType, request.ObjectId, cancellationToken);
        var id = Guid.NewGuid();
        var recordedAt = DateTimeOffset.UtcNow;
        var metadata = request.Metadata ?? new Dictionary<string, JsonElement>();
        var integrityHash = CalculateHash(
            tenantId, id, request.ObjectType, request.ObjectId, request.EventType, request.Category,
            request.Title, request.Description, request.ActorId, request.SourceSystem,
            request.CorrelationId, request.CausationId, request.OccurredAt, recordedAt, metadata,
            previous?.IntegrityHash);

        var entry = new TimelineEntry(
            id, tenantId, request.ObjectType.Trim(), request.ObjectId, request.EventType.Trim(), request.Category,
            request.Title.Trim(), request.Description?.Trim(), request.ActorId, request.ActorDisplayName?.Trim(),
            request.SourceSystem.Trim(), request.CorrelationId?.Trim(), request.CausationId?.Trim(),
            request.OccurredAt, recordedAt, 0, metadata, integrityHash, previous?.IntegrityHash, false, null);

        await repository.AddAsync(entry, cancellationToken);
        return entry;
    }

    public async Task<TimelinePage> ListAsync(Guid tenantId, string objectType, Guid objectId, int limit, int offset, CancellationToken cancellationToken)
    {
        limit = Math.Clamp(limit, 1, 200);
        offset = Math.Max(0, offset);
        var items = await repository.ListAsync(tenantId, objectType, objectId, limit, offset, cancellationToken);
        var total = await repository.CountAsync(tenantId, objectType, objectId, cancellationToken);
        return new TimelinePage(items, total, limit, offset);
    }

    public async Task<TimelineIntegrityResult> VerifyAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken cancellationToken)
    {
        var total = await repository.CountAsync(tenantId, objectType, objectId, cancellationToken);
        var entries = await repository.ListAsync(tenantId, objectType, objectId, Math.Max(1, total), 0, cancellationToken);
        var ordered = entries.OrderBy(x => x.SequenceNumber).ToArray();
        string? previousHash = null;

        foreach (var entry in ordered)
        {
            if (!string.Equals(entry.PreviousHash, previousHash, StringComparison.Ordinal))
                return new(false, ordered.Length, entry.Id, "Hash-chain predecessor does not match.");

            var expected = CalculateHash(
                entry.TenantId, entry.Id, entry.ObjectType, entry.ObjectId, entry.EventType, entry.Category,
                entry.Title, entry.Description, entry.ActorId, entry.SourceSystem, entry.CorrelationId,
                entry.CausationId, entry.OccurredAt, entry.RecordedAt, entry.Metadata, previousHash);

            if (!CryptographicOperations.FixedTimeEquals(Convert.FromHexString(expected), Convert.FromHexString(entry.IntegrityHash)))
                return new(false, ordered.Length, entry.Id, "Entry integrity hash does not match its canonical content.");

            previousHash = entry.IntegrityHash;
        }

        return new(true, ordered.Length, null, null);
    }

    public async Task<TimelineEntry> RedactAsync(Guid tenantId, Guid id, RedactTimelineEntryRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Reason)) throw new ArgumentException("A redaction reason is required.");
        var entry = await repository.GetAsync(tenantId, id, cancellationToken) ?? throw new KeyNotFoundException("Timeline entry not found.");
        var redacted = entry with
        {
            IsRedacted = true,
            RedactionReason = request.Reason.Trim(),
            Description = null,
            ActorDisplayName = null,
            Metadata = new Dictionary<string, JsonElement>()
        };
        await repository.ReplaceAsync(redacted, cancellationToken);
        return redacted;
    }

    private static void Validate(AppendTimelineEntryRequest request)
    {
        if (request.ObjectId == Guid.Empty) throw new ArgumentException("ObjectId is required.");
        if (string.IsNullOrWhiteSpace(request.ObjectType)) throw new ArgumentException("ObjectType is required.");
        if (string.IsNullOrWhiteSpace(request.EventType)) throw new ArgumentException("EventType is required.");
        if (string.IsNullOrWhiteSpace(request.Title)) throw new ArgumentException("Title is required.");
        if (request.Title.Length > MaxTitleLength) throw new ArgumentException($"Title cannot exceed {MaxTitleLength} characters.");
        if (string.IsNullOrWhiteSpace(request.SourceSystem)) throw new ArgumentException("SourceSystem is required.");
        if (request.OccurredAt > DateTimeOffset.UtcNow.AddMinutes(5)) throw new ArgumentException("OccurredAt cannot be materially in the future.");
    }

    private static string CalculateHash(
        Guid tenantId, Guid id, string objectType, Guid objectId, string eventType, TimelineCategory category,
        string title, string? description, Guid? actorId, string sourceSystem, string? correlationId,
        string? causationId, DateTimeOffset occurredAt, DateTimeOffset recordedAt,
        IReadOnlyDictionary<string, JsonElement> metadata, string? previousHash)
    {
        var canonical = JsonSerializer.Serialize(new
        {
            tenantId, id, objectType, objectId, eventType, category = category.ToString(), title, description,
            actorId, sourceSystem, correlationId, causationId,
            occurredAt = occurredAt.ToUniversalTime().ToString("O"),
            recordedAt = recordedAt.ToUniversalTime().ToString("O"),
            metadata = metadata.OrderBy(x => x.Key).ToDictionary(x => x.Key, x => x.Value),
            previousHash
        });
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(canonical))).ToLowerInvariant();
    }
}
