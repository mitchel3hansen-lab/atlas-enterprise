using System.Collections.Concurrent;

namespace Atlas.Api.Timeline;

public sealed class InMemoryTimelineRepository : ITimelineRepository
{
    private readonly ConcurrentDictionary<Guid, TimelineEntry> _entries = new();
    private long _sequence;

    public Task<TimelineEntry?> GetLastAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken cancellationToken)
    {
        var entry = _entries.Values
            .Where(x => x.TenantId == tenantId && x.ObjectType == objectType && x.ObjectId == objectId)
            .OrderByDescending(x => x.SequenceNumber)
            .FirstOrDefault();
        return Task.FromResult(entry);
    }

    public Task AddAsync(TimelineEntry entry, CancellationToken cancellationToken)
    {
        var persisted = entry with { SequenceNumber = Interlocked.Increment(ref _sequence) };
        if (!_entries.TryAdd(persisted.Id, persisted))
            throw new InvalidOperationException($"Timeline entry {persisted.Id} already exists.");
        return Task.CompletedTask;
    }

    public Task<TimelineEntry?> GetAsync(Guid tenantId, Guid id, CancellationToken cancellationToken)
    {
        _entries.TryGetValue(id, out var entry);
        return Task.FromResult(entry?.TenantId == tenantId ? entry : null);
    }

    public Task<IReadOnlyList<TimelineEntry>> ListAsync(Guid tenantId, string objectType, Guid objectId, int limit, int offset, CancellationToken cancellationToken)
    {
        IReadOnlyList<TimelineEntry> result = _entries.Values
            .Where(x => x.TenantId == tenantId && x.ObjectType == objectType && x.ObjectId == objectId)
            .OrderByDescending(x => x.OccurredAt)
            .ThenByDescending(x => x.SequenceNumber)
            .Skip(offset)
            .Take(limit)
            .ToArray();
        return Task.FromResult(result);
    }

    public Task<int> CountAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken cancellationToken)
        => Task.FromResult(_entries.Values.Count(x => x.TenantId == tenantId && x.ObjectType == objectType && x.ObjectId == objectId));

    public Task ReplaceAsync(TimelineEntry entry, CancellationToken cancellationToken)
    {
        _entries[entry.Id] = entry;
        return Task.CompletedTask;
    }
}
