using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Atlas.Api.Timeline;

[ApiController]
[Route("api/v1/timeline")]
public sealed class TimelineController(TimelineService service, TenantContext tenantContext) : ControllerBase
{
    [HttpPost]
    [Authorize(Policy = AtlasPermissions.TimelineWrite)]
    public async Task<ActionResult<TimelineEntry>> Append(AppendTimelineEntryRequest request, CancellationToken cancellationToken)
        => Ok(await service.AppendAsync(tenantContext.TenantId, request, cancellationToken));

    [HttpGet("object/{objectType}/{objectId:guid}")]
    [Authorize(Policy = AtlasPermissions.TimelineRead)]
    public async Task<ActionResult<TimelinePage>> List(string objectType, Guid objectId, [FromQuery] int limit = 50, [FromQuery] int offset = 0, CancellationToken cancellationToken = default)
        => Ok(await service.ListAsync(tenantContext.TenantId, objectType, objectId, limit, offset, cancellationToken));

    [HttpGet("object/{objectType}/{objectId:guid}/integrity")]
    [Authorize(Policy = AtlasPermissions.AuditRead)]
    public async Task<ActionResult<TimelineIntegrityResult>> Verify(string objectType, Guid objectId, CancellationToken cancellationToken)
        => Ok(await service.VerifyAsync(tenantContext.TenantId, objectType, objectId, cancellationToken));

    [HttpPost("{id:guid}/redact")]
    [Authorize(Policy = AtlasPermissions.AuditRedact)]
    public async Task<ActionResult<TimelineEntry>> Redact(Guid id, RedactTimelineEntryRequest request, CancellationToken cancellationToken)
        => Ok(await service.RedactAsync(tenantContext.TenantId, id, request, cancellationToken));
}
