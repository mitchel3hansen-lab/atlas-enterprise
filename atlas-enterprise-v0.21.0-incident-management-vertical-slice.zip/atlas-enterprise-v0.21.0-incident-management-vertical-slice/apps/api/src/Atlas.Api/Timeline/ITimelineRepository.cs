namespace Atlas.Api.Timeline;

public interface ITimelineRepository
{
    Task<TimelineEntry?> GetLastAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken cancellationToken);
    Task AddAsync(TimelineEntry entry, CancellationToken cancellationToken);
    Task<TimelineEntry?> GetAsync(Guid tenantId, Guid id, CancellationToken cancellationToken);
    Task<IReadOnlyList<TimelineEntry>> ListAsync(Guid tenantId, string objectType, Guid objectId, int limit, int offset, CancellationToken cancellationToken);
    Task<int> CountAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken cancellationToken);
    Task ReplaceAsync(TimelineEntry entry, CancellationToken cancellationToken);
}
