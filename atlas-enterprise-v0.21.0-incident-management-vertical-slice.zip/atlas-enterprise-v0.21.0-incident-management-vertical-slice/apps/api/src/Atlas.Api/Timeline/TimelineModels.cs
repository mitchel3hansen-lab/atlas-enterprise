using System.Text.Json;

namespace Atlas.Api.Timeline;

public enum TimelineCategory
{
    System,
    Workflow,
    Evidence,
    Rule,
    Risk,
    Health,
    Assignment,
    Relationship,
    UserAction,
    Notification,
    Capa
}

public sealed record AppendTimelineEntryRequest(
    string ObjectType,
    Guid ObjectId,
    string EventType,
    TimelineCategory Category,
    string Title,
    string? Description,
    Guid? ActorId,
    string? ActorDisplayName,
    string SourceSystem,
    string? CorrelationId,
    string? CausationId,
    DateTimeOffset OccurredAt,
    IReadOnlyDictionary<string, JsonElement>? Metadata);

public sealed record TimelineEntry(
    Guid Id,
    Guid TenantId,
    string ObjectType,
    Guid ObjectId,
    string EventType,
    TimelineCategory Category,
    string Title,
    string? Description,
    Guid? ActorId,
    string? ActorDisplayName,
    string SourceSystem,
    string? CorrelationId,
    string? CausationId,
    DateTimeOffset OccurredAt,
    DateTimeOffset RecordedAt,
    long SequenceNumber,
    IReadOnlyDictionary<string, JsonElement> Metadata,
    string IntegrityHash,
    string? PreviousHash,
    bool IsRedacted,
    string? RedactionReason);

public sealed record TimelinePage(
    IReadOnlyList<TimelineEntry> Items,
    int Total,
    int Limit,
    int Offset);

public sealed record TimelineIntegrityResult(
    bool IsValid,
    int EntriesChecked,
    Guid? FailedEntryId,
    string? Reason);

public sealed record RedactTimelineEntryRequest(string Reason, Guid? RedactedBy);
