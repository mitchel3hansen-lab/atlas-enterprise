using System.Security.Claims;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Atlas.Api.Incidents;

[ApiController]
[Route("api/v1/incidents")]
public sealed class IncidentsController(IncidentService service, TenantContext tenantContext) : ControllerBase
{
    [HttpPost]
    [Authorize(Policy = AtlasPermissions.IncidentsManage)]
    public async Task<ActionResult<IncidentTransitionResult>> Create(CreateIncidentRequest request, CancellationToken ct)
    {
        var actorId = ActorId();
        var correlationId = HttpContext.TraceIdentifier;
        var result = await service.CreateAsync(tenantContext.TenantId, actorId, User.Identity?.Name, request, correlationId, ct);
        return CreatedAtAction(nameof(Get), new { id = result.Incident.Id }, result);
    }

    [HttpGet]
    [Authorize(Policy = AtlasPermissions.IncidentsRead)]
    public async Task<ActionResult<IncidentPage>> List([FromQuery] int limit = 50, [FromQuery] int offset = 0, CancellationToken ct = default)
        => Ok(await service.ListAsync(tenantContext.TenantId, limit, offset, ct));

    [HttpGet("{id:guid}")]
    [Authorize(Policy = AtlasPermissions.IncidentsRead)]
    public async Task<ActionResult<IncidentRecord>> Get(Guid id, CancellationToken ct)
        => Ok(await service.GetAsync(tenantContext.TenantId, id, ct));

    [HttpPut("{id:guid}")]
    [Authorize(Policy = AtlasPermissions.IncidentsManage)]
    public async Task<ActionResult<IncidentRecord>> Update(Guid id, UpdateIncidentRequest request, CancellationToken ct)
        => Ok(await service.UpdateAsync(tenantContext.TenantId, id, request, ct));

    [HttpPost("{id:guid}/transitions")]
    [Authorize(Policy = AtlasPermissions.IncidentsTransition)]
    public async Task<ActionResult<IncidentTransitionResult>> Transition(Guid id, TransitionIncidentRequest request, CancellationToken ct)
        => Ok(await service.TransitionAsync(tenantContext.TenantId, id, request, HttpContext.TraceIdentifier, ct));

    private Guid ActorId()
    {
        var raw = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub");
        return Guid.TryParse(raw, out var id) ? id : Guid.Empty;
    }
}
