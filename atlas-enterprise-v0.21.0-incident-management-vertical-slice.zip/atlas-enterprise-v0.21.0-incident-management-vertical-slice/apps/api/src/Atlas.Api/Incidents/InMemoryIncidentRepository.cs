using System.Collections.Concurrent;

namespace Atlas.Api.Incidents;

public sealed class InMemoryIncidentRepository : IIncidentRepository
{
    private readonly ConcurrentDictionary<(Guid TenantId, Guid Id), IncidentRecord> _items = new();
    private readonly ConcurrentDictionary<(Guid TenantId, int Year), int> _sequences = new();

    public Task<IncidentRecord?> GetAsync(Guid tenantId, Guid id, CancellationToken cancellationToken)
        => Task.FromResult(_items.TryGetValue((tenantId, id), out var item) ? item : null);

    public Task<IncidentRecord> AddAsync(IncidentRecord incident, CancellationToken cancellationToken)
    {
        if (!_items.TryAdd((incident.TenantId, incident.Id), incident))
            throw new InvalidOperationException("Incident already exists.");
        return Task.FromResult(incident);
    }

    public Task<IncidentRecord> ReplaceAsync(IncidentRecord incident, long expectedVersion, CancellationToken cancellationToken)
    {
        var key = (incident.TenantId, incident.Id);
        if (!_items.TryGetValue(key, out var current)) throw new KeyNotFoundException("Incident not found.");
        if (current.Version != expectedVersion) throw new InvalidOperationException("Incident was modified by another user.");
        var updated = incident with { Version = expectedVersion + 1, UpdatedAt = DateTimeOffset.UtcNow };
        if (!_items.TryUpdate(key, updated, current)) throw new InvalidOperationException("Incident update conflict.");
        return Task.FromResult(updated);
    }

    public Task<IReadOnlyList<IncidentRecord>> ListAsync(Guid tenantId, int limit, int offset, CancellationToken cancellationToken)
        => Task.FromResult<IReadOnlyList<IncidentRecord>>(_items.Values.Where(x => x.TenantId == tenantId)
            .OrderByDescending(x => x.CreatedAt).Skip(offset).Take(limit).ToArray());

    public Task<int> CountAsync(Guid tenantId, CancellationToken cancellationToken)
        => Task.FromResult(_items.Values.Count(x => x.TenantId == tenantId));

    public Task<int> NextSequenceAsync(Guid tenantId, int year, CancellationToken cancellationToken)
        => Task.FromResult(_sequences.AddOrUpdate((tenantId, year), 1, (_, value) => value + 1));
}
