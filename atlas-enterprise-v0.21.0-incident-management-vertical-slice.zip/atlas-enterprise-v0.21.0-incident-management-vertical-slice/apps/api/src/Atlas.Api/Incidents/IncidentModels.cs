using System.Text.Json;

namespace Atlas.Api.Incidents;

public enum IncidentStatus { Draft, Submitted, Assigned, Investigating, Verification, Closed }
public enum IncidentSeverity { Low, Moderate, High, Critical }

public sealed record CreateIncidentRequest(
    string Title,
    string Description,
    DateTimeOffset OccurredAt,
    Guid FacilityId,
    IncidentSeverity Severity,
    Guid? EmployeeId,
    Guid? EquipmentId,
    Guid? ChemicalId,
    IReadOnlyList<string>? Tags,
    IReadOnlyDictionary<string, JsonElement>? Metadata);

public sealed record UpdateIncidentRequest(
    string Title,
    string Description,
    DateTimeOffset OccurredAt,
    Guid FacilityId,
    IncidentSeverity Severity,
    Guid? EmployeeId,
    Guid? EquipmentId,
    Guid? ChemicalId,
    IReadOnlyList<string>? Tags,
    IReadOnlyDictionary<string, JsonElement>? Metadata,
    long ExpectedVersion);

public sealed record TransitionIncidentRequest(
    IncidentStatus TargetStatus,
    Guid ActorId,
    string? ActorDisplayName,
    Guid? AssigneeId,
    string? Comment,
    long ExpectedVersion);

public sealed record IncidentRecord(
    Guid Id,
    Guid TenantId,
    string Number,
    string Title,
    string Description,
    DateTimeOffset OccurredAt,
    Guid FacilityId,
    IncidentSeverity Severity,
    IncidentStatus Status,
    Guid? ReporterId,
    Guid? AssigneeId,
    Guid? EmployeeId,
    Guid? EquipmentId,
    Guid? ChemicalId,
    int RiskScore,
    bool CapaRequired,
    Guid? CapaId,
    IReadOnlyList<string> Tags,
    IReadOnlyDictionary<string, JsonElement> Metadata,
    DateTimeOffset CreatedAt,
    DateTimeOffset UpdatedAt,
    long Version);

public sealed record IncidentPage(IReadOnlyList<IncidentRecord> Items, int Total, int Limit, int Offset);

public sealed record IncidentTransitionResult(
    IncidentRecord Incident,
    IReadOnlyList<Guid> RuleExecutionIds,
    IReadOnlyList<Guid> TimelineEntryIds,
    Guid? KnowledgeGraphNodeId,
    string CorrelationId);
