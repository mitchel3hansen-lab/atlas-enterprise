namespace Atlas.Api.Incidents;

public interface IIncidentRepository
{
    Task<IncidentRecord?> GetAsync(Guid tenantId, Guid id, CancellationToken cancellationToken);
    Task<IncidentRecord> AddAsync(IncidentRecord incident, CancellationToken cancellationToken);
    Task<IncidentRecord> ReplaceAsync(IncidentRecord incident, long expectedVersion, CancellationToken cancellationToken);
    Task<IReadOnlyList<IncidentRecord>> ListAsync(Guid tenantId, int limit, int offset, CancellationToken cancellationToken);
    Task<int> CountAsync(Guid tenantId, CancellationToken cancellationToken);
    Task<int> NextSequenceAsync(Guid tenantId, int year, CancellationToken cancellationToken);
}
