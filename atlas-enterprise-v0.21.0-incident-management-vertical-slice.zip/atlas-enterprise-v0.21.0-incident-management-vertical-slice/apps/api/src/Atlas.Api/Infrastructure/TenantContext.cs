namespace Atlas.Api.Infrastructure;

public sealed class TenantContext
{
    public Guid? OrganizationId { get; private set; }
    public Guid TenantId => OrganizationId ?? throw new InvalidOperationException("Tenant context has not been resolved.");
    public void Set(Guid organizationId) => OrganizationId = organizationId;
}
