using System.Collections.Concurrent;

namespace Atlas.Api.KnowledgeGraph;

public sealed class InMemoryKnowledgeGraphRepository : IKnowledgeGraphRepository
{
    private readonly ConcurrentDictionary<(Guid TenantId, Guid NodeId), GraphNode> _nodes = new();
    private readonly ConcurrentDictionary<(Guid TenantId, string Type, Guid ObjectId), Guid> _objectIndex = new();
    private readonly ConcurrentDictionary<(Guid TenantId, Guid EdgeId), GraphEdge> _edges = new();
    private static readonly RelationshipType RelatedTo = new(Guid.Parse("00000000-0000-0000-0000-000000000001"), "related_to", "Related to", null, false, new HashSet<string>(), new HashSet<string>());

    public Task<GraphNode?> GetNodeAsync(Guid tenantId, Guid nodeId, CancellationToken ct)
        => Task.FromResult(_nodes.TryGetValue((tenantId, nodeId), out var item) ? item : null);

    public Task<GraphNode?> FindNodeAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken ct)
    {
        if (_objectIndex.TryGetValue((tenantId, objectType.ToLowerInvariant(), objectId), out var nodeId) && _nodes.TryGetValue((tenantId, nodeId), out var node)) return Task.FromResult<GraphNode?>(node);
        return Task.FromResult<GraphNode?>(null);
    }

    public Task<GraphNode> CreateNodeAsync(GraphNode node, Guid actorId, CancellationToken ct)
    {
        _nodes[(node.TenantId, node.Id)] = node;
        _objectIndex[(node.TenantId, node.ObjectType.ToLowerInvariant(), node.ObjectId)] = node.Id;
        return Task.FromResult(node);
    }

    public Task<RelationshipType?> GetRelationshipTypeAsync(Guid tenantId, string code, CancellationToken ct)
        => Task.FromResult<RelationshipType?>(string.Equals(code, "related_to", StringComparison.OrdinalIgnoreCase) ? RelatedTo : null);

    public Task<GraphEdge> CreateEdgeAsync(GraphEdge edge, Guid actorId, string? correlationId, CancellationToken ct)
    {
        _edges[(edge.TenantId, edge.Id)] = edge;
        return Task.FromResult(edge);
    }

    public Task<IReadOnlyList<GraphEdge>> GetAdjacentEdgesAsync(Guid tenantId, Guid nodeId, CancellationToken ct)
        => Task.FromResult<IReadOnlyList<GraphEdge>>(_edges.Values.Where(x => x.TenantId == tenantId && (x.SourceNodeId == nodeId || x.TargetNodeId == nodeId)).ToArray());

    public Task<IReadOnlyList<GraphNode>> GetNodesAsync(Guid tenantId, IEnumerable<Guid> ids, CancellationToken ct)
    {
        var wanted = ids.ToHashSet();
        return Task.FromResult<IReadOnlyList<GraphNode>>(_nodes.Values.Where(x => x.TenantId == tenantId && wanted.Contains(x.Id)).ToArray());
    }
}
