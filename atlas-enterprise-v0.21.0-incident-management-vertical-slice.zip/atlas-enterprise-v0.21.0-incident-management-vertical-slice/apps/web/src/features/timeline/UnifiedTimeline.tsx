import React, { useMemo, useState } from 'react';

export type TimelineItem = {
  id: string;
  eventType: string;
  category: string;
  title: string;
  description?: string;
  actorDisplayName?: string;
  occurredAt: string;
  sourceSystem: string;
  correlationId?: string;
  integrityHash: string;
  isRedacted: boolean;
};

type Props = { items: TimelineItem[]; onVerify?: () => Promise<boolean> };

export function UnifiedTimeline({ items, onVerify }: Props) {
  const [category, setCategory] = useState('All');
  const [verified, setVerified] = useState<boolean | null>(null);
  const categories = useMemo(() => ['All', ...Array.from(new Set(items.map(x => x.category)))], [items]);
  const visible = category === 'All' ? items : items.filter(x => x.category === category);

  const verify = async () => setVerified(onVerify ? await onVerify() : true);

  return <section className="timeline-panel" aria-label="Unified operational timeline">
    <div className="timeline-toolbar">
      <div><h3>Unified Timeline</h3><p>Chronological, tenant-scoped operational history with integrity verification.</p></div>
      <div><select value={category} onChange={e => setCategory(e.target.value)}>{categories.map(x => <option key={x}>{x}</option>)}</select><button onClick={verify}>Verify integrity</button></div>
    </div>
    {verified !== null && <div className={verified ? 'integrity-ok' : 'integrity-failed'}>{verified ? 'Integrity chain verified' : 'Integrity verification failed'}</div>}
    <ol className="timeline-list">
      {visible.map(item => <li key={item.id}>
        <time>{new Date(item.occurredAt).toLocaleString()}</time>
        <div className="timeline-marker" aria-hidden="true" />
        <article>
          <span>{item.category} · {item.eventType}</span>
          <h4>{item.isRedacted ? 'Redacted audit entry' : item.title}</h4>
          {!item.isRedacted && item.description && <p>{item.description}</p>}
          <small>{item.actorDisplayName ?? 'System'} · {item.sourceSystem} · hash {item.integrityHash.slice(0, 10)}…</small>
        </article>
      </li>)}
    </ol>
  </section>;
}
