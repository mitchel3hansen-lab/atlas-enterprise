namespace Atlas.IncidentApi.Domain;

public sealed record WorkItem(
    Guid Id,
    Guid AssigneeId,
    string? AssigneeRole,
    string WorkType,
    string EntityType,
    Guid EntityId,
    string Title,
    string? Description,
    string Priority,
    string Status,
    DateTimeOffset? DueAt,
    int EscalationLevel,
    DateTimeOffset CreatedAt,
    DateTimeOffset? CompletedAt,
    DateTimeOffset UpdatedAt);

public sealed record Notification(
    Guid Id,
    Guid RecipientId,
    string NotificationType,
    string Title,
    string Body,
    string? EntityType,
    Guid? EntityId,
    string Severity,
    string Status,
    string DeliveryChannel,
    DateTimeOffset ScheduledAt,
    DateTimeOffset? SentAt,
    DateTimeOffset? ReadAt,
    DateTimeOffset CreatedAt);

public sealed record WorkQueueSummary(
    int OpenItems,
    int DueSoon,
    int Overdue,
    int UnreadNotifications,
    IReadOnlyList<WorkItem> Items,
    IReadOnlyList<Notification> Notifications);
