namespace Atlas.IncidentApi.Infrastructure;

public sealed class NotificationBackgroundService(
    IServiceProvider serviceProvider,
    IConfiguration configuration,
    ILogger<NotificationBackgroundService> logger)
    : BackgroundService
{
    protected override async Task ExecuteAsync(
        CancellationToken stoppingToken)
    {
        var intervalMinutes = configuration.GetValue(
            "Notifications:SchedulerIntervalMinutes",
            60);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = serviceProvider.CreateScope();
                var scheduler =
                    scope.ServiceProvider.GetRequiredService<NotificationScheduler>();

                var configuredTenant =
                    configuration["Notifications:DefaultTenantId"];

                if (Guid.TryParse(configuredTenant, out var tenantId))
                {
                    await scheduler.SynchronizeAssignmentsAsync(
                        tenantId,
                        stoppingToken);

                    var generated =
                        await scheduler.GenerateNotificationsAsync(
                            tenantId,
                            stoppingToken);

                    logger.LogInformation(
                        "Notification cycle complete. Tenant={TenantId} Generated={Generated}",
                        tenantId,
                        generated);
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Notification cycle failed.");
            }

            await Task.Delay(
                TimeSpan.FromMinutes(intervalMinutes),
                stoppingToken);
        }
    }
}
