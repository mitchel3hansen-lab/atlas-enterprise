using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class NotificationScheduler(
    IConfiguration configuration,
    ILogger<NotificationScheduler> logger)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    public async Task<int> SynchronizeAssignmentsAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        const string investigationSql = """
        INSERT INTO work_items (
            id, tenant_id, assignee_id, assignee_role, work_type,
            entity_type, entity_id, title, description, priority,
            status, due_at)
        SELECT
            gen_random_uuid(),
            i.tenant_id,
            i.investigator_id,
            'Safety',
            'Investigation',
            'Incident',
            i.id,
            CONCAT('Investigate ', i.incident_number),
            i.title,
            CASE
                WHEN COALESCE(i.confirmed_severity, i.severity) IN ('Critical', 'High')
                    THEN 'High'
                ELSE 'Medium'
            END,
            'Open',
            i.investigation_due_at
        FROM incidents i
        WHERE i.tenant_id = @TenantId
          AND i.workflow_state = 'Investigation'
          AND i.investigator_id IS NOT NULL
        ON CONFLICT (
            tenant_id, work_type, entity_type, entity_id, assignee_id
        ) DO UPDATE SET
            due_at = EXCLUDED.due_at,
            title = EXCLUDED.title,
            description = EXCLUDED.description,
            priority = EXCLUDED.priority,
            updated_at = NOW();
        """;

        const string capaSql = """
        INSERT INTO work_items (
            id, tenant_id, assignee_id, assignee_role, work_type,
            entity_type, entity_id, title, description, priority,
            status, due_at)
        SELECT
            gen_random_uuid(),
            c.tenant_id,
            c.owner_id,
            'Employee',
            'CAPA',
            'CapaAction',
            c.id,
            CONCAT('Complete ', c.capa_number),
            c.title,
            c.priority,
            CASE WHEN c.status = 'Closed' THEN 'Completed' ELSE 'Open' END,
            c.target_date
        FROM capa_actions c
        WHERE c.tenant_id = @TenantId
        ON CONFLICT (
            tenant_id, work_type, entity_type, entity_id, assignee_id
        ) DO UPDATE SET
            due_at = EXCLUDED.due_at,
            title = EXCLUDED.title,
            description = EXCLUDED.description,
            priority = EXCLUDED.priority,
            status = EXCLUDED.status,
            completed_at = CASE
                WHEN EXCLUDED.status = 'Completed' THEN NOW()
                ELSE work_items.completed_at
            END,
            updated_at = NOW();
        """;

        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        var investigations = await connection.ExecuteAsync(
            new CommandDefinition(
                investigationSql,
                new { TenantId = tenantId },
                transaction,
                cancellationToken: cancellationToken));

        var capas = await connection.ExecuteAsync(
            new CommandDefinition(
                capaSql,
                new { TenantId = tenantId },
                transaction,
                cancellationToken: cancellationToken));

        await transaction.CommitAsync(cancellationToken);

        logger.LogInformation(
            "Work queue synchronized. Tenant={TenantId} Investigations={Investigations} CAPAs={Capas}",
            tenantId,
            investigations,
            capas);

        return investigations + capas;
    }

    public async Task<int> GenerateNotificationsAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        const string dueSoonSql = """
        INSERT INTO notifications (
            id, tenant_id, recipient_id, notification_type,
            title, body, entity_type, entity_id, severity,
            status, scheduled_at, sent_at)
        SELECT
            gen_random_uuid(),
            w.tenant_id,
            w.assignee_id,
            'DueSoon',
            CONCAT(w.work_type, ' due soon'),
            CONCAT(w.title, ' is due ', TO_CHAR(w.due_at, 'YYYY-MM-DD'), '.'),
            w.entity_type,
            w.entity_id,
            CASE WHEN w.priority IN ('Critical', 'High') THEN 'Warning' ELSE 'Info' END,
            'Unread',
            NOW(),
            NOW()
        FROM work_items w
        WHERE w.tenant_id = @TenantId
          AND w.status <> 'Completed'
          AND w.due_at BETWEEN NOW() AND NOW() + INTERVAL '7 days'
          AND NOT EXISTS (
              SELECT 1
              FROM notifications n
              WHERE n.tenant_id = w.tenant_id
                AND n.recipient_id = w.assignee_id
                AND n.notification_type = 'DueSoon'
                AND n.entity_type = w.entity_type
                AND n.entity_id = w.entity_id
                AND n.created_at >= CURRENT_DATE
          );
        """;

        const string overdueSql = """
        INSERT INTO notifications (
            id, tenant_id, recipient_id, notification_type,
            title, body, entity_type, entity_id, severity,
            status, scheduled_at, sent_at)
        SELECT
            gen_random_uuid(),
            w.tenant_id,
            w.assignee_id,
            'Overdue',
            CONCAT(w.work_type, ' overdue'),
            CONCAT(w.title, ' was due ', TO_CHAR(w.due_at, 'YYYY-MM-DD'), '.'),
            w.entity_type,
            w.entity_id,
            CASE
                WHEN NOW() - w.due_at >= INTERVAL '7 days' THEN 'Critical'
                ELSE 'Warning'
            END,
            'Unread',
            NOW(),
            NOW()
        FROM work_items w
        WHERE w.tenant_id = @TenantId
          AND w.status <> 'Completed'
          AND w.due_at < NOW()
          AND NOT EXISTS (
              SELECT 1
              FROM notifications n
              WHERE n.tenant_id = w.tenant_id
                AND n.recipient_id = w.assignee_id
                AND n.notification_type = 'Overdue'
                AND n.entity_type = w.entity_type
                AND n.entity_id = w.entity_id
                AND n.created_at >= CURRENT_DATE
          );
        """;

        const string escalationSql = """
        UPDATE work_items
        SET escalation_level = CASE
                WHEN due_at <= NOW() - INTERVAL '7 days' THEN 2
                WHEN due_at <= NOW() - INTERVAL '3 days' THEN 1
                ELSE escalation_level
            END,
            updated_at = NOW()
        WHERE tenant_id = @TenantId
          AND status <> 'Completed'
          AND due_at < NOW();
        """;

        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        var dueSoon = await connection.ExecuteAsync(
            new CommandDefinition(
                dueSoonSql,
                new { TenantId = tenantId },
                transaction,
                cancellationToken: cancellationToken));

        var overdue = await connection.ExecuteAsync(
            new CommandDefinition(
                overdueSql,
                new { TenantId = tenantId },
                transaction,
                cancellationToken: cancellationToken));

        await connection.ExecuteAsync(
            new CommandDefinition(
                escalationSql,
                new { TenantId = tenantId },
                transaction,
                cancellationToken: cancellationToken));

        await transaction.CommitAsync(cancellationToken);

        return dueSoon + overdue;
    }
}
