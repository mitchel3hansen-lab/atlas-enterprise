using Atlas.IncidentApi.Domain;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class WorkQueueRepository(IConfiguration configuration)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    public async Task<WorkQueueSummary> GetAsync(
        Guid tenantId,
        Guid userId,
        CancellationToken cancellationToken)
    {
        const string workSql = """
        SELECT
            id AS Id,
            assignee_id AS AssigneeId,
            assignee_role AS AssigneeRole,
            work_type AS WorkType,
            entity_type AS EntityType,
            entity_id AS EntityId,
            title AS Title,
            description AS Description,
            priority AS Priority,
            status AS Status,
            due_at AS DueAt,
            escalation_level AS EscalationLevel,
            created_at AS CreatedAt,
            completed_at AS CompletedAt,
            updated_at AS UpdatedAt
        FROM work_items
        WHERE tenant_id = @TenantId
          AND assignee_id = @UserId
          AND status <> 'Completed'
        ORDER BY
            CASE WHEN due_at < NOW() THEN 0 ELSE 1 END,
            due_at NULLS LAST,
            created_at;
        """;

        const string notificationSql = """
        SELECT
            id AS Id,
            recipient_id AS RecipientId,
            notification_type AS NotificationType,
            title AS Title,
            body AS Body,
            entity_type AS EntityType,
            entity_id AS EntityId,
            severity AS Severity,
            status AS Status,
            delivery_channel AS DeliveryChannel,
            scheduled_at AS ScheduledAt,
            sent_at AS SentAt,
            read_at AS ReadAt,
            created_at AS CreatedAt
        FROM notifications
        WHERE tenant_id = @TenantId
          AND recipient_id = @UserId
        ORDER BY created_at DESC
        LIMIT 50;
        """;

        await using var connection = CreateConnection();
        var args = new { TenantId = tenantId, UserId = userId };

        var workItems = (await connection.QueryAsync<WorkItem>(
            new CommandDefinition(
                workSql, args, cancellationToken: cancellationToken))).AsList();

        var notifications = (await connection.QueryAsync<Notification>(
            new CommandDefinition(
                notificationSql, args, cancellationToken: cancellationToken))).AsList();

        var now = DateTimeOffset.UtcNow;
        return new WorkQueueSummary(
            workItems.Count,
            workItems.Count(x =>
                x.DueAt.HasValue &&
                x.DueAt.Value >= now &&
                x.DueAt.Value <= now.AddDays(7)),
            workItems.Count(x => x.DueAt.HasValue && x.DueAt.Value < now),
            notifications.Count(x => x.Status == "Unread"),
            workItems,
            notifications);
    }

    public async Task<bool> CompleteAsync(
        Guid tenantId,
        Guid userId,
        Guid workItemId,
        CancellationToken cancellationToken)
    {
        const string sql = """
        UPDATE work_items
        SET status = 'Completed',
            completed_at = NOW(),
            updated_at = NOW()
        WHERE tenant_id = @TenantId
          AND assignee_id = @UserId
          AND id = @WorkItemId
          AND status <> 'Completed';
        """;

        await using var connection = CreateConnection();
        return await connection.ExecuteAsync(
            new CommandDefinition(
                sql,
                new
                {
                    TenantId = tenantId,
                    UserId = userId,
                    WorkItemId = workItemId
                },
                cancellationToken: cancellationToken)) == 1;
    }

    public async Task<bool> MarkNotificationReadAsync(
        Guid tenantId,
        Guid userId,
        Guid notificationId,
        CancellationToken cancellationToken)
    {
        const string sql = """
        UPDATE notifications
        SET status = 'Read',
            read_at = NOW()
        WHERE tenant_id = @TenantId
          AND recipient_id = @UserId
          AND id = @NotificationId;
        """;

        await using var connection = CreateConnection();
        return await connection.ExecuteAsync(
            new CommandDefinition(
                sql,
                new
                {
                    TenantId = tenantId,
                    UserId = userId,
                    NotificationId = notificationId
                },
                cancellationToken: cancellationToken)) == 1;
    }
}
