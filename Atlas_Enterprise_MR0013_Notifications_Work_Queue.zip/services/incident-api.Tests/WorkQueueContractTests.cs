using Atlas.IncidentApi.Domain;

namespace Atlas.IncidentApi.Tests;

public sealed class WorkQueueContractTests
{
    [Fact]
    public void Summary_tracks_due_and_unread_counts()
    {
        var now = DateTimeOffset.UtcNow;
        var userId = Guid.NewGuid();

        var items = new[]
        {
            new WorkItem(
                Guid.NewGuid(), userId, "Safety", "Investigation",
                "Incident", Guid.NewGuid(), "Investigate incident",
                null, "High", "Open", now.AddDays(2), 0,
                now, null, now),
            new WorkItem(
                Guid.NewGuid(), userId, "Employee", "CAPA",
                "CapaAction", Guid.NewGuid(), "Complete CAPA",
                null, "High", "Open", now.AddDays(-2), 1,
                now, null, now)
        };

        var notifications = new[]
        {
            new Notification(
                Guid.NewGuid(), userId, "Overdue", "CAPA overdue",
                "Action is overdue.", "CapaAction", Guid.NewGuid(),
                "Warning", "Unread", "InApp", now, now, null, now)
        };

        var summary = new WorkQueueSummary(
            items.Length, 1, 1, 1, items, notifications);

        Assert.Equal(2, summary.OpenItems);
        Assert.Equal(1, summary.Overdue);
        Assert.Equal(1, summary.UnreadNotifications);
    }
}
