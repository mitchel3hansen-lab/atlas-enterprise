#!/bin/sh
set -eu

dotnet test tests/integration/Atlas.IntegrationTests.csproj \
  --configuration Release \
  --logger "trx;LogFileName=integration-tests.trx" \
  --results-directory TestResults/integration
