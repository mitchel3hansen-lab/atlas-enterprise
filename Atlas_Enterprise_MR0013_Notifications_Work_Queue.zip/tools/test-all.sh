#!/bin/sh
set -eu

echo "Running backend unit tests..."
dotnet test services/incident-api.Tests/incident-api.Tests.csproj \
  --configuration Release

echo "Running PostgreSQL integration tests..."
dotnet test tests/integration/Atlas.IntegrationTests.csproj \
  --configuration Release

echo "Starting Atlas for browser tests..."
docker compose up --build -d

cleanup() {
  docker compose down -v
}
trap cleanup EXIT

for attempt in $(seq 1 60); do
  if curl --fail --silent \
    http://127.0.0.1:${INCIDENT_API_PORT:-8085}/health/ready >/dev/null; then
    break
  fi
  sleep 3
done

cd tests/e2e
npm ci
npx playwright install chromium
npm test
