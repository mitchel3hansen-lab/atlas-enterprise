# Atlas Enterprise

Atlas is an operational intelligence platform with a closed-loop incident workflow, role-based security, audit logging, dashboards, pilot deployment tooling, automated testing, and personal work queues.

## New in MR-0013

- Investigation and CAPA assignments
- Personal work queues
- Due-soon reminders
- Overdue notifications
- Escalation levels
- Background notification scheduling
- In-app notification center

## Start Atlas

```bash
cp .env.example .env
docker compose up --build -d
./tools/pilot-health.sh
./tools/pilot-acceptance.sh
```

## Run notification cycle manually

Use a Safety or Administrator development token:

```text
POST /api/notifications/run-cycle
```

## Tests

```bash
./tools/test-integration.sh
./tools/test-e2e.sh
./tools/test-all.sh
```
