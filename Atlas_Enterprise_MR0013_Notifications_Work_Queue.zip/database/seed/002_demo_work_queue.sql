INSERT INTO work_items (
    id, tenant_id, assignee_id, assignee_role, work_type,
    entity_type, entity_id, title, description, priority,
    status, due_at)
VALUES
(
    '14000000-0000-0000-0000-000000000001',
    '11111111-1111-1111-1111-111111111111',
    '44444444-4444-4444-4444-444444444444',
    'Safety',
    'Investigation',
    'Incident',
    '10000000-0000-0000-0000-000000000001',
    'Investigate INC-DEMO-0001',
    'Complete the demonstration forklift investigation.',
    'High',
    'Open',
    NOW() + INTERVAL '2 days'
)
ON CONFLICT (
    tenant_id, work_type, entity_type, entity_id, assignee_id
) DO NOTHING;

INSERT INTO notifications (
    id, tenant_id, recipient_id, notification_type,
    title, body, entity_type, entity_id, severity,
    status, scheduled_at, sent_at)
VALUES
(
    '15000000-0000-0000-0000-000000000001',
    '11111111-1111-1111-1111-111111111111',
    '44444444-4444-4444-4444-444444444444',
    'Assignment',
    'Investigation assigned',
    'You were assigned the demonstration forklift investigation.',
    'Incident',
    '10000000-0000-0000-0000-000000000001',
    'Warning',
    'Unread',
    NOW(),
    NOW()
)
ON CONFLICT (id) DO NOTHING;
