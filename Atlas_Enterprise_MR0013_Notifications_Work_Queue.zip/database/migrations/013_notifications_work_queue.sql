CREATE TABLE IF NOT EXISTS work_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    assignee_id UUID NOT NULL,
    assignee_role VARCHAR(60),
    work_type VARCHAR(80) NOT NULL,
    entity_type VARCHAR(80) NOT NULL,
    entity_id UUID NOT NULL,
    title VARCHAR(220) NOT NULL,
    description TEXT,
    priority VARCHAR(20) NOT NULL DEFAULT 'Medium',
    status VARCHAR(30) NOT NULL DEFAULT 'Open',
    due_at TIMESTAMPTZ,
    escalation_level INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, work_type, entity_type, entity_id, assignee_id)
);

CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    recipient_id UUID NOT NULL,
    notification_type VARCHAR(80) NOT NULL,
    title VARCHAR(220) NOT NULL,
    body TEXT NOT NULL,
    entity_type VARCHAR(80),
    entity_id UUID,
    severity VARCHAR(20) NOT NULL DEFAULT 'Info',
    status VARCHAR(30) NOT NULL DEFAULT 'Unread',
    delivery_channel VARCHAR(30) NOT NULL DEFAULT 'InApp',
    scheduled_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    sent_at TIMESTAMPTZ,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS escalation_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    work_type VARCHAR(80) NOT NULL,
    days_before_due INTEGER,
    days_overdue INTEGER,
    escalation_level INTEGER NOT NULL,
    recipient_role VARCHAR(60) NOT NULL,
    notification_severity VARCHAR(20) NOT NULL DEFAULT 'Warning',
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_work_items_assignee_status
    ON work_items (tenant_id, assignee_id, status, due_at);

CREATE INDEX IF NOT EXISTS ix_work_items_due
    ON work_items (tenant_id, status, due_at);

CREATE INDEX IF NOT EXISTS ix_notifications_recipient_status
    ON notifications (tenant_id, recipient_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS ix_notifications_scheduled
    ON notifications (status, scheduled_at);

INSERT INTO escalation_rules (
    id, tenant_id, work_type, days_before_due, days_overdue,
    escalation_level, recipient_role, notification_severity)
VALUES
(
    '13000000-0000-0000-0000-000000000001',
    '11111111-1111-1111-1111-111111111111',
    'Investigation',
    2,
    NULL,
    0,
    'Safety',
    'Warning'
),
(
    '13000000-0000-0000-0000-000000000002',
    '11111111-1111-1111-1111-111111111111',
    'CAPA',
    7,
    NULL,
    0,
    'Employee',
    'Info'
),
(
    '13000000-0000-0000-0000-000000000003',
    '11111111-1111-1111-1111-111111111111',
    'CAPA',
    NULL,
    3,
    1,
    'Supervisor',
    'Warning'
),
(
    '13000000-0000-0000-0000-000000000004',
    '11111111-1111-1111-1111-111111111111',
    'CAPA',
    NULL,
    7,
    2,
    'Safety',
    'Critical'
)
ON CONFLICT (id) DO NOTHING;
