# Atlas Automated Testing Strategy

## Testing pyramid

### Unit tests

Fast, isolated tests validate:

- request validation
- claim mapping
- closure gates
- security middleware contracts
- dashboard calculations

### Integration tests

Integration tests use Testcontainers for .NET to start a disposable PostgreSQL 17 database. The suite applies the real Atlas SQL migrations and starts the ASP.NET Core application through `WebApplicationFactory`.

Coverage includes:

- migration execution
- required schema objects
- append-only audit enforcement
- development-token issuance
- tenant identity replacement
- incident creation and submission
- role-based dashboard denial
- authorized dashboard and audit access

### End-to-end tests

Playwright starts from the browser and validates:

- initial Safety workspace
- role switching
- Employee dashboard restriction
- incident reporting
- responsive desktop and mobile Chromium projects

## Failure evidence

CI retains:

- .NET TRX results
- Playwright HTML report
- JUnit XML
- traces
- screenshots
- videos
- Docker Compose logs

## Local execution

```bash
./tools/test-integration.sh
./tools/test-e2e.sh
./tools/test-all.sh
```

Docker is required for PostgreSQL integration tests and end-to-end tests.
