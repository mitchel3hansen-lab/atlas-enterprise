# ADR-005: Work Queue and Notification Model

## Status

Accepted

## Decision

Atlas separates actionable assignments (`work_items`) from user-facing messages (`notifications`).

## Rationale

A notification may be dismissed, but an operational assignment must remain visible until completed or cancelled.

## Consequences

- Workflow services synchronize assignments into a common queue.
- Notifications can be regenerated without duplicating work.
- External delivery channels can be added later without changing assignment ownership.
- Multi-replica scheduling will require distributed locking.
