const { test, expect } = require("@playwright/test");

test("Safety user can open secure dashboard and operations", async ({ page }) => {
  await page.goto("/");

  await expect(page.getByText("Secure Operations")).toBeVisible();
  await expect(page.getByText("Authenticated")).toBeVisible();

  await page.getByRole("button", { name: "Operations" }).click();
  await expect(page.getByRole("heading", { name: "Report an Incident" }))
    .toBeVisible();
});

test("Employee role is restricted to incident operations", async ({ page }) => {
  await page.goto("/");

  await page.getByLabel("Active role").selectOption("Employee");

  await expect(page.getByRole("heading", { name: "Report an Incident" }))
    .toBeVisible();
  await expect(page.getByRole("button", { name: "Dashboard" }))
    .toHaveCount(0);
});

test("Employee can create a tenant-scoped incident", async ({ page }) => {
  await page.goto("/");
  await page.getByLabel("Active role").selectOption("Employee");

  const uniqueTitle = `E2E near miss ${Date.now()}`;

  await page.getByLabel("Incident title").fill(uniqueTitle);
  await page.getByLabel("Description").fill(
    "A forklift stopped before entering a marked pedestrian route.");

  const localDate = new Date(Date.now() - 5 * 60 * 1000)
    .toISOString()
    .slice(0, 16);

  await page.getByLabel("Occurred at").fill(localDate);
  await page.getByRole("button", { name: "Save Incident Draft" }).click();

  await expect(page.getByText(/created using authenticated identity/i))
    .toBeVisible();
  await expect(page.getByText(uniqueTitle)).toBeVisible();
});
