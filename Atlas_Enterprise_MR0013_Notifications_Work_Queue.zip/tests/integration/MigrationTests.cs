using Npgsql;

namespace Atlas.IntegrationTests;

public sealed class MigrationTests(PostgresFixture database)
    : IClassFixture<PostgresFixture>
{
    [Theory]
    [InlineData("incidents")]
    [InlineData("investigations")]
    [InlineData("capa_actions")]
    [InlineData("incident_closure_reviews")]
    [InlineData("audit_events")]
    [InlineData("atlas_schema_history")]
    public async Task Required_table_exists(string tableName)
    {
        await using var connection =
            new NpgsqlConnection(database.ConnectionString);
        await connection.OpenAsync();

        await using var command = new NpgsqlCommand(
            """
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = 'public'
                  AND table_name = @table_name
            );
            """,
            connection);

        command.Parameters.AddWithValue("table_name", tableName);

        Assert.True((bool)(await command.ExecuteScalarAsync())!);
    }

    [Fact]
    public async Task Audit_table_rejects_updates()
    {
        await using var connection =
            new NpgsqlConnection(database.ConnectionString);
        await connection.OpenAsync();

        await using var insert = new NpgsqlCommand(
            """
            INSERT INTO audit_events (
                id, event_type, action, outcome, correlation_id)
            VALUES (
                @id, 'Test', 'Insert', 'Success', 'migration-test');
            """,
            connection);

        var id = Guid.NewGuid();
        insert.Parameters.AddWithValue("id", id);
        await insert.ExecuteNonQueryAsync();

        await using var update = new NpgsqlCommand(
            "UPDATE audit_events SET outcome = 'Changed' WHERE id = @id;",
            connection);
        update.Parameters.AddWithValue("id", id);

        await Assert.ThrowsAsync<PostgresException>(
            () => update.ExecuteNonQueryAsync());
    }
}
