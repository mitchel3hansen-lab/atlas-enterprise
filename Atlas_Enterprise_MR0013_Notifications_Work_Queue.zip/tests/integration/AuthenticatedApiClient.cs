using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Atlas.IntegrationTests;

public static class AuthenticatedApiClient
{
    public static async Task<HttpClient> CreateAsync(
        AtlasApiFactory factory,
        string role,
        string department = "Warehouse")
    {
        var client = factory.CreateClient();
        var tokenResponse = await client.PostAsJsonAsync(
            "/api/auth/dev-token",
            new
            {
                userId = Guid.NewGuid(),
                tenantId = TestIdentity.TenantId,
                role,
                department
            });

        tokenResponse.EnsureSuccessStatusCode();

        var payload = await tokenResponse.Content
            .ReadFromJsonAsync<TokenResponse>();

        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue(
                "Bearer",
                payload?.AccessToken ??
                throw new InvalidOperationException("Token was not returned."));

        return client;
    }

    private sealed record TokenResponse(string AccessToken);
}

public static class TestIdentity
{
    public static readonly Guid TenantId =
        Guid.Parse("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa");
}
