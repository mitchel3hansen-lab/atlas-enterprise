using Atlas.IncidentApi.Security;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;

namespace Atlas.IntegrationTests;

public sealed class AtlasApiFactory(PostgresFixture database)
    : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");

        builder.ConfigureAppConfiguration((_, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["ConnectionStrings:Atlas"] = database.ConnectionString,
                ["Authentication:Issuer"] = "atlas-integration-tests",
                ["Authentication:Audience"] = "atlas-api-tests",
                ["Authentication:DevSigningKey"] =
                    "atlas-integration-test-signing-key-must-be-long-enough-2026"
            });
        });
    }
}
