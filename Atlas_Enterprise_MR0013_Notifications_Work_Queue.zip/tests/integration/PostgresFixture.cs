using Npgsql;
using Testcontainers.PostgreSql;

namespace Atlas.IntegrationTests;

public sealed class PostgresFixture : IAsyncLifetime
{
    public PostgreSqlContainer Container { get; } =
        new PostgreSqlBuilder("postgres:17-alpine")
            .WithDatabase("atlas_test")
            .WithUsername("atlas_test")
            .WithPassword("atlas_test_password")
            .Build();

    public string ConnectionString => Container.GetConnectionString();

    public async Task InitializeAsync()
    {
        await Container.StartAsync();
        await ApplyMigrationsAsync();
    }

    public async Task DisposeAsync()
    {
        await Container.DisposeAsync();
    }

    private async Task ApplyMigrationsAsync()
    {
        var repositoryRoot = FindRepositoryRoot();
        var migrationDirectory =
            Path.Combine(repositoryRoot, "database", "migrations");

        var files = Directory
            .GetFiles(migrationDirectory, "*.sql")
            .OrderBy(path => path, StringComparer.Ordinal)
            .ToArray();

        await using var connection = new NpgsqlConnection(ConnectionString);
        await connection.OpenAsync();

        foreach (var file in files)
        {
            var sql = await File.ReadAllTextAsync(file);
            await using var command = new NpgsqlCommand(sql, connection);
            await command.ExecuteNonQueryAsync();
        }
    }

    private static string FindRepositoryRoot()
    {
        var current = new DirectoryInfo(AppContext.BaseDirectory);

        while (current is not null)
        {
            if (Directory.Exists(Path.Combine(current.FullName, "database")) &&
                Directory.Exists(Path.Combine(current.FullName, "services")))
                return current.FullName;

            current = current.Parent;
        }

        throw new DirectoryNotFoundException(
            "Unable to locate the Atlas repository root.");
    }
}
