using System.Net;
using System.Net.Http.Json;

namespace Atlas.IntegrationTests;

public sealed class IncidentWorkflowTests(PostgresFixture database)
    : IClassFixture<PostgresFixture>
{
    [Fact]
    public async Task Employee_can_create_and_submit_incident()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory,
            "Employee");

        var createResponse = await client.PostAsJsonAsync(
            "/api/incidents",
            new
            {
                tenantId = Guid.Empty,
                reporterId = Guid.Empty,
                title = "Integration test forklift near miss",
                description = "A forklift stopped before entering a pedestrian path.",
                incidentType = "Near Miss",
                severity = "Medium",
                occurredAt = DateTimeOffset.UtcNow.AddMinutes(-10),
                site = "Lindon",
                department = "Warehouse"
            });

        Assert.Equal(HttpStatusCode.Created, createResponse.StatusCode);

        var created = await createResponse.Content
            .ReadFromJsonAsync<IncidentResponse>();

        Assert.NotNull(created);
        Assert.Equal(TestIdentity.TenantId, created.TenantId);
        Assert.Equal("Draft", created.WorkflowState);

        var submitResponse = await client.PostAsync(
            $"/api/incidents/{created.Id}/submit",
            content: null);

        Assert.Equal(HttpStatusCode.OK, submitResponse.StatusCode);

        var submitted = await submitResponse.Content
            .ReadFromJsonAsync<IncidentResponse>();

        Assert.Equal("SupervisorReview", submitted?.WorkflowState);
    }

    [Fact]
    public async Task Employee_cannot_open_executive_dashboard()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory,
            "Employee");

        var response = await client.GetAsync("/api/dashboard/summary");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        Assert.True(response.Headers.Contains("X-Correlation-ID"));
    }

    [Fact]
    public async Task Executive_can_open_dashboard_and_audit_log()
    {
        await using var factory = new AtlasApiFactory(database);
        using var client = await AuthenticatedApiClient.CreateAsync(
            factory,
            "Executive",
            "Executive");

        var dashboard = await client.GetAsync("/api/dashboard/summary");
        var audit = await client.GetAsync("/api/audit-events?limit=10");

        Assert.Equal(HttpStatusCode.OK, dashboard.StatusCode);
        Assert.Equal(HttpStatusCode.OK, audit.StatusCode);
    }

    private sealed record IncidentResponse(
        Guid Id,
        Guid TenantId,
        string IncidentNumber,
        string Status,
        string WorkflowState);
}
