using System.Net;
using System.Net.Http.Json;
using Dapper;
using Npgsql;

namespace Atlas.IntegrationTests;

public sealed class WorkQueueIntegrationTests(PostgresFixture database)
    : IClassFixture<PostgresFixture>
{
    [Fact]
    public async Task Authenticated_user_can_read_personal_work_queue()
    {
        var userId = Guid.NewGuid();

        await using (var connection =
            new NpgsqlConnection(database.ConnectionString))
        {
            await connection.OpenAsync();

            await connection.ExecuteAsync(
                """
                INSERT INTO work_items (
                    id, tenant_id, assignee_id, assignee_role,
                    work_type, entity_type, entity_id, title,
                    priority, status, due_at)
                VALUES (
                    @Id, @TenantId, @UserId, 'Employee',
                    'CAPA', 'CapaAction', @EntityId, 'Complete test CAPA',
                    'High', 'Open', NOW() + INTERVAL '2 days');
                """,
                new
                {
                    Id = Guid.NewGuid(),
                    TenantId = TestIdentity.TenantId,
                    UserId = userId,
                    EntityId = Guid.NewGuid()
                });
        }

        await using var factory = new AtlasApiFactory(database);
        var client = factory.CreateClient();

        var tokenResponse = await client.PostAsJsonAsync(
            "/api/auth/dev-token",
            new
            {
                userId,
                tenantId = TestIdentity.TenantId,
                role = "Employee",
                department = "Warehouse"
            });

        var token = await tokenResponse.Content
            .ReadFromJsonAsync<TokenPayload>();

        client.DefaultRequestHeaders.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue(
                "Bearer",
                token!.AccessToken);

        var response = await client.GetAsync("/api/work-queue");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var queue = await response.Content
            .ReadFromJsonAsync<QueuePayload>();

        Assert.NotNull(queue);
        Assert.Equal(1, queue.OpenItems);
        Assert.Single(queue.Items);
    }

    private sealed record TokenPayload(string AccessToken);

    private sealed record QueuePayload(
        int OpenItems,
        IReadOnlyList<QueueItem> Items);

    private sealed record QueueItem(
        Guid Id,
        string Title);
}
