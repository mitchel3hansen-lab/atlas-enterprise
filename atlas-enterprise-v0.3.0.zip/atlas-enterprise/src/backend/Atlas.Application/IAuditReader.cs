namespace Atlas.Application;

public sealed record AuditEntry(
    Guid Id,
    Guid? OrganizationId,
    Guid? ActorId,
    string Action,
    string ResourceType,
    Guid? ResourceId,
    DateTimeOffset OccurredAt,
    string Payload);

public interface IAuditReader
{
    Task<IReadOnlyList<AuditEntry>> ListForOrganizationAsync(
        Guid organizationId,
        int limit,
        CancellationToken cancellationToken);
}
