using Atlas.Application;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Infrastructure;

public sealed class AuditReader(AtlasDbContext dbContext) : IAuditReader
{
    public async Task<IReadOnlyList<AuditEntry>> ListForOrganizationAsync(
        Guid organizationId,
        int limit,
        CancellationToken cancellationToken)
    {
        var take = Math.Clamp(limit, 1, 100);
        return await dbContext.AuditEvents
            .AsNoTracking()
            .Where(x => x.OrganizationId == organizationId)
            .OrderByDescending(x => x.OccurredAt)
            .Take(take)
            .Select(x => new AuditEntry(
                x.Id,
                x.OrganizationId,
                x.ActorId,
                x.Action,
                x.ResourceType,
                x.ResourceId,
                x.OccurredAt,
                x.Payload))
            .ToListAsync(cancellationToken);
    }
}
