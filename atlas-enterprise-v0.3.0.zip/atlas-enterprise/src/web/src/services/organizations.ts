export type Organization = {
  id: string;
  name: string;
  code: string;
  isArchived: boolean;
  createdAt: string;
  updatedAt: string;
  facilities?: Facility[];
  departments?: Department[];
};

export type Facility = {
  id: string;
  organizationId: string;
  name: string;
  code: string;
  isArchived: boolean;
  createdAt: string;
  updatedAt: string;
};

export type Department = {
  id: string;
  organizationId: string;
  facilityId: string | null;
  parentDepartmentId: string | null;
  name: string;
  isArchived: boolean;
  createdAt: string;
  updatedAt: string;
};

export type AuditEntry = {
  id: string;
  organizationId: string | null;
  actorId: string | null;
  action: string;
  resourceType: string;
  resourceId: string | null;
  occurredAt: string;
  payload: string;
};

export type CreateOrganization = { name: string; code: string };
export type CreateFacility = { name: string; code: string };
export type CreateDepartment = {
  name: string;
  facilityId?: string | null;
  parentDepartmentId?: string | null;
};

const baseUrl = import.meta.env.VITE_ATLAS_API_URL ?? 'http://localhost:5080/api/v1';

async function parseResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const problem = await response.json().catch(() => null) as { detail?: string } | null;
    throw new Error(problem?.detail ?? `Atlas API returned ${response.status}.`);
  }
  return response.json() as Promise<T>;
}

const tenantHeaders = (organizationId: string) => ({
  'Content-Type': 'application/json',
  'X-Atlas-Organization-Id': organizationId,
});

export async function listOrganizations(): Promise<Organization[]> {
  return parseResponse<Organization[]>(await fetch(`${baseUrl}/organizations`));
}

export async function getOrganization(organizationId: string): Promise<Organization> {
  return parseResponse<Organization>(await fetch(`${baseUrl}/organizations/${organizationId}`));
}

export async function createOrganization(input: CreateOrganization): Promise<Organization> {
  return parseResponse<Organization>(await fetch(`${baseUrl}/organizations`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  }));
}

export async function createFacility(organizationId: string, input: CreateFacility): Promise<Facility> {
  return parseResponse<Facility>(await fetch(`${baseUrl}/organizations/${organizationId}/facilities`, {
    method: 'POST',
    headers: tenantHeaders(organizationId),
    body: JSON.stringify(input),
  }));
}

export async function createDepartment(organizationId: string, input: CreateDepartment): Promise<Department> {
  return parseResponse<Department>(await fetch(`${baseUrl}/organizations/${organizationId}/departments`, {
    method: 'POST',
    headers: tenantHeaders(organizationId),
    body: JSON.stringify(input),
  }));
}

export async function listAuditEvents(organizationId: string): Promise<AuditEntry[]> {
  return parseResponse<AuditEntry[]>(await fetch(
    `${baseUrl}/organizations/${organizationId}/audit-events?limit=25`,
    { headers: tenantHeaders(organizationId) },
  ));
}
