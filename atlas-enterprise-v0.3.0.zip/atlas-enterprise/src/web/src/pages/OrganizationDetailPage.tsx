import { FormEvent, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useParams } from 'react-router-dom';
import {
  createDepartment,
  createFacility,
  getOrganization,
  listAuditEvents,
} from '../services/organizations';

export function OrganizationDetailPage() {
  const { organizationId = '' } = useParams();
  const queryClient = useQueryClient();
  const [facilityName, setFacilityName] = useState('');
  const [facilityCode, setFacilityCode] = useState('');
  const [departmentName, setDepartmentName] = useState('');
  const [departmentFacilityId, setDepartmentFacilityId] = useState('');

  const organization = useQuery({
    queryKey: ['organization', organizationId],
    queryFn: () => getOrganization(organizationId),
    enabled: Boolean(organizationId),
  });
  const audit = useQuery({
    queryKey: ['audit-events', organizationId],
    queryFn: () => listAuditEvents(organizationId),
    enabled: Boolean(organizationId),
  });

  const refresh = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['organization', organizationId] }),
      queryClient.invalidateQueries({ queryKey: ['audit-events', organizationId] }),
    ]);
  };

  const facilityMutation = useMutation({
    mutationFn: () => createFacility(organizationId, {
      name: facilityName.trim(),
      code: facilityCode.trim().toUpperCase(),
    }),
    onSuccess: async () => {
      setFacilityName('');
      setFacilityCode('');
      await refresh();
    },
  });

  const departmentMutation = useMutation({
    mutationFn: () => createDepartment(organizationId, {
      name: departmentName.trim(),
      facilityId: departmentFacilityId || null,
    }),
    onSuccess: async () => {
      setDepartmentName('');
      setDepartmentFacilityId('');
      await refresh();
    },
  });

  function submitFacility(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    facilityMutation.mutate();
  }

  function submitDepartment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    departmentMutation.mutate();
  }

  if (organization.isLoading) return <p>Loading organization…</p>;
  if (organization.isError || !organization.data) return <p role="alert">Organization could not be loaded.</p>;

  const data = organization.data;
  const facilities = data.facilities ?? [];
  const departments = data.departments ?? [];

  return (
    <section>
      <Link className="back-link" to="/organizations">← Organizations</Link>
      <header className="page-header">
        <div>
          <p className="eyebrow">Atlas Core / {data.code}</p>
          <h1>{data.name}</h1>
          <p>Build the operational structure that anchors risk, knowledge, workflows, and reporting.</p>
        </div>
        <span className="status-pill">{data.isArchived ? 'Archived' : 'Active'}</span>
      </header>

      <div className="two-column-grid">
        <article className="panel">
          <h2>Facilities</h2>
          <form className="stack-form" onSubmit={submitFacility}>
            <label>Name<input value={facilityName} onChange={(e) => setFacilityName(e.target.value)} required /></label>
            <label>Code<input value={facilityCode} onChange={(e) => setFacilityCode(e.target.value)} required /></label>
            <button disabled={facilityMutation.isPending}>Add facility</button>
            {facilityMutation.isError && <p role="alert">{facilityMutation.error.message}</p>}
          </form>
          <div className="record-list">
            {facilities.length === 0 && <p>No facilities yet.</p>}
            {facilities.map((facility) => (
              <div className="record-row" key={facility.id}>
                <strong>{facility.name}</strong><span>{facility.code}</span>
              </div>
            ))}
          </div>
        </article>

        <article className="panel">
          <h2>Departments</h2>
          <form className="stack-form" onSubmit={submitDepartment}>
            <label>Name<input value={departmentName} onChange={(e) => setDepartmentName(e.target.value)} required /></label>
            <label>Facility
              <select value={departmentFacilityId} onChange={(e) => setDepartmentFacilityId(e.target.value)}>
                <option value="">Organization-wide</option>
                {facilities.map((facility) => <option key={facility.id} value={facility.id}>{facility.name}</option>)}
              </select>
            </label>
            <button disabled={departmentMutation.isPending}>Add department</button>
            {departmentMutation.isError && <p role="alert">{departmentMutation.error.message}</p>}
          </form>
          <div className="record-list">
            {departments.length === 0 && <p>No departments yet.</p>}
            {departments.map((department) => {
              const facility = facilities.find((item) => item.id === department.facilityId);
              return <div className="record-row" key={department.id}><strong>{department.name}</strong><span>{facility?.name ?? 'Organization-wide'}</span></div>;
            })}
          </div>
        </article>
      </div>

      <article className="panel">
        <h2>Activity</h2>
        {audit.isLoading && <p>Loading activity…</p>}
        {audit.data?.length === 0 && <p>No activity has been recorded.</p>}
        <div className="timeline">
          {audit.data?.map((entry) => (
            <div className="timeline-item" key={entry.id}>
              <strong>{entry.action.replaceAll('.', ' ')}</strong>
              <span>{new Date(entry.occurredAt).toLocaleString()}</span>
            </div>
          ))}
        </div>
      </article>
    </section>
  );
}
