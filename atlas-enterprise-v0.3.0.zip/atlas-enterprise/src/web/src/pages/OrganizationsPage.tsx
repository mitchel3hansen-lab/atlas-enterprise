import { FormEvent, useState } from 'react';
import { Link } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { createOrganization, listOrganizations } from '../services/organizations';

export function OrganizationsPage() {
  const queryClient = useQueryClient();
  const [isFormOpen, setFormOpen] = useState(false);
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const query = useQuery({ queryKey: ['organizations'], queryFn: listOrganizations });
  const mutation = useMutation({
    mutationFn: createOrganization,
    onSuccess: async () => {
      setName('');
      setCode('');
      setFormOpen(false);
      await queryClient.invalidateQueries({ queryKey: ['organizations'] });
    },
  });

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    mutation.mutate({ name: name.trim(), code: code.trim().toUpperCase() });
  }

  return (
    <section>
      <header className="page-header">
        <div>
          <p className="eyebrow">Atlas Core</p>
          <h1>Organizations</h1>
          <p>Manage the tenant-level structures that anchor every Atlas capability.</p>
        </div>
        <button type="button" onClick={() => setFormOpen((value) => !value)}>
          {isFormOpen ? 'Cancel' : 'New organization'}
        </button>
      </header>

      {isFormOpen && (
        <form className="panel organization-form" onSubmit={submit}>
          <div>
            <label htmlFor="organization-name">Organization name</label>
            <input
              id="organization-name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              maxLength={200}
              required
              autoFocus
            />
          </div>
          <div>
            <label htmlFor="organization-code">Code</label>
            <input
              id="organization-code"
              value={code}
              onChange={(event) => setCode(event.target.value)}
              maxLength={50}
              required
            />
          </div>
          <button type="submit" disabled={mutation.isPending}>Create organization</button>
          {mutation.isError && <p role="alert">{mutation.error.message}</p>}
        </form>
      )}

      <article className="panel">
        {query.isLoading && <p>Loading organizations…</p>}
        {query.isError && <p role="alert">The Atlas API is unavailable. Start the backend to load live data.</p>}
        {query.data?.length === 0 && <p>No organizations have been created.</p>}
        {query.data?.map((organization) => (
          <div className="organization-row" key={organization.id}>
            <div>
              <strong><Link to={`/organizations/${organization.id}`}>{organization.name}</Link></strong>
              <span>{organization.code}</span>
            </div>
            <span>{organization.isArchived ? 'Archived' : 'Active'}</span>
          </div>
        ))}
      </article>
    </section>
  );
}
