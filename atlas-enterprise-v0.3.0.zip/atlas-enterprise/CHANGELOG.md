# Changelog

## [0.3.0] - 2026-07-22

### Added
- Organization operational-structure workspace.
- Facility and department creation interfaces.
- Organization-scoped audit activity endpoint and timeline.
- Tenant-aware frontend API client.

## [0.2.0] - 2026-07-22

### Added
- Organization creation UI.
- Tenant-scoped facility and department APIs.
- Immutable create-operation audit events.
- Domain guardrails and OpenAPI 0.2 contract.


## [0.1.0-genesis] - 2026-07-22

### Added
- Atlas Foundation repository structure.
- Initial company charter and enterprise blueprint.
- Organization, facility, and department domain models.
- PostgreSQL schema and OpenAPI contract.
- ASP.NET Core and React application skeletons.
- Docker Compose and CI workflow.
