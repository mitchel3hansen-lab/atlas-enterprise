# Atlas Enterprise

Atlas is an operational intelligence platform beginning with a complete incident and CAPA vertical slice.

## Current workflow

```text
Draft
→ SupervisorReview
→ SafetyReview
→ Investigation
→ CAPA
→ Verification
```

## Current capabilities

- Incident creation and submission
- Supervisor and Safety review
- Investigator assignment
- Structured investigation
- Findings and evidence
- Root cause and recommendations
- Corrective and preventive actions
- Ownership and due dates
- Completion evidence
- Independent verification
- Effectiveness review
- Reopening controls
- Automatic routing toward final incident verification

## Start locally

```bash
docker compose down -v
docker compose up --build
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger
