import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const apiUrl = import.meta.env.VITE_INCIDENT_API_URL ?? "http://localhost:8085";
const tenantId = "11111111-1111-1111-1111-111111111111";

const personas = {
  Employee: {
    userId: "22222222-2222-2222-2222-222222222222",
    department: "Warehouse"
  },
  Supervisor: {
    userId: "33333333-3333-3333-3333-333333333333",
    department: "Warehouse"
  },
  Safety: {
    userId: "44444444-4444-4444-4444-444444444444",
    department: "Safety"
  },
  Executive: {
    userId: "77777777-7777-7777-7777-777777777777",
    department: "Executive"
  }
} as const;

type Role = keyof typeof personas;

type Incident = {
  id: string;
  incidentNumber: string;
  title: string;
  severity: string;
  status: string;
  workflowState: string;
  site: string;
  department: string;
};

type Dashboard = {
  openIncidents: number;
  criticalIncidents: number;
  capasOpen: number;
  capasOverdue: number;
  closureRate: number;
  capaEffectivenessRate: number;
  averageClosureDays: number;
  bySeverity: Array<{ name: string; count: number }>;
  byWorkflow: Array<{ name: string; count: number }>;
  byDepartment: Array<{
    department: string;
    totalIncidents: number;
    openIncidents: number;
    openCapas: number;
    overdueCapas: number;
  }>;
};

function App() {
  const [role, setRole] = useState<Role>("Safety");
  const [token, setToken] = useState("");
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [view, setView] = useState<"dashboard" | "operations">("dashboard");
  const [message, setMessage] = useState("");

  async function login(nextRole: Role) {
    const persona = personas[nextRole];
    const response = await fetch(`${apiUrl}/api/auth/dev-token`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: persona.userId,
        tenantId,
        role: nextRole,
        department: persona.department
      })
    });
    if (!response.ok) {
      const correlationId = response.headers.get("X-Correlation-ID");
      throw new Error(`Unable to create development token.${correlationId ? ` Reference: ${correlationId}` : ""}`);
    }
    const result = await response.json();
    setToken(result.accessToken);
    setRole(nextRole);
    setMessage(`Signed in as ${nextRole}.`);
    return result.accessToken as string;
  }

  async function apiFetch(path: string, init?: RequestInit, accessToken = token) {
    return fetch(`${apiUrl}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
        ...(init?.headers ?? {})
      }
    });
  }

  async function load(accessToken = token, currentRole = role) {
    if (!accessToken) return;
    const incidentResponse = await apiFetch("/api/incidents", undefined, accessToken);
    setIncidents(incidentResponse.ok ? await incidentResponse.json() : []);

    if (currentRole !== "Employee") {
      const dashboardResponse = await apiFetch(
        "/api/dashboard/summary", undefined, accessToken);
      setDashboard(dashboardResponse.ok ? await dashboardResponse.json() : null);
    } else {
      setDashboard(null);
      setView("operations");
    }
  }

  useEffect(() => {
    login("Safety")
      .then(accessToken => load(accessToken, "Safety"))
      .catch(error => setMessage(error.message));
  }, []);

  async function changeRole(nextRole: Role) {
    try {
      const accessToken = await login(nextRole);
      await load(accessToken, nextRole);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Login failed.");
    }
  }

  async function createIncident(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const response = await apiFetch("/api/incidents", {
      method: "POST",
      body: JSON.stringify({
        tenantId: "00000000-0000-0000-0000-000000000000",
        reporterId: "00000000-0000-0000-0000-000000000000",
        title: String(form.get("title") ?? ""),
        description: String(form.get("description") ?? ""),
        incidentType: "Property Damage",
        severity: "High",
        occurredAt: new Date(String(form.get("occurredAt"))).toISOString(),
        site: "Lindon",
        department: personas[role].department
      })
    });

    const result = await response.json();
    if (!response.ok) {
      const correlationId = response.headers.get("X-Correlation-ID");
      setMessage(`${result.message ?? result.title ?? "Unable to create incident."}${correlationId ? ` Reference: ${correlationId}` : ""}`);
      return;
    }

    setMessage(`${result.incidentNumber} created using authenticated identity.`);
    event.currentTarget.reset();
    await load();
  }

  const maxSeverity = useMemo(
    () => Math.max(1, ...(dashboard?.bySeverity.map(x => x.count) ?? [1])),
    [dashboard]
  );

  return (
    <main>
      <header className="app-header">
        <div>
          <span className="eyebrow">ATLAS ENTERPRISE</span>
          <h1>Secure Operations</h1>
          <p>Tenant-isolated workflows with role-based access.</p>
        </div>
        <div className="session">
          <label>
            Active role
            <select value={role} onChange={event => changeRole(event.target.value as Role)}>
              {Object.keys(personas).map(name => <option key={name}>{name}</option>)}
            </select>
          </label>
          <span className="badge">Authenticated</span>
        </div>
      </header>

      {role !== "Employee" && (
        <nav>
          <button className={view === "dashboard" ? "" : "secondary"}
            onClick={() => setView("dashboard")}>Dashboard</button>
          <button className={view === "operations" ? "" : "secondary"}
            onClick={() => setView("operations")}>Operations</button>
        </nav>
      )}

      {view === "dashboard" && dashboard && (
        <>
          <section className="metrics">
            <Metric label="Open incidents" value={dashboard.openIncidents} />
            <Metric label="Critical incidents" value={dashboard.criticalIncidents} />
            <Metric label="Open CAPAs" value={dashboard.capasOpen} />
            <Metric label="Overdue CAPAs" value={dashboard.capasOverdue} />
            <Metric label="Closure rate" value={`${dashboard.closureRate}%`} />
            <Metric label="CAPA effectiveness" value={`${dashboard.capaEffectivenessRate}%`} />
          </section>

          <section className="dashboard-grid">
            <div className="panel">
              <h2>Severity distribution</h2>
              {(dashboard.bySeverity ?? []).map(bucket => (
                <div className="bar-row" key={bucket.name}>
                  <span>{bucket.name}</span>
                  <div className="bar-track">
                    <div className="bar-fill"
                      style={{ width: `${100 * bucket.count / maxSeverity}%` }} />
                  </div>
                  <strong>{bucket.count}</strong>
                </div>
              ))}
            </div>

            <div className="panel">
              <h2>Workflow workload</h2>
              <div className="workflow-list">
                {(dashboard.byWorkflow ?? []).map(bucket => (
                  <div key={bucket.name}>
                    <span>{bucket.name}</span>
                    <strong>{bucket.count}</strong>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </>
      )}

      {view === "operations" && (
        <>
          <section className="panel">
            <h2>Report an Incident</h2>
            <p>The API ignores submitted tenant and reporter IDs and uses the signed-in claims.</p>
            <form onSubmit={createIncident}>
              <label>Incident title<input name="title" required /></label>
              <label>Description<textarea name="description" required rows={4} /></label>
              <label>Occurred at<input name="occurredAt" type="datetime-local" required /></label>
              <button>Save Incident Draft</button>
            </form>
          </section>

          <section className="panel">
            <div className="section-heading">
              <div>
                <h2>Authorized Incident Queue</h2>
                <p>Employee access is restricted to the authenticated department.</p>
              </div>
              <span className="badge">{incidents.length} visible</span>
            </div>
            <div className="incident-list">
              {incidents.map(incident => (
                <article key={incident.id}>
                  <div>
                    <span className="number">{incident.incidentNumber}</span>
                    <h3>{incident.title}</h3>
                    <p>{incident.site} · {incident.department}</p>
                  </div>
                  <div className="badges">
                    <span className={`badge ${incident.severity.toLowerCase()}`}>
                      {incident.severity}
                    </span>
                    <span className="badge">{incident.workflowState}</span>
                  </div>
                </article>
              ))}
            </div>
          </section>
        </>
      )}

      {message && <output>{message}</output>}
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string | number }) {
  return (
    <article className="metric">
      <span>{label}</span>
      <strong>{value}</strong>
    </article>
  );
}

createRoot(document.getElementById("root")!).render(
  <React.StrictMode><App /></React.StrictMode>
);
