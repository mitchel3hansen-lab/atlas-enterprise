# Atlas Enterprise

Atlas is an operational intelligence platform with a complete closed-loop incident workflow, role-based security, audit logging, dashboards, and controlled pilot deployment tooling.

## Start Atlas

```bash
cp .env.example .env
# Edit .env and replace default secrets.

docker compose up --build -d
./tools/pilot-health.sh
./tools/pilot-acceptance.sh
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger
- API liveness: http://localhost:8085/health/live
- API readiness: http://localhost:8085/health/ready

## Operations

```bash
./tools/backup.sh
./tools/restore.sh backups/<backup>.dump
./tools/reset-pilot.sh
```

## Pilot readiness

Review:

- `docs/PILOT_DEPLOYMENT_GUIDE.md`
- `docs/PILOT_ACCEPTANCE_CHECKLIST.md`

## Important limitations

The development identity provider is not production authentication. TLS, managed secrets, centralized monitoring, and production database resilience remain required before a broader deployment.
