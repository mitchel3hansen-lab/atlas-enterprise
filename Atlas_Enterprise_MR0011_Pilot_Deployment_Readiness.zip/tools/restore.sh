#!/bin/sh
set -eu

if [ "$#" -ne 1 ]; then
  echo "Usage: $0 backups/atlas-YYYYMMDDTHHMMSSZ.dump" >&2
  exit 1
fi

FILE="$1"
test -f "$FILE"

docker compose exec -T postgres dropdb \
  -U "${POSTGRES_USER:-atlas}" \
  --if-exists "${POSTGRES_DB:-atlas}"

docker compose exec -T postgres createdb \
  -U "${POSTGRES_USER:-atlas}" \
  "${POSTGRES_DB:-atlas}"

cat "$FILE" | docker compose exec -T postgres pg_restore \
  -U "${POSTGRES_USER:-atlas}" \
  -d "${POSTGRES_DB:-atlas}" \
  --clean \
  --if-exists \
  --no-owner

echo "Restore completed from: $FILE"
