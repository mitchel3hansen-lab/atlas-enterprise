#!/bin/sh
set -eu

docker compose down -v
docker compose up --build -d

echo "Waiting for services..."
sleep 15

./tools/pilot-health.sh
./tools/pilot-acceptance.sh
