#!/bin/sh
set -eu

BACKUP_DIR="${ATLAS_BACKUP_DIR:-./backups}"
STAMP=$(date -u +"%Y%m%dT%H%M%SZ")
FILE="$BACKUP_DIR/atlas-$STAMP.dump"

mkdir -p "$BACKUP_DIR"

docker compose exec -T postgres pg_dump \
  -U "${POSTGRES_USER:-atlas}" \
  -d "${POSTGRES_DB:-atlas}" \
  -Fc > "$FILE"

test -s "$FILE"
echo "Backup created: $FILE"
