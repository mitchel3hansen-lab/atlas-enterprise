#!/bin/sh
set -eu

API_PORT="${INCIDENT_API_PORT:-8085}"
WEB_PORT="${ATLAS_WEB_PORT:-5173}"

echo "Checking Atlas web..."
curl --fail --silent --show-error \
  "http://localhost:$WEB_PORT/" >/dev/null

echo "Checking API liveness..."
curl --fail --silent --show-error \
  "http://localhost:$API_PORT/health/live" >/dev/null

echo "Checking API readiness..."
curl --fail --silent --show-error \
  "http://localhost:$API_PORT/health/ready" >/dev/null

echo "Checking containers..."
docker compose ps

echo "Atlas pilot health checks passed."
