#!/bin/sh
set -eu

API_PORT="${INCIDENT_API_PORT:-8085}"
BASE="http://localhost:$API_PORT"

TENANT="11111111-1111-1111-1111-111111111111"
USER="88888888-8888-8888-8888-888888888888"

echo "Obtaining Administrator development token..."
TOKEN=$(curl --fail --silent --show-error \
  -H "Content-Type: application/json" \
  -d "{
    \"userId\":\"$USER\",
    \"tenantId\":\"$TENANT\",
    \"role\":\"Administrator\",
    \"department\":\"Administration\"
  }" \
  "$BASE/api/auth/dev-token" | sed -n 's/.*"accessToken":"\([^"]*\)".*/\1/p')

test -n "$TOKEN"

echo "Checking pilot readiness endpoint..."
curl --fail --silent --show-error \
  -H "Authorization: Bearer $TOKEN" \
  "$BASE/api/pilot/readiness"

echo
echo "Checking dashboard endpoint..."
curl --fail --silent --show-error \
  -H "Authorization: Bearer $TOKEN" \
  "$BASE/api/dashboard/summary" >/dev/null

echo "Checking audit endpoint..."
curl --fail --silent --show-error \
  -H "Authorization: Bearer $TOKEN" \
  "$BASE/api/audit-events?limit=5" >/dev/null

echo "Atlas pilot acceptance checks passed."
