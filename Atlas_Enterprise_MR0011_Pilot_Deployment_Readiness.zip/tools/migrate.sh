#!/bin/sh
set -eu

echo "Applying Atlas database migrations..."

for file in $(find /database/migrations -maxdepth 1 -type f -name '*.sql' | sort); do
  name=$(basename "$file")
  checksum=$(sha256sum "$file" | awk '{print $1}')

  if [ "$name" = "011_migration_history.sql" ]; then
    psql -v ON_ERROR_STOP=1 -f "$file"
    continue
  fi

  exists=$(psql -tAc \
    "SELECT COUNT(*) FROM atlas_schema_history WHERE migration_name = '$name';" \
    2>/dev/null || echo "0")

  if [ "$exists" = "1" ]; then
    stored=$(psql -tAc \
      "SELECT checksum FROM atlas_schema_history WHERE migration_name = '$name';")
    if [ "$stored" != "$checksum" ]; then
      echo "Checksum mismatch for previously applied migration: $name" >&2
      exit 1
    fi
    echo "Already applied: $name"
    continue
  fi

  echo "Applying: $name"
  psql -v ON_ERROR_STOP=1 -f "$file"

  psql -v ON_ERROR_STOP=1 -c \
    "INSERT INTO atlas_schema_history (migration_name, checksum, applied_by)
     VALUES ('$name', '$checksum', 'atlas-migrator');"
done

if [ "${ATLAS_LOAD_DEMO_DATA:-true}" = "true" ]; then
  echo "Loading idempotent demonstration data..."
  for file in $(find /database/seed -maxdepth 1 -type f -name '*.sql' | sort); do
    psql -v ON_ERROR_STOP=1 -f "$file"
  done
fi

echo "Atlas migrations complete."
