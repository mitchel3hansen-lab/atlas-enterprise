## Problem

Describe the user or operational problem.

## Solution

Describe the implementation.

## Verification

- [ ] Backend builds
- [ ] Frontend builds
- [ ] Tests pass
- [ ] Migration reviewed
- [ ] API contract reviewed
- [ ] Accessibility reviewed
- [ ] Security considerations documented
- [ ] Documentation updated
