CREATE TABLE IF NOT EXISTS capa_actions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    incident_id UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    capa_number VARCHAR(40) NOT NULL,
    action_type VARCHAR(30) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    owner_id UUID NOT NULL,
    department VARCHAR(120) NOT NULL,
    priority VARCHAR(20) NOT NULL,
    target_date TIMESTAMPTZ NOT NULL,
    status VARCHAR(40) NOT NULL DEFAULT 'Open',
    completion_notes TEXT,
    completed_at TIMESTAMPTZ,
    verification_status VARCHAR(40) NOT NULL DEFAULT 'Pending',
    effectiveness_status VARCHAR(40) NOT NULL DEFAULT 'Pending',
    estimated_cost NUMERIC(14,2),
    actual_cost NUMERIC(14,2),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, capa_number)
);

CREATE TABLE IF NOT EXISTS capa_evidence (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    capa_id UUID NOT NULL REFERENCES capa_actions(id) ON DELETE CASCADE,
    evidence_type VARCHAR(50) NOT NULL,
    title VARCHAR(200) NOT NULL,
    reference_uri TEXT NOT NULL,
    uploaded_by UUID NOT NULL,
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS capa_verifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    capa_id UUID NOT NULL REFERENCES capa_actions(id) ON DELETE CASCADE,
    verifier_id UUID NOT NULL,
    result VARCHAR(30) NOT NULL,
    notes TEXT NOT NULL,
    verified_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS capa_effectiveness_reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    capa_id UUID NOT NULL REFERENCES capa_actions(id) ON DELETE CASCADE,
    reviewer_id UUID NOT NULL,
    result VARCHAR(30) NOT NULL,
    recurrence_found BOOLEAN NOT NULL DEFAULT FALSE,
    comments TEXT NOT NULL,
    reviewed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_capa_incident
    ON capa_actions (incident_id, status, target_date);

CREATE INDEX IF NOT EXISTS ix_capa_owner
    ON capa_actions (tenant_id, owner_id, status, target_date);

CREATE INDEX IF NOT EXISTS ix_capa_overdue
    ON capa_actions (tenant_id, status, target_date);
