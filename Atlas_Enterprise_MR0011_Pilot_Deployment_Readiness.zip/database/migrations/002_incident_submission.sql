ALTER TABLE incidents
    ADD COLUMN IF NOT EXISTS submitted_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS workflow_state VARCHAR(40) NOT NULL DEFAULT 'Draft';

CREATE INDEX IF NOT EXISTS ix_incidents_tenant_status
    ON incidents (tenant_id, status, created_at DESC);
