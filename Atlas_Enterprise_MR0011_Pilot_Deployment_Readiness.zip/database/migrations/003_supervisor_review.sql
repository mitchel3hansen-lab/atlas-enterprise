CREATE TABLE IF NOT EXISTS incident_comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    incident_id UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    author_id UUID NOT NULL,
    author_role VARCHAR(40) NOT NULL,
    comment_type VARCHAR(40) NOT NULL,
    body TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE incidents
    ADD COLUMN IF NOT EXISTS supervisor_reviewed_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS supervisor_reviewer_id UUID,
    ADD COLUMN IF NOT EXISTS review_outcome VARCHAR(40);

CREATE INDEX IF NOT EXISTS ix_incident_comments_incident
    ON incident_comments (incident_id, created_at);

CREATE INDEX IF NOT EXISTS ix_incidents_department_workflow
    ON incidents (tenant_id, department, workflow_state, created_at DESC);
