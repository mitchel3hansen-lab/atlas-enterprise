CREATE TABLE IF NOT EXISTS incident_closure_reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    incident_id UUID NOT NULL UNIQUE REFERENCES incidents(id) ON DELETE CASCADE,
    reviewer_id UUID NOT NULL,
    reviewer_role VARCHAR(40) NOT NULL,
    capa_verified BOOLEAN NOT NULL DEFAULT FALSE,
    evidence_reviewed BOOLEAN NOT NULL DEFAULT FALSE,
    sop_updated BOOLEAN NOT NULL DEFAULT FALSE,
    training_completed BOOLEAN NOT NULL DEFAULT FALSE,
    equipment_controls_verified BOOLEAN NOT NULL DEFAULT FALSE,
    risk_register_updated BOOLEAN NOT NULL DEFAULT FALSE,
    supervisor_approved BOOLEAN NOT NULL DEFAULT FALSE,
    osha_recordable BOOLEAN,
    days_away INTEGER NOT NULL DEFAULT 0,
    restricted_days INTEGER NOT NULL DEFAULT 0,
    residual_risk VARCHAR(20),
    lessons_learned TEXT,
    management_decision VARCHAR(40),
    management_notes TEXT,
    reviewed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS incident_smeta_evidence (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    incident_id UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    pillar VARCHAR(50) NOT NULL,
    requirement_reference VARCHAR(120) NOT NULL,
    evidence_title VARCHAR(200) NOT NULL,
    evidence_uri TEXT NOT NULL,
    linked_by UUID NOT NULL,
    linked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_incident_closure_tenant_decision
    ON incident_closure_reviews (tenant_id, management_decision, reviewed_at DESC);

CREATE INDEX IF NOT EXISTS ix_incident_smeta_evidence_incident
    ON incident_smeta_evidence (incident_id, pillar, linked_at);
