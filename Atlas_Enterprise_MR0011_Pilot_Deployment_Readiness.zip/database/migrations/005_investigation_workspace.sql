CREATE TABLE IF NOT EXISTS investigations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    incident_id UUID NOT NULL UNIQUE REFERENCES incidents(id) ON DELETE CASCADE,
    investigator_id UUID NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Open',
    executive_summary TEXT,
    event_analysis TEXT,
    immediate_causes TEXT,
    root_cause_category VARCHAR(80),
    root_cause_detail TEXT,
    contributing_factors TEXT,
    recommendations TEXT,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS investigation_interviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    investigation_id UUID NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
    interviewee_name VARCHAR(160) NOT NULL,
    interviewee_role VARCHAR(120),
    summary TEXT NOT NULL,
    conducted_by UUID NOT NULL,
    conducted_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS investigation_findings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    investigation_id UUID NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
    finding_type VARCHAR(50) NOT NULL,
    statement TEXT NOT NULL,
    evidence_reference TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS investigation_evidence (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    investigation_id UUID NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
    evidence_type VARCHAR(50) NOT NULL,
    title VARCHAR(200) NOT NULL,
    reference_uri TEXT NOT NULL,
    description TEXT,
    added_by UUID NOT NULL,
    added_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_investigations_tenant_status
    ON investigations (tenant_id, status, updated_at DESC);

CREATE INDEX IF NOT EXISTS ix_investigation_interviews_parent
    ON investigation_interviews (investigation_id, conducted_at);

CREATE INDEX IF NOT EXISTS ix_investigation_findings_parent
    ON investigation_findings (investigation_id, created_at);

CREATE INDEX IF NOT EXISTS ix_investigation_evidence_parent
    ON investigation_evidence (investigation_id, added_at);
