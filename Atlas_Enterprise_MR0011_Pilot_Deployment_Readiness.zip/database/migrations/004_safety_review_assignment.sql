ALTER TABLE incidents
    ADD COLUMN IF NOT EXISTS safety_reviewed_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS safety_reviewer_id UUID,
    ADD COLUMN IF NOT EXISTS confirmed_severity VARCHAR(20),
    ADD COLUMN IF NOT EXISTS osha_review_required BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS medical_follow_up_required BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS immediate_controls_reviewed BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS investigator_id UUID,
    ADD COLUMN IF NOT EXISTS investigation_due_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS ix_incidents_investigator_workflow
    ON incidents (tenant_id, investigator_id, workflow_state, investigation_due_at);
