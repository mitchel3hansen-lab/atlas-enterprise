CREATE TABLE IF NOT EXISTS atlas_schema_history (
    migration_name VARCHAR(255) PRIMARY KEY,
    checksum VARCHAR(128) NOT NULL,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    applied_by VARCHAR(160) NOT NULL
);
