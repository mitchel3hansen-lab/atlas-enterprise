INSERT INTO incidents (
    id, tenant_id, incident_number, title, description, incident_type,
    severity, status, workflow_state, occurred_at, reporter_id, site,
    department, created_at, updated_at)
VALUES
(
    '10000000-0000-0000-0000-000000000001',
    '11111111-1111-1111-1111-111111111111',
    'INC-DEMO-0001',
    'Forklift contacted warehouse rack',
    'Demonstration incident used for Atlas pilot acceptance.',
    'Property Damage',
    'High',
    'Submitted',
    'SupervisorReview',
    NOW() - INTERVAL '2 days',
    '22222222-2222-2222-2222-222222222222',
    'Lindon',
    'Warehouse',
    NOW() - INTERVAL '2 days',
    NOW() - INTERVAL '2 days'
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO incident_timeline (
    id, tenant_id, incident_id, event_type, description, performed_by, occurred_at)
VALUES
(
    '11000000-0000-0000-0000-000000000001',
    '11111111-1111-1111-1111-111111111111',
    '10000000-0000-0000-0000-000000000001',
    'IncidentCreated',
    'Demonstration incident created for pilot validation.',
    '22222222-2222-2222-2222-222222222222',
    NOW() - INTERVAL '2 days'
)
ON CONFLICT (id) DO NOTHING;
