namespace Atlas.IncidentApi.Security;

public static class AtlasRoles
{
    public const string Employee = "Employee";
    public const string Supervisor = "Supervisor";
    public const string Safety = "Safety";
    public const string Executive = "Executive";
    public const string Administrator = "Administrator";
}
