using Atlas.IncidentApi.Infrastructure;

namespace Atlas.IncidentApi.Security;

public sealed class AuditMiddleware(
    RequestDelegate next,
    ILogger<AuditMiddleware> logger)
{
    public async Task InvokeAsync(
        HttpContext context,
        AuditRepository auditRepository)
    {
        var started = DateTimeOffset.UtcNow;

        await next(context);

        var status = context.Response.StatusCode;
        var shouldAudit =
            context.User.Identity?.IsAuthenticated == true ||
            status is StatusCodes.Status401Unauthorized
                or StatusCodes.Status403Forbidden;

        if (!shouldAudit)
            return;

        Guid? tenantId = null;
        Guid? actorId = null;
        string? role = null;

        if (context.User.Identity?.IsAuthenticated == true)
        {
            try
            {
                var user = CurrentUser.From(context.User);
                tenantId = user.TenantId;
                actorId = user.UserId;
                role = user.Role;
            }
            catch
            {
                // Claims failure itself will be captured as an authorization event.
            }
        }

        var outcome = status < 400 ? "Success" : "DeniedOrFailed";

        try
        {
            await auditRepository.WriteAsync(
                tenantId,
                actorId,
                role,
                status is 401 or 403 ? "Authorization" : "ApiRequest",
                null,
                null,
                $"{context.Request.Method} {context.Request.Path}",
                outcome,
                context.TraceIdentifier,
                context.Connection.RemoteIpAddress?.ToString(),
                context.Request.Headers.UserAgent.ToString(),
                new
                {
                    statusCode = status,
                    elapsedMs = (DateTimeOffset.UtcNow - started).TotalMilliseconds
                },
                context.RequestAborted);
        }
        catch (Exception ex)
        {
            logger.LogError(ex,
                "Failed to write audit event. CorrelationId={CorrelationId}",
                context.TraceIdentifier);
        }
    }
}
