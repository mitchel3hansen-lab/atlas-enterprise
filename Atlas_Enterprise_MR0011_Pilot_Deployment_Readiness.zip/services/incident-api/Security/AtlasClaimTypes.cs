namespace Atlas.IncidentApi.Security;

public static class AtlasClaimTypes
{
    public const string TenantId = "atlas_tenant_id";
    public const string Department = "atlas_department";
    public const string Role = "role";
}
