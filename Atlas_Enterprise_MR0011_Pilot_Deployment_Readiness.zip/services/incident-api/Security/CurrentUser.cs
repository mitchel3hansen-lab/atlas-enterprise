using System.Security.Claims;

namespace Atlas.IncidentApi.Security;

public sealed record CurrentUser(
    Guid UserId,
    Guid TenantId,
    string Role,
    string Department)
{
    public static CurrentUser From(ClaimsPrincipal principal)
    {
        var userIdText = principal.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? throw new UnauthorizedAccessException("Missing subject claim.");
        var tenantIdText = principal.FindFirstValue(AtlasClaimTypes.TenantId)
            ?? throw new UnauthorizedAccessException("Missing tenant claim.");
        var role = principal.FindFirstValue(ClaimTypes.Role)
            ?? principal.FindFirstValue(AtlasClaimTypes.Role)
            ?? throw new UnauthorizedAccessException("Missing role claim.");
        var department = principal.FindFirstValue(AtlasClaimTypes.Department) ?? string.Empty;

        if (!Guid.TryParse(userIdText, out var userId))
            throw new UnauthorizedAccessException("Invalid subject claim.");
        if (!Guid.TryParse(tenantIdText, out var tenantId))
            throw new UnauthorizedAccessException("Invalid tenant claim.");

        return new CurrentUser(userId, tenantId, role, department);
    }
}
