namespace Atlas.IncidentApi.Security;

public sealed record DevTokenRequest(
    Guid UserId,
    Guid TenantId,
    string Role,
    string Department);
