using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace Atlas.IncidentApi.Security;

public sealed class DevTokenService(IConfiguration configuration)
{
    public string Create(
        Guid userId,
        Guid tenantId,
        string role,
        string department)
    {
        var key = configuration["Authentication:DevSigningKey"]
            ?? throw new InvalidOperationException("Development signing key is missing.");
        var issuer = configuration["Authentication:Issuer"] ?? "atlas-dev";
        var audience = configuration["Authentication:Audience"] ?? "atlas-api";

        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, userId.ToString()),
            new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
            new Claim(AtlasClaimTypes.TenantId, tenantId.ToString()),
            new Claim(ClaimTypes.Role, role),
            new Claim(AtlasClaimTypes.Department, department)
        };

        var credentials = new SigningCredentials(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)),
            SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer,
            audience,
            claims,
            expires: DateTime.UtcNow.AddHours(8),
            signingCredentials: credentials);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
