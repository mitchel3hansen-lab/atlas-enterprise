using System.Text.Json;

namespace Atlas.IncidentApi.Security;

public sealed class ExceptionHandlingMiddleware(
    RequestDelegate next,
    ILogger<ExceptionHandlingMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (UnauthorizedAccessException ex)
        {
            logger.LogWarning(ex,
                "Unauthorized request. CorrelationId={CorrelationId}",
                context.TraceIdentifier);

            await WriteProblem(
                context,
                StatusCodes.Status401Unauthorized,
                "Unauthorized",
                "Authentication or required claims are missing.");
        }
        catch (Exception ex)
        {
            logger.LogError(ex,
                "Unhandled exception. CorrelationId={CorrelationId}",
                context.TraceIdentifier);

            await WriteProblem(
                context,
                StatusCodes.Status500InternalServerError,
                "Unexpected error",
                "The request could not be completed.");
        }
    }

    private static async Task WriteProblem(
        HttpContext context,
        int status,
        string title,
        string detail)
    {
        context.Response.StatusCode = status;
        context.Response.ContentType = "application/problem+json";

        await context.Response.WriteAsync(JsonSerializer.Serialize(new
        {
            type = "about:blank",
            title,
            status,
            detail,
            correlationId = context.TraceIdentifier
        }));
    }
}
