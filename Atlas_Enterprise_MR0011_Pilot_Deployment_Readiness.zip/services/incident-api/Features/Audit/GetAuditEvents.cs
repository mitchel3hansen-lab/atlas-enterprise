using Atlas.IncidentApi.Domain;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Features.Audit;

public sealed class AuditQueryService(IConfiguration configuration)
{
    public async Task<IReadOnlyList<AuditEvent>> GetAsync(
        Guid tenantId,
        int limit,
        CancellationToken cancellationToken)
    {
        const string sql = """
        SELECT
            id AS Id,
            tenant_id AS TenantId,
            actor_id AS ActorId,
            actor_role AS ActorRole,
            event_type AS EventType,
            entity_type AS EntityType,
            entity_id AS EntityId,
            action AS Action,
            outcome AS Outcome,
            correlation_id AS CorrelationId,
            host(ip_address) AS IpAddress,
            user_agent AS UserAgent,
            details::text AS Details,
            occurred_at AS OccurredAt
        FROM audit_events
        WHERE tenant_id = @TenantId
        ORDER BY occurred_at DESC
        LIMIT @Limit;
        """;

        await using var connection = new NpgsqlConnection(
            configuration.GetConnectionString("Atlas"));

        var rows = await connection.QueryAsync<AuditEvent>(
            new CommandDefinition(
                sql,
                new { TenantId = tenantId, Limit = Math.Clamp(limit, 1, 500) },
                cancellationToken: cancellationToken));

        return rows.AsList();
    }
}
