namespace Atlas.IncidentApi.Features.Closure;

public sealed record UpsertClosureReviewRequest(
    Guid TenantId,
    Guid ReviewerId,
    string ReviewerRole,
    bool CapaVerified,
    bool EvidenceReviewed,
    bool SopUpdated,
    bool TrainingCompleted,
    bool EquipmentControlsVerified,
    bool RiskRegisterUpdated,
    bool SupervisorApproved,
    bool? OshaRecordable,
    int DaysAway,
    int RestrictedDays,
    string ResidualRisk,
    string LessonsLearned,
    string ManagementDecision,
    string ManagementNotes);

public sealed record AddSmetaEvidenceRequest(
    Guid TenantId,
    Guid LinkedBy,
    string Pillar,
    string RequirementReference,
    string EvidenceTitle,
    string EvidenceUri);

public sealed record CloseIncidentRequest(
    Guid TenantId,
    Guid ReviewerId);
