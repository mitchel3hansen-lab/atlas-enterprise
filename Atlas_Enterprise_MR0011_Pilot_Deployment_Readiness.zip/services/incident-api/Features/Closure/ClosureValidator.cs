namespace Atlas.IncidentApi.Features.Closure;

public static class ClosureValidator
{
    private static readonly HashSet<string> Roles =
        new(StringComparer.OrdinalIgnoreCase) { "Safety", "Executive", "Administrator" };

    private static readonly HashSet<string> Decisions =
        new(StringComparer.OrdinalIgnoreCase) { "ApproveClosure", "RequestMoreWork" };

    private static readonly HashSet<string> ResidualRisks =
        new(StringComparer.OrdinalIgnoreCase) { "Low", "Medium", "High", "Critical" };

    public static Dictionary<string, string[]> Validate(UpsertClosureReviewRequest request)
    {
        var errors = new Dictionary<string, string[]>();

        if (request.TenantId == Guid.Empty)
            errors["tenantId"] = ["Tenant is required."];
        if (request.ReviewerId == Guid.Empty)
            errors["reviewerId"] = ["Reviewer is required."];
        if (!Roles.Contains(request.ReviewerRole ?? string.Empty))
            errors["reviewerRole"] = ["Reviewer must be Safety, Executive, or Administrator."];
        if (!ResidualRisks.Contains(request.ResidualRisk ?? string.Empty))
            errors["residualRisk"] = ["Residual risk must be Low, Medium, High, or Critical."];
        if (!Decisions.Contains(request.ManagementDecision ?? string.Empty))
            errors["managementDecision"] = ["Decision must be ApproveClosure or RequestMoreWork."];
        if (request.DaysAway < 0)
            errors["daysAway"] = ["Days away cannot be negative."];
        if (request.RestrictedDays < 0)
            errors["restrictedDays"] = ["Restricted days cannot be negative."];
        if (string.IsNullOrWhiteSpace(request.LessonsLearned))
            errors["lessonsLearned"] = ["Lessons learned are required."];
        if (string.IsNullOrWhiteSpace(request.ManagementNotes))
            errors["managementNotes"] = ["Management notes are required."];

        return errors;
    }

    public static string? ClosureGateError(UpsertClosureReviewRequest request)
    {
        if (!request.CapaVerified)
            return "All CAPAs must be verified.";
        if (!request.EvidenceReviewed)
            return "Supporting evidence must be reviewed.";
        if (!request.SupervisorApproved)
            return "Supervisor approval is required.";
        if (!request.EquipmentControlsVerified)
            return "Equipment or physical controls must be verified.";
        if (!request.RiskRegisterUpdated)
            return "The risk register must be reviewed and updated.";
        if (string.Equals(request.ManagementDecision, "ApproveClosure",
                StringComparison.OrdinalIgnoreCase) &&
            string.Equals(request.ResidualRisk, "Critical",
                StringComparison.OrdinalIgnoreCase))
            return "A case with Critical residual risk cannot be closed.";

        return null;
    }
}
