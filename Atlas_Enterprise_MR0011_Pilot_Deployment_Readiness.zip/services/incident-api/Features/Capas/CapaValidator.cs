namespace Atlas.IncidentApi.Features.Capas;

public static class CapaValidator
{
    private static readonly HashSet<string> ActionTypes =
        new(StringComparer.OrdinalIgnoreCase) { "Corrective", "Preventive" };

    private static readonly HashSet<string> Priorities =
        new(StringComparer.OrdinalIgnoreCase) { "Low", "Medium", "High", "Critical" };

    public static Dictionary<string, string[]> Validate(CreateCapaRequest request)
    {
        var errors = new Dictionary<string, string[]>();

        if (request.TenantId == Guid.Empty)
            errors["tenantId"] = ["Tenant is required."];
        if (!ActionTypes.Contains(request.ActionType ?? string.Empty))
            errors["actionType"] = ["Action type must be Corrective or Preventive."];
        if (string.IsNullOrWhiteSpace(request.Title))
            errors["title"] = ["Title is required."];
        if (string.IsNullOrWhiteSpace(request.Description))
            errors["description"] = ["Description is required."];
        if (request.OwnerId == Guid.Empty)
            errors["ownerId"] = ["Owner is required."];
        if (string.IsNullOrWhiteSpace(request.Department))
            errors["department"] = ["Department is required."];
        if (!Priorities.Contains(request.Priority ?? string.Empty))
            errors["priority"] = ["Priority must be Low, Medium, High, or Critical."];
        if (request.TargetDate <= DateTimeOffset.UtcNow)
            errors["targetDate"] = ["Target date must be in the future."];

        return errors;
    }
}
