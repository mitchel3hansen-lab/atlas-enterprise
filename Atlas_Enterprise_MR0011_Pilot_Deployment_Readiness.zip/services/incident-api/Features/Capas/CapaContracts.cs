namespace Atlas.IncidentApi.Features.Capas;

public sealed record CreateCapaRequest(
    Guid TenantId,
    string ActionType,
    string Title,
    string Description,
    Guid OwnerId,
    string Department,
    string Priority,
    DateTimeOffset TargetDate,
    decimal? EstimatedCost);

public sealed record CompleteCapaRequest(
    Guid TenantId,
    Guid ActorId,
    string CompletionNotes,
    decimal? ActualCost);

public sealed record AddCapaEvidenceRequest(
    Guid TenantId,
    Guid UploadedBy,
    string EvidenceType,
    string Title,
    string ReferenceUri);

public sealed record VerifyCapaRequest(
    Guid TenantId,
    Guid VerifierId,
    string Result,
    string Notes);

public sealed record ReviewCapaEffectivenessRequest(
    Guid TenantId,
    Guid ReviewerId,
    string Result,
    bool RecurrenceFound,
    string Comments);

public sealed record ReopenCapaRequest(
    Guid TenantId,
    Guid ActorId,
    string Reason);
