namespace Atlas.IncidentApi.Features.Investigations;

public sealed record UpsertInvestigationRequest(
    Guid TenantId,
    Guid InvestigatorId,
    string ExecutiveSummary,
    string EventAnalysis,
    string ImmediateCauses,
    string RootCauseCategory,
    string RootCauseDetail,
    string ContributingFactors,
    string Recommendations);

public sealed record AddInterviewRequest(
    Guid TenantId,
    Guid InvestigatorId,
    string IntervieweeName,
    string IntervieweeRole,
    string Summary,
    DateTimeOffset ConductedAt);

public sealed record AddFindingRequest(
    Guid TenantId,
    string FindingType,
    string Statement,
    string EvidenceReference);

public sealed record AddEvidenceRequest(
    Guid TenantId,
    Guid AddedBy,
    string EvidenceType,
    string Title,
    string ReferenceUri,
    string Description);

public sealed record CompleteInvestigationRequest(
    Guid TenantId,
    Guid InvestigatorId);
