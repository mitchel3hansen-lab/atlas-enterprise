namespace Atlas.IncidentApi.Features.Investigations;

public static class InvestigationValidator
{
    public static Dictionary<string, string[]> Validate(
        UpsertInvestigationRequest request)
    {
        var errors = new Dictionary<string, string[]>();

        if (request.TenantId == Guid.Empty)
            errors["tenantId"] = ["Tenant is required."];
        if (request.InvestigatorId == Guid.Empty)
            errors["investigatorId"] = ["Investigator is required."];
        if (string.IsNullOrWhiteSpace(request.ExecutiveSummary))
            errors["executiveSummary"] = ["Executive summary is required."];
        if (string.IsNullOrWhiteSpace(request.EventAnalysis))
            errors["eventAnalysis"] = ["Event analysis is required."];
        if (string.IsNullOrWhiteSpace(request.RootCauseCategory))
            errors["rootCauseCategory"] = ["Root-cause category is required."];
        if (string.IsNullOrWhiteSpace(request.RootCauseDetail))
            errors["rootCauseDetail"] = ["Root-cause detail is required."];
        if (string.IsNullOrWhiteSpace(request.Recommendations))
            errors["recommendations"] = ["Recommendations are required."];

        return errors;
    }
}
