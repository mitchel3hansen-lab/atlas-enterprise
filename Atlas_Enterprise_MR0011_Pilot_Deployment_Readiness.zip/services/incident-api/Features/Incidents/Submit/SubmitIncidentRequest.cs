namespace Atlas.IncidentApi.Features.Incidents.Submit;

public sealed record SubmitIncidentRequest(Guid TenantId, Guid ActorId);
