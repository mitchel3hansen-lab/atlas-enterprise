namespace Atlas.IncidentApi.Features.Incidents.Create;

public sealed record CreateIncidentRequest(
    Guid TenantId,
    string Title,
    string Description,
    string IncidentType,
    string Severity,
    DateTimeOffset OccurredAt,
    Guid ReporterId,
    string Site,
    string Department);
