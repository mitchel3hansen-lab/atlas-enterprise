namespace Atlas.IncidentApi.Features.Incidents.Create;

public static class CreateIncidentValidator
{
    private static readonly HashSet<string> Severities =
        new(StringComparer.OrdinalIgnoreCase) { "Low", "Medium", "High", "Critical" };

    public static Dictionary<string, string[]> Validate(CreateIncidentRequest request)
    {
        var errors = new Dictionary<string, string[]>();

        if (request.TenantId == Guid.Empty)
            errors["tenantId"] = ["Tenant is required."];
        if (string.IsNullOrWhiteSpace(request.Title))
            errors["title"] = ["Title is required."];
        if (request.Title?.Length > 200)
            errors["title"] = ["Title cannot exceed 200 characters."];
        if (string.IsNullOrWhiteSpace(request.Description))
            errors["description"] = ["Description is required."];
        if (string.IsNullOrWhiteSpace(request.IncidentType))
            errors["incidentType"] = ["Incident type is required."];
        if (!Severities.Contains(request.Severity ?? string.Empty))
            errors["severity"] = ["Severity must be Low, Medium, High, or Critical."];
        if (request.OccurredAt > DateTimeOffset.UtcNow.AddMinutes(5))
            errors["occurredAt"] = ["Occurred date cannot be in the future."];
        if (request.ReporterId == Guid.Empty)
            errors["reporterId"] = ["Reporter is required."];
        if (string.IsNullOrWhiteSpace(request.Site))
            errors["site"] = ["Site is required."];
        if (string.IsNullOrWhiteSpace(request.Department))
            errors["department"] = ["Department is required."];

        return errors;
    }
}
