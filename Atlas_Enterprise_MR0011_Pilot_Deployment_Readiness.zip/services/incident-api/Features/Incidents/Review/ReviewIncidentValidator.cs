namespace Atlas.IncidentApi.Features.Incidents.Review;

public static class ReviewIncidentValidator
{
    private static readonly HashSet<string> Decisions =
        new(StringComparer.OrdinalIgnoreCase)
        {
            "Approve",
            "ReturnForCorrection"
        };

    public static Dictionary<string, string[]> Validate(ReviewIncidentRequest request)
    {
        var errors = new Dictionary<string, string[]>();

        if (request.TenantId == Guid.Empty)
            errors["tenantId"] = ["Tenant is required."];
        if (request.ReviewerId == Guid.Empty)
            errors["reviewerId"] = ["Reviewer is required."];
        if (!string.Equals(request.ReviewerRole, "Supervisor",
                StringComparison.OrdinalIgnoreCase))
            errors["reviewerRole"] = ["Supervisor role is required."];
        if (string.IsNullOrWhiteSpace(request.ReviewerDepartment))
            errors["reviewerDepartment"] = ["Reviewer department is required."];
        if (!Decisions.Contains(request.Decision ?? string.Empty))
            errors["decision"] = ["Decision must be Approve or ReturnForCorrection."];
        if (string.IsNullOrWhiteSpace(request.Comment))
            errors["comment"] = ["A review comment is required."];
        if (request.Comment?.Length > 2000)
            errors["comment"] = ["Comment cannot exceed 2000 characters."];

        return errors;
    }
}
