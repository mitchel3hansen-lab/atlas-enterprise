namespace Atlas.IncidentApi.Features.Incidents.Review;

public sealed record ReviewIncidentRequest(
    Guid TenantId,
    Guid ReviewerId,
    string ReviewerRole,
    string ReviewerDepartment,
    string Decision,
    string Comment);
