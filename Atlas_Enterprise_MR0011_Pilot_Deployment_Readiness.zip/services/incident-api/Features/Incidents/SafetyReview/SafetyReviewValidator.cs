namespace Atlas.IncidentApi.Features.Incidents.SafetyReview;

public static class SafetyReviewValidator
{
    private static readonly HashSet<string> Severities =
        new(StringComparer.OrdinalIgnoreCase) { "Low", "Medium", "High", "Critical" };

    public static Dictionary<string, string[]> Validate(SafetyReviewRequest request)
    {
        var errors = new Dictionary<string, string[]>();

        if (request.TenantId == Guid.Empty)
            errors["tenantId"] = ["Tenant is required."];
        if (request.SafetyReviewerId == Guid.Empty)
            errors["safetyReviewerId"] = ["Safety reviewer is required."];
        if (!string.Equals(request.ReviewerRole, "Safety", StringComparison.OrdinalIgnoreCase))
            errors["reviewerRole"] = ["Safety role is required."];
        if (!Severities.Contains(request.ConfirmedSeverity ?? string.Empty))
            errors["confirmedSeverity"] = ["Confirmed severity must be Low, Medium, High, or Critical."];
        if (!request.ImmediateControlsReviewed)
            errors["immediateControlsReviewed"] = ["Immediate controls must be reviewed before assignment."];
        if (request.InvestigatorId == Guid.Empty)
            errors["investigatorId"] = ["Investigator is required."];
        if (request.InvestigationDueAt <= DateTimeOffset.UtcNow)
            errors["investigationDueAt"] = ["Investigation due date must be in the future."];
        if (string.IsNullOrWhiteSpace(request.Comment))
            errors["comment"] = ["A safety review comment is required."];

        return errors;
    }
}
