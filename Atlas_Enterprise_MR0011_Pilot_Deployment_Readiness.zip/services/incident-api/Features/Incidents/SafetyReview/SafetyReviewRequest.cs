namespace Atlas.IncidentApi.Features.Incidents.SafetyReview;

public sealed record SafetyReviewRequest(
    Guid TenantId,
    Guid SafetyReviewerId,
    string ReviewerRole,
    string ConfirmedSeverity,
    bool OshaReviewRequired,
    bool MedicalFollowUpRequired,
    bool ImmediateControlsReviewed,
    Guid InvestigatorId,
    DateTimeOffset InvestigationDueAt,
    string Comment);
