namespace Atlas.IncidentApi.Domain;

public sealed record IncidentClosureReview(
    Guid Id,
    Guid IncidentId,
    Guid ReviewerId,
    string ReviewerRole,
    bool CapaVerified,
    bool EvidenceReviewed,
    bool SopUpdated,
    bool TrainingCompleted,
    bool EquipmentControlsVerified,
    bool RiskRegisterUpdated,
    bool SupervisorApproved,
    bool? OshaRecordable,
    int DaysAway,
    int RestrictedDays,
    string? ResidualRisk,
    string? LessonsLearned,
    string? ManagementDecision,
    string? ManagementNotes,
    DateTimeOffset ReviewedAt,
    DateTimeOffset? ClosedAt);

public sealed record SmetaEvidenceLink(
    Guid Id,
    string Pillar,
    string RequirementReference,
    string EvidenceTitle,
    string EvidenceUri,
    Guid LinkedBy,
    DateTimeOffset LinkedAt);

public sealed record IncidentClosureWorkspace(
    IncidentClosureReview? Review,
    IReadOnlyList<SmetaEvidenceLink> SmetaEvidence);
