namespace Atlas.IncidentApi.Domain;

public sealed record PilotReadinessResult(
    string Status,
    DateTimeOffset CheckedAt,
    IReadOnlyList<PilotReadinessCheck> Checks);

public sealed record PilotReadinessCheck(
    string Name,
    bool Passed,
    string Detail);
