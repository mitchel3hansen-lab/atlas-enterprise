namespace Atlas.IncidentApi.Domain;

public sealed record Investigation(
    Guid Id,
    Guid IncidentId,
    Guid InvestigatorId,
    string Status,
    string? ExecutiveSummary,
    string? EventAnalysis,
    string? ImmediateCauses,
    string? RootCauseCategory,
    string? RootCauseDetail,
    string? ContributingFactors,
    string? Recommendations,
    DateTimeOffset StartedAt,
    DateTimeOffset? CompletedAt,
    DateTimeOffset UpdatedAt);

public sealed record InvestigationInterview(
    Guid Id,
    string IntervieweeName,
    string? IntervieweeRole,
    string Summary,
    Guid ConductedBy,
    DateTimeOffset ConductedAt);

public sealed record InvestigationFinding(
    Guid Id,
    string FindingType,
    string Statement,
    string? EvidenceReference,
    DateTimeOffset CreatedAt);

public sealed record InvestigationEvidence(
    Guid Id,
    string EvidenceType,
    string Title,
    string ReferenceUri,
    string? Description,
    Guid AddedBy,
    DateTimeOffset AddedAt);

public sealed record InvestigationWorkspace(
    Investigation Investigation,
    IReadOnlyList<InvestigationInterview> Interviews,
    IReadOnlyList<InvestigationFinding> Findings,
    IReadOnlyList<InvestigationEvidence> Evidence);
