namespace Atlas.IncidentApi.Domain;

public sealed record DashboardSummary(
    int TotalIncidents,
    int OpenIncidents,
    int ClosedIncidents,
    int CriticalIncidents,
    int InvestigationsOpen,
    int CapasOpen,
    int CapasOverdue,
    decimal ClosureRate,
    decimal CapaEffectivenessRate,
    decimal AverageClosureDays,
    IReadOnlyList<DashboardBucket> BySeverity,
    IReadOnlyList<DashboardBucket> ByWorkflow,
    IReadOnlyList<DashboardDepartment> ByDepartment);

public sealed record DashboardBucket(
    string Name,
    int Count);

public sealed record DashboardDepartment(
    string Department,
    int TotalIncidents,
    int OpenIncidents,
    int OpenCapas,
    int OverdueCapas);
