namespace Atlas.IncidentApi.Domain;

public sealed record CapaAction(
    Guid Id,
    Guid IncidentId,
    string CapaNumber,
    string ActionType,
    string Title,
    string Description,
    Guid OwnerId,
    string Department,
    string Priority,
    DateTimeOffset TargetDate,
    string Status,
    string? CompletionNotes,
    DateTimeOffset? CompletedAt,
    string VerificationStatus,
    string EffectivenessStatus,
    decimal? EstimatedCost,
    decimal? ActualCost,
    DateTimeOffset CreatedAt,
    DateTimeOffset UpdatedAt);

public sealed record CapaEvidence(
    Guid Id,
    string EvidenceType,
    string Title,
    string ReferenceUri,
    Guid UploadedBy,
    DateTimeOffset UploadedAt);

public sealed record CapaVerification(
    Guid Id,
    Guid VerifierId,
    string Result,
    string Notes,
    DateTimeOffset VerifiedAt);

public sealed record CapaEffectivenessReview(
    Guid Id,
    Guid ReviewerId,
    string Result,
    bool RecurrenceFound,
    string Comments,
    DateTimeOffset ReviewedAt);

public sealed record CapaWorkspace(
    CapaAction Action,
    IReadOnlyList<CapaEvidence> Evidence,
    IReadOnlyList<CapaVerification> Verifications,
    IReadOnlyList<CapaEffectivenessReview> EffectivenessReviews);
