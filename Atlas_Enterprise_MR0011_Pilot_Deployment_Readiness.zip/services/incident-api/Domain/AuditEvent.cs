namespace Atlas.IncidentApi.Domain;

public sealed record AuditEvent(
    Guid Id,
    Guid? TenantId,
    Guid? ActorId,
    string? ActorRole,
    string EventType,
    string? EntityType,
    Guid? EntityId,
    string Action,
    string Outcome,
    string CorrelationId,
    string? IpAddress,
    string? UserAgent,
    string Details,
    DateTimeOffset OccurredAt);
