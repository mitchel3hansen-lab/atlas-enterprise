using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class DatabaseReadinessService(IConfiguration configuration)
{
    public async Task<(bool Ready, string Message)> CheckAsync(
        CancellationToken cancellationToken)
    {
        try
        {
            await using var connection = new NpgsqlConnection(
                configuration.GetConnectionString("Atlas"));

            await connection.OpenAsync(cancellationToken);
            var result = await connection.ExecuteScalarAsync<int>(
                new CommandDefinition(
                    "SELECT 1;",
                    cancellationToken: cancellationToken));

            return result == 1
                ? (true, "Database connection is ready.")
                : (false, "Database readiness query returned an unexpected result.");
        }
        catch (Exception ex)
        {
            return (false, $"Database is not ready: {ex.GetType().Name}");
        }
    }
}
