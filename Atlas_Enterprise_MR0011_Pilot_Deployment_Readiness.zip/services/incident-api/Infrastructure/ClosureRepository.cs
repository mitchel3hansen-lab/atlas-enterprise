using Atlas.IncidentApi.Domain;
using Atlas.IncidentApi.Features.Closure;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class ClosureRepository(IConfiguration configuration)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    public async Task<IncidentClosureWorkspace> GetAsync(
        Guid tenantId,
        Guid incidentId,
        CancellationToken cancellationToken)
    {
        const string reviewSql = """
        SELECT
            id AS Id,
            incident_id AS IncidentId,
            reviewer_id AS ReviewerId,
            reviewer_role AS ReviewerRole,
            capa_verified AS CapaVerified,
            evidence_reviewed AS EvidenceReviewed,
            sop_updated AS SopUpdated,
            training_completed AS TrainingCompleted,
            equipment_controls_verified AS EquipmentControlsVerified,
            risk_register_updated AS RiskRegisterUpdated,
            supervisor_approved AS SupervisorApproved,
            osha_recordable AS OshaRecordable,
            days_away AS DaysAway,
            restricted_days AS RestrictedDays,
            residual_risk AS ResidualRisk,
            lessons_learned AS LessonsLearned,
            management_decision AS ManagementDecision,
            management_notes AS ManagementNotes,
            reviewed_at AS ReviewedAt,
            closed_at AS ClosedAt
        FROM incident_closure_reviews
        WHERE tenant_id = @TenantId AND incident_id = @IncidentId;
        """;

        const string evidenceSql = """
        SELECT
            id AS Id,
            pillar AS Pillar,
            requirement_reference AS RequirementReference,
            evidence_title AS EvidenceTitle,
            evidence_uri AS EvidenceUri,
            linked_by AS LinkedBy,
            linked_at AS LinkedAt
        FROM incident_smeta_evidence
        WHERE tenant_id = @TenantId AND incident_id = @IncidentId
        ORDER BY linked_at;
        """;

        await using var connection = CreateConnection();
        var args = new { TenantId = tenantId, IncidentId = incidentId };

        var review = await connection.QuerySingleOrDefaultAsync<IncidentClosureReview>(
            new CommandDefinition(
                reviewSql, args, cancellationToken: cancellationToken));

        var evidence = await connection.QueryAsync<SmetaEvidenceLink>(
            new CommandDefinition(
                evidenceSql, args, cancellationToken: cancellationToken));

        return new IncidentClosureWorkspace(review, evidence.AsList());
    }

    public async Task<IncidentClosureReview?> UpsertAsync(
        Guid incidentId,
        UpsertClosureReviewRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO incident_closure_reviews (
            id, tenant_id, incident_id, reviewer_id, reviewer_role,
            capa_verified, evidence_reviewed, sop_updated, training_completed,
            equipment_controls_verified, risk_register_updated,
            supervisor_approved, osha_recordable, days_away, restricted_days,
            residual_risk, lessons_learned, management_decision,
            management_notes, reviewed_at)
        SELECT
            @Id, @TenantId, @IncidentId, @ReviewerId, @ReviewerRole,
            @CapaVerified, @EvidenceReviewed, @SopUpdated, @TrainingCompleted,
            @EquipmentControlsVerified, @RiskRegisterUpdated,
            @SupervisorApproved, @OshaRecordable, @DaysAway, @RestrictedDays,
            @ResidualRisk, @LessonsLearned, @ManagementDecision,
            @ManagementNotes, NOW()
        FROM incidents i
        WHERE i.tenant_id = @TenantId
          AND i.id = @IncidentId
          AND i.workflow_state = 'Verification'
        ON CONFLICT (incident_id)
        DO UPDATE SET
            reviewer_id = EXCLUDED.reviewer_id,
            reviewer_role = EXCLUDED.reviewer_role,
            capa_verified = EXCLUDED.capa_verified,
            evidence_reviewed = EXCLUDED.evidence_reviewed,
            sop_updated = EXCLUDED.sop_updated,
            training_completed = EXCLUDED.training_completed,
            equipment_controls_verified = EXCLUDED.equipment_controls_verified,
            risk_register_updated = EXCLUDED.risk_register_updated,
            supervisor_approved = EXCLUDED.supervisor_approved,
            osha_recordable = EXCLUDED.osha_recordable,
            days_away = EXCLUDED.days_away,
            restricted_days = EXCLUDED.restricted_days,
            residual_risk = EXCLUDED.residual_risk,
            lessons_learned = EXCLUDED.lessons_learned,
            management_decision = EXCLUDED.management_decision,
            management_notes = EXCLUDED.management_notes,
            reviewed_at = NOW()
        RETURNING
            id AS Id,
            incident_id AS IncidentId,
            reviewer_id AS ReviewerId,
            reviewer_role AS ReviewerRole,
            capa_verified AS CapaVerified,
            evidence_reviewed AS EvidenceReviewed,
            sop_updated AS SopUpdated,
            training_completed AS TrainingCompleted,
            equipment_controls_verified AS EquipmentControlsVerified,
            risk_register_updated AS RiskRegisterUpdated,
            supervisor_approved AS SupervisorApproved,
            osha_recordable AS OshaRecordable,
            days_away AS DaysAway,
            restricted_days AS RestrictedDays,
            residual_risk AS ResidualRisk,
            lessons_learned AS LessonsLearned,
            management_decision AS ManagementDecision,
            management_notes AS ManagementNotes,
            reviewed_at AS ReviewedAt,
            closed_at AS ClosedAt;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<IncidentClosureReview>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    request.TenantId,
                    IncidentId = incidentId,
                    request.ReviewerId,
                    request.ReviewerRole,
                    request.CapaVerified,
                    request.EvidenceReviewed,
                    request.SopUpdated,
                    request.TrainingCompleted,
                    request.EquipmentControlsVerified,
                    request.RiskRegisterUpdated,
                    request.SupervisorApproved,
                    request.OshaRecordable,
                    request.DaysAway,
                    request.RestrictedDays,
                    request.ResidualRisk,
                    request.LessonsLearned,
                    request.ManagementDecision,
                    request.ManagementNotes
                },
                cancellationToken: cancellationToken));
    }

    public async Task<Guid?> AddSmetaEvidenceAsync(
        Guid incidentId,
        AddSmetaEvidenceRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO incident_smeta_evidence (
            id, tenant_id, incident_id, pillar, requirement_reference,
            evidence_title, evidence_uri, linked_by)
        SELECT
            @Id, @TenantId, i.id, @Pillar, @RequirementReference,
            @EvidenceTitle, @EvidenceUri, @LinkedBy
        FROM incidents i
        WHERE i.tenant_id = @TenantId AND i.id = @IncidentId
        RETURNING id;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<Guid?>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    request.TenantId,
                    IncidentId = incidentId,
                    request.Pillar,
                    request.RequirementReference,
                    request.EvidenceTitle,
                    request.EvidenceUri,
                    request.LinkedBy
                },
                cancellationToken: cancellationToken));
    }

    public async Task<(bool Closed, string? Error)> CloseAsync(
        Guid incidentId,
        CloseIncidentRequest request,
        CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;

        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        const string gateSql = """
        SELECT
            c.management_decision,
            c.capa_verified,
            c.evidence_reviewed,
            c.equipment_controls_verified,
            c.risk_register_updated,
            c.supervisor_approved,
            c.lessons_learned,
            c.residual_risk,
            EXISTS (
                SELECT 1
                FROM incident_smeta_evidence s
                WHERE s.tenant_id = c.tenant_id
                  AND s.incident_id = c.incident_id
            ) AS has_smeta_evidence,
            NOT EXISTS (
                SELECT 1
                FROM capa_actions a
                WHERE a.tenant_id = c.tenant_id
                  AND a.incident_id = c.incident_id
                  AND a.status <> 'Closed'
            ) AS all_capas_closed
        FROM incident_closure_reviews c
        WHERE c.tenant_id = @TenantId
          AND c.incident_id = @IncidentId
        FOR UPDATE;
        """;

        var gate = await connection.QuerySingleOrDefaultAsync<dynamic>(
            new CommandDefinition(
                gateSql,
                new { request.TenantId, IncidentId = incidentId },
                transaction,
                cancellationToken: cancellationToken));

        if (gate is null)
        {
            await transaction.RollbackAsync(cancellationToken);
            return (false, "Closure review was not found.");
        }

        bool approved = string.Equals(
            (string?)gate.management_decision,
            "ApproveClosure",
            StringComparison.OrdinalIgnoreCase);

        bool valid =
            approved &&
            (bool)gate.capa_verified &&
            (bool)gate.evidence_reviewed &&
            (bool)gate.equipment_controls_verified &&
            (bool)gate.risk_register_updated &&
            (bool)gate.supervisor_approved &&
            (bool)gate.all_capas_closed &&
            !string.IsNullOrWhiteSpace((string?)gate.lessons_learned) &&
            !string.Equals(
                (string?)gate.residual_risk,
                "Critical",
                StringComparison.OrdinalIgnoreCase);

        if (!valid)
        {
            await transaction.RollbackAsync(cancellationToken);
            return (false, "Closure gates are incomplete or management has not approved closure.");
        }

        const string closeSql = """
        UPDATE incident_closure_reviews
        SET closed_at = @Now
        WHERE tenant_id = @TenantId AND incident_id = @IncidentId;

        UPDATE incidents
        SET status = 'Closed',
            workflow_state = 'Closed',
            updated_at = @Now
        WHERE tenant_id = @TenantId
          AND id = @IncidentId
          AND workflow_state = 'Verification';

        INSERT INTO incident_timeline (
            id, tenant_id, incident_id, event_type,
            description, performed_by, occurred_at)
        VALUES (
            @TimelineId, @TenantId, @IncidentId,
            'IncidentClosed',
            'Final verification completed and management approved case closure.',
            @ReviewerId, @Now);
        """;

        var affected = await connection.ExecuteAsync(
            new CommandDefinition(
                closeSql,
                new
                {
                    request.TenantId,
                    IncidentId = incidentId,
                    request.ReviewerId,
                    TimelineId = Guid.NewGuid(),
                    Now = now
                },
                transaction,
                cancellationToken: cancellationToken));

        await transaction.CommitAsync(cancellationToken);
        return affected > 0
            ? (true, null)
            : (false, "Incident was not in Verification.");
    }
}
