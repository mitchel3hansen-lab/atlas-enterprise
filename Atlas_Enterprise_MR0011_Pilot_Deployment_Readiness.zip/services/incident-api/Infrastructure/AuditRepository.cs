using System.Text.Json;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class AuditRepository(IConfiguration configuration)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    public async Task WriteAsync(
        Guid? tenantId,
        Guid? actorId,
        string? actorRole,
        string eventType,
        string? entityType,
        Guid? entityId,
        string action,
        string outcome,
        string correlationId,
        string? ipAddress,
        string? userAgent,
        object? details,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO audit_events (
            id, tenant_id, actor_id, actor_role, event_type,
            entity_type, entity_id, action, outcome, correlation_id,
            ip_address, user_agent, details, occurred_at)
        VALUES (
            @Id, @TenantId, @ActorId, @ActorRole, @EventType,
            @EntityType, @EntityId, @Action, @Outcome, @CorrelationId,
            CAST(@IpAddress AS inet), @UserAgent, CAST(@Details AS jsonb), NOW());
        """;

        await using var connection = CreateConnection();
        await connection.ExecuteAsync(new CommandDefinition(
            sql,
            new
            {
                Id = Guid.NewGuid(),
                TenantId = tenantId,
                ActorId = actorId,
                ActorRole = actorRole,
                EventType = eventType,
                EntityType = entityType,
                EntityId = entityId,
                Action = action,
                Outcome = outcome,
                CorrelationId = correlationId,
                IpAddress = ipAddress,
                UserAgent = userAgent,
                Details = JsonSerializer.Serialize(details ?? new { })
            },
            cancellationToken: cancellationToken));
    }
}
