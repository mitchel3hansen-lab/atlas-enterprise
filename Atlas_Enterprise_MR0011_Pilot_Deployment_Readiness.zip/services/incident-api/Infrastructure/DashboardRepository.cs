using Atlas.IncidentApi.Domain;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class DashboardRepository(IConfiguration configuration)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    public async Task<DashboardSummary> GetAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        const string totalsSql = """
        SELECT
            COUNT(*)::int AS TotalIncidents,
            COUNT(*) FILTER (WHERE workflow_state <> 'Closed')::int AS OpenIncidents,
            COUNT(*) FILTER (WHERE workflow_state = 'Closed')::int AS ClosedIncidents,
            COUNT(*) FILTER (
                WHERE COALESCE(confirmed_severity, severity) = 'Critical'
            )::int AS CriticalIncidents,
            COUNT(*) FILTER (WHERE workflow_state = 'Investigation')::int AS InvestigationsOpen,
            COALESCE(AVG(
                EXTRACT(EPOCH FROM (updated_at - created_at)) / 86400
            ) FILTER (WHERE workflow_state = 'Closed'), 0)::numeric(12,2) AS AverageClosureDays
        FROM incidents
        WHERE tenant_id = @TenantId;
        """;

        const string capaSql = """
        SELECT
            COUNT(*) FILTER (WHERE status <> 'Closed')::int AS CapasOpen,
            COUNT(*) FILTER (
                WHERE status <> 'Closed' AND target_date < NOW()
            )::int AS CapasOverdue,
            COALESCE(
                100.0 * COUNT(*) FILTER (
                    WHERE effectiveness_status = 'Effective'
                ) / NULLIF(COUNT(*) FILTER (
                    WHERE effectiveness_status IN ('Effective', 'Ineffective')
                ), 0),
                0
            )::numeric(12,2) AS CapaEffectivenessRate
        FROM capa_actions
        WHERE tenant_id = @TenantId;
        """;

        const string severitySql = """
        SELECT
            COALESCE(confirmed_severity, severity) AS Name,
            COUNT(*)::int AS Count
        FROM incidents
        WHERE tenant_id = @TenantId
        GROUP BY COALESCE(confirmed_severity, severity)
        ORDER BY Count DESC;
        """;

        const string workflowSql = """
        SELECT
            workflow_state AS Name,
            COUNT(*)::int AS Count
        FROM incidents
        WHERE tenant_id = @TenantId
        GROUP BY workflow_state
        ORDER BY Count DESC;
        """;

        const string departmentSql = """
        SELECT
            i.department AS Department,
            COUNT(DISTINCT i.id)::int AS TotalIncidents,
            COUNT(DISTINCT i.id) FILTER (
                WHERE i.workflow_state <> 'Closed'
            )::int AS OpenIncidents,
            COUNT(DISTINCT c.id) FILTER (
                WHERE c.status <> 'Closed'
            )::int AS OpenCapas,
            COUNT(DISTINCT c.id) FILTER (
                WHERE c.status <> 'Closed' AND c.target_date < NOW()
            )::int AS OverdueCapas
        FROM incidents i
        LEFT JOIN capa_actions c
            ON c.tenant_id = i.tenant_id
           AND c.incident_id = i.id
        WHERE i.tenant_id = @TenantId
        GROUP BY i.department
        ORDER BY OpenIncidents DESC, Department;
        """;

        await using var connection = CreateConnection();

        var totals = await connection.QuerySingleAsync<dynamic>(
            new CommandDefinition(
                totalsSql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken));

        var capa = await connection.QuerySingleAsync<dynamic>(
            new CommandDefinition(
                capaSql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken));

        var severity = await connection.QueryAsync<DashboardBucket>(
            new CommandDefinition(
                severitySql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken));

        var workflow = await connection.QueryAsync<DashboardBucket>(
            new CommandDefinition(
                workflowSql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken));

        var departments = await connection.QueryAsync<DashboardDepartment>(
            new CommandDefinition(
                departmentSql,
                new { TenantId = tenantId },
                cancellationToken: cancellationToken));

        int total = (int)totals.totalincidents;
        int closed = (int)totals.closedincidents;
        decimal closureRate = total == 0
            ? 0
            : decimal.Round(100m * closed / total, 2);

        return new DashboardSummary(
            total,
            (int)totals.openincidents,
            closed,
            (int)totals.criticalincidents,
            (int)totals.investigationsopen,
            (int)capa.capasopen,
            (int)capa.capasoverdue,
            closureRate,
            (decimal)capa.capaeffectivenessrate,
            (decimal)totals.averageclosuredays,
            severity.AsList(),
            workflow.AsList(),
            departments.AsList());
    }
}
