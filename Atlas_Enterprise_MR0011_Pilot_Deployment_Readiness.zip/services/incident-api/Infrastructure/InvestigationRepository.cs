using Atlas.IncidentApi.Domain;
using Atlas.IncidentApi.Features.Investigations;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class InvestigationRepository(IConfiguration configuration)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    public async Task<InvestigationWorkspace?> GetAsync(
        Guid tenantId,
        Guid incidentId,
        CancellationToken cancellationToken)
    {
        const string investigationSql = """
        SELECT
            id AS Id,
            incident_id AS IncidentId,
            investigator_id AS InvestigatorId,
            status AS Status,
            executive_summary AS ExecutiveSummary,
            event_analysis AS EventAnalysis,
            immediate_causes AS ImmediateCauses,
            root_cause_category AS RootCauseCategory,
            root_cause_detail AS RootCauseDetail,
            contributing_factors AS ContributingFactors,
            recommendations AS Recommendations,
            started_at AS StartedAt,
            completed_at AS CompletedAt,
            updated_at AS UpdatedAt
        FROM investigations
        WHERE tenant_id = @TenantId AND incident_id = @IncidentId;
        """;

        const string interviewsSql = """
        SELECT
            id AS Id,
            interviewee_name AS IntervieweeName,
            interviewee_role AS IntervieweeRole,
            summary AS Summary,
            conducted_by AS ConductedBy,
            conducted_at AS ConductedAt
        FROM investigation_interviews
        WHERE tenant_id = @TenantId AND investigation_id = @InvestigationId
        ORDER BY conducted_at;
        """;

        const string findingsSql = """
        SELECT
            id AS Id,
            finding_type AS FindingType,
            statement AS Statement,
            evidence_reference AS EvidenceReference,
            created_at AS CreatedAt
        FROM investigation_findings
        WHERE tenant_id = @TenantId AND investigation_id = @InvestigationId
        ORDER BY created_at;
        """;

        const string evidenceSql = """
        SELECT
            id AS Id,
            evidence_type AS EvidenceType,
            title AS Title,
            reference_uri AS ReferenceUri,
            description AS Description,
            added_by AS AddedBy,
            added_at AS AddedAt
        FROM investigation_evidence
        WHERE tenant_id = @TenantId AND investigation_id = @InvestigationId
        ORDER BY added_at;
        """;

        await using var connection = CreateConnection();
        var investigation = await connection.QuerySingleOrDefaultAsync<Investigation>(
            new CommandDefinition(
                investigationSql,
                new { TenantId = tenantId, IncidentId = incidentId },
                cancellationToken: cancellationToken));

        if (investigation is null)
            return null;

        var args = new { TenantId = tenantId, InvestigationId = investigation.Id };
        var interviews = await connection.QueryAsync<InvestigationInterview>(
            new CommandDefinition(interviewsSql, args, cancellationToken: cancellationToken));
        var findings = await connection.QueryAsync<InvestigationFinding>(
            new CommandDefinition(findingsSql, args, cancellationToken: cancellationToken));
        var evidence = await connection.QueryAsync<InvestigationEvidence>(
            new CommandDefinition(evidenceSql, args, cancellationToken: cancellationToken));

        return new InvestigationWorkspace(
            investigation,
            interviews.AsList(),
            findings.AsList(),
            evidence.AsList());
    }

    public async Task<Investigation> UpsertAsync(
        Guid incidentId,
        UpsertInvestigationRequest request,
        CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;

        const string sql = """
        INSERT INTO investigations (
            id, tenant_id, incident_id, investigator_id, status,
            executive_summary, event_analysis, immediate_causes,
            root_cause_category, root_cause_detail, contributing_factors,
            recommendations, started_at, updated_at)
        VALUES (
            @Id, @TenantId, @IncidentId, @InvestigatorId, 'Open',
            @ExecutiveSummary, @EventAnalysis, @ImmediateCauses,
            @RootCauseCategory, @RootCauseDetail, @ContributingFactors,
            @Recommendations, @Now, @Now)
        ON CONFLICT (incident_id)
        DO UPDATE SET
            executive_summary = EXCLUDED.executive_summary,
            event_analysis = EXCLUDED.event_analysis,
            immediate_causes = EXCLUDED.immediate_causes,
            root_cause_category = EXCLUDED.root_cause_category,
            root_cause_detail = EXCLUDED.root_cause_detail,
            contributing_factors = EXCLUDED.contributing_factors,
            recommendations = EXCLUDED.recommendations,
            updated_at = EXCLUDED.updated_at
        RETURNING
            id AS Id,
            incident_id AS IncidentId,
            investigator_id AS InvestigatorId,
            status AS Status,
            executive_summary AS ExecutiveSummary,
            event_analysis AS EventAnalysis,
            immediate_causes AS ImmediateCauses,
            root_cause_category AS RootCauseCategory,
            root_cause_detail AS RootCauseDetail,
            contributing_factors AS ContributingFactors,
            recommendations AS Recommendations,
            started_at AS StartedAt,
            completed_at AS CompletedAt,
            updated_at AS UpdatedAt;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleAsync<Investigation>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    request.TenantId,
                    IncidentId = incidentId,
                    request.InvestigatorId,
                    request.ExecutiveSummary,
                    request.EventAnalysis,
                    request.ImmediateCauses,
                    request.RootCauseCategory,
                    request.RootCauseDetail,
                    request.ContributingFactors,
                    request.Recommendations,
                    Now = now
                },
                cancellationToken: cancellationToken));
    }

    public async Task<Guid?> AddInterviewAsync(
        Guid incidentId,
        AddInterviewRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO investigation_interviews (
            id, tenant_id, investigation_id, interviewee_name,
            interviewee_role, summary, conducted_by, conducted_at)
        SELECT
            @Id, @TenantId, i.id, @IntervieweeName,
            @IntervieweeRole, @Summary, @InvestigatorId, @ConductedAt
        FROM investigations i
        WHERE i.tenant_id = @TenantId AND i.incident_id = @IncidentId
        RETURNING id;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<Guid?>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    request.TenantId,
                    IncidentId = incidentId,
                    request.IntervieweeName,
                    request.IntervieweeRole,
                    request.Summary,
                    request.InvestigatorId,
                    request.ConductedAt
                },
                cancellationToken: cancellationToken));
    }

    public async Task<Guid?> AddFindingAsync(
        Guid incidentId,
        AddFindingRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO investigation_findings (
            id, tenant_id, investigation_id, finding_type,
            statement, evidence_reference)
        SELECT
            @Id, @TenantId, i.id, @FindingType,
            @Statement, @EvidenceReference
        FROM investigations i
        WHERE i.tenant_id = @TenantId AND i.incident_id = @IncidentId
        RETURNING id;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<Guid?>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    request.TenantId,
                    IncidentId = incidentId,
                    request.FindingType,
                    request.Statement,
                    request.EvidenceReference
                },
                cancellationToken: cancellationToken));
    }

    public async Task<Guid?> AddEvidenceAsync(
        Guid incidentId,
        AddEvidenceRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO investigation_evidence (
            id, tenant_id, investigation_id, evidence_type,
            title, reference_uri, description, added_by)
        SELECT
            @Id, @TenantId, i.id, @EvidenceType,
            @Title, @ReferenceUri, @Description, @AddedBy
        FROM investigations i
        WHERE i.tenant_id = @TenantId AND i.incident_id = @IncidentId
        RETURNING id;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<Guid?>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    request.TenantId,
                    IncidentId = incidentId,
                    request.EvidenceType,
                    request.Title,
                    request.ReferenceUri,
                    request.Description,
                    request.AddedBy
                },
                cancellationToken: cancellationToken));
    }

    public async Task<(bool Completed, string? Error)> CompleteAsync(
        Guid incidentId,
        CompleteInvestigationRequest request,
        CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;

        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        const string validateSql = """
        SELECT
            i.id,
            i.executive_summary,
            i.event_analysis,
            i.root_cause_category,
            i.root_cause_detail,
            i.recommendations,
            EXISTS (
                SELECT 1 FROM investigation_findings f
                WHERE f.investigation_id = i.id
            ) AS has_finding,
            EXISTS (
                SELECT 1 FROM investigation_evidence e
                WHERE e.investigation_id = i.id
            ) AS has_evidence
        FROM investigations i
        WHERE i.tenant_id = @TenantId
          AND i.incident_id = @IncidentId
          AND i.investigator_id = @InvestigatorId
        FOR UPDATE;
        """;

        var row = await connection.QuerySingleOrDefaultAsync<dynamic>(
            new CommandDefinition(
                validateSql,
                new
                {
                    request.TenantId,
                    IncidentId = incidentId,
                    request.InvestigatorId
                },
                transaction,
                cancellationToken: cancellationToken));

        if (row is null)
        {
            await transaction.RollbackAsync(cancellationToken);
            return (false, "Investigation was not found or is assigned to another investigator.");
        }

        bool incomplete =
            string.IsNullOrWhiteSpace((string?)row.executive_summary) ||
            string.IsNullOrWhiteSpace((string?)row.event_analysis) ||
            string.IsNullOrWhiteSpace((string?)row.root_cause_category) ||
            string.IsNullOrWhiteSpace((string?)row.root_cause_detail) ||
            string.IsNullOrWhiteSpace((string?)row.recommendations) ||
            !(bool)row.has_finding ||
            !(bool)row.has_evidence;

        if (incomplete)
        {
            await transaction.RollbackAsync(cancellationToken);
            return (false, "Investigation is incomplete. Summary, analysis, root cause, recommendations, a finding, and evidence are required.");
        }

        const string completeSql = """
        UPDATE investigations
        SET status = 'Completed',
            completed_at = @Now,
            updated_at = @Now
        WHERE tenant_id = @TenantId AND incident_id = @IncidentId;

        UPDATE incidents
        SET status = 'CorrectiveAction',
            workflow_state = 'CAPA',
            updated_at = @Now
        WHERE tenant_id = @TenantId AND id = @IncidentId;

        INSERT INTO incident_timeline (
            id, tenant_id, incident_id, event_type, description,
            performed_by, occurred_at)
        VALUES (
            @TimelineId, @TenantId, @IncidentId,
            'InvestigationCompleted',
            'Investigation completed and routed to CAPA.',
            @InvestigatorId, @Now);
        """;

        await connection.ExecuteAsync(
            new CommandDefinition(
                completeSql,
                new
                {
                    request.TenantId,
                    IncidentId = incidentId,
                    request.InvestigatorId,
                    TimelineId = Guid.NewGuid(),
                    Now = now
                },
                transaction,
                cancellationToken: cancellationToken));

        await transaction.CommitAsync(cancellationToken);
        return (true, null);
    }
}
