using Atlas.IncidentApi.Domain;
using Atlas.IncidentApi.Features.Incidents.Create;
using Atlas.IncidentApi.Features.Incidents.Review;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class IncidentRepository(IConfiguration configuration)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    private const string IncidentProjection = """
        id AS Id,
        tenant_id AS TenantId,
        incident_number AS IncidentNumber,
        title AS Title,
        description AS Description,
        incident_type AS IncidentType,
        severity AS Severity,
        status AS Status,
        workflow_state AS WorkflowState,
        occurred_at AS OccurredAt,
        reporter_id AS ReporterId,
        site AS Site,
        department AS Department,
        created_at AS CreatedAt,
        updated_at AS UpdatedAt,
        submitted_at AS SubmittedAt,
        supervisor_reviewed_at AS SupervisorReviewedAt,
        supervisor_reviewer_id AS SupervisorReviewerId,
        review_outcome AS ReviewOutcome,
        safety_reviewed_at AS SafetyReviewedAt,
        safety_reviewer_id AS SafetyReviewerId,
        confirmed_severity AS ConfirmedSeverity,
        osha_review_required AS OshaReviewRequired,
        medical_follow_up_required AS MedicalFollowUpRequired,
        immediate_controls_reviewed AS ImmediateControlsReviewed,
        investigator_id AS InvestigatorId,
        investigation_due_at AS InvestigationDueAt
        """;

    public async Task<Incident> CreateAsync(
        CreateIncidentRequest request,
        CancellationToken cancellationToken)
    {
        var id = Guid.NewGuid();
        var now = DateTimeOffset.UtcNow;
        var incidentNumber =
            $"INC-{now:yyyy}-{now:MMddHHmmss}-{Random.Shared.Next(100, 999)}";

        const string insertIncident = """
        INSERT INTO incidents (
            id, tenant_id, incident_number, title, description, incident_type,
            severity, status, workflow_state, occurred_at, reporter_id, site,
            department, created_at, updated_at)
        VALUES (
            @Id, @TenantId, @IncidentNumber, @Title, @Description, @IncidentType,
            @Severity, 'Draft', 'Draft', @OccurredAt, @ReporterId, @Site,
            @Department, @Now, @Now);
        """;

        const string insertTimeline = """
        INSERT INTO incident_timeline (
            id, tenant_id, incident_id, event_type, description, performed_by, occurred_at)
        VALUES (
            @TimelineId, @TenantId, @IncidentId, 'IncidentCreated',
            'Incident draft created.', @ReporterId, @Now);
        """;

        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        var args = new
        {
            Id = id,
            request.TenantId,
            IncidentNumber = incidentNumber,
            request.Title,
            request.Description,
            request.IncidentType,
            request.Severity,
            request.OccurredAt,
            request.ReporterId,
            request.Site,
            request.Department,
            Now = now
        };

        await connection.ExecuteAsync(new CommandDefinition(
            insertIncident, args, transaction,
            cancellationToken: cancellationToken));

        await connection.ExecuteAsync(new CommandDefinition(
            insertTimeline,
            new
            {
                TimelineId = Guid.NewGuid(),
                request.TenantId,
                IncidentId = id,
                request.ReporterId,
                Now = now
            },
            transaction,
            cancellationToken: cancellationToken));

        await transaction.CommitAsync(cancellationToken);

        return new Incident(
            id, request.TenantId, incidentNumber, request.Title,
            request.Description, request.IncidentType, request.Severity,
            "Draft", "Draft", request.OccurredAt, request.ReporterId,
            request.Site, request.Department, now, now, null, null, null, null,
            null, null, null, false, false, false, null, null);
    }

    public async Task<IReadOnlyList<Incident>> ListAsync(
        Guid tenantId,
        string? department,
        CancellationToken cancellationToken)
    {
        var sql = $"""
        SELECT {IncidentProjection}
        FROM incidents
        WHERE tenant_id = @TenantId
          AND (@Department IS NULL OR department = @Department)
        ORDER BY created_at DESC;
        """;

        await using var connection = CreateConnection();
        var rows = await connection.QueryAsync<Incident>(
            new CommandDefinition(
                sql,
                new { TenantId = tenantId, Department = department },
                cancellationToken: cancellationToken));

        return rows.AsList();
    }

    public async Task<IncidentDetails?> GetAsync(
        Guid tenantId,
        Guid incidentId,
        CancellationToken cancellationToken)
    {
        var incidentSql = $"""
        SELECT {IncidentProjection}
        FROM incidents
        WHERE tenant_id = @TenantId AND id = @IncidentId;
        """;

        const string timelineSql = """
        SELECT
            id AS Id,
            incident_id AS IncidentId,
            event_type AS EventType,
            description AS Description,
            performed_by AS PerformedBy,
            occurred_at AS OccurredAt
        FROM incident_timeline
        WHERE tenant_id = @TenantId AND incident_id = @IncidentId
        ORDER BY occurred_at;
        """;

        const string commentsSql = """
        SELECT
            id AS Id,
            incident_id AS IncidentId,
            author_id AS AuthorId,
            author_role AS AuthorRole,
            comment_type AS CommentType,
            body AS Body,
            created_at AS CreatedAt
        FROM incident_comments
        WHERE tenant_id = @TenantId AND incident_id = @IncidentId
        ORDER BY created_at;
        """;

        await using var connection = CreateConnection();
        var args = new { TenantId = tenantId, IncidentId = incidentId };

        var incident = await connection.QuerySingleOrDefaultAsync<Incident>(
            new CommandDefinition(
                incidentSql, args, cancellationToken: cancellationToken));

        if (incident is null)
            return null;

        var timeline = await connection.QueryAsync<IncidentTimelineEvent>(
            new CommandDefinition(
                timelineSql, args, cancellationToken: cancellationToken));

        var comments = await connection.QueryAsync<IncidentComment>(
            new CommandDefinition(
                commentsSql, args, cancellationToken: cancellationToken));

        return new IncidentDetails(
            incident,
            timeline.AsList(),
            comments.AsList());
    }

    public async Task<Incident?> SubmitAsync(
        Guid tenantId,
        Guid incidentId,
        Guid actorId,
        CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;

        var updateSql = $"""
        UPDATE incidents
        SET status = 'Submitted',
            workflow_state = 'SupervisorReview',
            submitted_at = @Now,
            updated_at = @Now
        WHERE tenant_id = @TenantId
          AND id = @IncidentId
          AND status = 'Draft'
        RETURNING {IncidentProjection};
        """;

        const string timelineSql = """
        INSERT INTO incident_timeline (
            id, tenant_id, incident_id, event_type, description,
            performed_by, occurred_at)
        VALUES (
            @TimelineId, @TenantId, @IncidentId, 'IncidentSubmitted',
            'Incident submitted and routed to Supervisor Review.',
            @ActorId, @Now);
        """;

        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        var incident = await connection.QuerySingleOrDefaultAsync<Incident>(
            new CommandDefinition(
                updateSql,
                new { TenantId = tenantId, IncidentId = incidentId, Now = now },
                transaction,
                cancellationToken: cancellationToken));

        if (incident is null)
        {
            await transaction.RollbackAsync(cancellationToken);
            return null;
        }

        await connection.ExecuteAsync(new CommandDefinition(
            timelineSql,
            new
            {
                TimelineId = Guid.NewGuid(),
                TenantId = tenantId,
                IncidentId = incidentId,
                ActorId = actorId,
                Now = now
            },
            transaction,
            cancellationToken: cancellationToken));

        await transaction.CommitAsync(cancellationToken);
        return incident;
    }

    public async Task<(Incident? Incident, string? Error)> ReviewAsync(
        Guid incidentId,
        ReviewIncidentRequest request,
        CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;
        var approved = string.Equals(
            request.Decision, "Approve", StringComparison.OrdinalIgnoreCase);

        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        const string currentSql = """
        SELECT department, workflow_state
        FROM incidents
        WHERE tenant_id = @TenantId AND id = @IncidentId
        FOR UPDATE;
        """;

        var current = await connection.QuerySingleOrDefaultAsync<dynamic>(
            new CommandDefinition(
                currentSql,
                new { request.TenantId, IncidentId = incidentId },
                transaction,
                cancellationToken: cancellationToken));

        if (current is null)
        {
            await transaction.RollbackAsync(cancellationToken);
            return (null, "Incident was not found.");
        }

        if (!string.Equals(
                (string)current.department,
                request.ReviewerDepartment,
                StringComparison.OrdinalIgnoreCase))
        {
            await transaction.RollbackAsync(cancellationToken);
            return (null, "Supervisor may only review incidents for their department.");
        }

        if (!string.Equals(
                (string)current.workflow_state,
                "SupervisorReview",
                StringComparison.OrdinalIgnoreCase))
        {
            await transaction.RollbackAsync(cancellationToken);
            return (null, "Incident is not awaiting Supervisor Review.");
        }

        var nextStatus = approved ? "UnderReview" : "Draft";
        var nextWorkflow = approved ? "SafetyReview" : "CorrectionRequested";
        var eventType = approved
            ? "SupervisorReviewApproved"
            : "SupervisorCorrectionRequested";
        var eventDescription = approved
            ? "Supervisor approved the initial review and routed the incident to Safety Review."
            : "Supervisor returned the incident for correction.";

        var updateSql = $"""
        UPDATE incidents
        SET status = @NextStatus,
            workflow_state = @NextWorkflow,
            supervisor_reviewed_at = @Now,
            supervisor_reviewer_id = @ReviewerId,
            review_outcome = @Decision,
            updated_at = @Now
        WHERE tenant_id = @TenantId AND id = @IncidentId
        RETURNING {IncidentProjection};
        """;

        var incident = await connection.QuerySingleAsync<Incident>(
            new CommandDefinition(
                updateSql,
                new
                {
                    request.TenantId,
                    IncidentId = incidentId,
                    NextStatus = nextStatus,
                    NextWorkflow = nextWorkflow,
                    request.ReviewerId,
                    request.Decision,
                    Now = now
                },
                transaction,
                cancellationToken: cancellationToken));

        const string commentSql = """
        INSERT INTO incident_comments (
            id, tenant_id, incident_id, author_id, author_role,
            comment_type, body, created_at)
        VALUES (
            @Id, @TenantId, @IncidentId, @AuthorId, 'Supervisor',
            'SupervisorReview', @Body, @Now);
        """;

        const string timelineSql = """
        INSERT INTO incident_timeline (
            id, tenant_id, incident_id, event_type, description,
            performed_by, occurred_at)
        VALUES (
            @Id, @TenantId, @IncidentId, @EventType, @Description,
            @PerformedBy, @Now);
        """;

        await connection.ExecuteAsync(new CommandDefinition(
            commentSql,
            new
            {
                Id = Guid.NewGuid(),
                request.TenantId,
                IncidentId = incidentId,
                AuthorId = request.ReviewerId,
                Body = request.Comment,
                Now = now
            },
            transaction,
            cancellationToken: cancellationToken));

        await connection.ExecuteAsync(new CommandDefinition(
            timelineSql,
            new
            {
                Id = Guid.NewGuid(),
                request.TenantId,
                IncidentId = incidentId,
                EventType = eventType,
                Description = eventDescription,
                PerformedBy = request.ReviewerId,
                Now = now
            },
            transaction,
            cancellationToken: cancellationToken));

        await transaction.CommitAsync(cancellationToken);
        return (incident, null);
    }

    public async Task<(Incident? Incident, string? Error)> SafetyReviewAsync(
        Guid incidentId,
        Atlas.IncidentApi.Features.Incidents.SafetyReview.SafetyReviewRequest request,
        CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;

        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        var updateSql = $"""
        UPDATE incidents
        SET status = 'UnderInvestigation',
            workflow_state = 'Investigation',
            severity = @ConfirmedSeverity,
            confirmed_severity = @ConfirmedSeverity,
            osha_review_required = @OshaReviewRequired,
            medical_follow_up_required = @MedicalFollowUpRequired,
            immediate_controls_reviewed = @ImmediateControlsReviewed,
            investigator_id = @InvestigatorId,
            investigation_due_at = @InvestigationDueAt,
            safety_reviewed_at = @Now,
            safety_reviewer_id = @SafetyReviewerId,
            updated_at = @Now
        WHERE tenant_id = @TenantId
          AND id = @IncidentId
          AND workflow_state = 'SafetyReview'
        RETURNING {IncidentProjection};
        """;

        var incident = await connection.QuerySingleOrDefaultAsync<Incident>(
            new CommandDefinition(
                updateSql,
                new
                {
                    request.TenantId,
                    IncidentId = incidentId,
                    request.ConfirmedSeverity,
                    request.OshaReviewRequired,
                    request.MedicalFollowUpRequired,
                    request.ImmediateControlsReviewed,
                    request.InvestigatorId,
                    request.InvestigationDueAt,
                    SafetyReviewerId = request.SafetyReviewerId,
                    Now = now
                },
                transaction,
                cancellationToken: cancellationToken));

        if (incident is null)
        {
            await transaction.RollbackAsync(cancellationToken);
            return (null, "Incident was not found or is not awaiting Safety Review.");
        }

        const string commentSql = """
        INSERT INTO incident_comments (
            id, tenant_id, incident_id, author_id, author_role,
            comment_type, body, created_at)
        VALUES (
            @Id, @TenantId, @IncidentId, @AuthorId, 'Safety',
            'SafetyReview', @Body, @Now);
        """;

        const string timelineSql = """
        INSERT INTO incident_timeline (
            id, tenant_id, incident_id, event_type, description,
            performed_by, occurred_at)
        VALUES (
            @Id, @TenantId, @IncidentId, 'InvestigatorAssigned',
            @Description, @PerformedBy, @Now);
        """;

        await connection.ExecuteAsync(new CommandDefinition(
            commentSql,
            new
            {
                Id = Guid.NewGuid(),
                request.TenantId,
                IncidentId = incidentId,
                AuthorId = request.SafetyReviewerId,
                Body = request.Comment,
                Now = now
            },
            transaction,
            cancellationToken: cancellationToken));

        await connection.ExecuteAsync(new CommandDefinition(
            timelineSql,
            new
            {
                Id = Guid.NewGuid(),
                request.TenantId,
                IncidentId = incidentId,
                Description =
                    $"Safety review completed. Investigator assigned with due date {request.InvestigationDueAt:yyyy-MM-dd}.",
                PerformedBy = request.SafetyReviewerId,
                Now = now
            },
            transaction,
            cancellationToken: cancellationToken));

        await transaction.CommitAsync(cancellationToken);
        return (incident, null);
    }

}
