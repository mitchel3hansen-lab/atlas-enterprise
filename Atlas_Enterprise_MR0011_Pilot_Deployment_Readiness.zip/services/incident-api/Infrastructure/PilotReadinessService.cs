using Atlas.IncidentApi.Domain;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class PilotReadinessService(IConfiguration configuration)
{
    public async Task<PilotReadinessResult> CheckAsync(
        CancellationToken cancellationToken)
    {
        var checks = new List<PilotReadinessCheck>();

        try
        {
            await using var connection = new NpgsqlConnection(
                configuration.GetConnectionString("Atlas"));
            await connection.OpenAsync(cancellationToken);

            var requiredTables = new[]
            {
                "incidents",
                "incident_timeline",
                "investigations",
                "capa_actions",
                "incident_closure_reviews",
                "audit_events"
            };

            foreach (var table in requiredTables)
            {
                var exists = await connection.ExecuteScalarAsync<bool>(
                    new CommandDefinition(
                        """
                        SELECT EXISTS (
                            SELECT 1
                            FROM information_schema.tables
                            WHERE table_schema = 'public'
                              AND table_name = @TableName
                        );
                        """,
                        new { TableName = table },
                        cancellationToken: cancellationToken));

                checks.Add(new PilotReadinessCheck(
                    $"table:{table}",
                    exists,
                    exists ? "Present." : "Missing."));
            }

            var demoIncident = await connection.ExecuteScalarAsync<int>(
                new CommandDefinition(
                    """
                    SELECT COUNT(*)::int
                    FROM incidents
                    WHERE tenant_id = '11111111-1111-1111-1111-111111111111';
                    """,
                    cancellationToken: cancellationToken));

            checks.Add(new PilotReadinessCheck(
                "demo-data",
                demoIncident > 0,
                demoIncident > 0
                    ? $"{demoIncident} demonstration incident(s) available."
                    : "No demonstration incident is loaded."));
        }
        catch (Exception ex)
        {
            checks.Add(new PilotReadinessCheck(
                "database",
                false,
                $"Readiness check failed: {ex.GetType().Name}"));
        }

        var status = checks.All(x => x.Passed) ? "Ready" : "NotReady";
        return new PilotReadinessResult(
            status,
            DateTimeOffset.UtcNow,
            checks);
    }
}
