using Atlas.IncidentApi.Domain;
using Atlas.IncidentApi.Features.Capas;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class CapaRepository(IConfiguration configuration)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    private const string Projection = """
        id AS Id,
        incident_id AS IncidentId,
        capa_number AS CapaNumber,
        action_type AS ActionType,
        title AS Title,
        description AS Description,
        owner_id AS OwnerId,
        department AS Department,
        priority AS Priority,
        target_date AS TargetDate,
        status AS Status,
        completion_notes AS CompletionNotes,
        completed_at AS CompletedAt,
        verification_status AS VerificationStatus,
        effectiveness_status AS EffectivenessStatus,
        estimated_cost AS EstimatedCost,
        actual_cost AS ActualCost,
        created_at AS CreatedAt,
        updated_at AS UpdatedAt
        """;

    public async Task<IReadOnlyList<CapaAction>> ListForIncidentAsync(
        Guid tenantId,
        Guid incidentId,
        CancellationToken cancellationToken)
    {
        var sql = $"""
        SELECT {Projection}
        FROM capa_actions
        WHERE tenant_id = @TenantId AND incident_id = @IncidentId
        ORDER BY created_at;
        """;

        await using var connection = CreateConnection();
        var rows = await connection.QueryAsync<CapaAction>(
            new CommandDefinition(
                sql,
                new { TenantId = tenantId, IncidentId = incidentId },
                cancellationToken: cancellationToken));

        return rows.AsList();
    }

    public async Task<CapaWorkspace?> GetAsync(
        Guid tenantId,
        Guid capaId,
        CancellationToken cancellationToken)
    {
        var actionSql = $"""
        SELECT {Projection}
        FROM capa_actions
        WHERE tenant_id = @TenantId AND id = @CapaId;
        """;

        const string evidenceSql = """
        SELECT
            id AS Id,
            evidence_type AS EvidenceType,
            title AS Title,
            reference_uri AS ReferenceUri,
            uploaded_by AS UploadedBy,
            uploaded_at AS UploadedAt
        FROM capa_evidence
        WHERE tenant_id = @TenantId AND capa_id = @CapaId
        ORDER BY uploaded_at;
        """;

        const string verificationSql = """
        SELECT
            id AS Id,
            verifier_id AS VerifierId,
            result AS Result,
            notes AS Notes,
            verified_at AS VerifiedAt
        FROM capa_verifications
        WHERE tenant_id = @TenantId AND capa_id = @CapaId
        ORDER BY verified_at;
        """;

        const string effectivenessSql = """
        SELECT
            id AS Id,
            reviewer_id AS ReviewerId,
            result AS Result,
            recurrence_found AS RecurrenceFound,
            comments AS Comments,
            reviewed_at AS ReviewedAt
        FROM capa_effectiveness_reviews
        WHERE tenant_id = @TenantId AND capa_id = @CapaId
        ORDER BY reviewed_at;
        """;

        await using var connection = CreateConnection();
        var args = new { TenantId = tenantId, CapaId = capaId };

        var action = await connection.QuerySingleOrDefaultAsync<CapaAction>(
            new CommandDefinition(actionSql, args, cancellationToken: cancellationToken));

        if (action is null)
            return null;

        var evidence = await connection.QueryAsync<CapaEvidence>(
            new CommandDefinition(evidenceSql, args, cancellationToken: cancellationToken));
        var verifications = await connection.QueryAsync<CapaVerification>(
            new CommandDefinition(verificationSql, args, cancellationToken: cancellationToken));
        var reviews = await connection.QueryAsync<CapaEffectivenessReview>(
            new CommandDefinition(effectivenessSql, args, cancellationToken: cancellationToken));

        return new CapaWorkspace(
            action,
            evidence.AsList(),
            verifications.AsList(),
            reviews.AsList());
    }

    public async Task<CapaAction?> CreateAsync(
        Guid incidentId,
        CreateCapaRequest request,
        CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;
        var capaNumber =
            $"CAPA-{now:yyyy}-{now:MMddHHmmss}-{Random.Shared.Next(100, 999)}";

        var sql = $"""
        INSERT INTO capa_actions (
            id, tenant_id, incident_id, capa_number, action_type,
            title, description, owner_id, department, priority,
            target_date, status, estimated_cost, created_at, updated_at)
        SELECT
            @Id, @TenantId, @IncidentId, @CapaNumber, @ActionType,
            @Title, @Description, @OwnerId, @Department, @Priority,
            @TargetDate, 'Open', @EstimatedCost, @Now, @Now
        FROM incidents i
        WHERE i.tenant_id = @TenantId
          AND i.id = @IncidentId
          AND i.workflow_state = 'CAPA'
        RETURNING {Projection};
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<CapaAction>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    request.TenantId,
                    IncidentId = incidentId,
                    CapaNumber = capaNumber,
                    request.ActionType,
                    request.Title,
                    request.Description,
                    request.OwnerId,
                    request.Department,
                    request.Priority,
                    request.TargetDate,
                    request.EstimatedCost,
                    Now = now
                },
                cancellationToken: cancellationToken));
    }

    public async Task<Guid?> AddEvidenceAsync(
        Guid capaId,
        AddCapaEvidenceRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        INSERT INTO capa_evidence (
            id, tenant_id, capa_id, evidence_type, title,
            reference_uri, uploaded_by)
        SELECT
            @Id, @TenantId, c.id, @EvidenceType, @Title,
            @ReferenceUri, @UploadedBy
        FROM capa_actions c
        WHERE c.tenant_id = @TenantId AND c.id = @CapaId
        RETURNING id;
        """;

        await using var connection = CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<Guid?>(
            new CommandDefinition(
                sql,
                new
                {
                    Id = Guid.NewGuid(),
                    request.TenantId,
                    CapaId = capaId,
                    request.EvidenceType,
                    request.Title,
                    request.ReferenceUri,
                    request.UploadedBy
                },
                cancellationToken: cancellationToken));
    }

    public async Task<(bool Completed, string? Error)> CompleteAsync(
        Guid capaId,
        CompleteCapaRequest request,
        CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;

        const string sql = """
        UPDATE capa_actions c
        SET status = 'Completed',
            completion_notes = @CompletionNotes,
            completed_at = @Now,
            actual_cost = @ActualCost,
            updated_at = @Now
        WHERE c.tenant_id = @TenantId
          AND c.id = @CapaId
          AND c.status IN ('Open', 'InProgress', 'Reopened')
          AND c.owner_id = @ActorId
          AND EXISTS (
              SELECT 1
              FROM capa_evidence e
              WHERE e.tenant_id = c.tenant_id
                AND e.capa_id = c.id
          );
        """;

        await using var connection = CreateConnection();
        var affected = await connection.ExecuteAsync(
            new CommandDefinition(
                sql,
                new
                {
                    request.TenantId,
                    CapaId = capaId,
                    request.ActorId,
                    request.CompletionNotes,
                    request.ActualCost,
                    Now = now
                },
                cancellationToken: cancellationToken));

        return affected == 1
            ? (true, null)
            : (false, "CAPA was not found, is not assigned to this owner, is not completable, or has no evidence.");
    }

    public async Task<(bool Verified, string? Error)> VerifyAsync(
        Guid capaId,
        VerifyCapaRequest request,
        CancellationToken cancellationToken)
    {
        var passed = string.Equals(
            request.Result, "Passed", StringComparison.OrdinalIgnoreCase);
        var now = DateTimeOffset.UtcNow;

        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        const string lockSql = """
        SELECT id, status
        FROM capa_actions
        WHERE tenant_id = @TenantId AND id = @CapaId
        FOR UPDATE;
        """;

        var current = await connection.QuerySingleOrDefaultAsync<dynamic>(
            new CommandDefinition(
                lockSql,
                new { request.TenantId, CapaId = capaId },
                transaction,
                cancellationToken: cancellationToken));

        if (current is null || !string.Equals(
                (string)current.status, "Completed",
                StringComparison.OrdinalIgnoreCase))
        {
            await transaction.RollbackAsync(cancellationToken);
            return (false, "CAPA must be completed before verification.");
        }

        const string insertSql = """
        INSERT INTO capa_verifications (
            id, tenant_id, capa_id, verifier_id, result, notes, verified_at)
        VALUES (
            @Id, @TenantId, @CapaId, @VerifierId, @Result, @Notes, @Now);
        """;

        const string updateSql = """
        UPDATE capa_actions
        SET status = @Status,
            verification_status = @VerificationStatus,
            updated_at = @Now
        WHERE tenant_id = @TenantId AND id = @CapaId;
        """;

        await connection.ExecuteAsync(new CommandDefinition(
            insertSql,
            new
            {
                Id = Guid.NewGuid(),
                request.TenantId,
                CapaId = capaId,
                request.VerifierId,
                request.Result,
                request.Notes,
                Now = now
            },
            transaction,
            cancellationToken: cancellationToken));

        await connection.ExecuteAsync(new CommandDefinition(
            updateSql,
            new
            {
                request.TenantId,
                CapaId = capaId,
                Status = passed ? "Verified" : "Reopened",
                VerificationStatus = passed ? "Passed" : "Failed",
                Now = now
            },
            transaction,
            cancellationToken: cancellationToken));

        await transaction.CommitAsync(cancellationToken);
        return (true, null);
    }

    public async Task<(bool Reviewed, string? Error)> ReviewEffectivenessAsync(
        Guid capaId,
        ReviewCapaEffectivenessRequest request,
        CancellationToken cancellationToken)
    {
        var effective = string.Equals(
            request.Result, "Effective", StringComparison.OrdinalIgnoreCase)
            && !request.RecurrenceFound;
        var now = DateTimeOffset.UtcNow;

        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        const string currentSql = """
        SELECT incident_id, status
        FROM capa_actions
        WHERE tenant_id = @TenantId AND id = @CapaId
        FOR UPDATE;
        """;

        var current = await connection.QuerySingleOrDefaultAsync<dynamic>(
            new CommandDefinition(
                currentSql,
                new { request.TenantId, CapaId = capaId },
                transaction,
                cancellationToken: cancellationToken));

        if (current is null || !string.Equals(
                (string)current.status, "Verified",
                StringComparison.OrdinalIgnoreCase))
        {
            await transaction.RollbackAsync(cancellationToken);
            return (false, "CAPA must pass verification before effectiveness review.");
        }

        const string insertSql = """
        INSERT INTO capa_effectiveness_reviews (
            id, tenant_id, capa_id, reviewer_id, result,
            recurrence_found, comments, reviewed_at)
        VALUES (
            @Id, @TenantId, @CapaId, @ReviewerId, @Result,
            @RecurrenceFound, @Comments, @Now);
        """;

        const string updateSql = """
        UPDATE capa_actions
        SET status = @Status,
            effectiveness_status = @EffectivenessStatus,
            updated_at = @Now
        WHERE tenant_id = @TenantId AND id = @CapaId;
        """;

        await connection.ExecuteAsync(new CommandDefinition(
            insertSql,
            new
            {
                Id = Guid.NewGuid(),
                request.TenantId,
                CapaId = capaId,
                request.ReviewerId,
                request.Result,
                request.RecurrenceFound,
                request.Comments,
                Now = now
            },
            transaction,
            cancellationToken: cancellationToken));

        await connection.ExecuteAsync(new CommandDefinition(
            updateSql,
            new
            {
                request.TenantId,
                CapaId = capaId,
                Status = effective ? "Closed" : "Reopened",
                EffectivenessStatus = effective ? "Effective" : "Ineffective",
                Now = now
            },
            transaction,
            cancellationToken: cancellationToken));

        if (effective)
        {
            const string advanceIncidentSql = """
            UPDATE incidents
            SET status = 'Verification',
                workflow_state = 'Verification',
                updated_at = @Now
            WHERE tenant_id = @TenantId
              AND id = @IncidentId
              AND NOT EXISTS (
                  SELECT 1
                  FROM capa_actions c
                  WHERE c.tenant_id = @TenantId
                    AND c.incident_id = @IncidentId
                    AND c.status <> 'Closed'
              );

            INSERT INTO incident_timeline (
                id, tenant_id, incident_id, event_type,
                description, performed_by, occurred_at)
            VALUES (
                @TimelineId, @TenantId, @IncidentId,
                'CapaEffectivenessConfirmed',
                'CAPA effectiveness confirmed. Incident routed to Verification.',
                @ReviewerId, @Now);
            """;

            await connection.ExecuteAsync(new CommandDefinition(
                advanceIncidentSql,
                new
                {
                    request.TenantId,
                    IncidentId = (Guid)current.incident_id,
                    request.ReviewerId,
                    TimelineId = Guid.NewGuid(),
                    Now = now
                },
                transaction,
                cancellationToken: cancellationToken));
        }

        await transaction.CommitAsync(cancellationToken);
        return (true, null);
    }

    public async Task<bool> ReopenAsync(
        Guid capaId,
        ReopenCapaRequest request,
        CancellationToken cancellationToken)
    {
        const string sql = """
        UPDATE capa_actions
        SET status = 'Reopened',
            verification_status = 'Pending',
            effectiveness_status = 'Pending',
            completion_notes = CONCAT(
                COALESCE(completion_notes, ''),
                E'\nReopened: ',
                @Reason),
            updated_at = NOW()
        WHERE tenant_id = @TenantId AND id = @CapaId;
        """;

        await using var connection = CreateConnection();
        return await connection.ExecuteAsync(
            new CommandDefinition(
                sql,
                new
                {
                    request.TenantId,
                    CapaId = capaId,
                    request.Reason
                },
                cancellationToken: cancellationToken)) == 1;
    }
}
