using Atlas.IncidentApi.Security;

namespace Atlas.IncidentApi.Tests;

public sealed class SecurityMiddlewareTests
{
    [Fact]
    public async Task Correlation_id_is_added_to_response()
    {
        var context = new DefaultHttpContext();
        var middleware = new CorrelationIdMiddleware(_ => Task.CompletedTask);

        await middleware.InvokeAsync(context);

        Assert.False(string.IsNullOrWhiteSpace(context.TraceIdentifier));
        Assert.True(context.Response.Headers.ContainsKey(
            CorrelationIdMiddleware.HeaderName));
    }

    [Fact]
    public async Task Supplied_correlation_id_is_preserved()
    {
        var context = new DefaultHttpContext();
        context.Request.Headers[CorrelationIdMiddleware.HeaderName] =
            "test-correlation-123";

        var middleware = new CorrelationIdMiddleware(_ => Task.CompletedTask);
        await middleware.InvokeAsync(context);

        Assert.Equal("test-correlation-123", context.TraceIdentifier);
    }
}
