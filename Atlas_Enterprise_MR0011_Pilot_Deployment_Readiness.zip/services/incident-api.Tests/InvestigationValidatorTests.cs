using Atlas.IncidentApi.Features.Investigations;

namespace Atlas.IncidentApi.Tests;

public sealed class InvestigationValidatorTests
{
    [Fact]
    public void Complete_analysis_has_no_errors()
    {
        var request = new UpsertInvestigationRequest(
            Guid.NewGuid(),
            Guid.NewGuid(),
            "Forklift contacted a rack beam while reversing.",
            "Aisle geometry and line-of-sight were reviewed.",
            "Limited clearance during the turn.",
            "Environment",
            "Aisle width and walking-path placement constrained the maneuver.",
            "Long pallet and adjacent stored material.",
            "Reconfigure aisle controls and verify operator refresher training.");

        Assert.Empty(InvestigationValidator.Validate(request));
    }

    [Fact]
    public void Missing_root_cause_and_recommendations_are_rejected()
    {
        var request = new UpsertInvestigationRequest(
            Guid.Empty, Guid.Empty, "", "", "", "", "", "", "");

        var errors = InvestigationValidator.Validate(request);

        Assert.Contains("tenantId", errors.Keys);
        Assert.Contains("investigatorId", errors.Keys);
        Assert.Contains("rootCauseCategory", errors.Keys);
        Assert.Contains("rootCauseDetail", errors.Keys);
        Assert.Contains("recommendations", errors.Keys);
    }
}
