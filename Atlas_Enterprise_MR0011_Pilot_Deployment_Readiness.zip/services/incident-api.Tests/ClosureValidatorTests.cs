using Atlas.IncidentApi.Features.Closure;

namespace Atlas.IncidentApi.Tests;

public sealed class ClosureValidatorTests
{
    [Fact]
    public void Complete_closure_review_has_no_errors()
    {
        var request = new UpsertClosureReviewRequest(
            Guid.NewGuid(),
            Guid.NewGuid(),
            "Safety",
            true,
            true,
            true,
            true,
            true,
            true,
            true,
            false,
            0,
            0,
            "Low",
            "Aisle design must be considered when planning long-pallet movements.",
            "ApproveClosure",
            "Controls were implemented and remained effective.");

        Assert.Empty(ClosureValidator.Validate(request));
        Assert.Null(ClosureValidator.ClosureGateError(request));
    }

    [Fact]
    public void Missing_controls_block_closure()
    {
        var request = new UpsertClosureReviewRequest(
            Guid.NewGuid(),
            Guid.NewGuid(),
            "Safety",
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            null,
            0,
            0,
            "High",
            "Lessons documented.",
            "ApproveClosure",
            "Attempting closure.");

        Assert.NotNull(ClosureValidator.ClosureGateError(request));
    }

    [Fact]
    public void Critical_residual_risk_blocks_closure()
    {
        var request = new UpsertClosureReviewRequest(
            Guid.NewGuid(),
            Guid.NewGuid(),
            "Executive",
            true,
            true,
            true,
            true,
            true,
            true,
            true,
            true,
            2,
            4,
            "Critical",
            "Additional controls are still necessary.",
            "ApproveClosure",
            "Closure requested.");

        Assert.Equal(
            "A case with Critical residual risk cannot be closed.",
            ClosureValidator.ClosureGateError(request));
    }
}
