using Atlas.IncidentApi.Features.Incidents.Create;

namespace Atlas.IncidentApi.Tests;

public sealed class CreateIncidentValidatorTests
{
    [Fact]
    public void Valid_request_has_no_errors()
    {
        var request = new CreateIncidentRequest(
            Guid.NewGuid(),
            "Forklift contacted rack",
            "Forklift contacted a rack beam while reversing.",
            "Property Damage",
            "High",
            DateTimeOffset.UtcNow.AddMinutes(-10),
            Guid.NewGuid(),
            "Lindon",
            "Warehouse");

        var errors = CreateIncidentValidator.Validate(request);

        Assert.Empty(errors);
    }

    [Fact]
    public void Missing_required_fields_returns_errors()
    {
        var request = new CreateIncidentRequest(
            Guid.Empty,
            "",
            "",
            "",
            "Unknown",
            DateTimeOffset.UtcNow.AddHours(1),
            Guid.Empty,
            "",
            "");

        var errors = CreateIncidentValidator.Validate(request);

        Assert.Contains("tenantId", errors.Keys);
        Assert.Contains("title", errors.Keys);
        Assert.Contains("description", errors.Keys);
        Assert.Contains("severity", errors.Keys);
        Assert.Contains("occurredAt", errors.Keys);
    }
}
