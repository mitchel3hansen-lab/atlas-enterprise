using Atlas.IncidentApi.Features.Incidents.SafetyReview;

namespace Atlas.IncidentApi.Tests;

public sealed class SafetyReviewValidatorTests
{
    [Fact]
    public void Valid_safety_review_has_no_errors()
    {
        var request = new SafetyReviewRequest(
            Guid.NewGuid(),
            Guid.NewGuid(),
            "Safety",
            "High",
            true,
            false,
            true,
            Guid.NewGuid(),
            DateTimeOffset.UtcNow.AddDays(5),
            "Immediate controls reviewed and investigation assigned.");

        Assert.Empty(SafetyReviewValidator.Validate(request));
    }

    [Fact]
    public void Missing_controls_and_investigator_are_rejected()
    {
        var request = new SafetyReviewRequest(
            Guid.Empty,
            Guid.Empty,
            "Employee",
            "Unknown",
            false,
            false,
            false,
            Guid.Empty,
            DateTimeOffset.UtcNow.AddHours(-1),
            "");

        var errors = SafetyReviewValidator.Validate(request);

        Assert.Contains("tenantId", errors.Keys);
        Assert.Contains("reviewerRole", errors.Keys);
        Assert.Contains("confirmedSeverity", errors.Keys);
        Assert.Contains("immediateControlsReviewed", errors.Keys);
        Assert.Contains("investigatorId", errors.Keys);
        Assert.Contains("investigationDueAt", errors.Keys);
        Assert.Contains("comment", errors.Keys);
    }
}
