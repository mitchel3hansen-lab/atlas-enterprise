using Atlas.IncidentApi.Domain;

namespace Atlas.IncidentApi.Tests;

public sealed class DashboardContractTests
{
    [Fact]
    public void Closure_rate_can_be_represented_as_percentage()
    {
        var summary = new DashboardSummary(
            10, 4, 6, 1, 2, 3, 1,
            60m, 80m, 12.5m,
            [], [], []);

        Assert.Equal(60m, summary.ClosureRate);
        Assert.Equal(80m, summary.CapaEffectivenessRate);
    }
}
