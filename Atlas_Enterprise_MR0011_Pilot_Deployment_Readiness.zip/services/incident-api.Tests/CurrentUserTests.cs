using System.Security.Claims;
using Atlas.IncidentApi.Security;

namespace Atlas.IncidentApi.Tests;

public sealed class CurrentUserTests
{
    [Fact]
    public void Claims_are_mapped_to_current_user()
    {
        var userId = Guid.NewGuid();
        var tenantId = Guid.NewGuid();

        var principal = new ClaimsPrincipal(
            new ClaimsIdentity(
                new[]
                {
                    new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                    new Claim(AtlasClaimTypes.TenantId, tenantId.ToString()),
                    new Claim(ClaimTypes.Role, AtlasRoles.Safety),
                    new Claim(AtlasClaimTypes.Department, "Safety")
                },
                "test"));

        var current = CurrentUser.From(principal);

        Assert.Equal(userId, current.UserId);
        Assert.Equal(tenantId, current.TenantId);
        Assert.Equal(AtlasRoles.Safety, current.Role);
        Assert.Equal("Safety", current.Department);
    }

    [Fact]
    public void Missing_tenant_claim_is_rejected()
    {
        var principal = new ClaimsPrincipal(
            new ClaimsIdentity(
                new[]
                {
                    new Claim(ClaimTypes.NameIdentifier, Guid.NewGuid().ToString()),
                    new Claim(ClaimTypes.Role, AtlasRoles.Employee)
                },
                "test"));

        Assert.Throws<UnauthorizedAccessException>(
            () => CurrentUser.From(principal));
    }
}
