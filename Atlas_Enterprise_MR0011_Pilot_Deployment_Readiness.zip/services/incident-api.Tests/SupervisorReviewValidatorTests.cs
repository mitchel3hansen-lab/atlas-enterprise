using Atlas.IncidentApi.Features.Incidents.Review;

namespace Atlas.IncidentApi.Tests;

public sealed class SupervisorReviewValidatorTests
{
    [Fact]
    public void Valid_approval_has_no_errors()
    {
        var request = new ReviewIncidentRequest(
            Guid.NewGuid(),
            Guid.NewGuid(),
            "Supervisor",
            "Warehouse",
            "Approve",
            "Initial facts are complete and Safety should review.");

        Assert.Empty(ReviewIncidentValidator.Validate(request));
    }

    [Fact]
    public void Non_supervisor_and_missing_comment_are_rejected()
    {
        var request = new ReviewIncidentRequest(
            Guid.NewGuid(),
            Guid.NewGuid(),
            "Employee",
            "Warehouse",
            "Approve",
            "");

        var errors = ReviewIncidentValidator.Validate(request);

        Assert.Contains("reviewerRole", errors.Keys);
        Assert.Contains("comment", errors.Keys);
    }

    [Theory]
    [InlineData("Approve")]
    [InlineData("ReturnForCorrection")]
    public void Supported_decisions_are_valid(string decision)
    {
        var request = new ReviewIncidentRequest(
            Guid.NewGuid(),
            Guid.NewGuid(),
            "Supervisor",
            "Warehouse",
            decision,
            "Documented review decision.");

        Assert.DoesNotContain(
            "decision",
            ReviewIncidentValidator.Validate(request).Keys);
    }
}
