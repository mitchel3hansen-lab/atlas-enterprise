using Atlas.IncidentApi.Features.Capas;

namespace Atlas.IncidentApi.Tests;

public sealed class CapaValidatorTests
{
    [Fact]
    public void Valid_capa_has_no_errors()
    {
        var request = new CreateCapaRequest(
            Guid.NewGuid(),
            "Corrective",
            "Reconfigure warehouse aisle",
            "Increase maneuvering clearance and remove the walking-path conflict.",
            Guid.NewGuid(),
            "Warehouse",
            "High",
            DateTimeOffset.UtcNow.AddDays(30),
            4500m);

        Assert.Empty(CapaValidator.Validate(request));
    }

    [Fact]
    public void Missing_owner_and_past_due_date_are_rejected()
    {
        var request = new CreateCapaRequest(
            Guid.Empty,
            "Other",
            "",
            "",
            Guid.Empty,
            "",
            "Urgent",
            DateTimeOffset.UtcNow.AddDays(-1),
            null);

        var errors = CapaValidator.Validate(request);

        Assert.Contains("tenantId", errors.Keys);
        Assert.Contains("actionType", errors.Keys);
        Assert.Contains("ownerId", errors.Keys);
        Assert.Contains("priority", errors.Keys);
        Assert.Contains("targetDate", errors.Keys);
    }
}
