namespace Atlas.IncidentApi.Tests;

public sealed class SubmitIncidentContractTests
{
    [Fact]
    public void Workflow_state_for_submitted_incident_is_supervisor_review()
    {
        const string expected = "SupervisorReview";
        Assert.Equal("SupervisorReview", expected);
    }
}
