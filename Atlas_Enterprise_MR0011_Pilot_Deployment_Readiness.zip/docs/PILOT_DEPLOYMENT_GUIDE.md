# Atlas Pilot Deployment Guide

## Purpose

This guide supports a controlled Atlas Incident pilot. It is not a production-cloud deployment guide.

## Prerequisites

- Docker Desktop or Docker Engine with Compose
- At least 4 CPU cores
- At least 8 GB available RAM
- At least 20 GB available disk
- A secure location for `.env`
- A tested backup directory

## Initial setup

1. Copy `.env.example` to `.env`.
2. Replace all default passwords and signing keys.
3. Start Atlas:

```bash
docker compose up --build -d
```

4. Run health checks:

```bash
./tools/pilot-health.sh
./tools/pilot-acceptance.sh
```

## Backup

```bash
./tools/backup.sh
```

Store backup files outside the application host.

## Restore drill

```bash
./tools/restore.sh backups/<backup-file>.dump
./tools/pilot-health.sh
```

A restore drill should be completed before pilot go-live.

## Pilot limitations

- Development token issuance is not production authentication.
- TLS termination is not included.
- CORS remains suitable for local development.
- Email and external notification providers are not configured.
- Centralized log aggregation is not configured.
- Database high availability is not configured.

## Go-live gate

Do not begin the pilot until:

- all health checks pass
- acceptance checks pass
- a backup is created
- a restore is successfully tested
- user roles are reviewed
- test data is clearly labeled
- a pilot owner and rollback decision-maker are assigned
