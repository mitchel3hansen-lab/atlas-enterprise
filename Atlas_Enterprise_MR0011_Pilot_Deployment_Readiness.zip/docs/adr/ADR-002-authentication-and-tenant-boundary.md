# ADR-002: Authentication and Tenant Boundary

## Status

Accepted

## Decision

Atlas APIs use signed JWT bearer tokens and derive the current user, tenant, department, and role from validated claims.

## Rationale

Tenant and authorization context must not be trusted when supplied by application forms or query parameters.

## Consequences

- Every protected endpoint requires authentication.
- Tenant scope is enforced on the server.
- Role policies are centrally defined.
- Development tokens are temporary and cannot be used in production.
- Production deployments require an OpenID Connect identity provider.
