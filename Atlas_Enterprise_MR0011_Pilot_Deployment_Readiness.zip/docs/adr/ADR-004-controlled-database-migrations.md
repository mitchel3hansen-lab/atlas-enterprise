# ADR-004: Controlled Database Migrations

## Status

Accepted

## Decision

Atlas uses a dedicated migration container that applies ordered SQL migrations, records checksums, and rejects changes to previously applied migration files.

## Rationale

Mounting every migration into PostgreSQL initialization only works for a new database and does not safely support upgrades.

## Consequences

- Migrations execute before the API starts.
- Previously applied files must never be edited.
- New schema changes require a new numbered migration.
- Migration failure prevents application startup.
