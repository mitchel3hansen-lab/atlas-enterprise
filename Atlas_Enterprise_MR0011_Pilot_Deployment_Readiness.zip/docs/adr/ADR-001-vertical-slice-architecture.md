# ADR-001: Vertical Slice Architecture

## Status

Accepted

## Decision

Atlas features will be organized by user capability rather than technical layer.

## Rationale

This keeps API contracts, validation, business rules, persistence, and tests close to the operational feature they support.

## Consequences

- Features can evolve independently.
- Shared abstractions must earn their existence.
- Cross-cutting security, tenancy, audit, and observability remain centrally governed.
