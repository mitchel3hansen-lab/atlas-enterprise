# ADR-003: Audit and Observability Boundary

## Status

Accepted

## Decision

Atlas records authenticated API activity and authorization failures in an append-only PostgreSQL audit table. Every request receives a correlation identifier.

## Rationale

Operational and compliance workflows require traceability without exposing sensitive exception details to clients.

## Consequences

- Audit writes add a small amount of request overhead.
- Audit write failures are logged but do not block the primary operation.
- Production environments should forward structured logs and audit events to centralized, access-controlled storage.
