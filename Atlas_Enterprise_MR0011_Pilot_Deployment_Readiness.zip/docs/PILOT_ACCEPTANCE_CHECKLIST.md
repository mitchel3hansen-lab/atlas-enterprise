# Atlas Pilot Acceptance Checklist

## Environment

- [ ] `.env` created from the template
- [ ] Database password changed
- [ ] JWT signing key changed
- [ ] Pilot host has adequate CPU, memory, and disk
- [ ] System clock and time zone verified

## Deployment

- [ ] Containers build successfully
- [ ] Migrator completes successfully
- [ ] API liveness passes
- [ ] API readiness passes
- [ ] Web application loads
- [ ] Demonstration data is present
- [ ] Dashboard loads for authorized roles

## Security

- [ ] Development identity limitations acknowledged
- [ ] Role access reviewed
- [ ] Tenant boundary tested
- [ ] Audit endpoint restricted
- [ ] Secrets excluded from Git
- [ ] Host access limited to pilot administrators

## Operations

- [ ] Backup completed
- [ ] Restore drill completed
- [ ] Rollback procedure reviewed
- [ ] Incident support contact assigned
- [ ] Pilot issue log created
- [ ] User feedback process defined

## Workflow

- [ ] Employee can report an incident
- [ ] Supervisor can review
- [ ] Safety can assign an investigator
- [ ] Investigation can be completed
- [ ] CAPA can be created and verified
- [ ] Effectiveness can be reviewed
- [ ] Final closure gates work
- [ ] Dashboard metrics update
