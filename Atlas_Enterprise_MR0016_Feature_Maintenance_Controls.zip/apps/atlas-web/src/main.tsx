import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const apiUrl = import.meta.env.VITE_INCIDENT_API_URL ?? "http://localhost:8085";
const tenantId = "11111111-1111-1111-1111-111111111111";

const personas = {
  Employee: {
    userId: "22222222-2222-2222-2222-222222222222",
    department: "Warehouse"
  },
  Supervisor: {
    userId: "33333333-3333-3333-3333-333333333333",
    department: "Warehouse"
  },
  Safety: {
    userId: "44444444-4444-4444-4444-444444444444",
    department: "Safety"
  },
  Executive: {
    userId: "77777777-7777-7777-7777-777777777777",
    department: "Executive"
  },
  Administrator: {
    userId: "88888888-8888-8888-8888-888888888888",
    department: "Administration"
  }
} as const;

type Role = keyof typeof personas;

type Incident = {
  id: string;
  incidentNumber: string;
  title: string;
  severity: string;
  status: string;
  workflowState: string;
  site: string;
  department: string;
};

type WorkItem = {
  id: string;
  workType: string;
  entityType: string;
  entityId: string;
  title: string;
  description?: string | null;
  priority: string;
  status: string;
  dueAt?: string | null;
  escalationLevel: number;
};

type UserNotification = {
  id: string;
  notificationType: string;
  title: string;
  body: string;
  severity: string;
  status: string;
  createdAt: string;
};

type WorkQueue = {
  openItems: number;
  dueSoon: number;
  overdue: number;
  unreadNotifications: number;
  items: WorkItem[];
  notifications: UserNotification[];
};

type Dashboard = {
  openIncidents: number;
  criticalIncidents: number;
  capasOpen: number;
  capasOverdue: number;
  closureRate: number;
  capaEffectivenessRate: number;
  averageClosureDays: number;
  bySeverity: Array<{ name: string; count: number }>;
  byWorkflow: Array<{ name: string; count: number }>;
  byDepartment: Array<{
    department: string;
    totalIncidents: number;
    openIncidents: number;
    openCapas: number;
    overdueCapas: number;
  }>;
};

function App() {
  const [role, setRole] = useState<Role>("Safety");
  const [token, setToken] = useState("");
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [workQueue, setWorkQueue] = useState<WorkQueue | null>(null);
  const [view, setView] = useState<"dashboard" | "operations" | "admin">("dashboard");
  const [adminData, setAdminData] = useState<any>(null);
  const [systemStatus, setSystemStatus] = useState<any>(null);
  const [message, setMessage] = useState("");

  async function login(nextRole: Role) {
    const persona = personas[nextRole];
    const response = await fetch(`${apiUrl}/api/auth/dev-token`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: persona.userId,
        tenantId,
        role: nextRole,
        department: persona.department
      })
    });
    if (!response.ok) {
      const correlationId = response.headers.get("X-Correlation-ID");
      throw new Error(`Unable to create development token.${correlationId ? ` Reference: ${correlationId}` : ""}`);
    }
    const result = await response.json();
    setToken(result.accessToken);
    setRole(nextRole);
    setMessage(`Signed in as ${nextRole}.`);
    return result.accessToken as string;
  }

  async function apiFetch(path: string, init?: RequestInit, accessToken = token) {
    return fetch(`${apiUrl}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
        ...(init?.headers ?? {})
      }
    });
  }

  async function load(accessToken = token, currentRole = role) {
    if (!accessToken) return;
    const [incidentResponse, workQueueResponse, systemResponse] = await Promise.all([
      apiFetch("/api/incidents", undefined, accessToken),
      apiFetch("/api/work-queue", undefined, accessToken),
      apiFetch("/api/system/status", undefined, accessToken)
    ]);
    setSystemStatus(systemResponse.ok ? await systemResponse.json() : null);
    setWorkQueue(workQueueResponse.ok ? await workQueueResponse.json() : null);
    setIncidents(incidentResponse.ok ? await incidentResponse.json() : []);

    if (currentRole !== "Employee") {
      const dashboardResponse = await apiFetch(
        "/api/dashboard/summary", undefined, accessToken);
      setDashboard(dashboardResponse.ok ? await dashboardResponse.json() : null);

      if (currentRole === "Administrator") {
        const adminResponse = await apiFetch(
          "/api/admin/console", undefined, accessToken);
        setAdminData(adminResponse.ok ? await adminResponse.json() : null);
      } else {
        setAdminData(null);
      }
    } else {
      setDashboard(null);
      setView("operations");
    }
  }

  useEffect(() => {
    login("Safety")
      .then(accessToken => load(accessToken, "Safety"))
      .catch(error => setMessage(error.message));
  }, []);

  async function changeRole(nextRole: Role) {
    try {
      const accessToken = await login(nextRole);
      await load(accessToken, nextRole);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Login failed.");
    }
  }

  async function createIncident(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const response = await apiFetch("/api/incidents", {
      method: "POST",
      body: JSON.stringify({
        tenantId: "00000000-0000-0000-0000-000000000000",
        reporterId: "00000000-0000-0000-0000-000000000000",
        title: String(form.get("title") ?? ""),
        description: String(form.get("description") ?? ""),
        incidentType: "Property Damage",
        severity: "High",
        occurredAt: new Date(String(form.get("occurredAt"))).toISOString(),
        site: "Lindon",
        department: personas[role].department
      })
    });

    const result = await response.json();
    if (!response.ok) {
      const correlationId = response.headers.get("X-Correlation-ID");
      setMessage(`${result.message ?? result.title ?? "Unable to create incident."}${correlationId ? ` Reference: ${correlationId}` : ""}`);
      return;
    }

    setMessage(`${result.incidentNumber} created using authenticated identity.`);
    event.currentTarget.reset();
    await load();
  }

  const maxSeverity = useMemo(
    () => Math.max(1, ...(dashboard?.bySeverity.map(x => x.count) ?? [1])),
    [dashboard]
  );

  return (
    <main>
      <header className="app-header">
        <div>
          <span className="eyebrow">ATLAS ENTERPRISE</span>
          <h1>Secure Operations</h1>
          <p>Tenant-isolated workflows with role-based access.</p>
        </div>
        <div className="session">
          <label>
            Active role
            <select value={role} onChange={event => changeRole(event.target.value as Role)}>
              {Object.keys(personas).map(name => <option key={name}>{name}</option>)}
            </select>
          </label>
          <span className="badge">Authenticated</span>
        </div>
      </header>


      {systemStatus?.pilotMode && (
        <div className="system-banner pilot">
          <strong>Pilot Environment</strong>
          <span>{systemStatus?.pilotBannerMessage || "Atlas is operating in controlled pilot mode."}</span>
        </div>
      )}

      {systemStatus?.maintenanceMode && (
        <div className="system-banner maintenance">
          <strong>Maintenance Mode</strong>
          <span>{systemStatus?.maintenanceMessage || "Write operations may be restricted."}</span>
        </div>
      )}

      {systemStatus?.emergencyWriteLock && (
        <div className="system-banner locked">
          <strong>Emergency Read-Only Mode</strong>
          <span>Non-administrator write operations are temporarily locked.</span>
        </div>
      )}

      {role !== "Employee" && (
        <nav>
          <button className={view === "dashboard" ? "" : "secondary"}
            onClick={() => setView("dashboard")}>Dashboard</button>
          <button className={view === "operations" ? "" : "secondary"}
            onClick={() => setView("operations")}>Operations</button>
          {role === "Administrator" && (
            <button className={view === "admin" ? "" : "secondary"}
              onClick={() => setView("admin")}>Administration</button>
          )}
        </nav>
      )}

      {view === "dashboard" && dashboard && (
        <>
          <section className="metrics">
            <Metric label="Open incidents" value={dashboard.openIncidents} />
            <Metric label="Critical incidents" value={dashboard.criticalIncidents} />
            <Metric label="Open CAPAs" value={dashboard.capasOpen} />
            <Metric label="Overdue CAPAs" value={dashboard.capasOverdue} />
            <Metric label="Closure rate" value={`${dashboard.closureRate}%`} />
            <Metric label="CAPA effectiveness" value={`${dashboard.capaEffectivenessRate}%`} />
          </section>


          <section className="panel">
            <h2>Live System Controls</h2>
            <div className="control-grid">
              <div>
                <span>Pilot mode</span>
                <strong>{systemStatus?.pilotMode ? "Enabled" : "Disabled"}</strong>
              </div>
              <div>
                <span>Maintenance mode</span>
                <strong>{systemStatus?.maintenanceMode ? "Enabled" : "Disabled"}</strong>
              </div>
              <div>
                <span>Emergency write lock</span>
                <strong>{systemStatus?.emergencyWriteLock ? "Enabled" : "Disabled"}</strong>
              </div>
              <div>
                <span>Read-only access</span>
                <strong>{systemStatus?.allowReadOnlyAccess ? "Allowed" : "Blocked"}</strong>
              </div>
            </div>
          </section>

          <section className="dashboard-grid">
            <div className="panel">
              <h2>Severity distribution</h2>
              {(dashboard.bySeverity ?? []).map(bucket => (
                <div className="bar-row" key={bucket.name}>
                  <span>{bucket.name}</span>
                  <div className="bar-track">
                    <div className="bar-fill"
                      style={{ width: `${100 * bucket.count / maxSeverity}%` }} />
                  </div>
                  <strong>{bucket.count}</strong>
                </div>
              ))}
            </div>

            <div className="panel">
              <h2>Workflow workload</h2>
              <div className="workflow-list">
                {(dashboard.byWorkflow ?? []).map(bucket => (
                  <div key={bucket.name}>
                    <span>{bucket.name}</span>
                    <strong>{bucket.count}</strong>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </>
      )}

      {view === "operations" && (
        <>
          <section className="panel">
            <h2>Report an Incident</h2>
            <p>The API ignores submitted tenant and reporter IDs and uses the signed-in claims.</p>
            <form onSubmit={createIncident}>
              <label>Incident title<input name="title" required /></label>
              <label>Description<textarea name="description" required rows={4} /></label>
              <label>Occurred at<input name="occurredAt" type="datetime-local" required /></label>
              <button>Save Incident Draft</button>
            </form>
          </section>

          <section className="panel">
            <div className="section-heading">
              <div>
                <h2>Authorized Incident Queue</h2>
                <p>Employee access is restricted to the authenticated department.</p>
              </div>
              <span className="badge">{incidents.length} visible</span>
            </div>
            <div className="incident-list">
              {incidents.map(incident => (
                <article key={incident.id}>
                  <div>
                    <span className="number">{incident.incidentNumber}</span>
                    <h3>{incident.title}</h3>
                    <p>{incident.site} · {incident.department}</p>
                  </div>
                  <div className="badges">
                    <span className={`badge ${incident.severity.toLowerCase()}`}>
                      {incident.severity}
                    </span>
                    <span className="badge">{incident.workflowState}</span>
                  </div>
                </article>
              ))}
            </div>
          </section>
        </>
      )}


      <section className="panel">
        <div className="section-heading">
          <div>
            <h2>My Work Queue</h2>
            <p>Assignments, deadlines, and notifications for the signed-in user.</p>
          </div>
          <div className="badges">
            <span className="badge">{workQueue?.openItems ?? 0} open</span>
            <span className="badge high">{workQueue?.overdue ?? 0} overdue</span>
            <span className="badge">{workQueue?.unreadNotifications ?? 0} unread</span>
          </div>
        </div>

        <div className="work-grid">
          <div>
            <h3>Assignments</h3>
            <div className="workflow-list">
              {(workQueue?.items ?? []).map(item => (
                <div key={item.id} className="work-row">
                  <div>
                    <strong>{item.title}</strong>
                    <p>{item.workType} · {item.priority}</p>
                  </div>
                  <div className="work-meta">
                    <span className={`badge ${item.dueAt && new Date(item.dueAt) < new Date() ? "high" : ""}`}>
                      {item.dueAt
                        ? new Date(item.dueAt).toLocaleDateString()
                        : "No due date"}
                    </span>
                    {item.escalationLevel > 0 && (
                      <span className="badge high">Escalation {item.escalationLevel}</span>
                    )}
                  </div>
                </div>
              ))}
              {(workQueue?.items.length ?? 0) === 0 && <p>No open assignments.</p>}
            </div>
          </div>

          <div>
            <h3>Notifications</h3>
            <div className="workflow-list">
              {(workQueue?.notifications ?? []).slice(0, 8).map(note => (
                <div key={note.id} className="work-row">
                  <div>
                    <strong>{note.title}</strong>
                    <p>{note.body}</p>
                  </div>
                  <span className={`badge ${note.severity.toLowerCase()}`}>
                    {note.status}
                  </span>
                </div>
              ))}
              {(workQueue?.notifications.length ?? 0) === 0 && <p>No notifications.</p>}
            </div>
          </div>
        </div>
      </section>


      {view === "admin" && role === "Administrator" && (
        <>
          <section className="metrics">
            <Metric label="Sites" value={adminData?.sites?.length ?? 0} />
            <Metric label="Departments" value={adminData?.departments?.length ?? 0} />
            <Metric label="Users" value={adminData?.users?.length ?? 0} />
            <Metric label="Feature flags" value={adminData?.featureFlags?.length ?? 0} />
            <Metric label="Providers" value={adminData?.providers?.length ?? 0} />
            <Metric label="Pilot mode" value={adminData?.settings?.pilotMode ? "On" : "Off"} />
          </section>

          <section className="dashboard-grid">
            <div className="panel">
              <h2>Tenant Settings</h2>
              <dl className="admin-list">
                <div><dt>Name</dt><dd>{adminData?.settings?.tenantName}</dd></div>
                <div><dt>Time zone</dt><dd>{adminData?.settings?.defaultTimeZone}</dd></div>
                <div><dt>Incident prefix</dt><dd>{adminData?.settings?.incidentPrefix}</dd></div>
                <div><dt>CAPA prefix</dt><dd>{adminData?.settings?.capaPrefix}</dd></div>
                <div><dt>Maintenance</dt><dd>{adminData?.settings?.maintenanceMode ? "Enabled" : "Disabled"}</dd></div>
              </dl>
            </div>

            <div className="panel">
              <h2>Sites & Departments</h2>
              <div className="workflow-list">
                {(adminData?.sites ?? []).map((site: any) => (
                  <div key={site.id}>
                    <span>{site.name}</span>
                    <strong>{site.code}</strong>
                  </div>
                ))}
                {(adminData?.departments ?? []).map((department: any) => (
                  <div key={department.id}>
                    <span>{department.name}</span>
                    <strong>{department.code}</strong>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="panel">
            <h2>Feature Flags & Providers</h2>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>Type</th><th>Name</th><th>Status</th><th>Description</th></tr>
                </thead>
                <tbody>
                  {(adminData?.featureFlags ?? []).map((flag: any) => (
                    <tr key={flag.id}>
                      <td>Feature</td>
                      <td>{flag.flagKey}</td>
                      <td>{flag.enabled ? "Enabled" : "Disabled"}</td>
                      <td>{flag.description}</td>
                    </tr>
                  ))}
                  {(adminData?.providers ?? []).map((provider: any) => (
                    <tr key={provider.id}>
                      <td>Provider</td>
                      <td>{provider.providerType}</td>
                      <td>{provider.enabled ? "Enabled" : "Disabled"}</td>
                      <td>{provider.secretReference || "No secret reference"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}

      {message && <output>{message}</output>}
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string | number }) {
  return (
    <article className="metric">
      <span>{label}</span>
      <strong>{value}</strong>
    </article>
  );
}

createRoot(document.getElementById("root")!).render(
  <React.StrictMode><App /></React.StrictMode>
);
