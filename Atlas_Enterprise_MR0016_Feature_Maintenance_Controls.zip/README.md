# Atlas Enterprise

Atlas is an operational intelligence platform with closed-loop incident management, secured work queues, notifications, tenant administration, and live system controls.

## Live controls

Administrators can control:

- Pilot mode and banner
- Maintenance mode
- Read-only access during maintenance
- Emergency write lock
- Incident-creation rollout
- Executive-dashboard rollout
- External-notification rollout

Controls are enforced by the API, not only by the user interface.

## Start

```bash
cp .env.example .env
docker compose up --build -d
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger
