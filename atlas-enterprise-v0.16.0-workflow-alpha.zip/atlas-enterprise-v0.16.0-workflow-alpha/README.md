# Atlas Enterprise v0.16.0 — Workflow Alpha

This repository combines the v0.13 platform baseline with the v0.14 Operational Health Engine, v0.15 Metadata Object Engine, and the v0.16 Workflow Orchestration vertical slice.

## Alpha target
Login → create incident → start workflow → submit → assign → investigate → CAPA → verify → close → review immutable timeline.

## Local start
From `infrastructure/docker` run `docker compose up --build` on a machine with Docker Desktop and the .NET SDK/container build available.

## Validation status
The archive structure, checksums, JSON parsing, and ZIP integrity were validated in the artifact environment. The environment did not contain the .NET SDK or Docker daemon. Frontend dependency installation also did not complete in the available environment. Backend compilation, frontend build, database integration tests, and container startup remain explicit CI/development-machine gates.
