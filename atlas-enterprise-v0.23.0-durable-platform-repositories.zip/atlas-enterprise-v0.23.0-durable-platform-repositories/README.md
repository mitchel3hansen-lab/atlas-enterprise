# Atlas Enterprise v0.23.0

Operational Intelligence Platform reference implementation.

## Current integrated capabilities
Identity and tenancy, metadata, workflow, rules, evidence, knowledge graph, timeline/audit, incident management, PostgreSQL incident persistence, transactional outbox, and durable PostgreSQL platform repositories.

## Start
```bash
cp .env.example .env
docker compose up --build
```

Apply SQL migrations in numeric order before exercising the API. See `docs/deployment/V023-DURABLE-REPOSITORIES-RUNBOOK.md`.
