BEGIN;
DO $$
BEGIN
  IF to_regclass('public.atlas_timeline_entries') IS NULL THEN RAISE EXCEPTION 'timeline table missing'; END IF;
  IF to_regclass('public.automation_rules') IS NULL THEN RAISE EXCEPTION 'rules table missing'; END IF;
  IF to_regclass('public.evidence_records') IS NULL THEN RAISE EXCEPTION 'evidence table missing'; END IF;
  IF to_regclass('public.graph_nodes') IS NULL THEN RAISE EXCEPTION 'graph table missing'; END IF;
  IF NOT EXISTS (SELECT 1 FROM graph_relationship_types WHERE code='related_to') THEN RAISE EXCEPTION 'related_to seed missing'; END IF;
END $$;
ROLLBACK;
