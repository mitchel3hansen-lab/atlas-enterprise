# Atlas Enterprise v0.23.0 — Durable Platform Repositories

This release replaces default in-memory storage for Timeline, Rules, Evidence, and Knowledge Graph with tenant-scoped PostgreSQL repositories.

## Highlights
- Durable timeline entries, redaction updates, pagination, and integrity-chain retrieval
- Durable automation rules and idempotent execution history
- Durable evidence metadata, immutable versions, and access logs
- Durable graph nodes, edges, relationship types, and graph events
- Scoped dependency injection aligned with `AtlasDbContext`
- Global `related_to` relationship seed and query indexes
- Deployment runbook, ADR, rollback, and SQL smoke test

## Validation limits
The package was statically inspected and ZIP-tested. The current environment does not include the .NET 8 SDK or a live PostgreSQL service, so compilation and database integration tests must run in CI or a developer workstation.
