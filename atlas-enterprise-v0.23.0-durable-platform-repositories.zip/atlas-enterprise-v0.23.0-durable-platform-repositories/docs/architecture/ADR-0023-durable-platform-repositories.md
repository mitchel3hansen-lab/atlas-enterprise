# ADR-0023: Durable PostgreSQL platform repositories

## Status
Accepted

## Decision
Timeline, Rules, Evidence, and Knowledge Graph repository interfaces are backed by PostgreSQL in the default runtime. The in-memory implementations remain available only for focused tests and local experimentation.

Repositories are scoped to the request because they share the scoped `AtlasDbContext`. Every query includes tenant or organization isolation. JSON payloads remain stored as `jsonb`, and rule execution idempotency continues to use the existing unique key.

## Consequences
- Platform state survives process restarts.
- API instances can scale horizontally against one database.
- Database availability is now required for these platform features.
- Cross-repository atomicity is not implied; orchestration that spans aggregates must use the transactional outbox and idempotent consumers.
