# v0.23 durable repositories deployment runbook

1. Back up PostgreSQL.
2. Apply migrations through `V023__durable_platform_repositories.sql`.
3. Confirm the global `related_to` relationship type exists.
4. Deploy the API and worker together.
5. Call `/health` and exercise incident creation, evidence upload, rule activation, graph node creation, and timeline retrieval.
6. Restart the API and confirm all records remain available.
7. Review logs for tenant-isolation failures, duplicate rule executions, and database constraint errors.

Rollback removes only v0.23 indexes and seed data. It does not delete user records written through the durable repositories.
