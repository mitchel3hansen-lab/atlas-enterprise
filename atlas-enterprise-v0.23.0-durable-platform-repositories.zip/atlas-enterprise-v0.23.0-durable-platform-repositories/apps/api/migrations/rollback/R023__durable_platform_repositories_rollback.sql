BEGIN;
DROP INDEX IF EXISTS ux_timeline_object_sequence;
DROP INDEX IF EXISTS ix_evidence_records_object_ci;
DROP INDEX IF EXISTS ix_graph_nodes_object_ci;
DROP INDEX IF EXISTS ix_rules_lookup_ci;
DELETE FROM graph_relationship_types WHERE id='00000000-0000-0000-0000-000000000001' AND tenant_id IS NULL;
COMMIT;
