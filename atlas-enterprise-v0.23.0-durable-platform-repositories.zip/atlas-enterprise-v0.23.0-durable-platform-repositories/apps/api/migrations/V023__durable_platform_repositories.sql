BEGIN;

-- The platform repository release uses the existing v17-v20 tables and adds
-- baseline relationship data plus indexes used by durable query paths.
INSERT INTO graph_relationship_types
    (id, tenant_id, code, name, inverse_code, is_directional, allowed_source_types, allowed_target_types, created_by)
VALUES
    ('00000000-0000-0000-0000-000000000001', NULL, 'related_to', 'Related to', NULL, false, '[]'::jsonb, '[]'::jsonb, '00000000-0000-0000-0000-000000000000')
ON CONFLICT DO NOTHING;

CREATE INDEX IF NOT EXISTS ix_rules_lookup_ci
    ON automation_rules (organization_id, lower(trigger_event), status, priority);
CREATE INDEX IF NOT EXISTS ix_graph_nodes_object_ci
    ON graph_nodes (tenant_id, lower(object_type), object_id);
CREATE INDEX IF NOT EXISTS ix_evidence_records_object_ci
    ON evidence_records (organization_id, lower(object_type), object_id, modified_at_utc DESC);
CREATE UNIQUE INDEX IF NOT EXISTS ux_timeline_object_sequence
    ON atlas_timeline_entries (tenant_id, object_type, object_id, sequence_no);

COMMIT;
