using System.Data.Common;
using System.Text.Json;
using Atlas.Api.Infrastructure;

namespace Atlas.Api.KnowledgeGraph;

public sealed class PostgresKnowledgeGraphRepository(AtlasDbContext dbContext) : PostgresRepositoryBase(dbContext), IKnowledgeGraphRepository
{
    public Task<GraphNode?> GetNodeAsync(Guid tenantId,Guid nodeId,CancellationToken ct)=>GetNodeCoreAsync(tenantId,"id=@value",nodeId,null,null,ct);
    public Task<GraphNode?> FindNodeAsync(Guid tenantId,string objectType,Guid objectId,CancellationToken ct)=>GetNodeCoreAsync(tenantId,"lower(object_type)=lower(@object_type) AND object_id=@object_id",null,objectType,objectId,ct);
    public async Task<GraphNode> CreateNodeAsync(GraphNode x,Guid actorId,CancellationToken ct)
    {
        var c=await OpenConnectionAsync(ct);await using var cmd=c.CreateCommand();cmd.CommandText="""
          INSERT INTO graph_nodes(id,tenant_id,organization_id,object_type,object_id,display_name,attributes_json,created_by,modified_by,version)
          VALUES(@id,@tenant_id,@organization_id,@object_type,@object_id,@display_name,CAST(@attributes_json AS jsonb),@actor_id,@actor_id,@version)
          ON CONFLICT(tenant_id,object_type,object_id) DO UPDATE SET display_name=EXCLUDED.display_name,attributes_json=EXCLUDED.attributes_json,modified_at=now(),modified_by=EXCLUDED.modified_by,version=graph_nodes.version+1
          RETURNING id,tenant_id,organization_id,object_type,object_id,display_name,attributes_json::text,version
        """;
        Add(cmd,"id",x.Id);Add(cmd,"tenant_id",x.TenantId);Add(cmd,"organization_id",x.OrganizationId);Add(cmd,"object_type",x.ObjectType);Add(cmd,"object_id",x.ObjectId);Add(cmd,"display_name",x.DisplayName);Add(cmd,"attributes_json",JsonSerializer.Serialize(x.Attributes));Add(cmd,"actor_id",actorId);Add(cmd,"version",x.Version);
        await using var r=await cmd.ExecuteReaderAsync(ct);await r.ReadAsync(ct);return MapNode(r);
    }
    public async Task<RelationshipType?> GetRelationshipTypeAsync(Guid tenantId,string code,CancellationToken ct)
    {
        var c=await OpenConnectionAsync(ct);await using var cmd=c.CreateCommand();cmd.CommandText="""
          SELECT id,code,name,inverse_code,is_directional,allowed_source_types::text,allowed_target_types::text
          FROM graph_relationship_types WHERE code=@code AND (tenant_id=@tenant_id OR tenant_id IS NULL)
          ORDER BY tenant_id NULLS LAST LIMIT 1
        """;Add(cmd,"code",code);Add(cmd,"tenant_id",tenantId);await using var r=await cmd.ExecuteReaderAsync(ct);return await r.ReadAsync(ct)?MapType(r):null;
    }
    public async Task<GraphEdge> CreateEdgeAsync(GraphEdge x,Guid actorId,string? correlationId,CancellationToken ct)
    {
        var c=await OpenConnectionAsync(ct);await using var tx=await c.BeginTransactionAsync(ct);await using var cmd=c.CreateCommand();cmd.Transaction=tx;cmd.CommandText="""
          INSERT INTO graph_edges(id,tenant_id,organization_id,source_node_id,target_node_id,relationship_type_id,confidence,rationale,evidence_ids,valid_from,valid_to,created_by,supersedes_edge_id)
          VALUES(@id,@tenant_id,@organization_id,@source,@target,@type,@confidence,@rationale,CAST(@evidence AS jsonb),@valid_from,@valid_to,@actor,@supersedes)
        """;BindEdge(cmd,x,actorId);await cmd.ExecuteNonQueryAsync(ct);
        await using var evt=c.CreateCommand();evt.Transaction=tx;evt.CommandText="""
          INSERT INTO graph_events(id,tenant_id,organization_id,aggregate_type,aggregate_id,event_type,payload_json,actor_id,correlation_id)
          VALUES(@id,@tenant_id,@organization_id,'GraphEdge',@aggregate_id,'GraphEdge.Created',CAST(@payload AS jsonb),@actor,@correlation)
        """;Add(evt,"id",Guid.NewGuid());Add(evt,"tenant_id",x.TenantId);Add(evt,"organization_id",x.OrganizationId);Add(evt,"aggregate_id",x.Id);Add(evt,"payload",JsonSerializer.Serialize(x));Add(evt,"actor",actorId);Add(evt,"correlation",correlationId);await evt.ExecuteNonQueryAsync(ct);await tx.CommitAsync(ct);return x;
    }
    public async Task<IReadOnlyList<GraphEdge>> GetAdjacentEdgesAsync(Guid tenantId,Guid nodeId,CancellationToken ct)
    {
        var c=await OpenConnectionAsync(ct);await using var cmd=c.CreateCommand();cmd.CommandText=EdgeSelect+" WHERE tenant_id=@tenant_id AND valid_to IS NULL AND (source_node_id=@node_id OR target_node_id=@node_id)";Add(cmd,"tenant_id",tenantId);Add(cmd,"node_id",nodeId);var list=new List<GraphEdge>();await using var r=await cmd.ExecuteReaderAsync(ct);while(await r.ReadAsync(ct))list.Add(MapEdge(r));return list;
    }
    public async Task<IReadOnlyList<GraphNode>> GetNodesAsync(Guid tenantId,IEnumerable<Guid> ids,CancellationToken ct)
    {
        var wanted=ids.Distinct().ToArray();if(wanted.Length==0)return [];
        var c=await OpenConnectionAsync(ct);await using var cmd=c.CreateCommand();var names=new List<string>();for(var i=0;i<wanted.Length;i++){var n=$"id{i}";names.Add("@"+n);Add(cmd,n,wanted[i]);}
        cmd.CommandText=NodeSelect+$" WHERE tenant_id=@tenant_id AND id IN ({string.Join(',',names)})";Add(cmd,"tenant_id",tenantId);var list=new List<GraphNode>();await using var r=await cmd.ExecuteReaderAsync(ct);while(await r.ReadAsync(ct))list.Add(MapNode(r));return list;
    }
    private async Task<GraphNode?> GetNodeCoreAsync(Guid tenantId,string predicate,Guid? value,string? objectType,Guid? objectId,CancellationToken ct){var c=await OpenConnectionAsync(ct);await using var cmd=c.CreateCommand();cmd.CommandText=NodeSelect+$" WHERE tenant_id=@tenant_id AND {predicate}";Add(cmd,"tenant_id",tenantId);if(value.HasValue)Add(cmd,"value",value);if(objectType is not null)Add(cmd,"object_type",objectType);if(objectId.HasValue)Add(cmd,"object_id",objectId);await using var r=await cmd.ExecuteReaderAsync(ct);return await r.ReadAsync(ct)?MapNode(r):null;}
    private const string NodeSelect="SELECT id,tenant_id,organization_id,object_type,object_id,display_name,attributes_json::text,version FROM graph_nodes";
    private const string EdgeSelect="SELECT id,tenant_id,organization_id,source_node_id,target_node_id,relationship_type_id,confidence,rationale,evidence_ids::text,valid_from,valid_to,supersedes_edge_id FROM graph_edges";
    private static GraphNode MapNode(DbDataReader r){var attrs=JsonSerializer.Deserialize<Dictionary<string,object?>>(r.GetString(6))??[];return new(r.GetGuid(0),r.GetGuid(1),r.IsDBNull(2)?null:r.GetGuid(2),r.GetString(3),r.GetGuid(4),r.GetString(5),attrs,r.GetInt64(7));}
    private static RelationshipType MapType(DbDataReader r){var s=JsonSerializer.Deserialize<HashSet<string>>(r.GetString(5))??[];var t=JsonSerializer.Deserialize<HashSet<string>>(r.GetString(6))??[];return new(r.GetGuid(0),r.GetString(1),r.GetString(2),r.IsDBNull(3)?null:r.GetString(3),r.GetBoolean(4),s,t);}
    private static GraphEdge MapEdge(DbDataReader r){var evidence=JsonSerializer.Deserialize<List<Guid>>(r.GetString(8))??[];return new(r.GetGuid(0),r.GetGuid(1),r.IsDBNull(2)?null:r.GetGuid(2),r.GetGuid(3),r.GetGuid(4),r.GetGuid(5),r.GetDecimal(6),r.IsDBNull(7)?null:r.GetString(7),evidence,ReadTimestamp(r,9),ReadNullableTimestamp(r,10),r.IsDBNull(11)?null:r.GetGuid(11));}
    private static void BindEdge(DbCommand c,GraphEdge x,Guid actor){Add(c,"id",x.Id);Add(c,"tenant_id",x.TenantId);Add(c,"organization_id",x.OrganizationId);Add(c,"source",x.SourceNodeId);Add(c,"target",x.TargetNodeId);Add(c,"type",x.RelationshipTypeId);Add(c,"confidence",x.Confidence);Add(c,"rationale",x.Rationale);Add(c,"evidence",JsonSerializer.Serialize(x.EvidenceIds));Add(c,"valid_from",x.ValidFrom.UtcDateTime);Add(c,"valid_to",x.ValidTo?.UtcDateTime);Add(c,"actor",actor);Add(c,"supersedes",x.SupersedesEdgeId);}
    private static void Add(DbCommand c,string n,object? v){var p=c.CreateParameter();p.ParameterName=n;p.Value=v??DBNull.Value;c.Parameters.Add(p);}
}
