using System.Data.Common;
using System.Text.Json;
using Atlas.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Timeline;

public sealed class PostgresTimelineRepository(AtlasDbContext dbContext) : PostgresRepositoryBase(dbContext), ITimelineRepository
{
    public Task<TimelineEntry?> GetLastAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken cancellationToken)
        => QuerySingleAsync("""
            SELECT id, tenant_id, object_type, object_id, event_type, category, title, description,
                   actor_id, actor_display_name, source_system, correlation_id, causation_id,
                   occurred_at, recorded_at, sequence_no, metadata::text, integrity_hash,
                   previous_hash, is_redacted, redaction_reason
              FROM atlas_timeline_entries
             WHERE tenant_id = @tenant_id AND object_type = @object_type AND object_id = @object_id
             ORDER BY sequence_no DESC LIMIT 1
            """, tenantId, objectType, objectId, null, cancellationToken);

    public async Task AddAsync(TimelineEntry entry, CancellationToken cancellationToken)
    {
        var connection = await OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO atlas_timeline_entries
              (id, tenant_id, object_type, object_id, event_type, category, title, description,
               actor_id, actor_display_name, source_system, correlation_id, causation_id,
               occurred_at, recorded_at, metadata, integrity_hash, previous_hash, is_redacted, redaction_reason)
            VALUES
              (@id, @tenant_id, @object_type, @object_id, @event_type, @category, @title, @description,
               @actor_id, @actor_display_name, @source_system, @correlation_id, @causation_id,
               @occurred_at, @recorded_at, CAST(@metadata AS jsonb), @integrity_hash, @previous_hash,
               @is_redacted, @redaction_reason)
            """;
        Add(command, "id", entry.Id); Add(command, "tenant_id", entry.TenantId);
        Add(command, "object_type", entry.ObjectType); Add(command, "object_id", entry.ObjectId);
        Add(command, "event_type", entry.EventType); Add(command, "category", entry.Category.ToString());
        Add(command, "title", entry.Title); Add(command, "description", entry.Description);
        Add(command, "actor_id", entry.ActorId); Add(command, "actor_display_name", entry.ActorDisplayName);
        Add(command, "source_system", entry.SourceSystem); Add(command, "correlation_id", entry.CorrelationId);
        Add(command, "causation_id", entry.CausationId); Add(command, "occurred_at", entry.OccurredAt.UtcDateTime);
        Add(command, "recorded_at", entry.RecordedAt.UtcDateTime);
        Add(command, "metadata", JsonSerializer.Serialize(entry.Metadata));
        Add(command, "integrity_hash", entry.IntegrityHash); Add(command, "previous_hash", entry.PreviousHash);
        Add(command, "is_redacted", entry.IsRedacted); Add(command, "redaction_reason", entry.RedactionReason);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public Task<TimelineEntry?> GetAsync(Guid tenantId, Guid id, CancellationToken cancellationToken)
        => QuerySingleAsync("""
            SELECT id, tenant_id, object_type, object_id, event_type, category, title, description,
                   actor_id, actor_display_name, source_system, correlation_id, causation_id,
                   occurred_at, recorded_at, sequence_no, metadata::text, integrity_hash,
                   previous_hash, is_redacted, redaction_reason
              FROM atlas_timeline_entries WHERE tenant_id = @tenant_id AND id = @id
            """, tenantId, null, null, id, cancellationToken);

    public async Task<IReadOnlyList<TimelineEntry>> ListAsync(Guid tenantId, string objectType, Guid objectId, int limit, int offset, CancellationToken cancellationToken)
    {
        var connection = await OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT id, tenant_id, object_type, object_id, event_type, category, title, description,
                   actor_id, actor_display_name, source_system, correlation_id, causation_id,
                   occurred_at, recorded_at, sequence_no, metadata::text, integrity_hash,
                   previous_hash, is_redacted, redaction_reason
              FROM atlas_timeline_entries
             WHERE tenant_id = @tenant_id AND object_type = @object_type AND object_id = @object_id
             ORDER BY occurred_at DESC, sequence_no DESC LIMIT @limit OFFSET @offset
            """;
        Add(command, "tenant_id", tenantId); Add(command, "object_type", objectType); Add(command, "object_id", objectId);
        Add(command, "limit", limit); Add(command, "offset", offset);
        var results = new List<TimelineEntry>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken)) results.Add(Map(reader));
        return results;
    }

    public async Task<int> CountAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken cancellationToken)
    {
        var connection = await OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT count(*) FROM atlas_timeline_entries WHERE tenant_id=@tenant_id AND object_type=@object_type AND object_id=@object_id";
        Add(command, "tenant_id", tenantId); Add(command, "object_type", objectType); Add(command, "object_id", objectId);
        return Convert.ToInt32(await command.ExecuteScalarAsync(cancellationToken));
    }

    public async Task ReplaceAsync(TimelineEntry entry, CancellationToken cancellationToken)
    {
        var connection = await OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            UPDATE atlas_timeline_entries
               SET title=@title, description=@description, metadata=CAST(@metadata AS jsonb),
                   integrity_hash=@integrity_hash, previous_hash=@previous_hash,
                   is_redacted=@is_redacted, redaction_reason=@redaction_reason,
                   redacted_at=CASE WHEN @is_redacted THEN now() ELSE NULL END
             WHERE tenant_id=@tenant_id AND id=@id
            """;
        Add(command, "title", entry.Title); Add(command, "description", entry.Description);
        Add(command, "metadata", JsonSerializer.Serialize(entry.Metadata)); Add(command, "integrity_hash", entry.IntegrityHash);
        Add(command, "previous_hash", entry.PreviousHash); Add(command, "is_redacted", entry.IsRedacted);
        Add(command, "redaction_reason", entry.RedactionReason); Add(command, "tenant_id", entry.TenantId); Add(command, "id", entry.Id);
        if (await command.ExecuteNonQueryAsync(cancellationToken) != 1) throw new KeyNotFoundException($"Timeline entry {entry.Id} was not found.");
    }

    private async Task<TimelineEntry?> QuerySingleAsync(string sql, Guid tenantId, string? objectType, Guid? objectId, Guid? id, CancellationToken cancellationToken)
    {
        var connection = await OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand(); command.CommandText = sql;
        Add(command, "tenant_id", tenantId);
        if (objectType is not null) Add(command, "object_type", objectType);
        if (objectId.HasValue) Add(command, "object_id", objectId.Value);
        if (id.HasValue) Add(command, "id", id.Value);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        return await reader.ReadAsync(cancellationToken) ? Map(reader) : null;
    }

    private static TimelineEntry Map(DbDataReader r)
    {
        var metadata = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(r.GetString(16)) ?? [];
        return new TimelineEntry(r.GetGuid(0), r.GetGuid(1), r.GetString(2), r.GetGuid(3), r.GetString(4),
            Enum.Parse<TimelineCategory>(r.GetString(5), true), r.GetString(6), r.IsDBNull(7) ? null : r.GetString(7),
            r.IsDBNull(8) ? null : r.GetGuid(8), r.IsDBNull(9) ? null : r.GetString(9), r.GetString(10),
            r.IsDBNull(11) ? null : r.GetString(11), r.IsDBNull(12) ? null : r.GetString(12),
            ReadTimestamp(r, 13), ReadTimestamp(r, 14), r.GetInt64(15), metadata, r.GetString(17),
            r.IsDBNull(18) ? null : r.GetString(18), r.GetBoolean(19), r.IsDBNull(20) ? null : r.GetString(20));
    }

    private static void Add(DbCommand command, string name, object? value)
    { var parameter = command.CreateParameter(); parameter.ParameterName = name; parameter.Value = value ?? DBNull.Value; command.Parameters.Add(parameter); }
}
