using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Infrastructure;

public abstract class PostgresRepositoryBase(AtlasDbContext dbContext)
{
    protected AtlasDbContext DbContext { get; } = dbContext;

    protected async Task<DbConnection> OpenConnectionAsync(CancellationToken cancellationToken)
    {
        var connection = DbContext.Database.GetDbConnection();
        if (connection.State != System.Data.ConnectionState.Open)
            await connection.OpenAsync(cancellationToken);
        return connection;
    }

    protected static DateTimeOffset ReadTimestamp(DbDataReader reader, int ordinal)
    {
        var value = reader.GetFieldValue<DateTime>(ordinal);
        return new DateTimeOffset(DateTime.SpecifyKind(value, DateTimeKind.Utc));
    }

    protected static DateTimeOffset? ReadNullableTimestamp(DbDataReader reader, int ordinal)
        => reader.IsDBNull(ordinal) ? null : ReadTimestamp(reader, ordinal);
}
