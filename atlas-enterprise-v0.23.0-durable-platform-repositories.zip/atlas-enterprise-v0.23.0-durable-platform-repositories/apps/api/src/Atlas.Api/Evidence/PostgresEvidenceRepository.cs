using System.Data.Common;
using Atlas.Api.Infrastructure;

namespace Atlas.Api.Evidence;

public sealed class PostgresEvidenceRepository(AtlasDbContext dbContext) : PostgresRepositoryBase(dbContext), IEvidenceRepository
{
    public async Task<EvidenceRecord?> GetAsync(Guid organizationId, Guid evidenceId, CancellationToken cancellationToken)
    {
        var c=await OpenConnectionAsync(cancellationToken); await using var cmd=c.CreateCommand();
        cmd.CommandText=RecordSelect+" WHERE organization_id=@organization_id AND id=@id"; Add(cmd,"organization_id",organizationId);Add(cmd,"id",evidenceId);
        await using var r=await cmd.ExecuteReaderAsync(cancellationToken); return await r.ReadAsync(cancellationToken)?MapRecord(r):null;
    }
    public async Task<IReadOnlyList<EvidenceRecord>> ListForObjectAsync(Guid organizationId,string objectType,Guid objectId,CancellationToken cancellationToken)
    {
        var c=await OpenConnectionAsync(cancellationToken); await using var cmd=c.CreateCommand();
        cmd.CommandText=RecordSelect+" WHERE organization_id=@organization_id AND lower(object_type)=lower(@object_type) AND object_id=@object_id ORDER BY modified_at_utc DESC";
        Add(cmd,"organization_id",organizationId);Add(cmd,"object_type",objectType);Add(cmd,"object_id",objectId);
        var list=new List<EvidenceRecord>();await using var r=await cmd.ExecuteReaderAsync(cancellationToken);while(await r.ReadAsync(cancellationToken))list.Add(MapRecord(r));return list;
    }
    public async Task SaveAsync(EvidenceRecord x,CancellationToken cancellationToken)
    {
        var c=await OpenConnectionAsync(cancellationToken);await using var cmd=c.CreateCommand();
        cmd.CommandText="""
          INSERT INTO evidence_records(id,organization_id,object_id,object_type,title,description,classification,status,retention_policy,legal_hold,current_version,created_at_utc,created_by,modified_at_utc,modified_by)
          VALUES(@id,@organization_id,@object_id,@object_type,@title,@description,@classification,@status,@retention_policy,@legal_hold,@current_version,@created_at_utc,@created_by,@modified_at_utc,@modified_by)
          ON CONFLICT(id) DO UPDATE SET title=EXCLUDED.title,description=EXCLUDED.description,classification=EXCLUDED.classification,status=EXCLUDED.status,
          retention_policy=EXCLUDED.retention_policy,legal_hold=EXCLUDED.legal_hold,current_version=EXCLUDED.current_version,modified_at_utc=EXCLUDED.modified_at_utc,modified_by=EXCLUDED.modified_by
          WHERE evidence_records.organization_id=EXCLUDED.organization_id
        """; BindRecord(cmd,x);await cmd.ExecuteNonQueryAsync(cancellationToken);
    }
    public async Task<IReadOnlyList<EvidenceVersion>> GetVersionsAsync(Guid evidenceId,CancellationToken cancellationToken)
    {
        var c=await OpenConnectionAsync(cancellationToken);await using var cmd=c.CreateCommand();cmd.CommandText=VersionSelect+" WHERE evidence_id=@evidence_id ORDER BY version_number DESC";Add(cmd,"evidence_id",evidenceId);
        var list=new List<EvidenceVersion>();await using var r=await cmd.ExecuteReaderAsync(cancellationToken);while(await r.ReadAsync(cancellationToken))list.Add(MapVersion(r));return list;
    }
    public async Task<EvidenceVersion?> GetVersionAsync(Guid evidenceId,int versionNumber,CancellationToken cancellationToken)
    {
        var c=await OpenConnectionAsync(cancellationToken);await using var cmd=c.CreateCommand();cmd.CommandText=VersionSelect+" WHERE evidence_id=@evidence_id AND version_number=@version_number";Add(cmd,"evidence_id",evidenceId);Add(cmd,"version_number",versionNumber);
        await using var r=await cmd.ExecuteReaderAsync(cancellationToken);return await r.ReadAsync(cancellationToken)?MapVersion(r):null;
    }
    public async Task SaveVersionAsync(EvidenceVersion x,CancellationToken cancellationToken)
    {
        var c=await OpenConnectionAsync(cancellationToken);await using var cmd=c.CreateCommand();cmd.CommandText="""
          INSERT INTO evidence_versions(id,evidence_id,version_number,original_file_name,content_type,size_bytes,sha256,storage_key,notes,uploaded_at_utc,uploaded_by)
          VALUES(@id,@evidence_id,@version_number,@original_file_name,@content_type,@size_bytes,@sha256,@storage_key,@notes,@uploaded_at_utc,@uploaded_by)
        """;
        Add(cmd,"id",x.Id);Add(cmd,"evidence_id",x.EvidenceId);Add(cmd,"version_number",x.VersionNumber);Add(cmd,"original_file_name",x.OriginalFileName);Add(cmd,"content_type",x.ContentType);Add(cmd,"size_bytes",x.SizeBytes);Add(cmd,"sha256",x.Sha256);Add(cmd,"storage_key",x.StorageKey);Add(cmd,"notes",x.Notes);Add(cmd,"uploaded_at_utc",x.UploadedAtUtc.UtcDateTime);Add(cmd,"uploaded_by",x.UploadedBy);await cmd.ExecuteNonQueryAsync(cancellationToken);
    }
    public async Task AppendAccessAsync(EvidenceAccessEvent x,CancellationToken cancellationToken)
    {
        var c=await OpenConnectionAsync(cancellationToken);await using var cmd=c.CreateCommand();cmd.CommandText="""
          INSERT INTO evidence_access_log(id,organization_id,evidence_id,version_number,action,actor_id,correlation_id,occurred_at_utc,details_json)
          VALUES(@id,@organization_id,@evidence_id,@version_number,@action,@actor_id,@correlation_id,@occurred_at_utc,CAST(@details_json AS jsonb))
        """;
        Add(cmd,"id",x.Id);Add(cmd,"organization_id",x.OrganizationId);Add(cmd,"evidence_id",x.EvidenceId);Add(cmd,"version_number",x.VersionNumber);Add(cmd,"action",x.Action);Add(cmd,"actor_id",x.ActorId);Add(cmd,"correlation_id",x.CorrelationId);Add(cmd,"occurred_at_utc",x.OccurredAtUtc.UtcDateTime);Add(cmd,"details_json",x.DetailsJson);await cmd.ExecuteNonQueryAsync(cancellationToken);
    }
    private const string RecordSelect="SELECT id,organization_id,object_id,object_type,title,description,classification,status,retention_policy,legal_hold,current_version,created_at_utc,created_by,modified_at_utc,modified_by FROM evidence_records";
    private const string VersionSelect="SELECT id,evidence_id,version_number,original_file_name,content_type,size_bytes,sha256,storage_key,notes,uploaded_at_utc,uploaded_by FROM evidence_versions";
    private static EvidenceRecord MapRecord(DbDataReader r)=>new(){Id=r.GetGuid(0),OrganizationId=r.GetGuid(1),ObjectId=r.IsDBNull(2)?null:r.GetGuid(2),ObjectType=r.IsDBNull(3)?null:r.GetString(3),Title=r.GetString(4),Description=r.GetString(5),Classification=Enum.Parse<EvidenceClassification>(r.GetString(6),true),Status=Enum.Parse<EvidenceStatus>(r.GetString(7),true),RetentionPolicy=r.GetString(8),LegalHold=r.GetBoolean(9),CurrentVersion=r.GetInt32(10),CreatedAtUtc=ReadTimestamp(r,11),CreatedBy=r.GetGuid(12),ModifiedAtUtc=ReadTimestamp(r,13),ModifiedBy=r.GetGuid(14)};
    private static EvidenceVersion MapVersion(DbDataReader r)=>new(r.GetGuid(0),r.GetGuid(1),r.GetInt32(2),r.GetString(3),r.GetString(4),r.GetInt64(5),r.GetString(6),r.GetString(7),r.GetString(8),ReadTimestamp(r,9),r.GetGuid(10));
    private static void BindRecord(DbCommand c,EvidenceRecord x){Add(c,"id",x.Id);Add(c,"organization_id",x.OrganizationId);Add(c,"object_id",x.ObjectId);Add(c,"object_type",x.ObjectType);Add(c,"title",x.Title);Add(c,"description",x.Description);Add(c,"classification",x.Classification.ToString());Add(c,"status",x.Status.ToString());Add(c,"retention_policy",x.RetentionPolicy);Add(c,"legal_hold",x.LegalHold);Add(c,"current_version",x.CurrentVersion);Add(c,"created_at_utc",x.CreatedAtUtc.UtcDateTime);Add(c,"created_by",x.CreatedBy);Add(c,"modified_at_utc",x.ModifiedAtUtc.UtcDateTime);Add(c,"modified_by",x.ModifiedBy);}
    private static void Add(DbCommand c,string n,object? v){var p=c.CreateParameter();p.ParameterName=n;p.Value=v??DBNull.Value;c.Parameters.Add(p);}
}
