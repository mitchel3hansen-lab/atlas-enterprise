using System.Data.Common;
using Atlas.Api.Infrastructure;

namespace Atlas.Api.Rules;

public sealed class PostgresRuleRepository(AtlasDbContext dbContext) : PostgresRepositoryBase(dbContext), IRuleRepository
{
    public Task<IReadOnlyList<AutomationRule>> GetActiveForEventAsync(Guid organizationId, string eventName, CancellationToken cancellationToken)
        => ListRulesAsync(organizationId, "trigger_event = @event AND status = 'Active'", eventName, cancellationToken);

    public async Task<AutomationRule?> GetAsync(Guid organizationId, Guid ruleId, CancellationToken cancellationToken)
    {
        var connection = await OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = RuleSelect + " WHERE organization_id=@organization_id AND id=@id";
        Add(command, "organization_id", organizationId); Add(command, "id", ruleId);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        return await reader.ReadAsync(cancellationToken) ? MapRule(reader) : null;
    }

    public async Task AddAsync(AutomationRule rule, CancellationToken cancellationToken)
    {
        var connection = await OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO automation_rules
            (id, organization_id, name, description, trigger_event, priority, status, condition_json, action_json,
             version, created_at_utc, created_by, modified_at_utc, modified_by)
            VALUES (@id,@organization_id,@name,@description,@trigger_event,@priority,@status,CAST(@condition_json AS jsonb),
                    CAST(@action_json AS jsonb),@version,@created_at_utc,@created_by,@modified_at_utc,@modified_by)
            """;
        BindRule(command, rule); await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task UpdateAsync(AutomationRule rule, CancellationToken cancellationToken)
    {
        var connection = await OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            UPDATE automation_rules SET name=@name, description=@description, trigger_event=@trigger_event,
                priority=@priority, status=@status, condition_json=CAST(@condition_json AS jsonb),
                action_json=CAST(@action_json AS jsonb), version=@version, modified_at_utc=@modified_at_utc, modified_by=@modified_by
            WHERE organization_id=@organization_id AND id=@id
            """;
        BindRule(command, rule);
        if (await command.ExecuteNonQueryAsync(cancellationToken) != 1) throw new KeyNotFoundException($"Rule {rule.Id} was not found.");
    }

    public async Task AddExecutionAsync(RuleExecution execution, CancellationToken cancellationToken)
    {
        var connection = await OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO rule_executions
            (id, organization_id, rule_id, object_id, object_type, trigger_event, correlation_id, status,
             explanation_json, actions_json, error, started_at_utc, completed_at_utc)
            VALUES (@id,@organization_id,@rule_id,@object_id,@object_type,@trigger_event,@correlation_id,@status,
                    CAST(@explanation_json AS jsonb),CAST(@actions_json AS jsonb),@error,@started_at_utc,@completed_at_utc)
            ON CONFLICT (organization_id, rule_id, correlation_id) DO NOTHING
            """;
        Add(command,"id",execution.Id); Add(command,"organization_id",execution.OrganizationId); Add(command,"rule_id",execution.RuleId);
        Add(command,"object_id",execution.ObjectId); Add(command,"object_type",execution.ObjectType); Add(command,"trigger_event",execution.TriggerEvent);
        Add(command,"correlation_id",execution.CorrelationId); Add(command,"status",execution.Status.ToString());
        Add(command,"explanation_json",execution.ExplanationJson); Add(command,"actions_json",execution.ActionsJson); Add(command,"error",execution.Error);
        Add(command,"started_at_utc",execution.StartedAtUtc.UtcDateTime); Add(command,"completed_at_utc",execution.CompletedAtUtc?.UtcDateTime);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<RuleExecution>> GetExecutionsAsync(Guid organizationId, Guid ruleId, int take, CancellationToken cancellationToken)
    {
        var connection = await OpenConnectionAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT id, organization_id, rule_id, object_id, object_type, trigger_event, correlation_id, status,
                   explanation_json::text, actions_json::text, error, started_at_utc, completed_at_utc
              FROM rule_executions WHERE organization_id=@organization_id AND rule_id=@rule_id
             ORDER BY started_at_utc DESC LIMIT @take
            """;
        Add(command,"organization_id",organizationId); Add(command,"rule_id",ruleId); Add(command,"take",Math.Clamp(take,1,500));
        var result = new List<RuleExecution>(); await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken)) result.Add(MapExecution(reader)); return result;
    }

    private async Task<IReadOnlyList<AutomationRule>> ListRulesAsync(Guid organizationId, string predicate, string eventName, CancellationToken ct)
    {
        var connection = await OpenConnectionAsync(ct); await using var command = connection.CreateCommand();
        command.CommandText = RuleSelect + $" WHERE organization_id=@organization_id AND {predicate} ORDER BY priority, id";
        Add(command,"organization_id",organizationId); Add(command,"event",eventName);
        var result = new List<AutomationRule>(); await using var reader = await command.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) result.Add(MapRule(reader)); return result;
    }

    private const string RuleSelect = """
        SELECT id, organization_id, name, description, trigger_event, priority, status,
               condition_json::text, action_json::text, version, created_at_utc, created_by, modified_at_utc, modified_by
          FROM automation_rules
        """;

    private static AutomationRule MapRule(DbDataReader r) => new()
    {
        Id=r.GetGuid(0), OrganizationId=r.GetGuid(1), Name=r.GetString(2), Description=r.GetString(3), TriggerEvent=r.GetString(4),
        Priority=r.GetInt32(5), Status=Enum.Parse<RuleStatus>(r.GetString(6),true), ConditionJson=r.GetString(7), ActionJson=r.GetString(8),
        Version=r.GetInt32(9), CreatedAtUtc=ReadTimestamp(r,10), CreatedBy=r.GetGuid(11), ModifiedAtUtc=ReadTimestamp(r,12), ModifiedBy=r.GetGuid(13)
    };
    private static RuleExecution MapExecution(DbDataReader r) => new()
    {
        Id=r.GetGuid(0), OrganizationId=r.GetGuid(1), RuleId=r.GetGuid(2), ObjectId=r.IsDBNull(3)?null:r.GetGuid(3),
        ObjectType=r.IsDBNull(4)?null:r.GetString(4), TriggerEvent=r.GetString(5), CorrelationId=r.GetString(6),
        Status=Enum.Parse<RuleExecutionStatus>(r.GetString(7),true), ExplanationJson=r.GetString(8), ActionsJson=r.GetString(9),
        Error=r.IsDBNull(10)?null:r.GetString(10), StartedAtUtc=ReadTimestamp(r,11), CompletedAtUtc=ReadNullableTimestamp(r,12)
    };
    private static void BindRule(DbCommand c, AutomationRule r)
    {
        Add(c,"id",r.Id); Add(c,"organization_id",r.OrganizationId); Add(c,"name",r.Name); Add(c,"description",r.Description);
        Add(c,"trigger_event",r.TriggerEvent); Add(c,"priority",r.Priority); Add(c,"status",r.Status.ToString());
        Add(c,"condition_json",r.ConditionJson); Add(c,"action_json",r.ActionJson); Add(c,"version",r.Version);
        Add(c,"created_at_utc",r.CreatedAtUtc.UtcDateTime); Add(c,"created_by",r.CreatedBy);
        Add(c,"modified_at_utc",r.ModifiedAtUtc.UtcDateTime); Add(c,"modified_by",r.ModifiedBy);
    }
    private static void Add(DbCommand c,string n,object? v){var p=c.CreateParameter();p.ParameterName=n;p.Value=v??DBNull.Value;c.Parameters.Add(p);}
}
