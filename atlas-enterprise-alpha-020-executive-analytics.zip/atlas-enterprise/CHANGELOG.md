## 0.20.0 — Executive Analytics
- Added cross-domain executive metrics, explainable signals, work queues, and governed dashboard snapshots.

# Alpha 0.18.0
- Added Training & Competency Management vertical slice.

## 0.17.0
- Added Risk Management for Risk Register, JHA, and HIRA workflows.
- Added inherent/residual scoring, controls, verification, and acceptance guardrails.

# Changelog

## Alpha 0.16.0
- Added corrective action lifecycle, evidence submission, effectiveness verification, dashboard, API, migration, tests, and React workspace.


All notable changes to the canonical Atlas Enterprise repository will be recorded here.

The project follows Semantic Versioning after the first public release. Historical package notes are retained under `docs/archive/releases/` for traceability and are not treated as independent repositories.

## Unreleased

### Added

- Canonical repository governance and Apache 2.0 licensing
- Root development environment with PostgreSQL, Redis, Mailpit, API, and web services
- GitHub Actions continuous-integration workflow
- Branch, release, and architecture-decision governance

### Changed

- Consolidated historical package artifacts into a single source-of-truth repository

## [Unreleased] - Shared Kernel Sprint 001

### Added
- `Atlas.SharedKernel` class library with entity, aggregate, audit, event, result, error, value-object, context, clock, ID-generation, and specification primitives.
- Dedicated Shared Kernel unit-test project with code-coverage collection.
- ADR-0002 and Shared Kernel developer documentation.

### Changed
- API now references the canonical Shared Kernel project.
- Solution and CI include Shared Kernel build and tests.

## [Unreleased]

### Added
- Rotating refresh sessions and refresh endpoint.
- Access-token revocation on logout.
- Configurable failed-login lockout.
- Shared password policy and identity-security tests.
- V024 identity-hardening migration and rollback.


## Sprint 003 — Incident Management Milestone 1
Create, search, and view tenant-scoped incidents with durable numbering, PostgreSQL search, timeline creation, and a React incident register.


## Sprint 004 — Incident Draft Editing and Assignment
- Added draft-only updates with version checks, timeline events, and rules processing.
- Added dedicated investigator assignment and assignment-history endpoints.
- Added durable PostgreSQL assignment ledger and V026 migration.
- Added React edit/assignment workspace and tests.

## Alpha Release Program

### Added
- Alpha release charter with explicit scope, personas, gates, and quality objectives.
- Four-milestone alpha backlog and GitHub issue-import CSV.
- End-to-end reference acceptance test for incident investigation and CAPA closure.
- Release-readiness checklist and known-limitations register.
- Alpha work-item issue template and continuous readiness workflow.
- Local `scripts/alpha-readiness.sh` validation command.

## Alpha ALPHA-012 — Investigation Workspace
- Added structured incident investigations, witness statements, notes, 5 Whys, Fishbone, CAPA lifecycle, quality scoring, workflow gates, timeline integration, PostgreSQL migration V027, and a React investigation workspace.

## [0.14.0-alpha] - 2026-07-27

### Added
- Operational Knowledge context service, lessons learned, similar-record discovery, explainable recommendations, UI workspace, migration V028, and tests.
