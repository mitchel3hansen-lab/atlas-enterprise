import { useMemo, useState } from 'react';
type Metric={label:string;value:number;unit:string;status:'good'|'watch'|'critical';explanation:string};
const metrics:Metric[]=[
 {label:'Open incidents',value:6,unit:'records',status:'watch',explanation:'Active incident workload requiring investigation or closure.'},
 {label:'Overdue actions',value:4,unit:'actions',status:'watch',explanation:'Corrective actions past due and not yet verified.'},
 {label:'High residual risks',value:2,unit:'risks',status:'critical',explanation:'Open risks with residual score of 15 or higher.'},
 {label:'Overdue training',value:11,unit:'assignments',status:'critical',explanation:'Training assignments beyond their due date.'},
 {label:'Open audit findings',value:7,unit:'findings',status:'watch',explanation:'Audit findings that have not reached verified closure.'},
 {label:'Active inspections',value:9,unit:'inspections',status:'good',explanation:'Scheduled and in-progress inspections.'}
];
const trend=[8,7,9,6,5,6];
export function ExecutiveAnalyticsWorkspace(){
 const[facility,setFacility]=useState('Enterprise');const[period,setPeriod]=useState('Last 90 days');const[snapshots,setSnapshots]=useState<string[]>([]);
 const health=useMemo(()=>Math.max(0,100-metrics.reduce((n,m)=>n+(m.status==='critical'?8:m.status==='watch'?3:0),0)),[]);
 return <><header><div><span>Operational Intelligence · v0.20.0</span><h2>Executive Analytics</h2><p>Connected, explainable indicators across incidents, risk, actions, training, inspections, and assurance.</p></div><button onClick={()=>setSnapshots(x=>[`Board snapshot · ${new Date().toLocaleDateString()}`,...x])}>Save snapshot</button></header>
 <section className="analytics-toolbar"><select value={facility} onChange={e=>setFacility(e.target.value)}><option>Enterprise</option><option>Layton</option><option>Lindon</option></select><select value={period} onChange={e=>setPeriod(e.target.value)}><option>Last 30 days</option><option>Last 90 days</option><option>Year to date</option></select><span>Scope: {facility} · {period}</span></section>
 <section className="executive-hero"><div><small>Operational health score</small><strong>{health}</strong><p>Calculated from current critical and watch-level indicators.</p></div><div className="health-ring" style={{'--score':`${health}%`} as React.CSSProperties}><b>{health}%</b></div><div><small>Leadership focus</small><h3>Close critical risk and competency gaps</h3><p>Two high residual risks and eleven overdue training assignments require prioritized owner action.</p></div></section>
 <section className="metrics analytics-metrics">{metrics.map(m=><article key={m.label} className={`metric-${m.status}`}><small>{m.label}</small><strong>{m.value}</strong><span>{m.unit}</span><p>{m.explanation}</p></article>)}</section>
 <section className="analytics-grid"><article className="panel"><div className="toolbar"><div><h3>Incident trend</h3><p>Rolling six-period open incident volume.</p></div><span className="signal">Explainable</span></div><div className="bar-chart">{trend.map((v,i)=><div key={i}><span style={{height:`${v*10}px`}}></span><small>{['Feb','Mar','Apr','May','Jun','Jul'][i]}</small></div>)}</div></article>
 <article className="panel"><h3>Operational signals</h3><div className="signal-list"><div className="signal-card critical"><b>High residual risk remains</b><p>Two open risks remain at a residual score of 15 or above.</p><small>Recommended: review control effectiveness and acceptance authority.</small></div><div className="signal-card watch"><b>Competency coverage gap</b><p>Eleven training assignments are overdue.</p><small>Recommended: prioritize safety-critical qualifications.</small></div><div className="signal-card watch"><b>Action backlog</b><p>Four corrective actions are beyond due date.</p><small>Recommended: escalate owners and confirm recovery dates.</small></div></div></article>
 <article className="panel"><h3>Leadership work queue</h3><table><tbody><tr><td>Incidents</td><td><b>6</b></td></tr><tr><td>Corrective actions</td><td><b>9</b></td></tr><tr><td>Audit findings</td><td><b>7</b></td></tr><tr><td>Training follow-up</td><td><b>11</b></td></tr></tbody></table></article>
 <article className="panel"><h3>Saved snapshots</h3>{snapshots.length===0?<p>No board snapshots saved in this session.</p>:<ul>{snapshots.map(x=><li key={x}>{x}</li>)}</ul>}<small>Snapshots preserve the dashboard state for governance review and board reporting.</small></article></section></>;
}
