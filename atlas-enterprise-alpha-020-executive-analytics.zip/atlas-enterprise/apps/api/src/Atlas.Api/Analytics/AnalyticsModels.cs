namespace Atlas.Api.Analytics;

public sealed record MetricCard(string Key, string Label, decimal Value, string Unit, decimal? PreviousValue, string Trend, string Status, string Explanation);
public sealed record TrendPoint(DateOnly Period, decimal Value);
public sealed record TrendSeries(string Key, string Label, string Unit, IReadOnlyList<TrendPoint> Points);
public sealed record RiskSignal(string Key, string Title, string Severity, string Explanation, string RecommendedAction, int Confidence);
public sealed record ExecutiveDashboard(DateTimeOffset AsOf, IReadOnlyList<MetricCard> Metrics, IReadOnlyList<TrendSeries> Trends, IReadOnlyList<RiskSignal> Signals, IReadOnlyDictionary<string,int> WorkQueue);
public sealed record AnalyticsFilter(Guid? FacilityId, Guid? DepartmentId, DateOnly? From, DateOnly? To);
public sealed record DashboardSnapshot(Guid Id, Guid TenantId, string Name, string Period, string PayloadJson, DateTimeOffset CreatedAt, Guid CreatedBy);
public sealed record CreateSnapshotRequest(string Name, string Period);
