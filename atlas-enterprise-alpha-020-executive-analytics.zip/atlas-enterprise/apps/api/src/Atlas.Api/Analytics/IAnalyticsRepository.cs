namespace Atlas.Api.Analytics;
public interface IAnalyticsRepository
{
    Task<ExecutiveDashboard> GetExecutiveDashboardAsync(Guid tenantId, AnalyticsFilter filter, DateTimeOffset now, CancellationToken ct);
    Task<DashboardSnapshot> SaveSnapshotAsync(DashboardSnapshot snapshot, CancellationToken ct);
    Task<IReadOnlyList<DashboardSnapshot>> ListSnapshotsAsync(Guid tenantId, int limit, CancellationToken ct);
}
