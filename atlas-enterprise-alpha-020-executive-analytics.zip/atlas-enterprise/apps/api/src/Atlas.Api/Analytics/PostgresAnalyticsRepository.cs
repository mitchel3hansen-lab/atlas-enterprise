using Dapper;
using Npgsql;
namespace Atlas.Api.Analytics;
public sealed class PostgresAnalyticsRepository(IConfiguration configuration):IAnalyticsRepository
{
    private NpgsqlConnection Open()=>new(configuration.GetConnectionString("Atlas"));
    public async Task<ExecutiveDashboard> GetExecutiveDashboardAsync(Guid t,AnalyticsFilter f,DateTimeOffset now,CancellationToken ct)
    {
        await using var c=Open();
        var p=new{t,facility=f.FacilityId,department=f.DepartmentId,from=f.From?.ToDateTime(TimeOnly.MinValue),to=f.To?.ToDateTime(TimeOnly.MaxValue),now};
        const string sql="""
        select
          (select count(*) from incidents where tenant_id=@t and status::text not in ('Closed','Cancelled')) open_incidents,
          (select count(*) from corrective_actions where tenant_id=@t and status::text not in ('Closed','Verified')) open_actions,
          (select count(*) from corrective_actions where tenant_id=@t and due_at<@now and status::text not in ('Closed','Verified')) overdue_actions,
          (select count(*) from risks where tenant_id=@t and status::text not in ('Closed','Archived') and residual_score>=15) high_risks,
          (select count(*) from training_assignments where tenant_id=@t and due_at<@now and status::text not in ('Completed','Waived')) overdue_training,
          (select count(*) from audit_findings where tenant_id=@t and status::text<>'Closed') open_audit_findings,
          (select count(*) from inspections where tenant_id=@t and status::text in ('Scheduled','InProgress')) active_inspections
        """;
        dynamic x=await c.QuerySingleAsync(new CommandDefinition(sql,p,cancellationToken:ct));
        decimal openInc=(long)x.open_incidents, openActions=(long)x.open_actions, overdue=(long)x.overdue_actions, highRisks=(long)x.high_risks, overdueTraining=(long)x.overdue_training, auditFindings=(long)x.open_audit_findings, activeInspections=(long)x.active_inspections;
        var metrics=new List<MetricCard>{
          new("open-incidents","Open incidents",openInc,"records",null,openInc>5?"up":"stable",openInc>10?"critical":openInc>5?"watch":"good","Active incident workload requiring investigation or closure."),
          new("overdue-actions","Overdue actions",overdue,"actions",null,overdue>0?"up":"stable",overdue>5?"critical":overdue>0?"watch":"good","Corrective actions past due and not yet verified."),
          new("high-risks","High residual risks",highRisks,"risks",null,highRisks>0?"up":"stable",highRisks>3?"critical":highRisks>0?"watch":"good","Open risks with residual score of 15 or higher."),
          new("training","Overdue training",overdueTraining,"assignments",null,overdueTraining>0?"up":"stable",overdueTraining>10?"critical":overdueTraining>0?"watch":"good","Training assignments beyond their due date."),
          new("audit-findings","Open audit findings",auditFindings,"findings",null,auditFindings>0?"up":"stable",auditFindings>10?"critical":auditFindings>0?"watch":"good","Audit findings that have not reached verified closure."),
          new("active-inspections","Active inspections",activeInspections,"inspections",null,"stable","good","Scheduled and in-progress inspections."),
        };
        var signals=new List<RiskSignal>();
        if(overdue>0) signals.Add(new("action-backlog","Corrective-action backlog","High",$"{overdue} corrective actions are overdue.","Escalate overdue owners and confirm recovery dates.",96));
        if(highRisks>0) signals.Add(new("residual-risk","High residual risk remains","Critical",$"{highRisks} open risks remain at a residual score of 15 or above.","Review control effectiveness and risk acceptance authority.",98));
        if(overdueTraining>0) signals.Add(new("training-gap","Competency coverage gap","Medium",$"{overdueTraining} training assignments are overdue.","Prioritize safety-critical qualifications and supervisor follow-up.",93));
        var queue=new Dictionary<string,int>{{"Incidents",(int)openInc},{"Corrective actions",(int)openActions},{"Audit findings",(int)auditFindings},{"Training",(int)overdueTraining}};
        return new(now,metrics,Array.Empty<TrendSeries>(),signals,queue);
    }
    public async Task<DashboardSnapshot> SaveSnapshotAsync(DashboardSnapshot x,CancellationToken ct){const string sql="insert into analytics_snapshots(id,tenant_id,name,period,payload_json,created_at,created_by) values(@Id,@TenantId,@Name,@Period,cast(@PayloadJson as jsonb),@CreatedAt,@CreatedBy)";await using var c=Open();await c.ExecuteAsync(new CommandDefinition(sql,x,cancellationToken:ct));return x;}
    public async Task<IReadOnlyList<DashboardSnapshot>> ListSnapshotsAsync(Guid t,int limit,CancellationToken ct){await using var c=Open();return (await c.QueryAsync<DashboardSnapshot>(new CommandDefinition("select id,tenant_id TenantId,name,period,payload_json::text PayloadJson,created_at CreatedAt,created_by CreatedBy from analytics_snapshots where tenant_id=@t order by created_at desc limit @limit",new{t,limit},cancellationToken:ct))).AsList();}
}
