using System.Text.Json;
namespace Atlas.Api.Analytics;
public sealed class AnalyticsService(IAnalyticsRepository repository)
{
    public Task<ExecutiveDashboard> ExecutiveAsync(Guid tenantId, AnalyticsFilter filter, CancellationToken ct) =>
        repository.GetExecutiveDashboardAsync(tenantId, filter, DateTimeOffset.UtcNow, ct);

    public async Task<DashboardSnapshot> CreateSnapshotAsync(Guid tenantId, Guid userId, CreateSnapshotRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Name)) throw new ArgumentException("Snapshot name is required.");
        var dashboard = await ExecutiveAsync(tenantId, new(null,null,null,null), ct);
        var snapshot = new DashboardSnapshot(Guid.NewGuid(), tenantId, request.Name.Trim(), request.Period.Trim(), JsonSerializer.Serialize(dashboard), DateTimeOffset.UtcNow, userId);
        return await repository.SaveSnapshotAsync(snapshot, ct);
    }
    public Task<IReadOnlyList<DashboardSnapshot>> SnapshotsAsync(Guid tenantId, int limit, CancellationToken ct) => repository.ListSnapshotsAsync(tenantId, Math.Clamp(limit,1,100), ct);
}
