using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace Atlas.Api.Analytics;
[ApiController,Route("api/analytics"),Authorize]
public sealed class AnalyticsController(AnalyticsService service,TenantContext tenant):ControllerBase
{
    [HttpGet("executive"),Authorize(Policy=AtlasPermissions.AnalyticsRead)] public Task<ExecutiveDashboard> Executive([FromQuery]AnalyticsFilter filter,CancellationToken ct)=>service.ExecutiveAsync(tenant.TenantId,filter,ct);
    [HttpPost("snapshots"),Authorize(Policy=AtlasPermissions.AnalyticsManage)] public Task<DashboardSnapshot> Snapshot(CreateSnapshotRequest request,CancellationToken ct)=>service.CreateSnapshotAsync(tenant.TenantId,tenant.UserId,request,ct);
    [HttpGet("snapshots"),Authorize(Policy=AtlasPermissions.AnalyticsRead)] public Task<IReadOnlyList<DashboardSnapshot>> Snapshots([FromQuery]int limit=20,CancellationToken ct)=>service.SnapshotsAsync(tenant.TenantId,limit,ct);
}
