begin;
create table if not exists analytics_snapshots(
 id uuid primary key, tenant_id uuid not null, name text not null, period text not null,
 payload_json jsonb not null, created_at timestamptz not null, created_by uuid not null
);
create index if not exists ix_analytics_snapshots_tenant_created on analytics_snapshots(tenant_id,created_at desc);
insert into permissions(code,description) values
 ('analytics.read','View enterprise analytics and executive dashboards'),
 ('analytics.manage','Create and manage analytics snapshots')
on conflict(code) do nothing;
commit;
