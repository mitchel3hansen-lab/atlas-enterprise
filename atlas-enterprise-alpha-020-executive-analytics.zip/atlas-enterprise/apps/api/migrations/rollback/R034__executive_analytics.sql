begin;
delete from permissions where code in ('analytics.read','analytics.manage');
drop table if exists analytics_snapshots;
commit;
