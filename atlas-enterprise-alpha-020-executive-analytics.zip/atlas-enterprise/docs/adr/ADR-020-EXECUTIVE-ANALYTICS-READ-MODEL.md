# ADR-020: Cross-domain executive analytics read model

## Decision
Use a dedicated, read-only analytics service that aggregates authoritative transactional modules at query time and stores optional immutable JSON snapshots.

## Why
This preserves domain ownership, avoids duplicated write logic, supports explainability, and creates a migration path to materialized views or a warehouse when scale requires it.

## Consequences
- Transactional modules remain systems of record.
- Dashboard queries must be tenant scoped.
- Snapshots are evidence of what leadership saw at a point in time.
- Trend pipelines can be added without changing the dashboard contract.
