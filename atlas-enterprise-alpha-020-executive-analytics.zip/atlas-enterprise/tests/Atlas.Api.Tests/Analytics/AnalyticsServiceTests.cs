using Atlas.Api.Analytics;
using Xunit;
namespace Atlas.Api.Tests.Analytics;
public sealed class AnalyticsServiceTests
{
 [Fact] public async Task Snapshot_serializes_current_dashboard(){var repo=new MemoryRepo();var service=new AnalyticsService(repo);var x=await service.CreateSnapshotAsync(Guid.NewGuid(),Guid.NewGuid(),new("Board pack","2026-Q2"),default);Assert.Contains("Open incidents",x.PayloadJson);Assert.Equal("2026-Q2",x.Period);}
 [Fact] public async Task Snapshot_requires_name(){var service=new AnalyticsService(new MemoryRepo());await Assert.ThrowsAsync<ArgumentException>(()=>service.CreateSnapshotAsync(Guid.NewGuid(),Guid.NewGuid(),new(" ","Q2"),default));}
 private sealed class MemoryRepo:IAnalyticsRepository{readonly List<DashboardSnapshot>s=[];public Task<ExecutiveDashboard>GetExecutiveDashboardAsync(Guid t,AnalyticsFilter f,DateTimeOffset n,CancellationToken c)=>Task.FromResult(new ExecutiveDashboard(n,[new("inc","Open incidents",2,"records",1,"up","watch","test")],[],[],new Dictionary<string,int>()));public Task<DashboardSnapshot>SaveSnapshotAsync(DashboardSnapshot x,CancellationToken c){s.Add(x);return Task.FromResult(x);}public Task<IReadOnlyList<DashboardSnapshot>>ListSnapshotsAsync(Guid t,int l,CancellationToken c)=>Task.FromResult<IReadOnlyList<DashboardSnapshot>>(s);}
}
