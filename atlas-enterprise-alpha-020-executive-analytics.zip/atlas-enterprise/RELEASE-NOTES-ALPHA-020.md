# Atlas Enterprise Alpha 0.20 — Executive Analytics

Adds connected executive metrics, operational health scoring, explainable risk signals, leadership work queues, dashboard filtering, and governed dashboard snapshots.

## Technical delivery
- Analytics API, service, PostgreSQL repository, and contracts
- `V034__executive_analytics.sql` with rollback
- `analytics.read` and `analytics.manage` permissions
- React Executive Analytics workspace
- Snapshot unit tests
- Product specification and architecture decision record
