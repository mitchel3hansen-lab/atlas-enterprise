namespace Atlas.Api.Security;

public static class AtlasPermissions
{
    public const string OrganizationsRead = "organizations.read";
    public const string OrganizationsManage = "organizations.manage";
    public const string FacilitiesRead = "facilities.read";
    public const string FacilitiesManage = "facilities.manage";
    public const string UsersRead = "users.read";
    public const string UsersManage = "users.manage";
    public const string SafetyRead = "safety.read";
    public const string SafetyManage = "safety.manage";
    public const string ExplainabilityRead = "explainability.read";
    public const string ExplainabilityManage = "explainability.manage";
    public const string KnowledgeGraphRead = "knowledge_graph.read";
    public const string KnowledgeGraphManage = "knowledge_graph.manage";
    public const string RulesRead = "rules.read";
    public const string RulesManage = "rules.manage";
    public const string RulesExecute = "rules.execute";
    public const string EvidenceRead = "evidence.read";
    public const string EvidenceManage = "evidence.manage";
    public const string EvidenceDownload = "evidence.download";
    public const string EvidenceLegalHold = "evidence.legal_hold";
    public const string TimelineRead = "timeline.read";
    public const string TimelineWrite = "timeline.write";
    public const string AuditRead = "audit.read";
    public const string AuditRedact = "audit.redact";
    public const string IncidentsRead = "incidents.read";
    public const string IncidentsManage = "incidents.manage";
    public const string IncidentsTransition = "incidents.transition";
    public const string InspectionsRead = "inspections.read";
    public const string InspectionsManage = "inspections.manage";
    public const string InspectionsExecute = "inspections.execute";
    public const string CorrectiveActionsRead = "corrective_actions.read";
    public const string CorrectiveActionsManage = "corrective_actions.manage";
    public const string CorrectiveActionsExecute = "corrective_actions.execute";
    public const string CorrectiveActionsVerify = "corrective_actions.verify";

    public static readonly string[] All =
    [
        OrganizationsRead, OrganizationsManage, FacilitiesRead, FacilitiesManage,
        UsersRead, UsersManage, SafetyRead, SafetyManage,
        ExplainabilityRead, ExplainabilityManage,
        KnowledgeGraphRead, KnowledgeGraphManage,
        RulesRead, RulesManage, RulesExecute,
        EvidenceRead, EvidenceManage, EvidenceDownload, EvidenceLegalHold,
        TimelineRead, TimelineWrite, AuditRead, AuditRedact,
        IncidentsRead, IncidentsManage, IncidentsTransition,
        InspectionsRead, InspectionsManage, InspectionsExecute,
        CorrectiveActionsRead, CorrectiveActionsManage, CorrectiveActionsExecute, CorrectiveActionsVerify
    ];
}
