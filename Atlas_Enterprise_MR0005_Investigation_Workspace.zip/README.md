# Atlas Enterprise

Atlas is an operational intelligence platform beginning with a complete incident-management vertical slice.

## Current workflow

```text
Draft
→ SupervisorReview
→ SafetyReview
→ Investigation
→ CAPA
```

Alternative:

```text
SupervisorReview
→ CorrectionRequested
```

## Current capabilities

- Create and submit incident drafts
- Supervisor approval and correction routing
- Safety screening and investigator assignment
- Investigation analysis
- Interview records
- Findings
- Evidence references
- Root-cause documentation
- Recommendations
- Investigation completeness gate
- Routing into CAPA

## Start locally

```bash
docker compose down -v
docker compose up --build
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger
