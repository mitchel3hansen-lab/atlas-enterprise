# Changelog

## 0.5.0 - 2026-07-17
- Added tenant-scoped notification templates, user preferences, durable messages, and delivery audit fields.
- Added email and in-app channel adapters, background dispatch, bounded retries, and dead-message state.
- Added durable scheduled-job persistence for reminders, escalations, and overdue workflow processing.
- Added V005 migration and rollback, ADR-0017/0018, operations guidance, APIs, permissions, and unit tests.

## 0.4.0 - 2026-07-17
- Added configurable workflow definitions, instances, transitions, assignments, and SLA due dates.
- Added transactional outbox dispatch, bounded retries, and dead-letter persistence.
- Added workflow API endpoints, PostgreSQL migration V004, architecture records, operations runbook, and unit tests.

## [0.3.0] - 2026-07-17

### Added
- JWT bearer authentication with issuer, audience, signature, and lifetime validation.
- Authenticated tenant and actor claims.
- Permission-based endpoint authorization.
- Tenant-scoped users, roles, permissions, and assignments.
- Development-only token issuer for local testing.
- V003 forward and rollback database scripts.
- IAM architecture, security guidance, and bootstrap runbook.
- ADR-0013 and ADR-0014.

### Changed
- Tenant context is derived from the validated token rather than trusting a header.
- Actor IDs are derived from the authenticated subject rather than request bodies.

## [0.2.0] - 2026-07-17

### Added
- PostgreSQL/EF Core persistence for organizations and facilities.
- Tenant header middleware and tenant-scoped repository queries.
- Facility API endpoints and application service.
- Automatic entity audit-entry capture.
- V002 forward and rollback database scripts.
- Tenant isolation architecture and migration runbook.
- ADR-0011 and ADR-0012.

### Changed
- Organization names now use tenant-scoped normalized uniqueness.
- API failures use RFC-style Problem Details responses.

## [0.1.0] - 2026-07-17
- Initial Genesis foundation.
