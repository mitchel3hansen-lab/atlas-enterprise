# Atlas Enterprise

Atlas is an operational intelligence platform beginning with a complete incident-management vertical slice.

## Current capabilities

- Create a validated incident draft
- Generate a tenant-scoped incident number
- Persist the initial timeline event
- List incidents
- Retrieve incident details and timeline
- Submit a draft into Supervisor Review
- Prevent repeat submission

## Start locally

```bash
docker compose down -v
docker compose up --build
```

Open:

- Web: http://localhost:5173
- Incident API Swagger: http://localhost:8085/swagger
- PostgreSQL: localhost:5432

## Repository structure

- `apps/atlas-web` — React + TypeScript frontend
- `services/incident-api` — ASP.NET Core incident API
- `services/incident-api.Tests` — backend tests
- `database/migrations` — PostgreSQL migrations
- `docs` — architecture and merge-request documentation
