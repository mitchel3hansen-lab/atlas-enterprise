using Atlas.IncidentApi.Domain;
using Atlas.IncidentApi.Features.Incidents.Create;
using Dapper;
using Npgsql;

namespace Atlas.IncidentApi.Infrastructure;

public sealed class IncidentRepository(IConfiguration configuration)
{
    private NpgsqlConnection CreateConnection() =>
        new(configuration.GetConnectionString("Atlas")
            ?? throw new InvalidOperationException("Atlas connection string is missing."));

    public async Task<Incident> CreateAsync(
        CreateIncidentRequest request,
        CancellationToken cancellationToken)
    {
        var id = Guid.NewGuid();
        var now = DateTimeOffset.UtcNow;
        var incidentNumber =
            $"INC-{now:yyyy}-{now:MMddHHmmss}-{Random.Shared.Next(100, 999)}";

        const string insertIncident = """
        INSERT INTO incidents (
            id, tenant_id, incident_number, title, description, incident_type,
            severity, status, workflow_state, occurred_at, reporter_id, site,
            department, created_at, updated_at)
        VALUES (
            @Id, @TenantId, @IncidentNumber, @Title, @Description, @IncidentType,
            @Severity, 'Draft', 'Draft', @OccurredAt, @ReporterId, @Site,
            @Department, @Now, @Now);
        """;

        const string insertTimeline = """
        INSERT INTO incident_timeline (
            id, tenant_id, incident_id, event_type, description, performed_by, occurred_at)
        VALUES (
            @TimelineId, @TenantId, @IncidentId, 'IncidentCreated',
            'Incident draft created.', @ReporterId, @Now);
        """;

        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        var args = new
        {
            Id = id,
            request.TenantId,
            IncidentNumber = incidentNumber,
            request.Title,
            request.Description,
            request.IncidentType,
            request.Severity,
            request.OccurredAt,
            request.ReporterId,
            request.Site,
            request.Department,
            Now = now
        };

        await connection.ExecuteAsync(new CommandDefinition(
            insertIncident, args, transaction,
            cancellationToken: cancellationToken));

        await connection.ExecuteAsync(new CommandDefinition(
            insertTimeline,
            new
            {
                TimelineId = Guid.NewGuid(),
                request.TenantId,
                IncidentId = id,
                request.ReporterId,
                Now = now
            },
            transaction,
            cancellationToken: cancellationToken));

        await transaction.CommitAsync(cancellationToken);

        return new Incident(
            id, request.TenantId, incidentNumber, request.Title,
            request.Description, request.IncidentType, request.Severity,
            "Draft", "Draft", request.OccurredAt, request.ReporterId,
            request.Site, request.Department, now, now, null);
    }

    public async Task<IReadOnlyList<Incident>> ListAsync(
        Guid tenantId,
        CancellationToken cancellationToken)
    {
        const string sql = """
        SELECT
            id AS Id,
            tenant_id AS TenantId,
            incident_number AS IncidentNumber,
            title AS Title,
            description AS Description,
            incident_type AS IncidentType,
            severity AS Severity,
            status AS Status,
            workflow_state AS WorkflowState,
            occurred_at AS OccurredAt,
            reporter_id AS ReporterId,
            site AS Site,
            department AS Department,
            created_at AS CreatedAt,
            updated_at AS UpdatedAt,
            submitted_at AS SubmittedAt
        FROM incidents
        WHERE tenant_id = @TenantId
        ORDER BY created_at DESC;
        """;

        await using var connection = CreateConnection();
        var rows = await connection.QueryAsync<Incident>(
            new CommandDefinition(sql, new { TenantId = tenantId },
                cancellationToken: cancellationToken));
        return rows.AsList();
    }

    public async Task<IncidentDetails?> GetAsync(
        Guid tenantId,
        Guid incidentId,
        CancellationToken cancellationToken)
    {
        const string incidentSql = """
        SELECT
            id AS Id,
            tenant_id AS TenantId,
            incident_number AS IncidentNumber,
            title AS Title,
            description AS Description,
            incident_type AS IncidentType,
            severity AS Severity,
            status AS Status,
            workflow_state AS WorkflowState,
            occurred_at AS OccurredAt,
            reporter_id AS ReporterId,
            site AS Site,
            department AS Department,
            created_at AS CreatedAt,
            updated_at AS UpdatedAt,
            submitted_at AS SubmittedAt
        FROM incidents
        WHERE tenant_id = @TenantId AND id = @IncidentId;
        """;

        const string timelineSql = """
        SELECT
            id AS Id,
            incident_id AS IncidentId,
            event_type AS EventType,
            description AS Description,
            performed_by AS PerformedBy,
            occurred_at AS OccurredAt
        FROM incident_timeline
        WHERE tenant_id = @TenantId AND incident_id = @IncidentId
        ORDER BY occurred_at;
        """;

        await using var connection = CreateConnection();
        var args = new { TenantId = tenantId, IncidentId = incidentId };
        var incident = await connection.QuerySingleOrDefaultAsync<Incident>(
            new CommandDefinition(incidentSql, args,
                cancellationToken: cancellationToken));

        if (incident is null)
            return null;

        var timeline = await connection.QueryAsync<IncidentTimelineEvent>(
            new CommandDefinition(timelineSql, args,
                cancellationToken: cancellationToken));

        return new IncidentDetails(incident, timeline.AsList());
    }

    public async Task<Incident?> SubmitAsync(
        Guid tenantId,
        Guid incidentId,
        Guid actorId,
        CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;

        const string updateSql = """
        UPDATE incidents
        SET status = 'Submitted',
            workflow_state = 'SupervisorReview',
            submitted_at = @Now,
            updated_at = @Now
        WHERE tenant_id = @TenantId
          AND id = @IncidentId
          AND status = 'Draft'
        RETURNING
            id AS Id,
            tenant_id AS TenantId,
            incident_number AS IncidentNumber,
            title AS Title,
            description AS Description,
            incident_type AS IncidentType,
            severity AS Severity,
            status AS Status,
            workflow_state AS WorkflowState,
            occurred_at AS OccurredAt,
            reporter_id AS ReporterId,
            site AS Site,
            department AS Department,
            created_at AS CreatedAt,
            updated_at AS UpdatedAt,
            submitted_at AS SubmittedAt;
        """;

        const string timelineSql = """
        INSERT INTO incident_timeline (
            id, tenant_id, incident_id, event_type, description,
            performed_by, occurred_at)
        VALUES (
            @TimelineId, @TenantId, @IncidentId, 'IncidentSubmitted',
            'Incident submitted and routed to Supervisor Review.',
            @ActorId, @Now);
        """;

        await using var connection = CreateConnection();
        await connection.OpenAsync(cancellationToken);
        await using var transaction =
            await connection.BeginTransactionAsync(cancellationToken);

        var incident = await connection.QuerySingleOrDefaultAsync<Incident>(
            new CommandDefinition(
                updateSql,
                new { TenantId = tenantId, IncidentId = incidentId, Now = now },
                transaction,
                cancellationToken: cancellationToken));

        if (incident is null)
        {
            await transaction.RollbackAsync(cancellationToken);
            return null;
        }

        await connection.ExecuteAsync(new CommandDefinition(
            timelineSql,
            new
            {
                TimelineId = Guid.NewGuid(),
                TenantId = tenantId,
                IncidentId = incidentId,
                ActorId = actorId,
                Now = now
            },
            transaction,
            cancellationToken: cancellationToken));

        await transaction.CommitAsync(cancellationToken);
        return incident;
    }
}
