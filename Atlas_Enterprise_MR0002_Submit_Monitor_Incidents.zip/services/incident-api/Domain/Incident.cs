namespace Atlas.IncidentApi.Domain;

public sealed record Incident(
    Guid Id,
    Guid TenantId,
    string IncidentNumber,
    string Title,
    string Description,
    string IncidentType,
    string Severity,
    string Status,
    string WorkflowState,
    DateTimeOffset OccurredAt,
    Guid ReporterId,
    string Site,
    string Department,
    DateTimeOffset CreatedAt,
    DateTimeOffset UpdatedAt,
    DateTimeOffset? SubmittedAt);

public sealed record IncidentTimelineEvent(
    Guid Id,
    Guid IncidentId,
    string EventType,
    string Description,
    Guid PerformedBy,
    DateTimeOffset OccurredAt);

public sealed record IncidentDetails(
    Incident Incident,
    IReadOnlyList<IncidentTimelineEvent> Timeline);
