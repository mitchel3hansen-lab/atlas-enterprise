# Atlas Enterprise

Atlas is a modular operational intelligence platform for incident management, enterprise risk, compliance, EHS, and operational resilience.

## Platform foundation

MR-0018A adds reusable services for:

- Module registration
- Durable platform events
- Rules
- Background jobs
- Provider-neutral files
- Universal search
- Shared extension contracts

This foundation supports the next major modules without duplicating infrastructure.

## Start

```bash
cp .env.example .env
docker compose up --build -d
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger
