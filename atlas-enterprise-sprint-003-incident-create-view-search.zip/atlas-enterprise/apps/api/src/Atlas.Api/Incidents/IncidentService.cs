using System.Text.Json;
using Atlas.Api.KnowledgeGraph;
using Atlas.Api.Rules;
using Atlas.Api.Timeline;

namespace Atlas.Api.Incidents;

public sealed class IncidentService(
    IIncidentRepository repository,
    TimelineService timeline,
    RulesEngine rules,
    KnowledgeGraphService graph,
    ILogger<IncidentService> logger)
{
    private static readonly IReadOnlyDictionary<IncidentStatus, IncidentStatus[]> AllowedTransitions =
        new Dictionary<IncidentStatus, IncidentStatus[]>
        {
            [IncidentStatus.Draft] = [IncidentStatus.Submitted],
            [IncidentStatus.Submitted] = [IncidentStatus.Assigned],
            [IncidentStatus.Assigned] = [IncidentStatus.Investigating],
            [IncidentStatus.Investigating] = [IncidentStatus.Verification],
            [IncidentStatus.Verification] = [IncidentStatus.Closed],
            [IncidentStatus.Closed] = []
        };

    public async Task<IncidentTransitionResult> CreateAsync(Guid tenantId, Guid actorId, string? actorName, CreateIncidentRequest request, string correlationId, CancellationToken ct)
    {
        Validate(request);
        var now = DateTimeOffset.UtcNow;
        var sequence = await repository.NextSequenceAsync(tenantId, now.Year, ct);
        var incident = new IncidentRecord(Guid.NewGuid(), tenantId, $"INC-{now.Year}-{sequence:00000}", request.Title.Trim(), request.Description.Trim(), request.OccurredAt,
            request.FacilityId, request.DepartmentId, request.IncidentType, request.Severity, IncidentStatus.Draft, request.ImmediateActions?.Trim(), actorId, null, request.EmployeeId, request.EquipmentId, request.ChemicalId,
            CalculateRisk(request.Severity), request.Severity is IncidentSeverity.High or IncidentSeverity.Critical, null,
            request.Tags?.Distinct(StringComparer.OrdinalIgnoreCase).ToArray() ?? [], request.Metadata ?? new Dictionary<string, JsonElement>(), now, now, 1);
        incident = await repository.AddAsync(incident, ct);

        var node = await graph.EnsureNodeAsync(tenantId, actorId, new CreateNodeRequest("Incident", incident.Id, $"{incident.Number}: {incident.Title}",
            new Dictionary<string, object?> { ["status"] = incident.Status.ToString(), ["severity"] = incident.Severity.ToString(), ["riskScore"] = incident.RiskScore }, tenantId), ct);
        var timelineEntry = await timeline.AppendAsync(tenantId, TimelineRequest(incident, "Incident.Created", TimelineCategory.UserAction, "Incident created", actorId, actorName, correlationId, request.Description), ct);
        var executions = await ExecuteRulesAsync(incident, "Incident.Created", actorId, correlationId, ct);
        logger.LogInformation("Incident {IncidentNumber} created for tenant {TenantId}", incident.Number, tenantId);
        return new(incident, executions.Select(x => x.Id).ToArray(), [timelineEntry.Id], node.Id, correlationId);
    }

    public async Task<IncidentRecord> GetAsync(Guid tenantId, Guid id, CancellationToken ct)
        => await repository.GetAsync(tenantId, id, ct) ?? throw new KeyNotFoundException("Incident not found.");

    public async Task<IncidentPage> SearchAsync(Guid tenantId, IncidentSearchQuery query, CancellationToken ct)
    {
        var normalized = query with { Limit = Math.Clamp(query.Limit, 1, 200), Offset = Math.Max(0, query.Offset) };
        return new(await repository.SearchAsync(tenantId, normalized, ct), await repository.CountAsync(tenantId, normalized, ct), normalized.Limit, normalized.Offset);
    }

    public async Task<IncidentRecord> UpdateAsync(Guid tenantId, Guid id, UpdateIncidentRequest request, CancellationToken ct)
    {
        var current = await GetAsync(tenantId, id, ct);
        if (current.Status != IncidentStatus.Draft) throw new InvalidOperationException("Only draft incidents can be edited.");
        var updated = current with { Title = request.Title.Trim(), Description = request.Description.Trim(), OccurredAt = request.OccurredAt, FacilityId = request.FacilityId, DepartmentId = request.DepartmentId,
            IncidentType = request.IncidentType, Severity = request.Severity, ImmediateActions = request.ImmediateActions?.Trim(), EmployeeId = request.EmployeeId, EquipmentId = request.EquipmentId, ChemicalId = request.ChemicalId,
            RiskScore = CalculateRisk(request.Severity), CapaRequired = request.Severity is IncidentSeverity.High or IncidentSeverity.Critical,
            Tags = request.Tags?.Distinct(StringComparer.OrdinalIgnoreCase).ToArray() ?? [], Metadata = request.Metadata ?? new Dictionary<string, JsonElement>() };
        return await repository.ReplaceAsync(updated, request.ExpectedVersion, ct);
    }

    public async Task<IncidentTransitionResult> TransitionAsync(Guid tenantId, Guid id, TransitionIncidentRequest request, string correlationId, CancellationToken ct)
    {
        var current = await GetAsync(tenantId, id, ct);
        if (!AllowedTransitions[current.Status].Contains(request.TargetStatus)) throw new InvalidOperationException($"Transition from {current.Status} to {request.TargetStatus} is not allowed.");
        if (request.TargetStatus == IncidentStatus.Assigned && request.AssigneeId is null) throw new ArgumentException("An assignee is required when assigning an incident.");
        var updated = current with { Status = request.TargetStatus, AssigneeId = request.AssigneeId ?? current.AssigneeId };
        updated = await repository.ReplaceAsync(updated, request.ExpectedVersion, ct);
        var title = $"Incident moved to {updated.Status}";
        var entry = await timeline.AppendAsync(tenantId, TimelineRequest(updated, $"Incident.{updated.Status}", TimelineCategory.Workflow, title, request.ActorId, request.ActorDisplayName, correlationId, request.Comment), ct);
        var executions = await ExecuteRulesAsync(updated, $"Incident.{updated.Status}", request.ActorId, correlationId, ct);
        var node = await graph.EnsureNodeAsync(tenantId, request.ActorId, new CreateNodeRequest("Incident", updated.Id, $"{updated.Number}: {updated.Title}",
            new Dictionary<string, object?> { ["status"] = updated.Status.ToString(), ["severity"] = updated.Severity.ToString(), ["riskScore"] = updated.RiskScore }, tenantId), ct);
        return new(updated, executions.Select(x => x.Id).ToArray(), [entry.Id], node.Id, correlationId);
    }

    private async Task<IReadOnlyList<RuleExecution>> ExecuteRulesAsync(IncidentRecord incident, string eventName, Guid actorId, string correlationId, CancellationToken ct)
    {
        using var document = JsonDocument.Parse(JsonSerializer.Serialize(new { incident.Id, incident.Number, severity = incident.Severity.ToString(), status = incident.Status.ToString(), incident.RiskScore, incident.CapaRequired, incident.FacilityId, incident.DepartmentId, incidentType = incident.IncidentType.ToString() }));
        return await rules.ProcessAsync(new RuleEvent(incident.TenantId, eventName, correlationId, incident.Id, "Incident", document.RootElement.Clone(), actorId), ct);
    }

    private static AppendTimelineEntryRequest TimelineRequest(IncidentRecord incident, string eventType, TimelineCategory category, string title, Guid actorId, string? actorName, string correlationId, string? description)
        => new("Incident", incident.Id, eventType, category, title, description, actorId, actorName, "atlas.incidents", correlationId, null, DateTimeOffset.UtcNow,
            new Dictionary<string, JsonElement> { ["number"] = JsonSerializer.SerializeToElement(incident.Number), ["status"] = JsonSerializer.SerializeToElement(incident.Status.ToString()), ["severity"] = JsonSerializer.SerializeToElement(incident.Severity.ToString()), ["incidentType"] = JsonSerializer.SerializeToElement(incident.IncidentType.ToString()), ["riskScore"] = JsonSerializer.SerializeToElement(incident.RiskScore) });

    private static int CalculateRisk(IncidentSeverity severity) => severity switch { IncidentSeverity.Low => 20, IncidentSeverity.Moderate => 45, IncidentSeverity.High => 70, IncidentSeverity.Critical => 95, _ => 0 };
    private static void Validate(CreateIncidentRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Title)) throw new ArgumentException("Title is required.");
        if (request.Title.Length > 200) throw new ArgumentException("Title cannot exceed 200 characters.");
        if (string.IsNullOrWhiteSpace(request.Description)) throw new ArgumentException("Description is required.");
        if (request.FacilityId == Guid.Empty) throw new ArgumentException("FacilityId is required.");
        if (request.OccurredAt > DateTimeOffset.UtcNow.AddMinutes(5)) throw new ArgumentException("OccurredAt cannot be materially in the future.");
    }
}
