using System.Collections.Concurrent;

namespace Atlas.Api.Incidents;

public sealed class InMemoryIncidentRepository : IIncidentRepository
{
    private readonly ConcurrentDictionary<(Guid TenantId, Guid Id), IncidentRecord> _items = new();
    private readonly ConcurrentDictionary<(Guid TenantId, int Year), int> _sequences = new();

    public Task<IncidentRecord?> GetAsync(Guid tenantId, Guid id, CancellationToken cancellationToken)
        => Task.FromResult(_items.TryGetValue((tenantId, id), out var item) ? item : null);

    public Task<IncidentRecord> AddAsync(IncidentRecord incident, CancellationToken cancellationToken)
    {
        if (!_items.TryAdd((incident.TenantId, incident.Id), incident))
            throw new InvalidOperationException("Incident already exists.");
        return Task.FromResult(incident);
    }

    public Task<IncidentRecord> ReplaceAsync(IncidentRecord incident, long expectedVersion, CancellationToken cancellationToken)
    {
        var key = (incident.TenantId, incident.Id);
        if (!_items.TryGetValue(key, out var current)) throw new KeyNotFoundException("Incident not found.");
        if (current.Version != expectedVersion) throw new InvalidOperationException("Incident was modified by another user.");
        var updated = incident with { Version = expectedVersion + 1, UpdatedAt = DateTimeOffset.UtcNow };
        if (!_items.TryUpdate(key, updated, current)) throw new InvalidOperationException("Incident update conflict.");
        return Task.FromResult(updated);
    }

    public Task<IReadOnlyList<IncidentRecord>> SearchAsync(Guid tenantId, IncidentSearchQuery query, CancellationToken cancellationToken)
    {
        var items = Apply(_items.Values.Where(x => x.TenantId == tenantId), query)
            .OrderByDescending(x => x.OccurredAt).Skip(query.Offset).Take(query.Limit).ToArray();
        return Task.FromResult<IReadOnlyList<IncidentRecord>>(items);
    }

    public Task<int> CountAsync(Guid tenantId, IncidentSearchQuery query, CancellationToken cancellationToken)
        => Task.FromResult(Apply(_items.Values.Where(x => x.TenantId == tenantId), query).Count());

    public Task<int> NextSequenceAsync(Guid tenantId, int year, CancellationToken cancellationToken)
        => Task.FromResult(_sequences.AddOrUpdate((tenantId, year), 1, (_, value) => value + 1));

    private static IEnumerable<IncidentRecord> Apply(IEnumerable<IncidentRecord> source, IncidentSearchQuery query)
    {
        if (!string.IsNullOrWhiteSpace(query.Search))
        {
            var search = query.Search.Trim();
            source = source.Where(x => x.Number.Contains(search, StringComparison.OrdinalIgnoreCase)
                || x.Title.Contains(search, StringComparison.OrdinalIgnoreCase)
                || x.Description.Contains(search, StringComparison.OrdinalIgnoreCase));
        }
        if (query.Status is not null) source = source.Where(x => x.Status == query.Status);
        if (query.Severity is not null) source = source.Where(x => x.Severity == query.Severity);
        if (query.IncidentType is not null) source = source.Where(x => x.IncidentType == query.IncidentType);
        if (query.FacilityId is not null) source = source.Where(x => x.FacilityId == query.FacilityId);
        if (query.DepartmentId is not null) source = source.Where(x => x.DepartmentId == query.DepartmentId);
        if (query.OccurredFrom is not null) source = source.Where(x => x.OccurredAt >= query.OccurredFrom);
        if (query.OccurredTo is not null) source = source.Where(x => x.OccurredAt <= query.OccurredTo);
        return source;
    }
}
