# Changelog

All notable changes to the canonical Atlas Enterprise repository will be recorded here.

The project follows Semantic Versioning after the first public release. Historical package notes are retained under `docs/archive/releases/` for traceability and are not treated as independent repositories.

## Unreleased

### Added

- Canonical repository governance and Apache 2.0 licensing
- Root development environment with PostgreSQL, Redis, Mailpit, API, and web services
- GitHub Actions continuous-integration workflow
- Branch, release, and architecture-decision governance

### Changed

- Consolidated historical package artifacts into a single source-of-truth repository

## [Unreleased] - Shared Kernel Sprint 001

### Added
- `Atlas.SharedKernel` class library with entity, aggregate, audit, event, result, error, value-object, context, clock, ID-generation, and specification primitives.
- Dedicated Shared Kernel unit-test project with code-coverage collection.
- ADR-0002 and Shared Kernel developer documentation.

### Changed
- API now references the canonical Shared Kernel project.
- Solution and CI include Shared Kernel build and tests.

## [Unreleased]

### Added
- Rotating refresh sessions and refresh endpoint.
- Access-token revocation on logout.
- Configurable failed-login lockout.
- Shared password policy and identity-security tests.
- V024 identity-hardening migration and rollback.


## Sprint 003 — Incident Management Milestone 1
Create, search, and view tenant-scoped incidents with durable numbering, PostgreSQL search, timeline creation, and a React incident register.
