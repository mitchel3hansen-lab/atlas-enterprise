# Atlas Enterprise v0.22.0 — PostgreSQL Persistence & Transactional Outbox Alpha

This release introduces durable incident persistence and the runtime infrastructure for reliable event delivery: outbox, inbox, dead-letter storage, concurrent worker claiming, bounded retry, event envelopes, migration/rollback assets, tests, ADR, PRD, and deployment/UAT documentation.

The event publisher is intentionally a logging adapter in this alpha. Incident persistence is PostgreSQL-backed; other legacy engine repositories remain in-memory pending subsequent migrations.
