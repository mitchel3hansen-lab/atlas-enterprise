using System.Text.Json;
using Atlas.Api.Runtime;
using Xunit;
namespace Atlas.Api.Tests.Runtime;
public sealed class OutboxContractTests
{
 [Fact] public void MessageCarriesVersionAndCorrelation()
 {
   using var payload=JsonDocument.Parse("{\"incidentId\":\"00000000-0000-0000-0000-000000000001\"}");
   using var headers=JsonDocument.Parse("{}");
   var m=new OutboxMessage(Guid.NewGuid(),Guid.NewGuid(),"Incident.Created",1,"Incident",Guid.NewGuid(),"corr-1",null,payload,headers,DateTimeOffset.UtcNow,DateTimeOffset.UtcNow,0);
   Assert.Equal(1,m.EventVersion); Assert.Equal("corr-1",m.CorrelationId); Assert.Equal("Incident.Created",m.EventType);
 }
}
