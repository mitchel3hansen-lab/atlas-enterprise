# v0.22.0 Deployment Runbook

1. Back up PostgreSQL.
2. Apply migrations through `V022__postgresql_persistence_and_outbox.sql`.
3. Confirm `runtime.outbox_messages`, `runtime.inbox_messages`, and `runtime.dead_letter_messages` exist.
4. Deploy API instances with the same connection string and unique machine/container identities.
5. Verify `/health` and inspect logs for the dispatcher startup.
6. Insert a test outbox message and verify `processed_at` is populated.
7. Roll back only after stopping all dispatchers; apply `R022__postgresql_persistence_and_outbox.sql`.

The logging publisher is a development adapter. Configure a durable broker adapter before production use.
