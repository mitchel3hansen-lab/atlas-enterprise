# v0.22.0 Persistence & Outbox Alpha PRD

## User outcome
Operational records survive application restarts and committed changes produce recoverable integration events.

## Scope
PostgreSQL incident repository, optimistic concurrency, outbox/inbox/dead-letter schemas, background dispatcher, locking, retry, versioned event envelope, telemetry-ready logs, migration and rollback.

## Acceptance criteria
1. Incident CRUD uses PostgreSQL.
2. A worker may safely run concurrently with other workers.
3. Failed messages retry with backoff and eventually dead-letter.
4. Processed messages are not claimed again.
5. Every message includes tenant, aggregate, version, correlation, and payload.
