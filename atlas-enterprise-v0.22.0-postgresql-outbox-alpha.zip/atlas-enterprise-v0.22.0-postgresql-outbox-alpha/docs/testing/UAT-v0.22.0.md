# v0.22.0 UAT

- Restart API and verify incidents remain available.
- Submit concurrent updates with the same version; verify one fails.
- Run two dispatcher instances; verify each message is claimed once at a time.
- Force publisher failure; verify attempt count and delayed retry increase.
- Exceed maximum attempts; verify the message moves to dead letter.
- Verify tenant A cannot read tenant B incidents.
