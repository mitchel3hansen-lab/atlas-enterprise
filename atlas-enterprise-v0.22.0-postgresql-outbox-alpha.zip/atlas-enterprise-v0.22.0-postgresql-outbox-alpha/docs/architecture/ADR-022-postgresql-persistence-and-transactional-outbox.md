# ADR-022: PostgreSQL Persistence and Transactional Outbox

## Status
Accepted for v0.22.0 alpha.

## Decision
Atlas will use PostgreSQL as the durable system of record and a transactional outbox for domain-event delivery. Writers persist aggregate changes and outbox records in the same database transaction. Dispatchers claim rows with `FOR UPDATE SKIP LOCKED`, apply bounded exponential retry, and move exhausted messages to a dead-letter table.

## Consequences
- Event delivery is at least once; consumers must be idempotent.
- Ordering is guaranteed only within the chosen aggregate strategy, not globally.
- The alpha publisher logs events; production adapters may target RabbitMQ, Kafka, Azure Service Bus, or another broker.
- Database migrations must be applied before the worker starts.
