using System.Text.Json;
using Npgsql;
using NpgsqlTypes;
namespace Atlas.Api.Runtime;

public sealed class PostgresOutboxStore(IConfiguration configuration) : IOutboxStore
{
    private string ConnectionString => configuration.GetConnectionString("Atlas")
        ?? throw new InvalidOperationException("ConnectionStrings:Atlas is required.");

    public async Task EnqueueAsync(OutboxMessage m, CancellationToken ct)
    {
        await using var c = new NpgsqlConnection(ConnectionString); await c.OpenAsync(ct);
        await using var cmd = new NpgsqlCommand("""
            INSERT INTO runtime.outbox_messages
            (id,tenant_id,event_type,event_version,aggregate_type,aggregate_id,correlation_id,causation_id,payload,headers,occurred_at,available_at)
            VALUES (@id,@tenant,@type,@version,@aggregateType,@aggregateId,@correlation,@causation,@payload,@headers,@occurred,@available)
            """, c);
        cmd.Parameters.AddWithValue("id", m.Id); cmd.Parameters.AddWithValue("tenant", m.TenantId);
        cmd.Parameters.AddWithValue("type", m.EventType); cmd.Parameters.AddWithValue("version", m.EventVersion);
        cmd.Parameters.AddWithValue("aggregateType", m.AggregateType); cmd.Parameters.AddWithValue("aggregateId", m.AggregateId);
        cmd.Parameters.AddWithValue("correlation", (object?)m.CorrelationId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("causation", (object?)m.CausationId ?? DBNull.Value);
        cmd.Parameters.Add("payload", NpgsqlDbType.Jsonb).Value = m.Payload.RootElement.GetRawText();
        cmd.Parameters.Add("headers", NpgsqlDbType.Jsonb).Value = m.Headers.RootElement.GetRawText();
        cmd.Parameters.AddWithValue("occurred", m.OccurredAt); cmd.Parameters.AddWithValue("available", m.AvailableAt);
        await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task<IReadOnlyList<OutboxMessage>> ClaimBatchAsync(string workerId, int batchSize, TimeSpan lockFor, CancellationToken ct)
    {
        var result = new List<OutboxMessage>();
        await using var c = new NpgsqlConnection(ConnectionString); await c.OpenAsync(ct);
        await using var tx = await c.BeginTransactionAsync(ct);
        await using var cmd = new NpgsqlCommand("""
            WITH candidate AS (
              SELECT id FROM runtime.outbox_messages
              WHERE processed_at IS NULL AND available_at <= now()
                AND (locked_until IS NULL OR locked_until < now())
              ORDER BY occurred_at FOR UPDATE SKIP LOCKED LIMIT @limit
            )
            UPDATE runtime.outbox_messages o
            SET locked_by=@worker, locked_until=now()+@lock, attempt_count=attempt_count+1
            FROM candidate c WHERE o.id=c.id
            RETURNING o.id,o.tenant_id,o.event_type,o.event_version,o.aggregate_type,o.aggregate_id,
              o.correlation_id,o.causation_id,o.payload::text,o.headers::text,o.occurred_at,o.available_at,o.attempt_count
            """, c, tx);
        cmd.Parameters.AddWithValue("limit", batchSize); cmd.Parameters.AddWithValue("worker", workerId);
        cmd.Parameters.AddWithValue("lock", lockFor);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct)) result.Add(new OutboxMessage(r.GetGuid(0),r.GetGuid(1),r.GetString(2),r.GetInt32(3),r.GetString(4),r.GetGuid(5),r.IsDBNull(6)?null:r.GetString(6),r.IsDBNull(7)?null:r.GetString(7),JsonDocument.Parse(r.GetString(8)),JsonDocument.Parse(r.GetString(9)),r.GetFieldValue<DateTimeOffset>(10),r.GetFieldValue<DateTimeOffset>(11),r.GetInt32(12)));
        await r.CloseAsync(); await tx.CommitAsync(ct); return result;
    }

    public Task MarkProcessedAsync(Guid id, CancellationToken ct) => ExecuteAsync("UPDATE runtime.outbox_messages SET processed_at=now(),locked_by=NULL,locked_until=NULL,last_error=NULL WHERE id=@id", id, null, ct);

    public async Task MarkFailedAsync(Guid id, string error, int maxAttempts, CancellationToken ct)
    {
        await using var c = new NpgsqlConnection(ConnectionString); await c.OpenAsync(ct);
        await using var tx = await c.BeginTransactionAsync(ct);
        await using var dead = new NpgsqlCommand("""
          INSERT INTO runtime.dead_letter_messages(id,original_message_id,tenant_id,event_type,payload,attempts,last_error)
          SELECT gen_random_uuid(),id,tenant_id,event_type,payload,attempt_count,@error FROM runtime.outbox_messages
          WHERE id=@id AND attempt_count>=@max ON CONFLICT DO NOTHING;
          DELETE FROM runtime.outbox_messages WHERE id=@id AND attempt_count>=@max;
          UPDATE runtime.outbox_messages SET last_error=@error,locked_by=NULL,locked_until=NULL,
            available_at=now() + make_interval(secs => LEAST(300, power(2, attempt_count)::int))
          WHERE id=@id;
        """, c, tx);
        dead.Parameters.AddWithValue("id", id); dead.Parameters.AddWithValue("error", error[..Math.Min(error.Length,4000)]); dead.Parameters.AddWithValue("max", maxAttempts);
        await dead.ExecuteNonQueryAsync(ct); await tx.CommitAsync(ct);
    }

    private async Task ExecuteAsync(string sql, Guid id, string? error, CancellationToken ct)
    { await using var c=new NpgsqlConnection(ConnectionString); await c.OpenAsync(ct); await using var cmd=new NpgsqlCommand(sql,c); cmd.Parameters.AddWithValue("id",id); if(error is not null)cmd.Parameters.AddWithValue("error",error); await cmd.ExecuteNonQueryAsync(ct); }
}
