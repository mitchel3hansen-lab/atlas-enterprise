using System.Text.Json;
namespace Atlas.Api.Runtime;

public sealed record OutboxMessage(
    Guid Id, Guid TenantId, string EventType, int EventVersion,
    string AggregateType, Guid AggregateId, string? CorrelationId,
    string? CausationId, JsonDocument Payload, JsonDocument Headers,
    DateTimeOffset OccurredAt, DateTimeOffset AvailableAt, int AttemptCount);

public sealed record OutboxOptions
{
    public const string SectionName = "Outbox";
    public int BatchSize { get; init; } = 50;
    public int PollIntervalMilliseconds { get; init; } = 1000;
    public int LockSeconds { get; init; } = 30;
    public int MaxAttempts { get; init; } = 8;
}

public interface IOutboxWriter
{
    Task EnqueueAsync(OutboxMessage message, CancellationToken cancellationToken);
}

public interface IOutboxStore : IOutboxWriter
{
    Task<IReadOnlyList<OutboxMessage>> ClaimBatchAsync(string workerId, int batchSize, TimeSpan lockFor, CancellationToken cancellationToken);
    Task MarkProcessedAsync(Guid id, CancellationToken cancellationToken);
    Task MarkFailedAsync(Guid id, string error, int maxAttempts, CancellationToken cancellationToken);
}

public interface IAtlasEventPublisher
{
    Task PublishAsync(OutboxMessage message, CancellationToken cancellationToken);
}
