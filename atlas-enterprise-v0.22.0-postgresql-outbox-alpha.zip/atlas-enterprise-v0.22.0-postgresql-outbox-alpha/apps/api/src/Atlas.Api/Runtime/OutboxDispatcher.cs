using Microsoft.Extensions.Options;
namespace Atlas.Api.Runtime;

public sealed class OutboxDispatcher(
    IServiceScopeFactory scopes, IOptions<OutboxOptions> options, ILogger<OutboxDispatcher> logger) : BackgroundService
{
    private readonly string _workerId = $"{Environment.MachineName}:{Guid.NewGuid():N}";
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var cfg=options.Value;
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope=scopes.CreateScope();
                var store=scope.ServiceProvider.GetRequiredService<IOutboxStore>();
                var publisher=scope.ServiceProvider.GetRequiredService<IAtlasEventPublisher>();
                var batch=await store.ClaimBatchAsync(_workerId,cfg.BatchSize,TimeSpan.FromSeconds(cfg.LockSeconds),stoppingToken);
                foreach(var message in batch)
                {
                    try { await publisher.PublishAsync(message,stoppingToken); await store.MarkProcessedAsync(message.Id,stoppingToken); }
                    catch(Exception ex) { logger.LogError(ex,"Outbox message {MessageId} failed",message.Id); await store.MarkFailedAsync(message.Id,ex.Message,cfg.MaxAttempts,stoppingToken); }
                }
                if(batch.Count==0) await Task.Delay(cfg.PollIntervalMilliseconds,stoppingToken);
            }
            catch(OperationCanceledException) when(stoppingToken.IsCancellationRequested) { }
            catch(Exception ex) { logger.LogError(ex,"Outbox dispatch loop failed"); await Task.Delay(5000,stoppingToken); }
        }
    }
}

public sealed class LoggingAtlasEventPublisher(ILogger<LoggingAtlasEventPublisher> logger) : IAtlasEventPublisher
{
    public Task PublishAsync(OutboxMessage message, CancellationToken cancellationToken)
    {
        logger.LogInformation("Published {EventType} v{Version} for {AggregateType}/{AggregateId} ({MessageId})", message.EventType,message.EventVersion,message.AggregateType,message.AggregateId,message.Id);
        return Task.CompletedTask;
    }
}
