DROP TABLE IF EXISTS runtime.dead_letter_messages;
DROP TABLE IF EXISTS runtime.inbox_messages;
DROP TABLE IF EXISTS runtime.outbox_messages;
DROP FUNCTION IF EXISTS runtime.set_updated_at();
ALTER TABLE IF EXISTS atlas.incidents DROP COLUMN IF EXISTS concurrency_token;
