CREATE SCHEMA IF NOT EXISTS runtime;

CREATE TABLE IF NOT EXISTS runtime.outbox_messages (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    event_type varchar(200) NOT NULL,
    event_version integer NOT NULL DEFAULT 1,
    aggregate_type varchar(100) NOT NULL,
    aggregate_id uuid NOT NULL,
    correlation_id varchar(100),
    causation_id varchar(100),
    payload jsonb NOT NULL,
    headers jsonb NOT NULL DEFAULT '{}'::jsonb,
    occurred_at timestamptz NOT NULL,
    available_at timestamptz NOT NULL,
    locked_until timestamptz,
    locked_by varchar(200),
    attempt_count integer NOT NULL DEFAULT 0,
    processed_at timestamptz,
    last_error text,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_outbox_dispatch ON runtime.outbox_messages(processed_at, available_at, locked_until);
CREATE INDEX IF NOT EXISTS ix_outbox_tenant_aggregate ON runtime.outbox_messages(tenant_id, aggregate_type, aggregate_id);

CREATE TABLE IF NOT EXISTS runtime.inbox_messages (
    consumer_name varchar(200) NOT NULL,
    message_id uuid NOT NULL,
    processed_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (consumer_name, message_id)
);

CREATE TABLE IF NOT EXISTS runtime.dead_letter_messages (
    id uuid PRIMARY KEY,
    original_message_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    event_type varchar(200) NOT NULL,
    payload jsonb NOT NULL,
    attempts integer NOT NULL,
    last_error text NOT NULL,
    failed_at timestamptz NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION runtime.set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

ALTER TABLE IF EXISTS atlas.incidents ADD COLUMN IF NOT EXISTS concurrency_token uuid NOT NULL DEFAULT gen_random_uuid();
