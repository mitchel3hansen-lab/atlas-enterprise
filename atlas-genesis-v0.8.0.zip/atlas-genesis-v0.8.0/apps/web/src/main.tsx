import React from 'react';
import ReactDOM from 'react-dom/client';
import './styles/app.css';

const metrics = [
  ['Open incidents', '3'],
  ['Open CAPAs', '11'],
  ['Inspection completion', '92%'],
  ['Training compliance', '88%']
];

function App() {
  return (
    <div className="shell">
      <aside>
        <h1>ATLAS</h1>
        <p>Operational Intelligence</p>
        <nav>
          <a className="active">Command Center</a>
          <a>Safety</a><a>Inspections</a><a>Learning</a><a>Ready</a><a>Administration</a>
        </nav>
      </aside>
      <main>
        <header><div><span>Genesis Alpha</span><h2>Safety Command Center</h2></div><button>Report an event</button></header>
        <section className="metrics">
          {metrics.map(([label, value]) => <article key={label}><small>{label}</small><strong>{value}</strong></article>)}
        </section>
        <section className="panel">
          <div><h3>Priority work</h3><p>Records requiring management attention and timely closure.</p></div>
          <table><thead><tr><th>Record</th><th>Type</th><th>Owner</th><th>Status</th></tr></thead>
          <tbody><tr><td>Forklift aisle visibility</td><td>Hazard</td><td>Warehouse</td><td>In review</td></tr><tr><td>Machine guarding verification</td><td>CAPA</td><td>Operations</td><td>Due soon</td></tr></tbody></table>
        </section>
      </main>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>);
