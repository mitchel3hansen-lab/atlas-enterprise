using Atlas.Api.Domain;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Infrastructure;

public sealed class AtlasDbContext(DbContextOptions<AtlasDbContext> options) : DbContext(options)
{
    public DbSet<Organization> Organizations => Set<Organization>();
    public DbSet<Facility> Facilities => Set<Facility>();
    public DbSet<SafetyRecord> SafetyRecords => Set<SafetyRecord>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Organization>().HasKey(x => x.Id);
        modelBuilder.Entity<Organization>().HasIndex(x => x.Slug).IsUnique();

        modelBuilder.Entity<Facility>().HasKey(x => x.Id);
        modelBuilder.Entity<Facility>()
            .HasOne<Organization>()
            .WithMany()
            .HasForeignKey(x => x.OrganizationId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<SafetyRecord>().HasKey(x => x.Id);
        modelBuilder.Entity<SafetyRecord>()
            .HasIndex(x => new { x.OrganizationId, x.RecordType, x.Status });
    }
}
