namespace Atlas.Api.Domain;

public sealed record Organization(Guid Id, string Name, string Slug, DateTimeOffset CreatedAtUtc);

public sealed record Facility(
    Guid Id,
    Guid OrganizationId,
    string Name,
    string? TimeZone,
    DateTimeOffset CreatedAtUtc);

public sealed record SafetyRecord(
    Guid Id,
    Guid OrganizationId,
    Guid? FacilityId,
    string RecordType,
    string Title,
    string Status,
    string Severity,
    DateTimeOffset OccurredAtUtc,
    DateTimeOffset CreatedAtUtc);
