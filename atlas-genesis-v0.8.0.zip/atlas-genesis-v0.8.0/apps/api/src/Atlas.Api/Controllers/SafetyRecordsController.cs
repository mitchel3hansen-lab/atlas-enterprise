using Atlas.Api.Domain;
using Atlas.Api.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Controllers;

[ApiController]
[Route("api/v1/safety-records")]
public sealed class SafetyRecordsController(AtlasDbContext db, TenantContext tenant) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<SafetyRecord>>> Get(CancellationToken cancellationToken)
    {
        if (tenant.OrganizationId is not Guid organizationId)
            return BadRequest(new ProblemDetails { Title = "Tenant context is required", Detail = "Provide X-Atlas-Organization-Id for the development baseline." });

        var records = await db.SafetyRecords.AsNoTracking()
            .Where(x => x.OrganizationId == organizationId)
            .OrderByDescending(x => x.OccurredAtUtc)
            .ToListAsync(cancellationToken);
        return Ok(records);
    }
}
