using Atlas.Api.Domain;
using Atlas.Api.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Controllers;

[ApiController]
[Route("api/v1/organizations")]
public sealed class OrganizationsController(AtlasDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<Organization>>> Get(CancellationToken cancellationToken)
        => Ok(await db.Organizations.AsNoTracking().OrderBy(x => x.Name).ToListAsync(cancellationToken));

    [HttpPost]
    public async Task<ActionResult<Organization>> Create(CreateOrganizationRequest request, CancellationToken cancellationToken)
    {
        var item = new Organization(Guid.NewGuid(), request.Name.Trim(), request.Slug.Trim().ToLowerInvariant(), DateTimeOffset.UtcNow);
        db.Organizations.Add(item);
        await db.SaveChangesAsync(cancellationToken);
        return CreatedAtAction(nameof(Get), new { id = item.Id }, item);
    }
}

public sealed record CreateOrganizationRequest(string Name, string Slug);
