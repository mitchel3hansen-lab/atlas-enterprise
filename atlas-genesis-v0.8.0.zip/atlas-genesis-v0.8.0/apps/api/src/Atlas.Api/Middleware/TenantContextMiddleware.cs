using Atlas.Api.Infrastructure;

namespace Atlas.Api.Middleware;

public sealed class TenantContextMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context, TenantContext tenant)
    {
        if (context.Request.Headers.TryGetValue("X-Atlas-Organization-Id", out var value)
            && Guid.TryParse(value, out var organizationId))
        {
            tenant.Set(organizationId);
        }

        await next(context);
    }
}
