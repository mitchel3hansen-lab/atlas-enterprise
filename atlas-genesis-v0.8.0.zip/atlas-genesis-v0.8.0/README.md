# ATLAS Genesis v0.8.0

ATLAS is a multi-tenant Operational Intelligence Platform. This repository is the first implementation-ready baseline for the Genesis phase.

## Included

- ASP.NET Core API source baseline
- React + TypeScript web source baseline
- PostgreSQL local development configuration
- Docker Compose orchestration
- GitHub Actions validation workflow
- Product, architecture, governance, and decision records
- Initial health, organization, facility, incident, hazard, CAPA, and inspection contracts

## Quick start

Prerequisites: Docker Desktop with Docker Compose.

```bash
docker compose up --build
```

Services:

- Web: http://localhost:5173
- API: http://localhost:8080
- API health: http://localhost:8080/health
- PostgreSQL: localhost:5432

## Repository map

```text
apps/api        ASP.NET Core API
apps/web        React + TypeScript UI
docs            Product, architecture, governance, ADRs
infrastructure  Deployment and operations assets
tests           Test strategy and future automated suites
```

## Current milestone

Genesis Foundation: establish a cohesive, runnable baseline before adding advanced platform services.
