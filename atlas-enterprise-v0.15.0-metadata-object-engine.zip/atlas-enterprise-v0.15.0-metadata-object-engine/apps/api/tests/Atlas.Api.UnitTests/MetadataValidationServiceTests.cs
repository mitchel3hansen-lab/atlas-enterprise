using System.Text.Json;
using Atlas.Api.Metadata;
using Xunit;

namespace Atlas.Api.UnitTests;

public sealed class MetadataValidationServiceTests
{
    [Fact]
    public void MissingRequiredFieldFailsValidation()
    {
        var definition = Definition(Field("description", FieldType.Text, true, "{}"));
        using var data = JsonDocument.Parse("{}");

        var result = new MetadataValidationService().Validate(definition, data.RootElement);

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, x => x.FieldKey == "description" && x.Code == "required");
    }

    [Fact]
    public void NumericMinimumIsEnforced()
    {
        var definition = Definition(Field("severity", FieldType.Integer, true, "{\"minimum\":1,\"maximum\":5}"));
        using var data = JsonDocument.Parse("{\"severity\":0}");

        var result = new MetadataValidationService().Validate(definition, data.RootElement);

        Assert.Contains(result.Errors, x => x.Code == "minimum");
    }

    [Fact]
    public void ValidPayloadPasses()
    {
        var definition = Definition(
            Field("description", FieldType.Text, true, "{\"minLength\":3}"),
            Field("severity", FieldType.Integer, true, "{\"minimum\":1,\"maximum\":5}"));
        using var data = JsonDocument.Parse("{\"description\":\"Near miss\",\"severity\":2}");

        var result = new MetadataValidationService().Validate(definition, data.RootElement);

        Assert.True(result.IsValid);
    }

    private static ObjectDefinitionVersion Definition(params FieldDefinition[] fields) =>
        new(Guid.NewGuid(), Guid.NewGuid(), 1, DateTimeOffset.UtcNow, fields,
            new[] { new LifecycleStateDefinition("draft", "Draft", "Draft", 0, true, false) });

    private static FieldDefinition Field(string key, FieldType type, bool required, string validation) =>
        new(Guid.NewGuid(), key, key, type, required, false, true, false, 0,
            JsonDocument.Parse(validation), JsonDocument.Parse("{}"), JsonDocument.Parse("[]"));
}
