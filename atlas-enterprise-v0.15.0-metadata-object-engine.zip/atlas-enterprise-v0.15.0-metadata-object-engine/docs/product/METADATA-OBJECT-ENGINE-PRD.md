# Metadata Object Engine PRD

**Epic:** EPIC-METADATA-001  
**Release:** v0.15.0

## Business objective
Allow Atlas administrators to create and evolve operational object types without requiring a new codebase for each module.

## Initial capabilities
- Object definitions and version publication
- Field definitions and validation
- Form and list layouts
- Lifecycle states
- Dynamic records
- Typed relationships
- Record timeline events
- Search indexing
- Permission hooks
- Workflow, evidence, health, risk, and explainability extension points

## Acceptance criteria
1. Draft definitions can be created and edited.
2. Published versions cannot be modified or deleted.
3. Each published definition has exactly one initial lifecycle state.
4. Required and typed field validation is enforced server-side.
5. Numeric, string, and selection constraints are enforced.
6. Records retain the definition version used at creation.
7. Record numbers are unique per tenant and object type.
8. Cross-tenant reads and writes are denied.
9. Every material change appends an immutable timeline event.
10. Search can find records by title and configured searchable fields.
11. Sensitive fields are excluded from ordinary search and logs.
12. Relationship cardinality is enforced.
