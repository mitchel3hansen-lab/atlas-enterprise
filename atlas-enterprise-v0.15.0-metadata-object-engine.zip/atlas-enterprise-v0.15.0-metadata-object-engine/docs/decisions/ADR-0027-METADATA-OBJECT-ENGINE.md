# ADR-0027 — Metadata-Defined Operational Objects

## Status
Accepted for v0.15.0.

## Context
Feature-specific entities create duplicated CRUD, validation, permissions, workflow, timeline, evidence, search, reporting, and integration code.

## Decision
Atlas will implement a shared metadata engine for configurable operational objects.

- Definitions and fields are tenant scoped and versioned.
- Published versions are immutable.
- Dynamic record payloads use JSONB and are validated against the published definition.
- Core identity, ownership, lifecycle, audit, and tenancy remain relational columns.
- Relationships are typed and stored separately from record payloads.
- Object events use the standard `Object.Action` naming convention.
- Sensitive fields are identified in metadata and must be masked or encrypted by policy.
- Formula and computed fields cannot accept direct user writes.

## Consequences
New modules can be delivered primarily through configuration, while high-volume or regulated domains may still use specialized projections or bounded-context services.
