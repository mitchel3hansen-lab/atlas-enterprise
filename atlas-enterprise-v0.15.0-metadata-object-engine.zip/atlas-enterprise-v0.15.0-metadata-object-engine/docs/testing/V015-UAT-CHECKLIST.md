# Metadata Object Engine UAT

- [ ] Create a draft definition.
- [ ] Add, reorder, and remove fields before publication.
- [ ] Configure string and numeric validation.
- [ ] Configure one initial and one terminal state.
- [ ] Publish version 1.
- [ ] Confirm published version is immutable.
- [ ] Create a valid Incident record.
- [ ] Reject a record missing required fields.
- [ ] Reject an invalid severity value.
- [ ] Verify record retains definition version 1.
- [ ] Publish version 2 without changing version 1 records.
- [ ] Create a typed relationship.
- [ ] Verify timeline event creation.
- [ ] Search by title and searchable data.
- [ ] Verify tenant-boundary denial.
- [ ] Verify sensitive values are absent from logs and search.
- [ ] Verify keyboard operation of the definition designer.
