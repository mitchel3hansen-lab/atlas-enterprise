# v0.15 Deployment Runbook

1. Confirm v0.14 is integrated and tests pass.
2. Back up PostgreSQL.
3. Apply `V015__metadata_object_engine.sql` in staging.
4. Register metadata services, repositories, permissions, and exception mapping.
5. Ensure `MetadataValidationException` maps to HTTP 422.
6. Import the sample Incident definition as a draft.
7. Publish version 1 after validation.
8. Create, read, update, search, and relate test records.
9. Verify optimistic concurrency and record-number uniqueness.
10. Verify cross-tenant access denial.
11. Verify published versions reject mutation.
12. Complete UAT and promote through standard release gates.

## Rollback
Use the rollback script only when no controlled records depend on v0.15. In production, prefer a forward fix and preserve published definitions and records.
