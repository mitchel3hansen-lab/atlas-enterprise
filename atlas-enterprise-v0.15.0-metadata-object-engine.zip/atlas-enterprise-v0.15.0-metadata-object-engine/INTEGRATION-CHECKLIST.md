# v0.15 Integration Checklist

- [ ] Create `feature/metadata/object-engine`.
- [ ] Apply V015 migration.
- [ ] Add domain, validation, service, repository, and controller files.
- [ ] Implement `IMetadataRepository` with tenant predicates on every query.
- [ ] Register permissions: `metadata.definitions.admin`, `metadata.records.create`, `metadata.records.read`, `metadata.records.update`, `metadata.relationships.manage`.
- [ ] Map validation errors to HTTP 422 and concurrency conflicts to HTTP 409.
- [ ] Add audit and outbox events for definition publication and record mutations.
- [ ] Exclude sensitive fields from logs, search, exports, and AI context unless explicitly authorized.
- [ ] Add definition designer route.
- [ ] Merge OpenAPI paths.
- [ ] Run migration, unit, integration, tenancy, security, performance, and accessibility tests.
- [ ] Complete UAT and tag `v0.15.0`.
