using System.Text;
using System.Threading.RateLimiting;
using Atlas.IncidentApi.Features.Incidents.Create;
using Atlas.IncidentApi.Features.Incidents.Review;
using Atlas.IncidentApi.Features.Incidents.Submit;
using Atlas.IncidentApi.Features.Incidents.SafetyReview;
using Atlas.IncidentApi.Infrastructure;
using Atlas.IncidentApi.Features.Investigations;
using Atlas.IncidentApi.Features.Capas;
using Atlas.IncidentApi.Features.Closure;
using Atlas.IncidentApi.Security;
using Atlas.IncidentApi.Features.Audit;
using Atlas.IncidentApi.Features.Notifications;
using Atlas.IncidentApi.Features.Administration;
using Atlas.IncidentApi.Features.Risks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<IncidentRepository>();
builder.Services.AddSingleton<InvestigationRepository>();
builder.Services.AddSingleton<CapaRepository>();
builder.Services.AddSingleton<ClosureRepository>();
builder.Services.AddSingleton<DashboardRepository>();
builder.Services.AddSingleton<AuditRepository>();
builder.Services.AddSingleton<AuditQueryService>();
builder.Services.AddSingleton<DatabaseReadinessService>();
builder.Services.AddSingleton<PilotReadinessService>();
builder.Services.AddScoped<WorkQueueRepository>();
builder.Services.AddScoped<NotificationScheduler>();
builder.Services.AddHostedService<NotificationBackgroundService>();
builder.Services.AddScoped<NotificationPreferenceRepository>();
builder.Services.AddScoped<NotificationDeliveryService>();
builder.Services.AddScoped<AdministrationRepository>();
builder.Services.AddMemoryCache();
builder.Services.AddScoped<SystemControlRepository>();
builder.Services.AddScoped<SystemControlCache>();
builder.Services.AddScoped<RiskRepository>();
builder.Services.AddHttpClient("notification-provider", client =>
{
    client.Timeout = TimeSpan.FromSeconds(15);
});
builder.Services.AddHostedService<NotificationDeliveryBackgroundService>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton<DevTokenService>();

var signingKey = builder.Configuration["Authentication:DevSigningKey"]
    ?? throw new InvalidOperationException("Authentication signing key is missing.");
var issuer = builder.Configuration["Authentication:Issuer"] ?? "atlas-dev";
var audience = builder.Configuration["Authentication:Audience"] ?? "atlas-api";

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = issuer,
            ValidateAudience = true,
            ValidAudience = audience,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(signingKey)),
            ClockSkew = TimeSpan.FromMinutes(1),
            NameClaimType = System.Security.Claims.ClaimTypes.NameIdentifier,
            RoleClaimType = System.Security.Claims.ClaimTypes.Role
        };
    });


builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

    options.AddPolicy("api", context =>
        RateLimitPartition.GetFixedWindowLimiter(
            partitionKey:
                context.User.Identity?.Name ??
                context.Connection.RemoteIpAddress?.ToString() ??
                "anonymous",
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 120,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0,
                AutoReplenishment = true
            }));

    options.AddPolicy("auth", context =>
        RateLimitPartition.GetFixedWindowLimiter(
            partitionKey:
                context.Connection.RemoteIpAddress?.ToString() ?? "anonymous",
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 10,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0,
                AutoReplenishment = true
            }));
});

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("EmployeeOrAbove", policy =>
        policy.RequireRole(
            AtlasRoles.Employee,
            AtlasRoles.Supervisor,
            AtlasRoles.Safety,
            AtlasRoles.Executive,
            AtlasRoles.Administrator));

    options.AddPolicy("Supervisor", policy =>
        policy.RequireRole(AtlasRoles.Supervisor, AtlasRoles.Administrator));

    options.AddPolicy("Safety", policy =>
        policy.RequireRole(AtlasRoles.Safety, AtlasRoles.Administrator));

    options.AddPolicy("SafetyOrExecutive", policy =>
        policy.RequireRole(
            AtlasRoles.Safety,
            AtlasRoles.Executive,
            AtlasRoles.Administrator));

    options.AddPolicy("Dashboard", policy =>
        policy.RequireRole(
            AtlasRoles.Supervisor,
            AtlasRoles.Safety,
            AtlasRoles.Executive,
            AtlasRoles.Administrator));
});

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
});

var app = builder.Build();

app.UseMiddleware<CorrelationIdMiddleware>();
app.UseMiddleware<ExceptionHandlingMiddleware>();
app.UseMiddleware<SecurityHeadersMiddleware>();
app.UseCors();
app.UseAuthentication();
app.UseAuthorization();
app.UseMiddleware<SystemControlMiddleware>();
app.UseRateLimiter();
app.UseMiddleware<AuditMiddleware>();
app.UseSwagger();
app.UseSwaggerUI();

app.MapPost("/api/auth/dev-token", (
    DevTokenRequest request,
    DevTokenService tokenService,
    IWebHostEnvironment environment) =>
{
    if (!environment.IsDevelopment())
        return Results.NotFound();

    if (request.UserId == Guid.Empty || request.TenantId == Guid.Empty)
        return Results.BadRequest(new { message = "User and tenant are required." });

    var allowedRoles = new[]
    {
        AtlasRoles.Employee,
        AtlasRoles.Supervisor,
        AtlasRoles.Safety,
        AtlasRoles.Executive,
        AtlasRoles.Administrator
    };

    if (!allowedRoles.Contains(request.Role, StringComparer.OrdinalIgnoreCase))
        return Results.BadRequest(new { message = "Unsupported role." });

    var token = tokenService.Create(
        request.UserId,
        request.TenantId,
        request.Role,
        request.Department);

    return Results.Ok(new { accessToken = token });
})
.AllowAnonymous()
.RequireRateLimiting("auth")
.WithName("CreateDevelopmentToken")
.WithOpenApi();


app.MapGet("/health/live", () => Results.Ok(new
{
    service = "incident-api",
    status = "live",
    timestamp = DateTimeOffset.UtcNow
}))
.AllowAnonymous()
.WithName("Liveness")
.WithOpenApi();

app.MapGet("/health/ready", async (
    DatabaseReadinessService readiness,
    CancellationToken cancellationToken) =>
{
    var result = await readiness.CheckAsync(cancellationToken);
    return result.Ready
        ? Results.Ok(new
        {
            service = "incident-api",
            status = "ready",
            detail = result.Message,
            timestamp = DateTimeOffset.UtcNow
        })
        : Results.Json(
            new
            {
                service = "incident-api",
                status = "not-ready",
                detail = result.Message,
                timestamp = DateTimeOffset.UtcNow
            },
            statusCode: StatusCodes.Status503ServiceUnavailable);
})
.AllowAnonymous()
.WithName("Readiness")
.WithOpenApi();

app.MapGet("/health", () => Results.Redirect("/health/live"))
.AllowAnonymous()
.ExcludeFromDescription();

app.MapPost("/api/incidents", async (
    CreateIncidentRequest request,
    HttpContext httpContext,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    request = request with
    {
        TenantId = user.TenantId,
        ReporterId = user.UserId
    };

    var errors = CreateIncidentValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var incident = await repository.CreateAsync(request, cancellationToken);
    return Results.Created($"/api/incidents/{incident.Id}", incident);
})
.WithName("CreateIncident")
.AddEndpointFilter(new FeatureFlagEndpointFilter("incident-creation"))
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapGet("/api/incidents", async (
    string? department,
    HttpContext httpContext,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    if (string.Equals(user.Role, AtlasRoles.Employee, StringComparison.OrdinalIgnoreCase))
        department = user.Department;

    return Results.Ok(await repository.ListAsync(
        user.TenantId, department, cancellationToken));
})
.WithName("ListIncidents")
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapGet("/api/incidents/{incidentId:guid}", async (
    Guid incidentId,
    HttpContext httpContext,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    var incident = await repository.GetAsync(
        user.TenantId, incidentId, cancellationToken);

    return incident is null ? Results.NotFound() : Results.Ok(incident);
})
.WithName("GetIncident")
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/submit", async (
    Guid incidentId,
    HttpContext httpContext,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    var incident = await repository.SubmitAsync(
        user.TenantId,
        incidentId,
        user.UserId,
        cancellationToken);

    return incident is null
        ? Results.Conflict(new
        {
            message = "Incident was not found or is no longer a draft."
        })
        : Results.Ok(incident);
})
.WithName("SubmitIncident")
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/supervisor-review", async (
    Guid incidentId,
    ReviewIncidentRequest request,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = ReviewIncidentValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var result = await repository.ReviewAsync(
        incidentId, request, cancellationToken);

    return result.Incident is null
        ? Results.Conflict(new { message = result.Error })
        : Results.Ok(result.Incident);
})
.WithName("SupervisorReviewIncident")
.RequireAuthorization("Supervisor")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/safety-review", async (
    Guid incidentId,
    SafetyReviewRequest request,
    IncidentRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = SafetyReviewValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var result = await repository.SafetyReviewAsync(
        incidentId, request, cancellationToken);

    return result.Incident is null
        ? Results.Conflict(new { message = result.Error })
        : Results.Ok(result.Incident);
})
.WithName("SafetyReviewAndAssignInvestigator")
.RequireAuthorization("Safety")
.RequireRateLimiting("api")
.WithOpenApi();


app.MapGet("/api/incidents/{incidentId:guid}/investigation", async (
    Guid incidentId,
    Guid tenantId,
    InvestigationRepository repository,
    CancellationToken cancellationToken) =>
{
    var workspace = await repository.GetAsync(
        tenantId, incidentId, cancellationToken);

    return workspace is null ? Results.NotFound() : Results.Ok(workspace);
})
.WithName("GetInvestigationWorkspace")
.RequireAuthorization("Safety")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPut("/api/incidents/{incidentId:guid}/investigation", async (
    Guid incidentId,
    UpsertInvestigationRequest request,
    InvestigationRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = InvestigationValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    return Results.Ok(await repository.UpsertAsync(
        incidentId, request, cancellationToken));
})
.WithName("UpsertInvestigation")
.RequireAuthorization("Safety")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/investigation/interviews", async (
    Guid incidentId,
    AddInterviewRequest request,
    InvestigationRepository repository,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.IntervieweeName) ||
        string.IsNullOrWhiteSpace(request.Summary))
        return Results.BadRequest(new { message = "Interviewee name and summary are required." });

    var id = await repository.AddInterviewAsync(
        incidentId, request, cancellationToken);

    return id is null ? Results.NotFound() : Results.Created($"/api/investigation-interviews/{id}", new { id });
})
.WithName("AddInvestigationInterview")
.RequireAuthorization("Safety")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/investigation/findings", async (
    Guid incidentId,
    AddFindingRequest request,
    InvestigationRepository repository,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.FindingType) ||
        string.IsNullOrWhiteSpace(request.Statement))
        return Results.BadRequest(new { message = "Finding type and statement are required." });

    var id = await repository.AddFindingAsync(
        incidentId, request, cancellationToken);

    return id is null ? Results.NotFound() : Results.Created($"/api/investigation-findings/{id}", new { id });
})
.WithName("AddInvestigationFinding")
.RequireAuthorization("Safety")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/investigation/evidence", async (
    Guid incidentId,
    AddEvidenceRequest request,
    InvestigationRepository repository,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.Title) ||
        string.IsNullOrWhiteSpace(request.ReferenceUri))
        return Results.BadRequest(new { message = "Evidence title and reference are required." });

    var id = await repository.AddEvidenceAsync(
        incidentId, request, cancellationToken);

    return id is null ? Results.NotFound() : Results.Created($"/api/investigation-evidence/{id}", new { id });
})
.WithName("AddInvestigationEvidence")
.RequireAuthorization("Safety")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/investigation/complete", async (
    Guid incidentId,
    CompleteInvestigationRequest request,
    InvestigationRepository repository,
    CancellationToken cancellationToken) =>
{
    var result = await repository.CompleteAsync(
        incidentId, request, cancellationToken);

    return result.Completed
        ? Results.Ok(new { status = "Completed", workflowState = "CAPA" })
        : Results.Conflict(new { message = result.Error });
})
.WithName("CompleteInvestigation")
.RequireAuthorization("Safety")
.RequireRateLimiting("api")
.WithOpenApi();


app.MapGet("/api/incidents/{incidentId:guid}/capas", async (
    Guid incidentId,
    Guid tenantId,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    return Results.Ok(await repository.ListForIncidentAsync(
        tenantId, incidentId, cancellationToken));
})
.WithName("ListIncidentCapas")
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/capas", async (
    Guid incidentId,
    CreateCapaRequest request,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = CapaValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var action = await repository.CreateAsync(
        incidentId, request, cancellationToken);

    return action is null
        ? Results.Conflict(new { message = "Incident must be in CAPA before actions can be created." })
        : Results.Created($"/api/capas/{action.Id}", action);
})
.WithName("CreateCapa")
.RequireAuthorization("Safety")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapGet("/api/capas/{capaId:guid}", async (
    Guid capaId,
    Guid tenantId,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    var workspace = await repository.GetAsync(
        tenantId, capaId, cancellationToken);

    return workspace is null ? Results.NotFound() : Results.Ok(workspace);
})
.WithName("GetCapa")
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/capas/{capaId:guid}/evidence", async (
    Guid capaId,
    AddCapaEvidenceRequest request,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.Title) ||
        string.IsNullOrWhiteSpace(request.ReferenceUri))
        return Results.BadRequest(new { message = "Evidence title and reference are required." });

    var id = await repository.AddEvidenceAsync(
        capaId, request, cancellationToken);

    return id is null ? Results.NotFound() : Results.Created($"/api/capa-evidence/{id}", new { id });
})
.WithName("AddCapaEvidence")
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/capas/{capaId:guid}/complete", async (
    Guid capaId,
    CompleteCapaRequest request,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    var result = await repository.CompleteAsync(
        capaId, request, cancellationToken);

    return result.Completed
        ? Results.Ok(new { status = "Completed" })
        : Results.Conflict(new { message = result.Error });
})
.WithName("CompleteCapa")
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/capas/{capaId:guid}/verify", async (
    Guid capaId,
    VerifyCapaRequest request,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    if (request.Result is not ("Passed" or "Failed"))
        return Results.BadRequest(new { message = "Result must be Passed or Failed." });

    var result = await repository.VerifyAsync(
        capaId, request, cancellationToken);

    return result.Verified
        ? Results.Ok(new { status = request.Result == "Passed" ? "Verified" : "Reopened" })
        : Results.Conflict(new { message = result.Error });
})
.WithName("VerifyCapa")
.RequireAuthorization("Safety")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/capas/{capaId:guid}/effectiveness", async (
    Guid capaId,
    ReviewCapaEffectivenessRequest request,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    if (request.Result is not ("Effective" or "Ineffective"))
        return Results.BadRequest(new { message = "Result must be Effective or Ineffective." });

    var result = await repository.ReviewEffectivenessAsync(
        capaId, request, cancellationToken);

    return result.Reviewed
        ? Results.Ok(new { status = request.Result == "Effective" && !request.RecurrenceFound ? "Closed" : "Reopened" })
        : Results.Conflict(new { message = result.Error });
})
.WithName("ReviewCapaEffectiveness")
.RequireAuthorization("Safety")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/capas/{capaId:guid}/reopen", async (
    Guid capaId,
    ReopenCapaRequest request,
    CapaRepository repository,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.Reason))
        return Results.BadRequest(new { message = "Reason is required." });

    return await repository.ReopenAsync(capaId, request, cancellationToken)
        ? Results.Ok(new { status = "Reopened" })
        : Results.NotFound();
})
.WithName("ReopenCapa")
.RequireAuthorization("Safety")
.RequireRateLimiting("api")
.WithOpenApi();


app.MapGet("/api/incidents/{incidentId:guid}/closure", async (
    Guid incidentId,
    Guid tenantId,
    ClosureRepository repository,
    CancellationToken cancellationToken) =>
{
    return Results.Ok(await repository.GetAsync(
        tenantId, incidentId, cancellationToken));
})
.WithName("GetIncidentClosureWorkspace")
.RequireAuthorization("SafetyOrExecutive")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPut("/api/incidents/{incidentId:guid}/closure", async (
    Guid incidentId,
    UpsertClosureReviewRequest request,
    ClosureRepository repository,
    CancellationToken cancellationToken) =>
{
    var errors = ClosureValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var gateError = ClosureValidator.ClosureGateError(request);
    if (gateError is not null &&
        string.Equals(
            request.ManagementDecision,
            "ApproveClosure",
            StringComparison.OrdinalIgnoreCase))
        return Results.Conflict(new { message = gateError });

    var review = await repository.UpsertAsync(
        incidentId, request, cancellationToken);

    return review is null
        ? Results.Conflict(new { message = "Incident must be in Verification before closure review." })
        : Results.Ok(review);
})
.WithName("UpsertIncidentClosureReview")
.RequireAuthorization("SafetyOrExecutive")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/closure/smeta-evidence", async (
    Guid incidentId,
    AddSmetaEvidenceRequest request,
    ClosureRepository repository,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.Pillar) ||
        string.IsNullOrWhiteSpace(request.RequirementReference) ||
        string.IsNullOrWhiteSpace(request.EvidenceTitle) ||
        string.IsNullOrWhiteSpace(request.EvidenceUri))
        return Results.BadRequest(new { message = "Complete SMETA evidence metadata is required." });

    var id = await repository.AddSmetaEvidenceAsync(
        incidentId, request, cancellationToken);

    return id is null
        ? Results.NotFound()
        : Results.Created($"/api/incident-smeta-evidence/{id}", new { id });
})
.WithName("AddIncidentSmetaEvidence")
.RequireAuthorization("Safety")
.RequireRateLimiting("api")
.WithOpenApi();

app.MapPost("/api/incidents/{incidentId:guid}/close", async (
    Guid incidentId,
    CloseIncidentRequest request,
    ClosureRepository repository,
    CancellationToken cancellationToken) =>
{
    if (request.TenantId == Guid.Empty || request.ReviewerId == Guid.Empty)
        return Results.BadRequest(new { message = "Tenant and reviewer are required." });

    var result = await repository.CloseAsync(
        incidentId, request, cancellationToken);

    return result.Closed
        ? Results.Ok(new { status = "Closed", workflowState = "Closed" })
        : Results.Conflict(new { message = result.Error });
})
.WithName("CloseIncident")
.RequireAuthorization("SafetyOrExecutive")
.RequireRateLimiting("api")
.WithOpenApi();


app.MapGet("/api/dashboard/summary", async (
    HttpContext httpContext,
    DashboardRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    return Results.Ok(await repository.GetAsync(
        user.TenantId, cancellationToken));
})
.WithName("GetDashboardSummary")
.AddEndpointFilter(new FeatureFlagEndpointFilter("executive-dashboard"))
.RequireAuthorization("Dashboard")
.RequireRateLimiting("api")
.WithOpenApi();


app.MapGet("/api/audit-events", async (
    int? limit,
    HttpContext httpContext,
    AuditQueryService queryService,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    var events = await queryService.GetAsync(
        user.TenantId,
        limit ?? 100,
        cancellationToken);

    return Results.Ok(events);
})
.RequireAuthorization(policy =>
    policy.RequireRole(AtlasRoles.Administrator, AtlasRoles.Executive))
.RequireRateLimiting("api")
.WithName("GetAuditEvents")
.RequireRateLimiting("api")
.WithOpenApi();


app.MapGet("/api/pilot/readiness", async (
    PilotReadinessService readinessService,
    CancellationToken cancellationToken) =>
{
    var result = await readinessService.CheckAsync(cancellationToken);
    return result.Status == "Ready"
        ? Results.Ok(result)
        : Results.Json(result, statusCode: StatusCodes.Status503ServiceUnavailable);
})
.RequireAuthorization(policy =>
    policy.RequireRole(AtlasRoles.Administrator, AtlasRoles.Executive))
.RequireRateLimiting("api")
.WithName("GetPilotReadiness")
.WithOpenApi();


app.MapGet("/api/work-queue", async (
    HttpContext httpContext,
    WorkQueueRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    return Results.Ok(await repository.GetAsync(
        user.TenantId,
        user.UserId,
        cancellationToken));
})
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithName("GetCurrentUserWorkQueue")
.WithOpenApi();

app.MapPost("/api/work-queue/{workItemId:guid}/complete", async (
    Guid workItemId,
    HttpContext httpContext,
    WorkQueueRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    return await repository.CompleteAsync(
        user.TenantId,
        user.UserId,
        workItemId,
        cancellationToken)
        ? Results.Ok(new { status = "Completed" })
        : Results.NotFound();
})
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithName("CompleteWorkItem")
.WithOpenApi();

app.MapPost("/api/notifications/{notificationId:guid}/read", async (
    Guid notificationId,
    HttpContext httpContext,
    WorkQueueRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    return await repository.MarkNotificationReadAsync(
        user.TenantId,
        user.UserId,
        notificationId,
        cancellationToken)
        ? Results.Ok(new { status = "Read" })
        : Results.NotFound();
})
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithName("MarkNotificationRead")
.WithOpenApi();

app.MapPost("/api/notifications/run-cycle", async (
    HttpContext httpContext,
    NotificationScheduler scheduler,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    var synchronized = await scheduler.SynchronizeAssignmentsAsync(
        user.TenantId,
        cancellationToken);

    var generated = await scheduler.GenerateNotificationsAsync(
        user.TenantId,
        cancellationToken);

    return Results.Ok(new
    {
        synchronized,
        generated,
        completedAt = DateTimeOffset.UtcNow
    });
})
.RequireAuthorization(policy =>
    policy.RequireRole(AtlasRoles.Safety, AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("RunNotificationCycle")
.WithOpenApi();


app.MapGet("/api/notification-preferences", async (
    HttpContext httpContext,
    NotificationPreferenceRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    return Results.Ok(await repository.GetAsync(
        user.TenantId,
        user.UserId,
        cancellationToken));
})
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithName("GetNotificationPreferences")
.WithOpenApi();

app.MapPut("/api/notification-preferences", async (
    UpdateNotificationPreferenceRequest request,
    HttpContext httpContext,
    NotificationPreferenceRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    if (request.QuietHoursEnabled &&
        (!request.QuietHoursStart.HasValue || !request.QuietHoursEnd.HasValue))
        return Results.BadRequest(new
        {
            message = "Quiet-hour start and end are required when quiet hours are enabled."
        });

    return Results.Ok(await repository.UpdateAsync(
        user.TenantId,
        user.UserId,
        request,
        cancellationToken));
})
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithName("UpdateNotificationPreferences")
.WithOpenApi();

app.MapPost("/api/notifications/run-delivery", async (
    HttpContext httpContext,
    NotificationDeliveryService deliveryService,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    var delivered = await deliveryService.DeliverPendingAsync(
        user.TenantId,
        cancellationToken);

    return Results.Ok(new
    {
        delivered,
        completedAt = DateTimeOffset.UtcNow
    });
})
.RequireAuthorization(policy =>
    policy.RequireRole(AtlasRoles.Safety, AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("RunExternalNotificationDelivery")
.AddEndpointFilter(new FeatureFlagEndpointFilter("external-notifications"))
.WithOpenApi();


app.MapGet("/api/admin/console", async (
    HttpContext httpContext,
    AdministrationRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    return Results.Ok(await repository.GetAsync(
        user.TenantId,
        cancellationToken));
})
.RequireAuthorization(policy =>
    policy.RequireRole(AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("GetAdministratorConsole")
.WithOpenApi();

app.MapPut("/api/admin/settings", async (
    UpdateTenantSettingsRequest request,
    HttpContext httpContext,
    AdministrationRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    await repository.UpdateSettingsAsync(
        user.TenantId, user.UserId, request, cancellationToken);
    return Results.NoContent();
})
.RequireAuthorization(policy =>
    policy.RequireRole(AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("UpdateTenantSettings")
.WithOpenApi();

app.MapPost("/api/admin/sites", async (
    UpsertSiteRequest request,
    HttpContext httpContext,
    AdministrationRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    if (string.IsNullOrWhiteSpace(request.Name) ||
        string.IsNullOrWhiteSpace(request.Code))
        return Results.BadRequest(new { message = "Site name and code are required." });

    var id = await repository.UpsertSiteAsync(
        user.TenantId, request, cancellationToken);
    return Results.Ok(new { id });
})
.RequireAuthorization(policy =>
    policy.RequireRole(AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("UpsertSite")
.WithOpenApi();

app.MapPost("/api/admin/departments", async (
    UpsertDepartmentRequest request,
    HttpContext httpContext,
    AdministrationRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    if (string.IsNullOrWhiteSpace(request.Name) ||
        string.IsNullOrWhiteSpace(request.Code))
        return Results.BadRequest(new { message = "Department name and code are required." });

    var id = await repository.UpsertDepartmentAsync(
        user.TenantId, request, cancellationToken);
    return Results.Ok(new { id });
})
.RequireAuthorization(policy =>
    policy.RequireRole(AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("UpsertDepartment")
.WithOpenApi();

app.MapPost("/api/admin/users", async (
    UpsertTenantUserRequest request,
    HttpContext httpContext,
    AdministrationRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    var allowedRoles = new[]
    {
        AtlasRoles.Employee,
        AtlasRoles.Supervisor,
        AtlasRoles.Safety,
        AtlasRoles.Executive,
        AtlasRoles.Administrator
    };

    if (!allowedRoles.Contains(
        request.Role,
        StringComparer.OrdinalIgnoreCase))
        return Results.BadRequest(new { message = "Unsupported role." });

    await repository.UpsertUserAsync(
        user.TenantId, request, cancellationToken);
    return Results.NoContent();
})
.RequireAuthorization(policy =>
    policy.RequireRole(AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("UpsertTenantUser")
.WithOpenApi();

app.MapPut("/api/admin/feature-flags/{flagKey}", async (
    string flagKey,
    UpsertFeatureFlagRequest request,
    HttpContext httpContext,
    AdministrationRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    request = request with { FlagKey = flagKey };

    await repository.UpsertFeatureFlagAsync(
        user.TenantId, user.UserId, request, cancellationToken);
    return Results.NoContent();
})
.RequireAuthorization(policy =>
    policy.RequireRole(AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("UpsertFeatureFlag")
.WithOpenApi();

app.MapPut("/api/admin/providers/{providerType}", async (
    string providerType,
    UpsertProviderSettingRequest request,
    HttpContext httpContext,
    AdministrationRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    request = request with { ProviderType = providerType };

    try
    {
        System.Text.Json.JsonDocument.Parse(request.Configuration);
    }
    catch
    {
        return Results.BadRequest(new { message = "Provider configuration must be valid JSON." });
    }

    await repository.UpsertProviderAsync(
        user.TenantId, user.UserId, request, cancellationToken);
    return Results.NoContent();
})
.RequireAuthorization(policy =>
    policy.RequireRole(AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("UpsertProviderSetting")
.WithOpenApi();


app.MapGet("/api/system/status", async (
    HttpContext httpContext,
    SystemControlCache controls,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    var state = await controls.GetAsync(
        user.TenantId,
        cancellationToken);

    return Results.Ok(state);
})
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithName("GetSystemControlStatus")
.WithOpenApi();

app.MapPut("/api/admin/system-controls", async (
    UpdateSystemControlsRequest request,
    HttpContext httpContext,
    AdministrationRepository repository,
    SystemControlCache controls,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    if (request.MaintenanceMode &&
        string.IsNullOrWhiteSpace(request.MaintenanceMessage))
        return Results.BadRequest(new
        {
            message = "A maintenance message is required when maintenance mode is enabled."
        });

    await repository.UpdateSystemControlsAsync(
        user.TenantId,
        user.UserId,
        request,
        cancellationToken);

    controls.Invalidate(user.TenantId);

    return Results.NoContent();
})
.RequireAuthorization(policy =>
    policy.RequireRole(AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("UpdateSystemControls")
.WithOpenApi();


app.MapGet("/api/risks", async (
    HttpContext httpContext,
    RiskRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    return Results.Ok(await repository.ListAsync(
        user.TenantId,
        cancellationToken));
})
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithName("ListRisks")
.WithOpenApi();

app.MapPost("/api/risks", async (
    CreateRiskRequest request,
    HttpContext httpContext,
    RiskRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    var errors = RiskValidator.Validate(request);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var risk = await repository.CreateAsync(
        user.TenantId,
        user.UserId,
        request,
        cancellationToken);

    return Results.Created($"/api/risks/{risk.Id}", risk);
})
.RequireAuthorization(policy =>
    policy.RequireRole(
        AtlasRoles.Safety,
        AtlasRoles.Executive,
        AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("CreateRisk")
.WithOpenApi();

app.MapGet("/api/risks/{riskId:guid}", async (
    Guid riskId,
    HttpContext httpContext,
    RiskRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    var risk = await repository.GetAsync(
        user.TenantId,
        riskId,
        cancellationToken);

    return risk is null ? Results.NotFound() : Results.Ok(risk);
})
.RequireAuthorization("EmployeeOrAbove")
.RequireRateLimiting("api")
.WithName("GetRiskWorkspace")
.WithOpenApi();

app.MapPost("/api/risks/{riskId:guid}/controls", async (
    Guid riskId,
    AddRiskControlRequest request,
    HttpContext httpContext,
    RiskRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    if (string.IsNullOrWhiteSpace(request.Title) ||
        string.IsNullOrWhiteSpace(request.Description))
        return Results.BadRequest(new
        {
            message = "Control title and description are required."
        });

    var id = await repository.AddControlAsync(
        user.TenantId,
        riskId,
        request,
        cancellationToken);

    return id is null
        ? Results.NotFound()
        : Results.Created($"/api/risk-controls/{id}", new { id });
})
.RequireAuthorization(policy =>
    policy.RequireRole(
        AtlasRoles.Safety,
        AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("AddRiskControl")
.WithOpenApi();

app.MapPost("/api/risks/{riskId:guid}/reviews", async (
    Guid riskId,
    ReviewRiskRequest request,
    HttpContext httpContext,
    RiskRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);

    if (!RiskValidator.IsScore(request.NewLikelihood) ||
        !RiskValidator.IsScore(request.NewSeverity))
        return Results.BadRequest(new
        {
            message = "Likelihood and severity must be 1 through 5."
        });

    return await repository.ReviewAsync(
        user.TenantId,
        riskId,
        user.UserId,
        request,
        cancellationToken)
        ? Results.Ok(new
        {
            score = request.NewLikelihood * request.NewSeverity,
            rating = RiskValidator.Rating(
                request.NewLikelihood * request.NewSeverity)
        })
        : Results.NotFound();
})
.RequireAuthorization(policy =>
    policy.RequireRole(
        AtlasRoles.Safety,
        AtlasRoles.Executive,
        AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("ReviewRisk")
.WithOpenApi();

app.MapPost("/api/risks/{riskId:guid}/links", async (
    Guid riskId,
    LinkRiskRecordRequest request,
    HttpContext httpContext,
    RiskRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    var id = await repository.LinkAsync(
        user.TenantId,
        riskId,
        user.UserId,
        request,
        cancellationToken);

    return id is null
        ? Results.NotFound()
        : Results.Created($"/api/risk-links/{id}", new { id });
})
.RequireAuthorization(policy =>
    policy.RequireRole(
        AtlasRoles.Safety,
        AtlasRoles.Administrator))
.RequireRateLimiting("api")
.WithName("LinkRiskRecord")
.WithOpenApi();

app.MapGet("/api/risk-dashboard", async (
    HttpContext httpContext,
    RiskRepository repository,
    CancellationToken cancellationToken) =>
{
    var user = CurrentUser.From(httpContext.User);
    return Results.Ok(await repository.DashboardAsync(
        user.TenantId,
        cancellationToken));
})
.RequireAuthorization("Dashboard")
.RequireRateLimiting("api")
.WithName("GetRiskDashboard")
.WithOpenApi();

app.Run();


public partial class Program;
