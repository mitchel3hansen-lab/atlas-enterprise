# Atlas Enterprise

Atlas is an operational intelligence platform with closed-loop incident management, CAPA, notifications, administration, live controls, and an enterprise risk register.

## Enterprise Risk capabilities

- Inherent, residual, and target risk
- 5×5 scoring
- Risk ownership and review
- Controls and effectiveness
- Linked operational records
- Review history and trend
- Executive heat maps
- Top-risk dashboard

## Start

```bash
cp .env.example .env
docker compose up --build -d
```

Open:

- Web: http://localhost:5173
- API Swagger: http://localhost:8085/swagger
