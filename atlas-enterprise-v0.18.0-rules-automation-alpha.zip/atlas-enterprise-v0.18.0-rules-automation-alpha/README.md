# Atlas Enterprise v0.18.0 — Rules & Automation Alpha

Atlas v0.18 extends the v0.17 Knowledge Graph Alpha with an explainable rules runtime.

## Included platform capabilities
- Identity and tenant security
- Metadata Object Engine
- Workflow Orchestration
- Operational Health
- Knowledge Graph
- Rules and Automation Alpha

## Demonstration
Use `examples/rules/critical-incident-escalation.json` to configure a rule for `Incident.Created`. The rule matches critical incidents with risk scores of at least 90 and records an explainable action result.

## Local validation
The repository includes Docker configuration and CI assets inherited from prior releases. A .NET 8 SDK, Node.js, Docker, PostgreSQL, and Redis are required for full integration validation. This package was structurally validated and archive-tested in the generation environment; .NET compilation was not available there.
