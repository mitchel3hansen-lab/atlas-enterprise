# Changelog

## [0.1.0-genesis] - 2026-07-22

### Added
- Atlas Foundation repository structure.
- Initial company charter and enterprise blueprint.
- Organization, facility, and department domain models.
- PostgreSQL schema and OpenAPI contract.
- ASP.NET Core and React application skeletons.
- Docker Compose and CI workflow.
