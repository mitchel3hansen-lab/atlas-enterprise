using Atlas.Application;
using Atlas.Infrastructure;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddProblemDetails();
builder.Services.AddOpenApi();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<AtlasDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("Atlas")));
builder.Services.AddScoped<IOrganizationRepository, OrganizationRepository>();
builder.Services.AddScoped<OrganizationService>();

var app = builder.Build();

app.UseExceptionHandler();
app.UseSwagger();
app.UseSwaggerUI();

app.MapGet("/health", () => Results.Ok(new { status = "healthy", service = "atlas-api" }));

var organizations = app.MapGroup("/api/v1/organizations").WithTags("Organizations");

organizations.MapGet("/", async (IOrganizationRepository repository, CancellationToken ct) =>
    Results.Ok(await repository.ListAsync(ct)));

organizations.MapGet("/{id:guid}", async (Guid id, IOrganizationRepository repository, CancellationToken ct) =>
{
    var organization = await repository.GetAsync(id, ct);
    return organization is null ? Results.NotFound() : Results.Ok(organization);
});

organizations.MapPost("/", async (CreateOrganizationRequest request, OrganizationService service, CancellationToken ct) =>
{
    var organization = await service.CreateAsync(request.Name, request.Code, ct);
    return Results.Created($"/api/v1/organizations/{organization.Id}", organization);
});

app.Run();

public sealed record CreateOrganizationRequest(string Name, string Code);
