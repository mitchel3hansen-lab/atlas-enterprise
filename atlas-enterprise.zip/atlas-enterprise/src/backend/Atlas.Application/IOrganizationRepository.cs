using Atlas.Domain;

namespace Atlas.Application;

public interface IOrganizationRepository
{
    Task AddAsync(Organization organization, CancellationToken cancellationToken);
    Task<Organization?> GetAsync(Guid id, CancellationToken cancellationToken);
    Task<IReadOnlyList<Organization>> ListAsync(CancellationToken cancellationToken);
}
