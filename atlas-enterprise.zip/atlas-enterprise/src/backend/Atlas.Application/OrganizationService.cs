using Atlas.Domain;

namespace Atlas.Application;

public sealed class OrganizationService(IOrganizationRepository repository)
{
    public async Task<Organization> CreateAsync(string name, string code, CancellationToken cancellationToken)
    {
        var organization = Organization.Create(name, code);
        await repository.AddAsync(organization, cancellationToken);
        return organization;
    }
}
