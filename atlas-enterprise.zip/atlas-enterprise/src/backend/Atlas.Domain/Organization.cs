namespace Atlas.Domain;

public sealed class Organization : Entity
{
    private readonly List<Facility> _facilities = [];
    private readonly List<Department> _departments = [];

    private Organization(Guid id, string name, string code) : base(id)
    {
        Name = Require(name, nameof(name));
        Code = Require(code, nameof(code)).ToUpperInvariant();
    }

    public string Name { get; private set; }
    public string Code { get; private set; }
    public IReadOnlyCollection<Facility> Facilities => _facilities.AsReadOnly();
    public IReadOnlyCollection<Department> Departments => _departments.AsReadOnly();

    public static Organization Create(string name, string code) => new(Guid.NewGuid(), name, code);

    public Facility AddFacility(string name, string code)
    {
        if (IsArchived) throw new InvalidOperationException("Archived organizations cannot receive facilities.");
        if (_facilities.Any(x => string.Equals(x.Code, code, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("Facility code must be unique within the organization.");

        var facility = Facility.Create(Id, name, code);
        _facilities.Add(facility);
        UpdatedAt = DateTimeOffset.UtcNow;
        return facility;
    }

    public Department AddDepartment(string name, Guid? facilityId = null, Guid? parentDepartmentId = null)
    {
        var department = Department.Create(Id, name, facilityId, parentDepartmentId);
        _departments.Add(department);
        UpdatedAt = DateTimeOffset.UtcNow;
        return department;
    }

    private static string Require(string value, string parameterName) =>
        string.IsNullOrWhiteSpace(value)
            ? throw new ArgumentException("A non-empty value is required.", parameterName)
            : value.Trim();
}
