export interface Organization {
  id: string;
  name: string;
  code: string;
  isArchived: boolean;
}

export async function listOrganizations(): Promise<Organization[]> {
  const response = await fetch('/api/v1/organizations');
  if (!response.ok) throw new Error('Unable to load organizations.');
  return response.json() as Promise<Organization[]>;
}
