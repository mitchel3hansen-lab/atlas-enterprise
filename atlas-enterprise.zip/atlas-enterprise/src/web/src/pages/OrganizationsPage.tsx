import { useQuery } from '@tanstack/react-query';
import { listOrganizations } from '../services/organizations';

export function OrganizationsPage() {
  const query = useQuery({ queryKey: ['organizations'], queryFn: listOrganizations });

  return (
    <section>
      <header className="page-header">
        <div>
          <p className="eyebrow">Atlas Core</p>
          <h1>Organizations</h1>
          <p>Manage the tenant-level structures that anchor every Atlas capability.</p>
        </div>
        <button type="button">New organization</button>
      </header>
      <article className="panel">
        {query.isLoading && <p>Loading organizations…</p>}
        {query.isError && <p>The API is not available yet. Start the Atlas backend to load live data.</p>}
        {query.data?.length === 0 && <p>No organizations have been created.</p>}
        {query.data?.map((organization) => (
          <div className="organization-row" key={organization.id}>
            <div>
              <strong>{organization.name}</strong>
              <span>{organization.code}</span>
            </div>
            <span>{organization.isArchived ? 'Archived' : 'Active'}</span>
          </div>
        ))}
      </article>
    </section>
  );
}
