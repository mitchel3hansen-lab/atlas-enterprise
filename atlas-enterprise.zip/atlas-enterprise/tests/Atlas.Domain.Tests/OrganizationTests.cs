using Atlas.Domain;

namespace Atlas.Domain.Tests;

public sealed class OrganizationTests
{
    [Fact]
    public void Create_NormalizesCode()
    {
        var organization = Organization.Create("Atlas Technologies", " atlas ");
        Assert.Equal("ATLAS", organization.Code);
    }

    [Fact]
    public void AddFacility_RejectsDuplicateCode()
    {
        var organization = Organization.Create("Atlas Technologies", "ATLAS");
        organization.AddFacility("North", "NORTH");
        Assert.Throws<InvalidOperationException>(() => organization.AddFacility("North 2", "north"));
    }
}
