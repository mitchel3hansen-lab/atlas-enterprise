# Build Manifest — v0.12.0

- Release: ATLAS Enterprise v0.12.0
- Work package: PLT-003 Facility Management
- Frontend: TypeScript compilation and Vite production build passed
- npm audit: 0 vulnerabilities reported during clean install
- Backend: not compiled because the .NET SDK is unavailable in this environment
- Database migration: `apps/api/migrations/V012__facility_management.sql`
