# Integration Notes

Register `IWorkflowRepository` with a PostgreSQL/EF Core implementation and register `WorkflowEngine` in `Program.cs`. Map controllers and add database mappings for V016 tables. The workflow domain service is repository-agnostic so runtime rules remain separate from persistence.

## Required integration gates
- Implement all repository methods, including immutable-version lookup by definition ID and version.
- Wire event publication after successful state changes.
- Add tenant-scoped query filters and authorization policies.
- Run backend compilation, database integration tests, and Docker startup in CI or a development machine with the .NET SDK and Docker.
