CREATE TABLE IF NOT EXISTS evidence_records (
    id uuid PRIMARY KEY,
    organization_id uuid NOT NULL,
    object_id uuid NULL,
    object_type varchar(120) NULL,
    title varchar(240) NOT NULL,
    description text NOT NULL DEFAULT '',
    classification varchar(40) NOT NULL DEFAULT 'Internal',
    status varchar(40) NOT NULL DEFAULT 'Active',
    retention_policy varchar(80) NOT NULL DEFAULT 'standard-7-years',
    legal_hold boolean NOT NULL DEFAULT false,
    current_version integer NOT NULL DEFAULT 1,
    created_at_utc timestamptz NOT NULL,
    created_by uuid NOT NULL,
    modified_at_utc timestamptz NOT NULL,
    modified_by uuid NOT NULL
);

CREATE TABLE IF NOT EXISTS evidence_versions (
    id uuid PRIMARY KEY,
    evidence_id uuid NOT NULL REFERENCES evidence_records(id) ON DELETE CASCADE,
    version_number integer NOT NULL,
    original_file_name varchar(512) NOT NULL,
    content_type varchar(160) NOT NULL,
    size_bytes bigint NOT NULL CHECK (size_bytes >= 0),
    sha256 varchar(64) NOT NULL,
    storage_key varchar(800) NOT NULL,
    notes text NOT NULL DEFAULT '',
    uploaded_at_utc timestamptz NOT NULL,
    uploaded_by uuid NOT NULL,
    UNIQUE (evidence_id, version_number),
    UNIQUE (evidence_id, sha256)
);

CREATE TABLE IF NOT EXISTS evidence_access_log (
    id uuid PRIMARY KEY,
    organization_id uuid NOT NULL,
    evidence_id uuid NOT NULL REFERENCES evidence_records(id) ON DELETE CASCADE,
    version_number integer NULL,
    action varchar(80) NOT NULL,
    actor_id uuid NOT NULL,
    correlation_id varchar(160) NOT NULL,
    occurred_at_utc timestamptz NOT NULL,
    details_json jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS ix_evidence_records_org_object
    ON evidence_records(organization_id, object_type, object_id);
CREATE INDEX IF NOT EXISTS ix_evidence_versions_evidence
    ON evidence_versions(evidence_id, version_number DESC);
CREATE INDEX IF NOT EXISTS ix_evidence_access_log_evidence
    ON evidence_access_log(evidence_id, occurred_at_utc DESC);
