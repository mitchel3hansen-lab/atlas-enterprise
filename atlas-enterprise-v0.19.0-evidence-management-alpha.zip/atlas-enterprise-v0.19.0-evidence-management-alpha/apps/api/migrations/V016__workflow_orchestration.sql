BEGIN;
CREATE TABLE IF NOT EXISTS workflow_definitions (
  id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  key text NOT NULL,
  name text NOT NULL,
  description text,
  active_version integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid,
  modified_at timestamptz NOT NULL DEFAULT now(),
  modified_by uuid,
  UNIQUE (tenant_id, key)
);
CREATE TABLE IF NOT EXISTS workflow_versions (
  id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  workflow_definition_id uuid NOT NULL REFERENCES workflow_definitions(id),
  version integer NOT NULL,
  status text NOT NULL CHECK (status IN ('draft','published','retired')),
  definition jsonb NOT NULL,
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid,
  UNIQUE (workflow_definition_id, version)
);
CREATE TABLE IF NOT EXISTS workflow_instances (
  id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  workflow_definition_id uuid NOT NULL REFERENCES workflow_definitions(id),
  workflow_version_id uuid NOT NULL REFERENCES workflow_versions(id),
  subject_type text NOT NULL,
  subject_id uuid NOT NULL,
  current_state text NOT NULL,
  status text NOT NULL CHECK (status IN ('active','completed','cancelled','failed')),
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  lock_version integer NOT NULL DEFAULT 0,
  created_by uuid,
  UNIQUE (tenant_id, workflow_definition_id, subject_type, subject_id)
);
CREATE TABLE IF NOT EXISTS workflow_tasks (
  id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  workflow_instance_id uuid NOT NULL REFERENCES workflow_instances(id),
  task_type text NOT NULL,
  title text NOT NULL,
  status text NOT NULL CHECK (status IN ('open','in_progress','completed','cancelled')),
  assigned_user_id uuid,
  assigned_role text,
  due_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid
);
CREATE TABLE IF NOT EXISTS workflow_history (
  id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  workflow_instance_id uuid NOT NULL REFERENCES workflow_instances(id),
  sequence bigint GENERATED ALWAYS AS IDENTITY,
  event_type text NOT NULL,
  from_state text,
  to_state text,
  transition_key text,
  actor_id uuid,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE (workflow_instance_id, sequence)
);
CREATE TABLE IF NOT EXISTS workflow_sla_clocks (
  id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  workflow_instance_id uuid NOT NULL REFERENCES workflow_instances(id),
  state_key text NOT NULL,
  target_at timestamptz NOT NULL,
  breached_at timestamptz,
  satisfied_at timestamptz,
  UNIQUE (workflow_instance_id, state_key)
);
CREATE INDEX IF NOT EXISTS ix_workflow_instances_tenant_state ON workflow_instances(tenant_id,current_state,status);
CREATE INDEX IF NOT EXISTS ix_workflow_tasks_assignee ON workflow_tasks(tenant_id,assigned_user_id,status,due_at);
CREATE INDEX IF NOT EXISTS ix_workflow_history_instance ON workflow_history(workflow_instance_id,sequence);
COMMIT;
