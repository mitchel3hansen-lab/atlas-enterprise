ALTER TABLE organizations
  ADD COLUMN IF NOT EXISTS legal_name varchar(250),
  ADD COLUMN IF NOT EXISTS display_name varchar(200),
  ADD COLUMN IF NOT EXISTS status integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS industry varchar(120),
  ADD COLUMN IF NOT EXISTS time_zone varchar(100) NOT NULL DEFAULT 'UTC',
  ADD COLUMN IF NOT EXISTS country_code varchar(2) NOT NULL DEFAULT 'US',
  ADD COLUMN IF NOT EXISTS region varchar(120),
  ADD COLUMN IF NOT EXISTS logo_url varchar(500),
  ADD COLUMN IF NOT EXISTS primary_color varchar(20),
  ADD COLUMN IF NOT EXISTS secondary_color varchar(20),
  ADD COLUMN IF NOT EXISTS updated_at_utc timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS archived_at_utc timestamptz,
  ADD COLUMN IF NOT EXISTS created_by_user_id uuid,
  ADD COLUMN IF NOT EXISTS updated_by_user_id uuid,
  ADD COLUMN IF NOT EXISTS version bigint NOT NULL DEFAULT 0;

UPDATE organizations SET legal_name = name, display_name = name WHERE legal_name IS NULL OR display_name IS NULL;
ALTER TABLE organizations ALTER COLUMN legal_name SET NOT NULL;
ALTER TABLE organizations ALTER COLUMN display_name SET NOT NULL;
CREATE INDEX IF NOT EXISTS ix_organizations_status ON organizations(status);

CREATE TABLE IF NOT EXISTS organization_audit_events (
  id uuid PRIMARY KEY,
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  actor_user_id uuid NULL REFERENCES users(id) ON DELETE SET NULL,
  action varchar(120) NOT NULL,
  changes_json jsonb NOT NULL,
  occurred_at_utc timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_organization_audit_events_org_time ON organization_audit_events(organization_id, occurred_at_utc DESC);
