BEGIN;

CREATE TABLE IF NOT EXISTS knowledge_relationships (
    id uuid PRIMARY KEY,
    organization_id uuid NOT NULL REFERENCES organizations(id),
    source_type integer NOT NULL,
    source_id uuid NOT NULL,
    target_type integer NOT NULL,
    target_id uuid NOT NULL,
    relationship_type varchar(100) NOT NULL,
    weight numeric(4,3) NOT NULL DEFAULT 1.000 CHECK (weight >= 0 AND weight <= 1),
    rationale text NULL,
    created_at_utc timestamptz NOT NULL,
    created_by_user_id uuid NULL REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS ix_knowledge_relationships_source ON knowledge_relationships(organization_id, source_type, source_id);
CREATE INDEX IF NOT EXISTS ix_knowledge_relationships_target ON knowledge_relationships(organization_id, target_type, target_id);

CREATE TABLE IF NOT EXISTS evidence_records (
    id uuid PRIMARY KEY,
    organization_id uuid NOT NULL REFERENCES organizations(id),
    object_type integer NOT NULL,
    object_id uuid NOT NULL,
    evidence_type varchar(100) NOT NULL,
    title varchar(250) NOT NULL,
    summary text NULL,
    source_reference text NULL,
    strength integer NOT NULL,
    confidence numeric(4,3) NOT NULL CHECK (confidence >= 0 AND confidence <= 1),
    observed_at_utc timestamptz NOT NULL,
    created_at_utc timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_evidence_records_object ON evidence_records(organization_id, object_type, object_id);

INSERT INTO permissions (id, code, description)
VALUES
(gen_random_uuid(), 'explainability.read', 'View explanations, evidence, and operational relationships'),
(gen_random_uuid(), 'explainability.manage', 'Create evidence and knowledge-graph relationships')
ON CONFLICT (code) DO NOTHING;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p
WHERE r.is_system_role = true AND r.normalized_name IN ('ADMINISTRATOR','SYSTEM ADMINISTRATOR')
  AND p.code IN ('explainability.read','explainability.manage')
ON CONFLICT DO NOTHING;

COMMIT;
