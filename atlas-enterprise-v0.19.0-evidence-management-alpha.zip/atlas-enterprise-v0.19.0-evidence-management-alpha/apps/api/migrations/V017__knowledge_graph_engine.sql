BEGIN;

CREATE TABLE IF NOT EXISTS graph_nodes (
  id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  organization_id uuid NULL,
  object_type varchar(120) NOT NULL,
  object_id uuid NOT NULL,
  display_name varchar(300) NOT NULL,
  attributes_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid NOT NULL,
  modified_at timestamptz NOT NULL DEFAULT now(),
  modified_by uuid NOT NULL,
  deleted_at timestamptz NULL,
  version bigint NOT NULL DEFAULT 1,
  CONSTRAINT uq_graph_nodes_subject UNIQUE (tenant_id, object_type, object_id)
);
CREATE INDEX IF NOT EXISTS ix_graph_nodes_lookup ON graph_nodes(tenant_id, object_type, display_name);

CREATE TABLE IF NOT EXISTS graph_relationship_types (
  id uuid PRIMARY KEY,
  tenant_id uuid NULL,
  code varchar(120) NOT NULL,
  name varchar(200) NOT NULL,
  inverse_code varchar(120) NULL,
  is_directional boolean NOT NULL DEFAULT true,
  allowed_source_types jsonb NOT NULL DEFAULT '[]'::jsonb,
  allowed_target_types jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid NOT NULL,
  CONSTRAINT uq_graph_relationship_types UNIQUE NULLS NOT DISTINCT (tenant_id, code)
);

CREATE TABLE IF NOT EXISTS graph_edges (
  id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  organization_id uuid NULL,
  source_node_id uuid NOT NULL REFERENCES graph_nodes(id) ON DELETE RESTRICT,
  target_node_id uuid NOT NULL REFERENCES graph_nodes(id) ON DELETE RESTRICT,
  relationship_type_id uuid NOT NULL REFERENCES graph_relationship_types(id) ON DELETE RESTRICT,
  confidence numeric(5,4) NOT NULL DEFAULT 1 CHECK (confidence BETWEEN 0 AND 1),
  rationale text NULL,
  evidence_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  valid_from timestamptz NOT NULL DEFAULT now(),
  valid_to timestamptz NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid NOT NULL,
  supersedes_edge_id uuid NULL REFERENCES graph_edges(id),
  CONSTRAINT ck_graph_edge_nodes CHECK (source_node_id <> target_node_id),
  CONSTRAINT ck_graph_edge_dates CHECK (valid_to IS NULL OR valid_to > valid_from)
);
CREATE INDEX IF NOT EXISTS ix_graph_edges_source ON graph_edges(tenant_id, source_node_id, valid_to);
CREATE INDEX IF NOT EXISTS ix_graph_edges_target ON graph_edges(tenant_id, target_node_id, valid_to);
CREATE INDEX IF NOT EXISTS ix_graph_edges_type ON graph_edges(tenant_id, relationship_type_id, valid_to);

CREATE TABLE IF NOT EXISTS graph_events (
  id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  organization_id uuid NULL,
  aggregate_type varchar(80) NOT NULL,
  aggregate_id uuid NOT NULL,
  event_type varchar(160) NOT NULL,
  payload_json jsonb NOT NULL,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  actor_id uuid NOT NULL,
  correlation_id varchar(100) NULL
);
CREATE INDEX IF NOT EXISTS ix_graph_events_aggregate ON graph_events(tenant_id, aggregate_type, aggregate_id, occurred_at);

INSERT INTO permissions (id, code, description) VALUES
(gen_random_uuid(), 'knowledge_graph.read', 'View graph nodes, relationships, and traversals'),
(gen_random_uuid(), 'knowledge_graph.manage', 'Create and version graph nodes and relationships')
ON CONFLICT (code) DO NOTHING;

COMMIT;
