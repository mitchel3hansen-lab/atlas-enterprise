BEGIN;

CREATE TABLE health_models (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, organization_id uuid NULL,
 code varchar(100) NOT NULL, name varchar(200) NOT NULL, description text NULL,
 subject_type varchar(100) NOT NULL, status varchar(30) NOT NULL DEFAULT 'Draft',
 active_version_id uuid NULL, created_at timestamptz NOT NULL DEFAULT now(),
 created_by uuid NOT NULL, modified_at timestamptz NOT NULL DEFAULT now(),
 modified_by uuid NOT NULL, deleted_at timestamptz NULL, version integer NOT NULL DEFAULT 1,
 CONSTRAINT uq_health_models_tenant_code UNIQUE (tenant_id, code),
 CONSTRAINT ck_health_models_status CHECK (status IN ('Draft','Published','Retired'))
);

CREATE TABLE health_model_versions (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL,
 health_model_id uuid NOT NULL REFERENCES health_models(id),
 version_number integer NOT NULL, effective_from timestamptz NULL, effective_to timestamptz NULL,
 published_at timestamptz NULL, published_by uuid NULL,
 configuration_json jsonb NOT NULL DEFAULT '{}'::jsonb,
 created_at timestamptz NOT NULL DEFAULT now(), created_by uuid NOT NULL,
 CONSTRAINT uq_health_model_versions UNIQUE (health_model_id, version_number),
 CONSTRAINT ck_health_model_version_dates CHECK (effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from)
);

ALTER TABLE health_models ADD CONSTRAINT fk_health_models_active_version
FOREIGN KEY (active_version_id) REFERENCES health_model_versions(id);

CREATE TABLE health_indicators (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL,
 health_model_version_id uuid NOT NULL REFERENCES health_model_versions(id),
 code varchar(100) NOT NULL, name varchar(200) NOT NULL, description text NULL,
 unit varchar(50) NULL, direction varchar(20) NOT NULL, weight numeric(9,6) NOT NULL,
 minimum_value numeric(18,6) NOT NULL, target_value numeric(18,6) NOT NULL,
 maximum_value numeric(18,6) NOT NULL, stale_after_hours integer NULL,
 source_reliability numeric(5,4) NOT NULL DEFAULT 1, is_required boolean NOT NULL DEFAULT true,
 recommendation_template text NULL, display_order integer NOT NULL DEFAULT 0,
 created_at timestamptz NOT NULL DEFAULT now(), created_by uuid NOT NULL,
 CONSTRAINT uq_health_indicators_version_code UNIQUE (health_model_version_id, code),
 CONSTRAINT ck_health_indicator_direction CHECK (direction IN ('HigherIsBetter','LowerIsBetter','TargetRange')),
 CONSTRAINT ck_health_indicator_weight CHECK (weight >= 0),
 CONSTRAINT ck_health_indicator_range CHECK (minimum_value <= target_value AND target_value <= maximum_value),
 CONSTRAINT ck_health_indicator_reliability CHECK (source_reliability BETWEEN 0 AND 1)
);

CREATE TABLE health_measurements (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, organization_id uuid NULL, facility_id uuid NULL,
 subject_type varchar(100) NOT NULL, subject_id uuid NOT NULL, indicator_code varchar(100) NOT NULL,
 measured_value numeric(18,6) NOT NULL, unit varchar(50) NULL, measured_at timestamptz NOT NULL,
 source_type varchar(100) NOT NULL, source_reference varchar(500) NULL, evidence_id uuid NULL,
 confidence numeric(5,4) NOT NULL DEFAULT 1, metadata_json jsonb NOT NULL DEFAULT '{}'::jsonb,
 created_at timestamptz NOT NULL DEFAULT now(), created_by uuid NOT NULL,
 CONSTRAINT ck_health_measurement_confidence CHECK (confidence BETWEEN 0 AND 1)
);
CREATE INDEX ix_health_measurements_subject ON health_measurements
(tenant_id, subject_type, subject_id, indicator_code, measured_at DESC);

CREATE TABLE health_snapshots (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, organization_id uuid NULL, facility_id uuid NULL,
 subject_type varchar(100) NOT NULL, subject_id uuid NOT NULL,
 health_model_id uuid NOT NULL REFERENCES health_models(id),
 health_model_version_id uuid NOT NULL REFERENCES health_model_versions(id),
 score numeric(6,3) NOT NULL, confidence numeric(5,4) NOT NULL,
 status varchar(30) NOT NULL, trend varchar(30) NOT NULL, trend_delta numeric(8,3) NOT NULL DEFAULT 0,
 calculated_at timestamptz NOT NULL, explanation_json jsonb NOT NULL,
 recommendation_count integer NOT NULL DEFAULT 0, calculation_hash varchar(64) NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(), created_by uuid NOT NULL,
 CONSTRAINT ck_health_snapshot_score CHECK (score BETWEEN 0 AND 100),
 CONSTRAINT ck_health_snapshot_confidence CHECK (confidence BETWEEN 0 AND 1),
 CONSTRAINT ck_health_snapshot_status CHECK (status IN ('Exceptional','Healthy','Stable','NeedsAttention','Critical')),
 CONSTRAINT ck_health_snapshot_trend CHECK (trend IN ('Improving','Stable','Declining','InsufficientHistory'))
);
CREATE INDEX ix_health_snapshots_subject ON health_snapshots
(tenant_id, subject_type, subject_id, calculated_at DESC);

CREATE TABLE health_snapshot_contributions (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL,
 health_snapshot_id uuid NOT NULL REFERENCES health_snapshots(id),
 health_indicator_id uuid NOT NULL REFERENCES health_indicators(id),
 indicator_code varchar(100) NOT NULL, raw_value numeric(18,6) NULL,
 normalized_score numeric(6,3) NOT NULL, normalized_weight numeric(9,6) NOT NULL,
 weighted_contribution numeric(8,4) NOT NULL, confidence numeric(5,4) NOT NULL,
 evidence_status varchar(30) NOT NULL, explanation text NOT NULL
);

CREATE TABLE health_recommendations (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL,
 health_snapshot_id uuid NOT NULL REFERENCES health_snapshots(id),
 indicator_code varchar(100) NULL, title varchar(250) NOT NULL, rationale text NOT NULL,
 priority varchar(20) NOT NULL, estimated_score_gain numeric(6,3) NULL,
 recommended_action text NOT NULL, status varchar(30) NOT NULL DEFAULT 'Open',
 created_at timestamptz NOT NULL DEFAULT now(), created_by uuid NOT NULL,
 CONSTRAINT ck_health_recommendation_priority CHECK (priority IN ('Low','Medium','High','Critical')),
 CONSTRAINT ck_health_recommendation_status CHECK (status IN ('Open','Accepted','Dismissed','Completed'))
);

CREATE OR REPLACE FUNCTION prevent_health_snapshot_mutation() RETURNS trigger AS $$
BEGIN RAISE EXCEPTION 'Health snapshots and contributions are immutable.'; END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER trg_health_snapshots_immutable BEFORE UPDATE OR DELETE ON health_snapshots
FOR EACH ROW EXECUTE FUNCTION prevent_health_snapshot_mutation();
CREATE TRIGGER trg_health_contributions_immutable BEFORE UPDATE OR DELETE ON health_snapshot_contributions
FOR EACH ROW EXECUTE FUNCTION prevent_health_snapshot_mutation();

COMMIT;
