CREATE TABLE IF NOT EXISTS "Users" (
  "Id" uuid PRIMARY KEY,
  "Email" varchar(320) NOT NULL,
  "NormalizedEmail" varchar(320) NOT NULL UNIQUE,
  "DisplayName" varchar(200) NOT NULL,
  "PasswordHash" text NOT NULL,
  "IsActive" boolean NOT NULL DEFAULT true,
  "CreatedAtUtc" timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS "OrganizationMemberships" (
  "Id" uuid PRIMARY KEY,
  "OrganizationId" uuid NOT NULL REFERENCES "Organizations"("Id") ON DELETE RESTRICT,
  "UserId" uuid NOT NULL REFERENCES "Users"("Id") ON DELETE RESTRICT,
  "IsActive" boolean NOT NULL DEFAULT true,
  "CreatedAtUtc" timestamptz NOT NULL,
  UNIQUE ("OrganizationId", "UserId")
);

CREATE TABLE IF NOT EXISTS "Roles" (
  "Id" uuid PRIMARY KEY,
  "OrganizationId" uuid NULL REFERENCES "Organizations"("Id") ON DELETE RESTRICT,
  "Name" text NOT NULL,
  "NormalizedName" text NOT NULL,
  "IsSystemRole" boolean NOT NULL DEFAULT false,
  UNIQUE ("OrganizationId", "NormalizedName")
);

CREATE TABLE IF NOT EXISTS "Permissions" (
  "Id" uuid PRIMARY KEY,
  "Code" text NOT NULL UNIQUE,
  "Description" text NOT NULL
);

CREATE TABLE IF NOT EXISTS "MembershipRoles" (
  "MembershipId" uuid NOT NULL REFERENCES "OrganizationMemberships"("Id") ON DELETE CASCADE,
  "RoleId" uuid NOT NULL REFERENCES "Roles"("Id") ON DELETE CASCADE,
  PRIMARY KEY ("MembershipId", "RoleId")
);

CREATE TABLE IF NOT EXISTS "RolePermissions" (
  "RoleId" uuid NOT NULL REFERENCES "Roles"("Id") ON DELETE CASCADE,
  "PermissionId" uuid NOT NULL REFERENCES "Permissions"("Id") ON DELETE CASCADE,
  PRIMARY KEY ("RoleId", "PermissionId")
);
