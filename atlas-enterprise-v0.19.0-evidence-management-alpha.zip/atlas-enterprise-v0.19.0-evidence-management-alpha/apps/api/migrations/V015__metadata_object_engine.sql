BEGIN;

CREATE TABLE object_definitions (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    organization_id uuid NULL,
    key varchar(120) NOT NULL,
    singular_name varchar(160) NOT NULL,
    plural_name varchar(160) NOT NULL,
    description text NULL,
    icon varchar(80) NULL,
    status varchar(30) NOT NULL DEFAULT 'Draft',
    active_version_id uuid NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    created_by uuid NOT NULL,
    modified_at timestamptz NOT NULL DEFAULT now(),
    modified_by uuid NOT NULL,
    deleted_at timestamptz NULL,
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT uq_object_definitions_tenant_key UNIQUE (tenant_id, key),
    CONSTRAINT ck_object_definition_status CHECK (status IN ('Draft','Published','Retired'))
);

CREATE TABLE object_definition_versions (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    object_definition_id uuid NOT NULL REFERENCES object_definitions(id),
    version_number integer NOT NULL,
    schema_json jsonb NOT NULL DEFAULT '{}'::jsonb,
    settings_json jsonb NOT NULL DEFAULT '{}'::jsonb,
    published_at timestamptz NULL,
    published_by uuid NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    created_by uuid NOT NULL,
    CONSTRAINT uq_object_definition_versions UNIQUE (object_definition_id, version_number)
);

ALTER TABLE object_definitions
ADD CONSTRAINT fk_object_definitions_active_version
FOREIGN KEY (active_version_id) REFERENCES object_definition_versions(id);

CREATE TABLE field_definitions (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    object_definition_version_id uuid NOT NULL REFERENCES object_definition_versions(id),
    key varchar(120) NOT NULL,
    label varchar(180) NOT NULL,
    description text NULL,
    field_type varchar(40) NOT NULL,
    storage_path varchar(240) NOT NULL,
    display_order integer NOT NULL DEFAULT 0,
    is_required boolean NOT NULL DEFAULT false,
    is_unique boolean NOT NULL DEFAULT false,
    is_searchable boolean NOT NULL DEFAULT true,
    is_sensitive boolean NOT NULL DEFAULT false,
    default_value_json jsonb NULL,
    validation_json jsonb NOT NULL DEFAULT '{}'::jsonb,
    visibility_json jsonb NOT NULL DEFAULT '{}'::jsonb,
    options_json jsonb NOT NULL DEFAULT '[]'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    created_by uuid NOT NULL,
    CONSTRAINT uq_field_definition_key UNIQUE (object_definition_version_id, key),
    CONSTRAINT ck_field_definition_type CHECK (field_type IN (
        'Text','RichText','Integer','Decimal','Currency','Percentage','Boolean',
        'Date','DateTime','Duration','User','Team','Organization','Facility','Asset',
        'File','Image','Signature','SingleSelect','MultiSelect','Lookup','Formula','Computed'
    ))
);

CREATE TABLE layout_definitions (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    object_definition_version_id uuid NOT NULL REFERENCES object_definition_versions(id),
    key varchar(120) NOT NULL,
    name varchar(180) NOT NULL,
    purpose varchar(40) NOT NULL,
    layout_json jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    created_by uuid NOT NULL,
    CONSTRAINT uq_layout_definition_key UNIQUE (object_definition_version_id, key),
    CONSTRAINT ck_layout_purpose CHECK (purpose IN ('Create','Edit','View','List','Mobile','Print'))
);

CREATE TABLE lifecycle_state_definitions (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    object_definition_version_id uuid NOT NULL REFERENCES object_definition_versions(id),
    key varchar(100) NOT NULL,
    name varchar(160) NOT NULL,
    category varchar(30) NOT NULL,
    display_order integer NOT NULL DEFAULT 0,
    is_initial boolean NOT NULL DEFAULT false,
    is_terminal boolean NOT NULL DEFAULT false,
    settings_json jsonb NOT NULL DEFAULT '{}'::jsonb,
    CONSTRAINT uq_lifecycle_state_key UNIQUE (object_definition_version_id, key),
    CONSTRAINT ck_lifecycle_category CHECK (category IN ('Draft','Active','Pending','Closed','Archived'))
);

CREATE TABLE object_records (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    organization_id uuid NULL,
    facility_id uuid NULL,
    object_definition_id uuid NOT NULL REFERENCES object_definitions(id),
    object_definition_version_id uuid NOT NULL REFERENCES object_definition_versions(id),
    record_number varchar(120) NOT NULL,
    title varchar(300) NOT NULL,
    lifecycle_state_key varchar(100) NOT NULL,
    owner_user_id uuid NULL,
    owner_team_id uuid NULL,
    data_json jsonb NOT NULL DEFAULT '{}'::jsonb,
    search_text tsvector GENERATED ALWAYS AS (
        to_tsvector('simple', coalesce(title,'') || ' ' || coalesce(data_json::text,''))
    ) STORED,
    created_at timestamptz NOT NULL DEFAULT now(),
    created_by uuid NOT NULL,
    modified_at timestamptz NOT NULL DEFAULT now(),
    modified_by uuid NOT NULL,
    deleted_at timestamptz NULL,
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT uq_object_record_number UNIQUE (tenant_id, object_definition_id, record_number)
);

CREATE INDEX ix_object_records_definition ON object_records (tenant_id, object_definition_id, created_at DESC);
CREATE INDEX ix_object_records_owner ON object_records (tenant_id, owner_user_id, lifecycle_state_key);
CREATE INDEX ix_object_records_search ON object_records USING gin(search_text);
CREATE INDEX ix_object_records_data ON object_records USING gin(data_json jsonb_path_ops);

CREATE TABLE object_relationship_definitions (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    source_object_definition_id uuid NOT NULL REFERENCES object_definitions(id),
    target_object_definition_id uuid NOT NULL REFERENCES object_definitions(id),
    key varchar(120) NOT NULL,
    source_label varchar(180) NOT NULL,
    target_label varchar(180) NOT NULL,
    cardinality varchar(30) NOT NULL,
    is_required boolean NOT NULL DEFAULT false,
    settings_json jsonb NOT NULL DEFAULT '{}'::jsonb,
    CONSTRAINT uq_relationship_definition UNIQUE (tenant_id, source_object_definition_id, key),
    CONSTRAINT ck_relationship_cardinality CHECK (cardinality IN ('OneToOne','OneToMany','ManyToOne','ManyToMany'))
);

CREATE TABLE object_relationships (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    relationship_definition_id uuid NOT NULL REFERENCES object_relationship_definitions(id),
    source_record_id uuid NOT NULL REFERENCES object_records(id),
    target_record_id uuid NOT NULL REFERENCES object_records(id),
    metadata_json jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    created_by uuid NOT NULL,
    CONSTRAINT uq_object_relationship UNIQUE (relationship_definition_id, source_record_id, target_record_id),
    CONSTRAINT ck_relationship_not_self CHECK (source_record_id <> target_record_id)
);

CREATE TABLE object_record_events (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    object_record_id uuid NOT NULL REFERENCES object_records(id),
    event_type varchar(120) NOT NULL,
    actor_user_id uuid NULL,
    occurred_at timestamptz NOT NULL DEFAULT now(),
    correlation_id uuid NULL,
    payload_json jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX ix_object_record_events_timeline
ON object_record_events (tenant_id, object_record_id, occurred_at DESC);

CREATE OR REPLACE FUNCTION prevent_published_object_version_mutation()
RETURNS trigger AS $$
BEGIN
    IF OLD.published_at IS NOT NULL THEN
        RAISE EXCEPTION 'Published object definition versions are immutable.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_object_definition_versions_immutable
BEFORE UPDATE OR DELETE ON object_definition_versions
FOR EACH ROW EXECUTE FUNCTION prevent_published_object_version_mutation();

COMMIT;
