ALTER TABLE facilities
  ADD COLUMN IF NOT EXISTS code varchar(50),
  ADD COLUMN IF NOT EXISTS type integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS status integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS description varchar(1000),
  ADD COLUMN IF NOT EXISTS country_code varchar(2) NOT NULL DEFAULT 'US',
  ADD COLUMN IF NOT EXISTS region varchar(120),
  ADD COLUMN IF NOT EXISTS city varchar(160),
  ADD COLUMN IF NOT EXISTS address_line1 varchar(250),
  ADD COLUMN IF NOT EXISTS address_line2 varchar(250),
  ADD COLUMN IF NOT EXISTS postal_code varchar(30),
  ADD COLUMN IF NOT EXISTS latitude numeric(9,6),
  ADD COLUMN IF NOT EXISTS longitude numeric(9,6),
  ADD COLUMN IF NOT EXISTS emergency_zone varchar(120),
  ADD COLUMN IF NOT EXISTS updated_at_utc timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS archived_at_utc timestamptz,
  ADD COLUMN IF NOT EXISTS created_by_user_id uuid,
  ADD COLUMN IF NOT EXISTS updated_by_user_id uuid,
  ADD COLUMN IF NOT EXISTS version bigint NOT NULL DEFAULT 0;

UPDATE facilities SET code = upper(regexp_replace(name, '[^a-zA-Z0-9]+', '-', 'g')) WHERE code IS NULL;
ALTER TABLE facilities ALTER COLUMN code SET NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_facilities_organization_code ON facilities(organization_id, code);
CREATE INDEX IF NOT EXISTS ix_facilities_organization_status ON facilities(organization_id, status);

CREATE TABLE IF NOT EXISTS facility_audit_events (
  id uuid PRIMARY KEY,
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  facility_id uuid NOT NULL REFERENCES facilities(id) ON DELETE RESTRICT,
  actor_user_id uuid NULL REFERENCES users(id) ON DELETE SET NULL,
  action varchar(120) NOT NULL,
  changes_json jsonb NOT NULL,
  occurred_at_utc timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_facility_audit_events_scope_time ON facility_audit_events(organization_id, facility_id, occurred_at_utc DESC);
