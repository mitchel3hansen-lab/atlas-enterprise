BEGIN;
DROP TABLE IF EXISTS rule_schedules;
DROP TABLE IF EXISTS rule_executions;
DROP TABLE IF EXISTS automation_rules;
COMMIT;
