DROP TABLE IF EXISTS evidence_access_log;
DROP TABLE IF EXISTS evidence_versions;
DROP TABLE IF EXISTS evidence_records;
