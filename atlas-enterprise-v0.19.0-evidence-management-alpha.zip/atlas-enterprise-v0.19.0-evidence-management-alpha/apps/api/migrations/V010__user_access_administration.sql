CREATE TABLE IF NOT EXISTS user_invitations (
    id uuid PRIMARY KEY,
    organization_id uuid NOT NULL REFERENCES organizations(id),
    email varchar(320) NOT NULL,
    normalized_email varchar(320) NOT NULL,
    token_hash varchar(64) NOT NULL UNIQUE,
    invited_by_user_id uuid NOT NULL REFERENCES users(id),
    expires_at_utc timestamptz NOT NULL,
    accepted_at_utc timestamptz NULL,
    revoked_at_utc timestamptz NULL,
    created_at_utc timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_user_invitations_org_email ON user_invitations(organization_id, normalized_email);

CREATE TABLE IF NOT EXISTS access_audit_events (
    id uuid PRIMARY KEY,
    organization_id uuid NOT NULL REFERENCES organizations(id),
    actor_user_id uuid NULL REFERENCES users(id),
    subject_user_id uuid NULL REFERENCES users(id),
    action varchar(160) NOT NULL,
    details_json jsonb NOT NULL,
    occurred_at_utc timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_access_audit_events_org_time ON access_audit_events(organization_id, occurred_at_utc DESC);

CREATE TABLE IF NOT EXISTS revoked_sessions (
    id uuid PRIMARY KEY,
    organization_id uuid NOT NULL REFERENCES organizations(id),
    user_id uuid NOT NULL REFERENCES users(id),
    jwt_id varchar(100) NOT NULL UNIQUE,
    expires_at_utc timestamptz NOT NULL,
    revoked_at_utc timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_revoked_sessions_org_user ON revoked_sessions(organization_id, user_id);
