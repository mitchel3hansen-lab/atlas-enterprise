BEGIN;

CREATE TABLE automation_rules (
    id uuid PRIMARY KEY,
    organization_id uuid NOT NULL,
    name varchar(200) NOT NULL,
    description text NOT NULL DEFAULT '',
    trigger_event varchar(160) NOT NULL,
    priority integer NOT NULL DEFAULT 100,
    status varchar(32) NOT NULL,
    condition_json jsonb NOT NULL DEFAULT '[]'::jsonb,
    action_json jsonb NOT NULL DEFAULT '[]'::jsonb,
    version integer NOT NULL DEFAULT 1,
    created_at_utc timestamptz NOT NULL,
    created_by uuid NOT NULL,
    modified_at_utc timestamptz NOT NULL,
    modified_by uuid NOT NULL,
    CONSTRAINT ck_automation_rules_priority CHECK (priority BETWEEN 0 AND 10000),
    CONSTRAINT ck_automation_rules_status CHECK (status IN ('Draft','Active','Disabled','Archived'))
);
CREATE INDEX ix_automation_rules_trigger ON automation_rules (organization_id, trigger_event, status, priority);

CREATE TABLE rule_executions (
    id uuid PRIMARY KEY,
    organization_id uuid NOT NULL,
    rule_id uuid NOT NULL REFERENCES automation_rules(id) ON DELETE RESTRICT,
    object_id uuid NULL,
    object_type varchar(100) NULL,
    trigger_event varchar(160) NOT NULL,
    correlation_id varchar(120) NOT NULL,
    status varchar(32) NOT NULL,
    explanation_json jsonb NOT NULL DEFAULT '{}'::jsonb,
    actions_json jsonb NOT NULL DEFAULT '[]'::jsonb,
    error text NULL,
    started_at_utc timestamptz NOT NULL,
    completed_at_utc timestamptz NULL
);
CREATE INDEX ix_rule_executions_rule_time ON rule_executions (organization_id, rule_id, started_at_utc DESC);
CREATE INDEX ix_rule_executions_object ON rule_executions (organization_id, object_type, object_id);
CREATE UNIQUE INDEX ux_rule_execution_idempotency ON rule_executions (organization_id, rule_id, correlation_id);

CREATE TABLE rule_schedules (
    id uuid PRIMARY KEY,
    organization_id uuid NOT NULL,
    rule_id uuid NOT NULL REFERENCES automation_rules(id) ON DELETE CASCADE,
    cron_expression varchar(120) NOT NULL,
    time_zone varchar(100) NOT NULL DEFAULT 'UTC',
    next_run_at_utc timestamptz NULL,
    last_run_at_utc timestamptz NULL,
    enabled boolean NOT NULL DEFAULT true
);

COMMIT;
