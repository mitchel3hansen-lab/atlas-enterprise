using System.Text.Json;
using Atlas.Api.Rules;
using Xunit;

namespace Atlas.Api.Tests.Rules;

public sealed class RuleConditionEvaluatorTests
{
    [Fact]
    public void CriticalSeverity_Matches()
    {
        using var payload = JsonDocument.Parse("""{"severity":"Critical","riskScore":95}""");
        var conditions = """[{"field":"severity","operator":"eq","value":"Critical"},{"field":"riskScore","operator":"gte","value":90}]""";
        var result = new RuleConditionEvaluator().Evaluate(conditions, payload.RootElement);
        Assert.True(result.Matched);
        Assert.Equal(2, result.Reasons.Count);
    }

    [Fact]
    public void MissingField_DoesNotMatch()
    {
        using var payload = JsonDocument.Parse("""{"severity":"Low"}""");
        var result = new RuleConditionEvaluator().Evaluate("""[{"field":"facility.code","operator":"eq","value":"LINDON"}]""", payload.RootElement);
        Assert.False(result.Matched);
    }
}
