using System.Text.Json;

namespace Atlas.Api.Workflow;

public sealed record WorkflowState(string Key, string Name, bool IsTerminal = false, int? SlaHours = null);
public sealed record WorkflowTransition(string Key, string From, string To, string[] AllowedRoles, string[] RequiredFields);
public sealed record WorkflowDefinition(Guid Id, Guid TenantId, string Key, string Name, int Version,
    IReadOnlyList<WorkflowState> States, IReadOnlyList<WorkflowTransition> Transitions);
public sealed record WorkflowInstance(Guid Id, Guid TenantId, Guid DefinitionId, int DefinitionVersion,
    string SubjectType, Guid SubjectId, string CurrentState, string Status, int LockVersion, DateTimeOffset StartedAt);
public sealed record WorkflowHistoryEntry(Guid Id, Guid InstanceId, string EventType, string? FromState,
    string? ToState, string? TransitionKey, Guid? ActorId, DateTimeOffset OccurredAt, JsonElement Details);
public sealed record StartWorkflowRequest(string WorkflowKey, string SubjectType, Guid SubjectId, JsonElement SubjectData);
public sealed record TransitionWorkflowRequest(string TransitionKey, JsonElement SubjectData, int ExpectedLockVersion);
public sealed record WorkflowDecision(bool Allowed, string? Reason, WorkflowTransition? Transition);
