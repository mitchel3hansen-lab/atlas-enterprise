using System.Security.Claims;
using System.Text.Json;

namespace Atlas.Api.Workflow;

public sealed class WorkflowEngine(IWorkflowRepository repository, ILogger<WorkflowEngine> logger)
{
    public async Task<WorkflowInstance> StartAsync(Guid tenantId, Guid actorId, StartWorkflowRequest request, CancellationToken ct)
    {
        var definition = await repository.GetPublishedDefinitionAsync(tenantId, request.WorkflowKey, ct)
            ?? throw new InvalidOperationException($"Published workflow '{request.WorkflowKey}' was not found.");
        var initial = definition.States.FirstOrDefault() ?? throw new InvalidOperationException("Workflow has no states.");
        var instance = new WorkflowInstance(Guid.NewGuid(), tenantId, definition.Id, definition.Version,
            request.SubjectType, request.SubjectId, initial.Key, initial.IsTerminal ? "completed" : "active", 0, DateTimeOffset.UtcNow);
        await repository.AddInstanceAsync(instance, ct);
        await repository.AppendHistoryAsync(tenantId, new WorkflowHistoryEntry(Guid.NewGuid(), instance.Id,
            "Workflow.InstanceStarted", null, initial.Key, null, actorId, DateTimeOffset.UtcNow, request.SubjectData), ct);
        logger.LogInformation("Workflow {WorkflowKey} started for {SubjectType}/{SubjectId}", request.WorkflowKey, request.SubjectType, request.SubjectId);
        return instance;
    }

    public WorkflowDecision Validate(WorkflowDefinition definition, WorkflowInstance instance,
        string transitionKey, JsonElement subjectData, ClaimsPrincipal actor)
    {
        var transition = definition.Transitions.SingleOrDefault(x => x.Key == transitionKey && x.From == instance.CurrentState);
        if (transition is null) return new(false, "Transition is not available from the current state.", null);
        if (transition.AllowedRoles.Length > 0 && !transition.AllowedRoles.Any(actor.IsInRole))
            return new(false, "Actor does not hold an allowed role.", transition);
        foreach (var field in transition.RequiredFields)
            if (!subjectData.TryGetProperty(field, out var value) || value.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined ||
                (value.ValueKind == JsonValueKind.String && string.IsNullOrWhiteSpace(value.GetString())))
                return new(false, $"Required field '{field}' is missing.", transition);
        return new(true, null, transition);
    }

    public async Task<WorkflowInstance> TransitionAsync(Guid tenantId, Guid actorId, ClaimsPrincipal actor,
        Guid instanceId, TransitionWorkflowRequest request, CancellationToken ct)
    {
        var instance = await repository.GetInstanceAsync(tenantId, instanceId, ct) ?? throw new KeyNotFoundException("Workflow instance not found.");
        var definition = await repository.GetDefinitionByIdAsync(tenantId, instance.DefinitionId, instance.DefinitionVersion, ct)
            ?? throw new InvalidOperationException("Workflow definition not found.");
        var decision = Validate(definition, instance, request.TransitionKey, request.SubjectData, actor);
        if (!decision.Allowed) throw new InvalidOperationException(decision.Reason);
        var target = definition.States.Single(x => x.Key == decision.Transition!.To);
        var status = target.IsTerminal ? "completed" : "active";
        var updated = await repository.TryUpdateStateAsync(tenantId, instance.Id, instance.CurrentState, target.Key, status,
            request.ExpectedLockVersion, ct);
        if (!updated) throw new InvalidOperationException("Workflow was changed by another user. Reload and retry.");
        await repository.AppendHistoryAsync(tenantId, new WorkflowHistoryEntry(Guid.NewGuid(), instance.Id,
            "Workflow.StateChanged", instance.CurrentState, target.Key, request.TransitionKey, actorId,
            DateTimeOffset.UtcNow, request.SubjectData), ct);
        return instance with { CurrentState = target.Key, Status = status, LockVersion = instance.LockVersion + 1 };
    }
}
