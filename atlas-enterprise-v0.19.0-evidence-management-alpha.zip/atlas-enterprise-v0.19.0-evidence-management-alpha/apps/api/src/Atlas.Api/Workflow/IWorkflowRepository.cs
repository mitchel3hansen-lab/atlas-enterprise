namespace Atlas.Api.Workflow;

public interface IWorkflowRepository
{
    Task<WorkflowDefinition?> GetPublishedDefinitionAsync(Guid tenantId, string key, CancellationToken ct);
    Task<WorkflowDefinition?> GetDefinitionByIdAsync(Guid tenantId, Guid definitionId, int version, CancellationToken ct);
    Task<WorkflowInstance?> GetInstanceAsync(Guid tenantId, Guid instanceId, CancellationToken ct);
    Task AddInstanceAsync(WorkflowInstance instance, CancellationToken ct);
    Task<bool> TryUpdateStateAsync(Guid tenantId, Guid instanceId, string fromState, string toState,
        string status, int expectedLockVersion, CancellationToken ct);
    Task AppendHistoryAsync(Guid tenantId, WorkflowHistoryEntry entry, CancellationToken ct);
    Task<IReadOnlyList<WorkflowHistoryEntry>> GetHistoryAsync(Guid tenantId, Guid instanceId, CancellationToken ct);
}
