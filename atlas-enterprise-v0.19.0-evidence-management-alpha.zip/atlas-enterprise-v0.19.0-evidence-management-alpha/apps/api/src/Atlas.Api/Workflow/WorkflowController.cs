using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Atlas.Api.Workflow;

[ApiController]
[Route("api/v1/workflow-instances")]
[Authorize]
public sealed class WorkflowController(WorkflowEngine engine, IWorkflowRepository repository) : ControllerBase
{
    [HttpPost]
    public async Task<IActionResult> Start([FromBody] StartWorkflowRequest request, CancellationToken ct)
    {
        var tenantId = Guid.Parse(User.FindFirst("tenant_id")!.Value);
        var actorId = Guid.Parse(User.FindFirst("sub")!.Value);
        var instance = await engine.StartAsync(tenantId, actorId, request, ct);
        return CreatedAtAction(nameof(Get), new { id = instance.Id }, Envelope(instance));
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct)
    {
        var tenantId = Guid.Parse(User.FindFirst("tenant_id")!.Value);
        var instance = await repository.GetInstanceAsync(tenantId, id, ct);
        return instance is null ? NotFound() : Ok(Envelope(instance));
    }

    [HttpPost("{id:guid}/transitions")]
    public async Task<IActionResult> Transition(Guid id, [FromBody] TransitionWorkflowRequest request, CancellationToken ct)
    {
        var tenantId = Guid.Parse(User.FindFirst("tenant_id")!.Value);
        var actorId = Guid.Parse(User.FindFirst("sub")!.Value);
        return Ok(Envelope(await engine.TransitionAsync(tenantId, actorId, User, id, request, ct)));
    }

    [HttpGet("{id:guid}/history")]
    public async Task<IActionResult> History(Guid id, CancellationToken ct)
    {
        var tenantId = Guid.Parse(User.FindFirst("tenant_id")!.Value);
        return Ok(Envelope(await repository.GetHistoryAsync(tenantId, id, ct)));
    }

    private object Envelope(object data) => new { data, metadata = new { requestId = HttpContext.TraceIdentifier, timestamp = DateTimeOffset.UtcNow, version = "v0.16.0" }, errors = Array.Empty<object>() };
}
