using System.Security.Claims;
using System.Text.Json;
using Atlas.Api.Auth;
using Atlas.Api.Domain;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Administration;

[ApiController]
[Route("api/v1/admin/access")]
[Authorize]
public sealed class AccessAdministrationController(
    AtlasDbContext db,
    TenantContext tenant,
    InvitationTokenService invitationTokens) : ControllerBase
{
    [HttpGet("memberships")]
    [Authorize(Policy = AtlasPermissions.UsersRead)]
    public async Task<ActionResult<IReadOnlyList<MembershipView>>> List(CancellationToken ct)
    {
        var rows = await (
            from m in db.OrganizationMemberships
            join u in db.Users on m.UserId equals u.Id
            where m.OrganizationId == tenant.OrganizationId
            orderby u.DisplayName
            select new { m, u }).ToListAsync(ct);

        var membershipIds = rows.Select(x => x.m.Id).ToArray();
        var roleRows = await (
            from mr in db.MembershipRoles
            join r in db.Roles on mr.RoleId equals r.Id
            where membershipIds.Contains(mr.MembershipId)
            select new { mr.MembershipId, r.Name }).ToListAsync(ct);

        return Ok(rows.Select(x => new MembershipView(
            x.m.Id, x.u.Id, x.u.DisplayName, x.u.Email, x.m.IsActive,
            roleRows.Where(r => r.MembershipId == x.m.Id).Select(r => r.Name).Order().ToArray())).ToArray());
    }

    [HttpPost("invitations")]
    [Authorize(Policy = AtlasPermissions.UsersManage)]
    public async Task<ActionResult<InvitationCreated>> Invite(CreateInvitation request, CancellationToken ct)
    {
        var normalized = request.Email.Trim().ToUpperInvariant();
        var alreadyMember = await (
            from m in db.OrganizationMemberships
            join u in db.Users on m.UserId equals u.Id
            where m.OrganizationId == tenant.OrganizationId && u.NormalizedEmail == normalized && m.IsActive
            select m.Id).AnyAsync(ct);
        if (alreadyMember) return Conflict(new ProblemDetails { Title = "User already has active access." });

        var (plain, hash) = invitationTokens.Create();
        var actor = CurrentUserId();
        var invitation = new UserInvitation
        {
            Id = Guid.NewGuid(), OrganizationId = tenant.OrganizationId, Email = request.Email.Trim(),
            NormalizedEmail = normalized, TokenHash = hash, InvitedByUserId = actor,
            ExpiresAtUtc = DateTimeOffset.UtcNow.AddDays(7), CreatedAtUtc = DateTimeOffset.UtcNow
        };
        db.UserInvitations.Add(invitation);
        Audit(actor, null, "access.invitation.created", new { invitation.Id, invitation.Email, invitation.ExpiresAtUtc });
        await db.SaveChangesAsync(ct);
        return CreatedAtAction(nameof(GetInvitation), new { id = invitation.Id }, new InvitationCreated(invitation.Id, plain, invitation.ExpiresAtUtc));
    }

    [HttpGet("invitations/{id:guid}")]
    [Authorize(Policy = AtlasPermissions.UsersRead)]
    public async Task<ActionResult<InvitationView>> GetInvitation(Guid id, CancellationToken ct)
    {
        var x = await db.UserInvitations.SingleOrDefaultAsync(i => i.Id == id && i.OrganizationId == tenant.OrganizationId, ct);
        return x is null ? NotFound() : Ok(new InvitationView(x.Id, x.Email, x.ExpiresAtUtc, x.AcceptedAtUtc, x.RevokedAtUtc));
    }

    [HttpPut("memberships/{membershipId:guid}/roles")]
    [Authorize(Policy = AtlasPermissions.UsersManage)]
    public async Task<IActionResult> SetRoles(Guid membershipId, SetMembershipRoles request, CancellationToken ct)
    {
        var membership = await db.OrganizationMemberships.SingleOrDefaultAsync(x => x.Id == membershipId && x.OrganizationId == tenant.OrganizationId, ct);
        if (membership is null) return NotFound();
        var roles = await db.Roles.Where(r => request.RoleIds.Contains(r.Id) && (r.OrganizationId == null || r.OrganizationId == tenant.OrganizationId)).ToListAsync(ct);
        if (roles.Count != request.RoleIds.Distinct().Count()) return BadRequest(new ProblemDetails { Title = "One or more roles are invalid for this organization." });

        var current = await db.MembershipRoles.Where(x => x.MembershipId == membershipId).ToListAsync(ct);
        db.MembershipRoles.RemoveRange(current);
        db.MembershipRoles.AddRange(roles.Select(r => new MembershipRole { MembershipId = membershipId, RoleId = r.Id }));
        Audit(CurrentUserId(), membership.UserId, "access.roles.replaced", new { membershipId, roleIds = roles.Select(r => r.Id) });
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    [HttpGet("memberships/{membershipId:guid}/effective-permissions")]
    [Authorize(Policy = AtlasPermissions.UsersRead)]
    public async Task<ActionResult<EffectivePermissions>> EffectivePermissions(Guid membershipId, CancellationToken ct)
    {
        var membership = await db.OrganizationMemberships.SingleOrDefaultAsync(x => x.Id == membershipId && x.OrganizationId == tenant.OrganizationId, ct);
        if (membership is null) return NotFound();
        var permissions = await (
            from mr in db.MembershipRoles
            join rp in db.RolePermissions on mr.RoleId equals rp.RoleId
            join p in db.Permissions on rp.PermissionId equals p.Id
            where mr.MembershipId == membershipId
            select p.Code).Distinct().OrderBy(x => x).ToListAsync(ct);
        return Ok(new EffectivePermissions(membershipId, permissions));
    }

    [HttpPost("memberships/{membershipId:guid}/deactivate")]
    [Authorize(Policy = AtlasPermissions.UsersManage)]
    public async Task<IActionResult> Deactivate(Guid membershipId, CancellationToken ct)
    {
        var membership = await db.OrganizationMemberships.SingleOrDefaultAsync(x => x.Id == membershipId && x.OrganizationId == tenant.OrganizationId, ct);
        if (membership is null) return NotFound();
        membership.IsActive = false;
        Audit(CurrentUserId(), membership.UserId, "access.membership.deactivated", new { membershipId });
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    private Guid CurrentUserId() => Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub")!);
    private void Audit(Guid? actor, Guid? subject, string action, object details) => db.AccessAuditEvents.Add(new AccessAuditEvent
    {
        Id = Guid.NewGuid(), OrganizationId = tenant.OrganizationId, ActorUserId = actor, SubjectUserId = subject,
        Action = action, DetailsJson = JsonSerializer.Serialize(details), OccurredAtUtc = DateTimeOffset.UtcNow
    });
}

public sealed record MembershipView(Guid MembershipId, Guid UserId, string DisplayName, string Email, bool IsActive, IReadOnlyList<string> Roles);
public sealed record CreateInvitation(string Email);
public sealed record InvitationCreated(Guid InvitationId, string InvitationToken, DateTimeOffset ExpiresAtUtc);
public sealed record InvitationView(Guid InvitationId, string Email, DateTimeOffset ExpiresAtUtc, DateTimeOffset? AcceptedAtUtc, DateTimeOffset? RevokedAtUtc);
public sealed record SetMembershipRoles(IReadOnlyList<Guid> RoleIds);
public sealed record EffectivePermissions(Guid MembershipId, IReadOnlyList<string> Permissions);
