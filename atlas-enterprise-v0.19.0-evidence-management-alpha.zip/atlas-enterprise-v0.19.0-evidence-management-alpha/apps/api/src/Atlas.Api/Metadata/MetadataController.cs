using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace Atlas.Api.Metadata;

public sealed record CreateRecordRequest(
    string RecordNumber,
    string Title,
    Guid? OrganizationId,
    Guid? FacilityId,
    Guid? OwnerUserId,
    Guid? OwnerTeamId,
    JsonDocument Data);

[ApiController]
[Route("api/v1/objects")]
[Authorize]
public sealed class MetadataController(
    ObjectDefinitionService service,
    IMetadataRepository repository,
    ITenantContext tenant,
    ICurrentUser currentUser) : ControllerBase
{
    [HttpPost("{objectKey}/records")]
    [Authorize(Policy = "metadata.records.create")]
    public async Task<IActionResult> CreateRecord(
        string objectKey,
        CreateRecordRequest request,
        CancellationToken ct)
    {
        var id = await service.CreateRecordAsync(
            tenant.TenantId,
            currentUser.UserId,
            new(objectKey, request.RecordNumber, request.Title, request.OrganizationId,
                request.FacilityId, request.OwnerUserId, request.OwnerTeamId, request.Data),
            ct);

        return Created($"/api/v1/objects/{objectKey}/records/{id}", new { id });
    }

    [HttpGet("{objectKey}/records/{recordId:guid}")]
    [Authorize(Policy = "metadata.records.read")]
    public async Task<IActionResult> GetRecord(string objectKey, Guid recordId, CancellationToken ct)
    {
        var record = await repository.GetRecordAsync(tenant.TenantId, recordId, ct);
        return record is null ? NotFound() : Ok(record);
    }
}
