namespace Atlas.Api.Metadata;

public interface IMetadataRepository
{
    Task<ObjectDefinitionVersion?> GetPublishedVersionAsync(Guid tenantId, string objectKey, CancellationToken ct);
    Task<bool> RecordNumberExistsAsync(Guid tenantId, Guid definitionId, string recordNumber, CancellationToken ct);
    Task<Guid> SaveRecordAsync(ObjectRecord record, Guid actorId, CancellationToken ct);
    Task<ObjectRecord?> GetRecordAsync(Guid tenantId, Guid recordId, CancellationToken ct);
    Task AppendEventAsync(Guid tenantId, Guid recordId, string eventType, Guid actorId, object payload, CancellationToken ct);
}

public sealed record CreateObjectRecordCommand(
    string ObjectKey,
    string RecordNumber,
    string Title,
    Guid? OrganizationId,
    Guid? FacilityId,
    Guid? OwnerUserId,
    Guid? OwnerTeamId,
    System.Text.Json.JsonDocument Data);

public sealed class ObjectDefinitionService(
    IMetadataRepository repository,
    MetadataValidationService validator)
{
    public async Task<Guid> CreateRecordAsync(
        Guid tenantId,
        Guid actorId,
        CreateObjectRecordCommand command,
        CancellationToken ct)
    {
        var definition = await repository.GetPublishedVersionAsync(tenantId, command.ObjectKey, ct)
            ?? throw new KeyNotFoundException($"Published object definition '{command.ObjectKey}' was not found.");

        var validation = validator.Validate(definition, command.Data.RootElement);
        if (!validation.IsValid)
            throw new MetadataValidationException(validation.Errors);

        if (await repository.RecordNumberExistsAsync(tenantId, definition.ObjectDefinitionId, command.RecordNumber, ct))
            throw new InvalidOperationException("Record number already exists.");

        var initialState = definition.States.SingleOrDefault(x => x.IsInitial)
            ?? throw new InvalidOperationException("Published object definition requires one initial lifecycle state.");

        var record = new ObjectRecord(
            Guid.NewGuid(), tenantId, command.OrganizationId, command.FacilityId,
            definition.ObjectDefinitionId, definition.Id, command.RecordNumber.Trim(),
            command.Title.Trim(), initialState.Key, command.OwnerUserId, command.OwnerTeamId,
            command.Data, 1);

        var id = await repository.SaveRecordAsync(record, actorId, ct);
        await repository.AppendEventAsync(tenantId, id, "Object.Created", actorId,
            new { command.ObjectKey, command.RecordNumber, State = initialState.Key }, ct);
        return id;
    }
}

public sealed class MetadataValidationException(IReadOnlyList<ValidationError> errors)
    : Exception("Dynamic record validation failed.")
{
    public IReadOnlyList<ValidationError> Errors { get; } = errors;
}
