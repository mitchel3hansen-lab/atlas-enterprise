using System.Text.Json;

namespace Atlas.Api.Metadata;

public enum ObjectDefinitionStatus { Draft, Published, Retired }
public enum FieldType
{
    Text, RichText, Integer, Decimal, Currency, Percentage, Boolean,
    Date, DateTime, Duration, User, Team, Organization, Facility, Asset,
    File, Image, Signature, SingleSelect, MultiSelect, Lookup, Formula, Computed
}

public sealed record FieldDefinition(
    Guid Id,
    string Key,
    string Label,
    FieldType FieldType,
    bool IsRequired,
    bool IsUnique,
    bool IsSearchable,
    bool IsSensitive,
    int DisplayOrder,
    JsonDocument Validation,
    JsonDocument Visibility,
    JsonDocument Options);

public sealed record LifecycleStateDefinition(
    string Key,
    string Name,
    string Category,
    int DisplayOrder,
    bool IsInitial,
    bool IsTerminal);

public sealed record ObjectDefinitionVersion(
    Guid Id,
    Guid ObjectDefinitionId,
    int VersionNumber,
    DateTimeOffset? PublishedAt,
    IReadOnlyList<FieldDefinition> Fields,
    IReadOnlyList<LifecycleStateDefinition> States);

public sealed record ObjectRecord(
    Guid Id,
    Guid TenantId,
    Guid? OrganizationId,
    Guid? FacilityId,
    Guid ObjectDefinitionId,
    Guid ObjectDefinitionVersionId,
    string RecordNumber,
    string Title,
    string LifecycleStateKey,
    Guid? OwnerUserId,
    Guid? OwnerTeamId,
    JsonDocument Data,
    int Version);

public sealed record ValidationError(string FieldKey, string Code, string Message);
public sealed record RecordValidationResult(bool IsValid, IReadOnlyList<ValidationError> Errors);
