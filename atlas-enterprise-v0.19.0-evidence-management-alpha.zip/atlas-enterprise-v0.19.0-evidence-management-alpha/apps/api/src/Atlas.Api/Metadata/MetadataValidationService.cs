using System.Text.Json;
using System.Text.RegularExpressions;

namespace Atlas.Api.Metadata;

public sealed class MetadataValidationService
{
    public RecordValidationResult Validate(ObjectDefinitionVersion definition, JsonElement data)
    {
        var errors = new List<ValidationError>();

        foreach (var field in definition.Fields)
        {
            var exists = data.TryGetProperty(field.Key, out var value) &&
                         value.ValueKind is not JsonValueKind.Null and not JsonValueKind.Undefined;

            if (field.IsRequired && !exists)
            {
                errors.Add(new(field.Key, "required", $"{field.Label} is required."));
                continue;
            }

            if (!exists) continue;

            ValidateType(field, value, errors);
            ValidateRules(field, value, errors);
        }

        return new(errors.Count == 0, errors);
    }

    private static void ValidateType(FieldDefinition field, JsonElement value, List<ValidationError> errors)
    {
        var valid = field.FieldType switch
        {
            FieldType.Text or FieldType.RichText or FieldType.SingleSelect or FieldType.Date or
            FieldType.DateTime or FieldType.Duration or FieldType.Signature => value.ValueKind == JsonValueKind.String,
            FieldType.Integer => value.ValueKind == JsonValueKind.Number && value.TryGetInt64(out _),
            FieldType.Decimal or FieldType.Currency or FieldType.Percentage => value.ValueKind == JsonValueKind.Number,
            FieldType.Boolean => value.ValueKind is JsonValueKind.True or JsonValueKind.False,
            FieldType.MultiSelect => value.ValueKind == JsonValueKind.Array,
            FieldType.User or FieldType.Team or FieldType.Organization or FieldType.Facility or
            FieldType.Asset or FieldType.File or FieldType.Image or FieldType.Lookup =>
                value.ValueKind is JsonValueKind.String or JsonValueKind.Object or JsonValueKind.Array,
            FieldType.Formula or FieldType.Computed => true,
            _ => false
        };

        if (!valid)
            errors.Add(new(field.Key, "type", $"{field.Label} is not a valid {field.FieldType} value."));
    }

    private static void ValidateRules(FieldDefinition field, JsonElement value, List<ValidationError> errors)
    {
        var rules = field.Validation.RootElement;

        if (value.ValueKind == JsonValueKind.String)
        {
            var text = value.GetString() ?? string.Empty;
            if (rules.TryGetProperty("minLength", out var min) && text.Length < min.GetInt32())
                errors.Add(new(field.Key, "minLength", $"{field.Label} is shorter than allowed."));
            if (rules.TryGetProperty("maxLength", out var max) && text.Length > max.GetInt32())
                errors.Add(new(field.Key, "maxLength", $"{field.Label} is longer than allowed."));
            if (rules.TryGetProperty("pattern", out var pattern) && !Regex.IsMatch(text, pattern.GetString() ?? ""))
                errors.Add(new(field.Key, "pattern", $"{field.Label} does not match the required format."));
        }

        if (value.ValueKind == JsonValueKind.Number && value.TryGetDecimal(out var number))
        {
            if (rules.TryGetProperty("minimum", out var min) && number < min.GetDecimal())
                errors.Add(new(field.Key, "minimum", $"{field.Label} is below the minimum."));
            if (rules.TryGetProperty("maximum", out var max) && number > max.GetDecimal())
                errors.Add(new(field.Key, "maximum", $"{field.Label} exceeds the maximum."));
        }
    }
}
