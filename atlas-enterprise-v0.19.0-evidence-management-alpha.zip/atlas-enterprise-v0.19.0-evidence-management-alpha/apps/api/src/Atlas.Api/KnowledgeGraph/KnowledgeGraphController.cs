using System.Security.Claims;
using Atlas.Api.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Atlas.Api.KnowledgeGraph;

[ApiController]
[Route("api/v1/knowledge-graph")]
[Authorize]
public sealed class KnowledgeGraphController(KnowledgeGraphService service, TenantContext tenant) : ControllerBase
{
    [HttpPost("nodes")]
    [Authorize(Policy = "knowledge_graph.manage")]
    public async Task<ActionResult<GraphNode>> CreateNode(CreateNodeRequest request, CancellationToken ct)
        => Ok(await service.EnsureNodeAsync(tenant.OrganizationId, ActorId(), request, ct));

    [HttpPost("edges")]
    [Authorize(Policy = "knowledge_graph.manage")]
    public async Task<ActionResult<GraphEdge>> CreateEdge(CreateEdgeRequest request, CancellationToken ct)
        => Ok(await service.ConnectAsync(tenant.OrganizationId, ActorId(), request,
            HttpContext.TraceIdentifier, ct));

    [HttpGet("nodes/{nodeId:guid}/impact")]
    [Authorize(Policy = "knowledge_graph.read")]
    public async Task<ActionResult<ImpactAnalysisResult>> Impact(Guid nodeId, [FromQuery] int depth = 2, CancellationToken ct = default)
        => Ok(await service.TraverseAsync(tenant.OrganizationId, nodeId, depth, ct));

    private Guid ActorId()
    {
        var value = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub");
        return Guid.TryParse(value, out var id) ? id : throw new UnauthorizedAccessException("User identifier is missing.");
    }
}
