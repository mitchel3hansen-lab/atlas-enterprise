namespace Atlas.Api.KnowledgeGraph;

public sealed record GraphNode(Guid Id, Guid TenantId, Guid? OrganizationId, string ObjectType,
    Guid ObjectId, string DisplayName, IReadOnlyDictionary<string, object?> Attributes, long Version);

public sealed record RelationshipType(Guid Id, string Code, string Name, string? InverseCode,
    bool IsDirectional, IReadOnlySet<string> AllowedSourceTypes, IReadOnlySet<string> AllowedTargetTypes);

public sealed record GraphEdge(Guid Id, Guid TenantId, Guid? OrganizationId, Guid SourceNodeId,
    Guid TargetNodeId, Guid RelationshipTypeId, decimal Confidence, string? Rationale,
    IReadOnlyList<Guid> EvidenceIds, DateTimeOffset ValidFrom, DateTimeOffset? ValidTo,
    Guid? SupersedesEdgeId);

public sealed record CreateNodeRequest(string ObjectType, Guid ObjectId, string DisplayName,
    Dictionary<string, object?>? Attributes, Guid? OrganizationId);
public sealed record CreateEdgeRequest(Guid SourceNodeId, Guid TargetNodeId, string RelationshipType,
    decimal Confidence, string? Rationale, IReadOnlyList<Guid>? EvidenceIds, Guid? OrganizationId);
public sealed record TraversalStep(Guid NodeId, string ObjectType, string DisplayName, int Depth,
    Guid? ViaEdgeId, string? RelationshipType);
public sealed record ImpactAnalysisResult(Guid RootNodeId, int MaxDepth,
    IReadOnlyList<TraversalStep> Nodes, IReadOnlyDictionary<string, int> CountsByObjectType);
