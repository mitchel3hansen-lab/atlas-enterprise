namespace Atlas.Api.KnowledgeGraph;

public sealed class KnowledgeGraphService(IKnowledgeGraphRepository repository)
{
    public async Task<GraphNode> EnsureNodeAsync(Guid tenantId, Guid actorId, CreateNodeRequest request, CancellationToken ct)
    {
        ValidateObjectType(request.ObjectType);
        if (string.IsNullOrWhiteSpace(request.DisplayName)) throw new ArgumentException("Display name is required.");
        var existing = await repository.FindNodeAsync(tenantId, request.ObjectType.Trim(), request.ObjectId, ct);
        if (existing is not null) return existing;
        var node = new GraphNode(Guid.NewGuid(), tenantId, request.OrganizationId, request.ObjectType.Trim(),
            request.ObjectId, request.DisplayName.Trim(), request.Attributes ?? new(), 1);
        return await repository.CreateNodeAsync(node, actorId, ct);
    }

    public async Task<GraphEdge> ConnectAsync(Guid tenantId, Guid actorId, CreateEdgeRequest request,
        string? correlationId, CancellationToken ct)
    {
        if (request.SourceNodeId == request.TargetNodeId) throw new ArgumentException("Self relationships are not allowed.");
        if (request.Confidence is < 0 or > 1) throw new ArgumentOutOfRangeException(nameof(request.Confidence));
        var source = await repository.GetNodeAsync(tenantId, request.SourceNodeId, ct)
            ?? throw new KeyNotFoundException("Source node was not found.");
        var target = await repository.GetNodeAsync(tenantId, request.TargetNodeId, ct)
            ?? throw new KeyNotFoundException("Target node was not found.");
        var type = await repository.GetRelationshipTypeAsync(tenantId, request.RelationshipType.Trim(), ct)
            ?? throw new KeyNotFoundException("Relationship type was not found.");
        ValidateAllowedType(type.AllowedSourceTypes, source.ObjectType, "source");
        ValidateAllowedType(type.AllowedTargetTypes, target.ObjectType, "target");
        var edge = new GraphEdge(Guid.NewGuid(), tenantId, request.OrganizationId, source.Id, target.Id,
            type.Id, request.Confidence, request.Rationale?.Trim(), request.EvidenceIds ?? Array.Empty<Guid>(),
            DateTimeOffset.UtcNow, null, null);
        return await repository.CreateEdgeAsync(edge, actorId, correlationId, ct);
    }

    public async Task<ImpactAnalysisResult> TraverseAsync(Guid tenantId, Guid rootNodeId, int maxDepth, CancellationToken ct)
    {
        if (maxDepth is < 0 or > 6) throw new ArgumentOutOfRangeException(nameof(maxDepth), "Depth must be between 0 and 6.");
        var root = await repository.GetNodeAsync(tenantId, rootNodeId, ct)
            ?? throw new KeyNotFoundException("Root node was not found.");
        var visited = new HashSet<Guid> { root.Id };
        var steps = new List<TraversalStep> { new(root.Id, root.ObjectType, root.DisplayName, 0, null, null) };
        var queue = new Queue<(Guid NodeId, int Depth)>(); queue.Enqueue((root.Id, 0));
        while (queue.Count > 0)
        {
            var current = queue.Dequeue(); if (current.Depth >= maxDepth) continue;
            var edges = await repository.GetAdjacentEdgesAsync(tenantId, current.NodeId, ct);
            foreach (var edge in edges)
            {
                var nextId = edge.SourceNodeId == current.NodeId ? edge.TargetNodeId : edge.SourceNodeId;
                if (!visited.Add(nextId)) continue;
                var node = (await repository.GetNodesAsync(tenantId, new[] { nextId }, ct)).Single();
                steps.Add(new(node.Id, node.ObjectType, node.DisplayName, current.Depth + 1, edge.Id,
                    edge.RelationshipTypeId.ToString()));
                queue.Enqueue((nextId, current.Depth + 1));
            }
        }
        return new(root.Id, maxDepth, steps, steps.GroupBy(x => x.ObjectType)
            .ToDictionary(x => x.Key, x => x.Count(), StringComparer.OrdinalIgnoreCase));
    }

    private static void ValidateObjectType(string value)
    {
        if (string.IsNullOrWhiteSpace(value) || value.Length > 120) throw new ArgumentException("A valid object type is required.");
    }
    private static void ValidateAllowedType(IReadOnlySet<string> allowed, string actual, string side)
    {
        if (allowed.Count > 0 && !allowed.Contains(actual)) throw new InvalidOperationException($"Object type '{actual}' is not allowed as the {side}.");
    }
}
