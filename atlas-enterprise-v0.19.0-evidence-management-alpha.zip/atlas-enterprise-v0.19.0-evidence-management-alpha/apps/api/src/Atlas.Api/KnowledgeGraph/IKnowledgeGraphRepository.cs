namespace Atlas.Api.KnowledgeGraph;

public interface IKnowledgeGraphRepository
{
    Task<GraphNode?> GetNodeAsync(Guid tenantId, Guid nodeId, CancellationToken ct);
    Task<GraphNode?> FindNodeAsync(Guid tenantId, string objectType, Guid objectId, CancellationToken ct);
    Task<GraphNode> CreateNodeAsync(GraphNode node, Guid actorId, CancellationToken ct);
    Task<RelationshipType?> GetRelationshipTypeAsync(Guid tenantId, string code, CancellationToken ct);
    Task<GraphEdge> CreateEdgeAsync(GraphEdge edge, Guid actorId, string? correlationId, CancellationToken ct);
    Task<IReadOnlyList<GraphEdge>> GetAdjacentEdgesAsync(Guid tenantId, Guid nodeId, CancellationToken ct);
    Task<IReadOnlyList<GraphNode>> GetNodesAsync(Guid tenantId, IEnumerable<Guid> ids, CancellationToken ct);
}
