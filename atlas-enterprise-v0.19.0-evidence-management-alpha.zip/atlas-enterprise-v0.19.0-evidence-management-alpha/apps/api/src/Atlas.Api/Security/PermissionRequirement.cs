using Microsoft.AspNetCore.Authorization;

namespace Atlas.Api.Security;

public sealed record PermissionRequirement(string Permission) : IAuthorizationRequirement;

public sealed class PermissionAuthorizationHandler : AuthorizationHandler<PermissionRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        PermissionRequirement requirement)
    {
        if (context.User.Claims.Any(x => x.Type == "permission" && x.Value == requirement.Permission))
            context.Succeed(requirement);

        return Task.CompletedTask;
    }
}
