namespace Atlas.Api.Security;

public static class AtlasPermissions
{
    public const string OrganizationsRead = "organizations.read";
    public const string OrganizationsManage = "organizations.manage";
    public const string FacilitiesRead = "facilities.read";
    public const string FacilitiesManage = "facilities.manage";
    public const string UsersRead = "users.read";
    public const string UsersManage = "users.manage";
    public const string SafetyRead = "safety.read";
    public const string SafetyManage = "safety.manage";
    public const string ExplainabilityRead = "explainability.read";
    public const string ExplainabilityManage = "explainability.manage";
    public const string KnowledgeGraphRead = "knowledge_graph.read";
    public const string KnowledgeGraphManage = "knowledge_graph.manage";
    public const string RulesRead = "rules.read";
    public const string RulesManage = "rules.manage";
    public const string RulesExecute = "rules.execute";
    public const string EvidenceRead = "evidence.read";
    public const string EvidenceManage = "evidence.manage";
    public const string EvidenceDownload = "evidence.download";
    public const string EvidenceLegalHold = "evidence.legal_hold";

    public static readonly string[] All =
    [
        OrganizationsRead, OrganizationsManage, FacilitiesRead, FacilitiesManage,
        UsersRead, UsersManage, SafetyRead, SafetyManage,
        ExplainabilityRead, ExplainabilityManage,
        KnowledgeGraphRead, KnowledgeGraphManage,
        RulesRead, RulesManage, RulesExecute,
        EvidenceRead, EvidenceManage, EvidenceDownload, EvidenceLegalHold
    ];
}
