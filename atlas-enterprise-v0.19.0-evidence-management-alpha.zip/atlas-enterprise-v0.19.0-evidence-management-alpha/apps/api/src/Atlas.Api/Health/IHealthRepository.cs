namespace Atlas.Api.Health;
public interface IHealthRepository
{
 Task<HealthModelVersion?> GetPublishedModelAsync(Guid tenantId, Guid modelId, CancellationToken ct);
 Task<IReadOnlyCollection<HealthMeasurement>> GetMeasurementsAsync(Guid tenantId, string subjectType,
  Guid subjectId, IReadOnlyCollection<string> indicatorCodes, CancellationToken ct);
 Task<decimal?> GetLatestScoreAsync(Guid tenantId, Guid modelId, string subjectType, Guid subjectId, CancellationToken ct);
 Task<Guid> SaveMeasurementAsync(HealthMeasurement measurement, Guid actorId, CancellationToken ct);
 Task<Guid> SaveSnapshotAsync(Guid tenantId, RecalculateHealthRequest request, HealthModelVersion model,
  HealthCalculationResult result, Guid actorId, CancellationToken ct);
 Task<HealthSnapshotResponse?> GetLatestSnapshotAsync(Guid tenantId, string subjectType, Guid subjectId, CancellationToken ct);
}
