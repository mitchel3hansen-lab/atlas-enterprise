namespace Atlas.Api.Health;
public sealed class HealthService(IHealthRepository repository, HealthCalculationService calculator, TimeProvider timeProvider)
{
 public async Task<Guid> RecordMeasurementAsync(Guid tenantId, Guid actorId,
  CreateMeasurementRequest r, CancellationToken ct)
 {
  if (r.Confidence is < 0 or > 1) throw new ArgumentOutOfRangeException(nameof(r.Confidence));
  var m = new HealthMeasurement(Guid.NewGuid(), tenantId, r.SubjectType.Trim(), r.SubjectId,
   r.IndicatorCode.Trim(), r.MeasuredValue, r.MeasuredAt, r.SourceType.Trim(),
   r.SourceReference, r.EvidenceId, r.Confidence);
  return await repository.SaveMeasurementAsync(m, actorId, ct);
 }
 public async Task<Guid> RecalculateAsync(Guid tenantId, Guid actorId,
  RecalculateHealthRequest r, CancellationToken ct)
 {
  var model = await repository.GetPublishedModelAsync(tenantId, r.HealthModelId, ct)
   ?? throw new KeyNotFoundException("Published health model not found.");
  var measurements = await repository.GetMeasurementsAsync(tenantId, r.SubjectType, r.SubjectId,
   model.Indicators.Select(x => x.Code).ToArray(), ct);
  var prior = await repository.GetLatestScoreAsync(tenantId, r.HealthModelId, r.SubjectType, r.SubjectId, ct);
  var result = calculator.Calculate(model, measurements, prior, timeProvider.GetUtcNow());
  return await repository.SaveSnapshotAsync(tenantId, r, model, result, actorId, ct);
 }
}
