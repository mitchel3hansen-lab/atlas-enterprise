namespace Atlas.Api.Health;

public enum HealthDirection { HigherIsBetter, LowerIsBetter, TargetRange }
public enum HealthStatus { Exceptional, Healthy, Stable, NeedsAttention, Critical }
public enum HealthTrend { Improving, Stable, Declining, InsufficientHistory }

public sealed record HealthIndicator(Guid Id, string Code, string Name, HealthDirection Direction,
 decimal Weight, decimal MinimumValue, decimal TargetValue, decimal MaximumValue,
 int? StaleAfterHours, decimal SourceReliability, bool IsRequired, string? RecommendationTemplate);

public sealed record HealthMeasurement(Guid Id, Guid TenantId, string SubjectType, Guid SubjectId,
 string IndicatorCode, decimal MeasuredValue, DateTimeOffset MeasuredAt, string SourceType,
 string? SourceReference, Guid? EvidenceId, decimal Confidence);

public sealed record HealthModelVersion(Guid Id, Guid HealthModelId, int VersionNumber,
 IReadOnlyList<HealthIndicator> Indicators);

public sealed record HealthContribution(Guid IndicatorId, string IndicatorCode, string IndicatorName,
 decimal? RawValue, decimal NormalizedScore, decimal NormalizedWeight, decimal WeightedContribution,
 decimal Confidence, string EvidenceStatus, string Explanation);

public sealed record HealthRecommendation(string? IndicatorCode, string Title, string Rationale,
 string Priority, decimal? EstimatedScoreGain, string RecommendedAction);

public sealed record HealthCalculationResult(decimal Score, decimal Confidence, HealthStatus Status,
 HealthTrend Trend, decimal TrendDelta, IReadOnlyList<HealthContribution> Contributions,
 IReadOnlyList<HealthRecommendation> Recommendations, IReadOnlyList<string> MissingEvidence,
 string CalculationHash);
