using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace Atlas.Api.Health;

[ApiController, Route("api/v1/health"), Authorize]
public sealed class HealthController(HealthService service, IHealthRepository repository,
 ITenantContext tenantContext, ICurrentUser currentUser) : ControllerBase
{
 [HttpPost("measurements"), Authorize(Policy="health.measurements.write")]
 public async Task<IActionResult> RecordMeasurement(CreateMeasurementRequest r, CancellationToken ct)
 {
  var id = await service.RecordMeasurementAsync(tenantContext.TenantId, currentUser.UserId, r, ct);
  return Created($"/api/v1/health/measurements/{id}", new { id });
 }
 [HttpPost("recalculate"), Authorize(Policy="health.calculate")]
 public async Task<IActionResult> Recalculate(RecalculateHealthRequest r, CancellationToken ct)
 {
  var id = await service.RecalculateAsync(tenantContext.TenantId, currentUser.UserId, r, ct);
  return Accepted($"/api/v1/health/snapshots/{id}", new { snapshotId = id });
 }
 [HttpGet("{subjectType}/{subjectId:guid}"), Authorize(Policy="health.read")]
 public async Task<ActionResult<HealthSnapshotResponse>> GetLatest(string subjectType, Guid subjectId, CancellationToken ct)
 {
  var result = await repository.GetLatestSnapshotAsync(tenantContext.TenantId, subjectType, subjectId, ct);
  return result is null ? NotFound() : Ok(result);
 }
 [HttpGet("{subjectType}/{subjectId:guid}/explain"), Authorize(Policy="health.explain")]
 public Task<ActionResult<HealthSnapshotResponse>> Explain(string subjectType, Guid subjectId, CancellationToken ct)
  => GetLatest(subjectType, subjectId, ct);
}
