namespace Atlas.Api.Health;
public sealed record CreateMeasurementRequest(string SubjectType, Guid SubjectId, Guid? OrganizationId,
 Guid? FacilityId, string IndicatorCode, decimal MeasuredValue, string? Unit,
 DateTimeOffset MeasuredAt, string SourceType, string? SourceReference, Guid? EvidenceId, decimal Confidence);
public sealed record RecalculateHealthRequest(Guid HealthModelId, string SubjectType, Guid SubjectId,
 Guid? OrganizationId, Guid? FacilityId);
public sealed record HealthSnapshotResponse(Guid SnapshotId, string SubjectType, Guid SubjectId,
 decimal Score, decimal Confidence, string Status, string Trend, decimal TrendDelta,
 DateTimeOffset CalculatedAt, IReadOnlyList<HealthContribution> Contributions,
 IReadOnlyList<HealthRecommendation> Recommendations, IReadOnlyList<string> MissingEvidence);
