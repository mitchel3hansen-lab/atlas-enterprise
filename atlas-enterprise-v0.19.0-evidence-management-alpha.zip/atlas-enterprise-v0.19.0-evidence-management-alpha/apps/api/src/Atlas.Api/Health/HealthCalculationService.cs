using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Atlas.Api.Health;

public sealed class HealthCalculationService
{
 public HealthCalculationResult Calculate(HealthModelVersion model,
  IReadOnlyCollection<HealthMeasurement> measurements, decimal? previousScore,
  DateTimeOffset calculatedAt)
 {
  if (model.Indicators.Count == 0) throw new InvalidOperationException("Published model requires indicators.");
  var totalWeight = model.Indicators.Sum(x => x.Weight);
  if (totalWeight <= 0) throw new InvalidOperationException("Indicator weight total must exceed zero.");

  var contributions = new List<HealthContribution>();
  var recommendations = new List<HealthRecommendation>();
  var missing = new List<string>();

  foreach (var i in model.Indicators.OrderBy(x => x.Code))
  {
   var m = measurements.Where(x => x.IndicatorCode.Equals(i.Code, StringComparison.OrdinalIgnoreCase))
    .OrderByDescending(x => x.MeasuredAt).FirstOrDefault();
   var weight = i.Weight / totalWeight;
   if (m is null)
   {
    missing.Add(i.Code);
    contributions.Add(new(i.Id, i.Code, i.Name, null, 0, weight, 0, 0, "Missing",
     $"No current measurement exists for {i.Name}."));
    continue;
   }
   var score = Normalize(i, m.MeasuredValue);
   var freshness = Freshness(i, m, calculatedAt);
   var evidence = m.EvidenceId.HasValue ? 1m : .85m;
   var confidence = Clamp01(m.Confidence * i.SourceReliability * freshness * evidence);
   contributions.Add(new(i.Id, i.Code, i.Name, m.MeasuredValue, score, weight,
    score * weight, confidence, m.EvidenceId.HasValue ? "Verified" : "Unlinked",
    $"{i.Name} scored {score:0.0}/100 and contributed {(score * weight):0.0} points."));
   if (score < 70)
    recommendations.Add(new(i.Code, $"Improve {i.Name}",
     $"{i.Name} currently scores {score:0.0}/100.",
     score < 40 ? "Critical" : score < 55 ? "High" : "Medium",
     decimal.Round((100 - score) * weight, 2),
     i.RecommendationTemplate ?? $"Review and improve {i.Name}."));
  }

  var scoreTotal = Clamp100(contributions.Sum(x => x.WeightedContribution));
  var confidenceTotal = Clamp01(contributions.Sum(x => x.Confidence * x.NormalizedWeight) * .75m +
   ((decimal)(model.Indicators.Count - missing.Count) / model.Indicators.Count) * .25m);
  var status = scoreTotal switch { >= 90 => HealthStatus.Exceptional, >= 80 => HealthStatus.Healthy,
   >= 65 => HealthStatus.Stable, >= 40 => HealthStatus.NeedsAttention, _ => HealthStatus.Critical };
  var delta = previousScore.HasValue ? scoreTotal - previousScore.Value : 0;
  var trend = previousScore is null ? HealthTrend.InsufficientHistory :
   delta > 1 ? HealthTrend.Improving : delta < -1 ? HealthTrend.Declining : HealthTrend.Stable;

  var serialized = JsonSerializer.Serialize(new { model.Id, model.VersionNumber, scoreTotal, confidenceTotal, contributions });
  var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(serialized))).ToLowerInvariant();
  return new(decimal.Round(scoreTotal, 3), decimal.Round(confidenceTotal, 4), status, trend,
   decimal.Round(delta, 3), contributions, recommendations, missing, hash);
 }

 internal static decimal Normalize(HealthIndicator i, decimal value)
 {
  static decimal Div(decimal a, decimal b) => b == 0 ? (a >= 0 ? 1m : 0m) : a / b;
  var raw = i.Direction switch
  {
   HealthDirection.HigherIsBetter => 100 * Div(value - i.MinimumValue, i.TargetValue - i.MinimumValue),
   HealthDirection.LowerIsBetter => 100 * Div(i.MaximumValue - value, i.MaximumValue - i.TargetValue),
   HealthDirection.TargetRange when value <= i.TargetValue => 100 * Div(value - i.MinimumValue, i.TargetValue - i.MinimumValue),
   HealthDirection.TargetRange => 100 * Div(i.MaximumValue - value, i.MaximumValue - i.TargetValue),
   _ => 0
  };
  return Clamp100(raw);
 }

 static decimal Freshness(HealthIndicator i, HealthMeasurement m, DateTimeOffset now)
 {
  if (i.StaleAfterHours is null) return 1;
  var hours = (now - m.MeasuredAt).TotalHours;
  if (hours <= i.StaleAfterHours.Value) return 1;
  return Clamp01(1 / (decimal)(hours / i.StaleAfterHours.Value));
 }
 static decimal Clamp01(decimal v) => Math.Min(1, Math.Max(0, v));
 static decimal Clamp100(decimal v) => Math.Min(100, Math.Max(0, v));
}
