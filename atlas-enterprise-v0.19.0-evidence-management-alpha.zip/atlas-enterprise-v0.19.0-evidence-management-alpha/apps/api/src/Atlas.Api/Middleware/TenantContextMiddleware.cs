using System.Security.Claims;
using Atlas.Api.Infrastructure;

namespace Atlas.Api.Middleware;

public sealed class TenantContextMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context, TenantContext tenant)
    {
        var claimValue = context.User.FindFirstValue("organization_id");
        if (Guid.TryParse(claimValue, out var claimOrganizationId))
            tenant.Set(claimOrganizationId);

        await next(context);
    }
}
