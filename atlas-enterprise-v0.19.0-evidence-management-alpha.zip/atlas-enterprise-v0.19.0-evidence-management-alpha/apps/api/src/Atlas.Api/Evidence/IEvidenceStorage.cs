namespace Atlas.Api.Evidence;

public interface IEvidenceStorage
{
    Task<string> PutAsync(Guid organizationId, Guid evidenceId, int versionNumber, byte[] content, CancellationToken cancellationToken);
    Task<byte[]> GetAsync(string storageKey, CancellationToken cancellationToken);
}
