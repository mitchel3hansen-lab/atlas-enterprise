namespace Atlas.Api.Evidence;

public interface IEvidenceRepository
{
    Task<EvidenceRecord?> GetAsync(Guid organizationId, Guid evidenceId, CancellationToken cancellationToken);
    Task<IReadOnlyList<EvidenceRecord>> ListForObjectAsync(Guid organizationId, string objectType, Guid objectId, CancellationToken cancellationToken);
    Task SaveAsync(EvidenceRecord record, CancellationToken cancellationToken);
    Task<IReadOnlyList<EvidenceVersion>> GetVersionsAsync(Guid evidenceId, CancellationToken cancellationToken);
    Task<EvidenceVersion?> GetVersionAsync(Guid evidenceId, int versionNumber, CancellationToken cancellationToken);
    Task SaveVersionAsync(EvidenceVersion version, CancellationToken cancellationToken);
    Task AppendAccessAsync(EvidenceAccessEvent accessEvent, CancellationToken cancellationToken);
}
