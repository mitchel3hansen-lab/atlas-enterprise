using System.Collections.Concurrent;

namespace Atlas.Api.Evidence;

public sealed class InMemoryEvidenceRepository : IEvidenceRepository
{
    private readonly ConcurrentDictionary<Guid, EvidenceRecord> _records = new();
    private readonly ConcurrentDictionary<Guid, ConcurrentDictionary<int, EvidenceVersion>> _versions = new();
    private readonly ConcurrentQueue<EvidenceAccessEvent> _access = new();

    public Task<EvidenceRecord?> GetAsync(Guid organizationId, Guid evidenceId, CancellationToken cancellationToken)
    {
        _records.TryGetValue(evidenceId, out var record);
        return Task.FromResult(record is not null && record.OrganizationId == organizationId ? record : null);
    }

    public Task<IReadOnlyList<EvidenceRecord>> ListForObjectAsync(Guid organizationId, string objectType, Guid objectId, CancellationToken cancellationToken)
    {
        IReadOnlyList<EvidenceRecord> result = _records.Values
            .Where(x => x.OrganizationId == organizationId && x.ObjectId == objectId && string.Equals(x.ObjectType, objectType, StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(x => x.ModifiedAtUtc)
            .ToArray();
        return Task.FromResult(result);
    }

    public Task SaveAsync(EvidenceRecord record, CancellationToken cancellationToken)
    {
        _records[record.Id] = record;
        return Task.CompletedTask;
    }

    public Task<IReadOnlyList<EvidenceVersion>> GetVersionsAsync(Guid evidenceId, CancellationToken cancellationToken)
    {
        IReadOnlyList<EvidenceVersion> result = _versions.TryGetValue(evidenceId, out var versions)
            ? versions.Values.OrderByDescending(x => x.VersionNumber).ToArray()
            : Array.Empty<EvidenceVersion>();
        return Task.FromResult(result);
    }

    public Task<EvidenceVersion?> GetVersionAsync(Guid evidenceId, int versionNumber, CancellationToken cancellationToken)
    {
        EvidenceVersion? result = null;
        if (_versions.TryGetValue(evidenceId, out var versions)) versions.TryGetValue(versionNumber, out result);
        return Task.FromResult(result);
    }

    public Task SaveVersionAsync(EvidenceVersion version, CancellationToken cancellationToken)
    {
        var versions = _versions.GetOrAdd(version.EvidenceId, _ => new ConcurrentDictionary<int, EvidenceVersion>());
        if (!versions.TryAdd(version.VersionNumber, version))
            throw new InvalidOperationException($"Evidence version {version.VersionNumber} already exists.");
        return Task.CompletedTask;
    }

    public Task AppendAccessAsync(EvidenceAccessEvent accessEvent, CancellationToken cancellationToken)
    {
        _access.Enqueue(accessEvent);
        return Task.CompletedTask;
    }
}
