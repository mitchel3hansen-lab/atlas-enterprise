using System.Security.Claims;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Atlas.Api.Evidence;

[ApiController]
[Route("api/v1/evidence")]
public sealed class EvidenceController(EvidenceService service, IEvidenceRepository repository) : ControllerBase
{
    [HttpPost]
    [Authorize(Policy = AtlasPermissions.EvidenceManage)]
    public async Task<ActionResult<EvidenceRecord>> Create(CreateEvidenceRequest request, CancellationToken cancellationToken)
    {
        var record = await service.CreateAsync(OrganizationId(), ActorId(), CorrelationId(), request, cancellationToken);
        return CreatedAtAction(nameof(Get), new { evidenceId = record.Id }, record);
    }

    [HttpGet("{evidenceId:guid}")]
    [Authorize(Policy = AtlasPermissions.EvidenceRead)]
    public async Task<ActionResult<EvidenceRecord>> Get(Guid evidenceId, CancellationToken cancellationToken)
    {
        var record = await repository.GetAsync(OrganizationId(), evidenceId, cancellationToken);
        return record is null ? NotFound() : Ok(record);
    }

    [HttpGet("object/{objectType}/{objectId:guid}")]
    [Authorize(Policy = AtlasPermissions.EvidenceRead)]
    public async Task<ActionResult<IReadOnlyList<EvidenceRecord>>> ListForObject(string objectType, Guid objectId, CancellationToken cancellationToken) =>
        Ok(await repository.ListForObjectAsync(OrganizationId(), objectType, objectId, cancellationToken));

    [HttpGet("{evidenceId:guid}/versions")]
    [Authorize(Policy = AtlasPermissions.EvidenceRead)]
    public async Task<ActionResult<IReadOnlyList<EvidenceVersion>>> Versions(Guid evidenceId, CancellationToken cancellationToken)
    {
        if (await repository.GetAsync(OrganizationId(), evidenceId, cancellationToken) is null) return NotFound();
        return Ok(await repository.GetVersionsAsync(evidenceId, cancellationToken));
    }

    [HttpPost("{evidenceId:guid}/versions")]
    [Authorize(Policy = AtlasPermissions.EvidenceManage)]
    public async Task<ActionResult<EvidenceVersion>> AddVersion(Guid evidenceId, AddEvidenceVersionRequest request, CancellationToken cancellationToken) =>
        Ok(await service.AddVersionAsync(OrganizationId(), evidenceId, ActorId(), CorrelationId(), request, cancellationToken));

    [HttpGet("{evidenceId:guid}/content")]
    [Authorize(Policy = AtlasPermissions.EvidenceDownload)]
    public async Task<IActionResult> Download(Guid evidenceId, [FromQuery] int? version, CancellationToken cancellationToken)
    {
        var file = await service.DownloadAsync(OrganizationId(), evidenceId, version, ActorId(), CorrelationId(), cancellationToken);
        Response.Headers.Append("X-Atlas-SHA256", file.Sha256);
        Response.Headers.Append("X-Atlas-Evidence-Version", file.VersionNumber.ToString());
        return File(file.Content, file.ContentType, file.FileName);
    }

    [HttpPost("{evidenceId:guid}/legal-hold")]
    [Authorize(Policy = AtlasPermissions.EvidenceLegalHold)]
    public async Task<IActionResult> LegalHold(Guid evidenceId, [FromQuery] bool enabled, CancellationToken cancellationToken)
    {
        await service.SetLegalHoldAsync(OrganizationId(), evidenceId, enabled, ActorId(), CorrelationId(), cancellationToken);
        return NoContent();
    }

    private Guid OrganizationId() => Guid.TryParse(User.FindFirstValue("organization_id"), out var id) ? id : throw new UnauthorizedAccessException("organization_id claim required.");
    private Guid ActorId() => Guid.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : throw new UnauthorizedAccessException("sub claim required.");
    private string CorrelationId() => HttpContext.TraceIdentifier;
}
