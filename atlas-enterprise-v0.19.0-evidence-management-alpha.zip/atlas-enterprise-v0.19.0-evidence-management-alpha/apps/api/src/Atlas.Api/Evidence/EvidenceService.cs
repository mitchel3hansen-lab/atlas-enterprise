using System.Security.Cryptography;

namespace Atlas.Api.Evidence;

public sealed class EvidenceService(IEvidenceRepository repository, IEvidenceStorage storage)
{
    private const int MaxBytes = 25 * 1024 * 1024;

    public async Task<EvidenceRecord> CreateAsync(Guid organizationId, Guid actorId, string correlationId, CreateEvidenceRequest request, CancellationToken cancellationToken)
    {
        ValidateMetadata(request.Title, request.FileName, request.ContentType);
        var bytes = Decode(request.Base64Content);
        var record = new EvidenceRecord
        {
            Id = Guid.NewGuid(), OrganizationId = organizationId, ObjectId = request.ObjectId, ObjectType = request.ObjectType,
            Title = request.Title.Trim(), Description = request.Description.Trim(), Classification = request.Classification,
            RetentionPolicy = string.IsNullOrWhiteSpace(request.RetentionPolicy) ? "standard-7-years" : request.RetentionPolicy.Trim(),
            CreatedBy = actorId, ModifiedBy = actorId
        };
        var version = await BuildVersionAsync(record, 1, actorId, request.FileName, request.ContentType, bytes, request.Notes, cancellationToken);
        await repository.SaveAsync(record, cancellationToken);
        await repository.SaveVersionAsync(version, cancellationToken);
        await LogAsync(record, 1, "Evidence.Created", actorId, correlationId, $"{{\"sha256\":\"{version.Sha256}\"}}", cancellationToken);
        return record;
    }

    public async Task<EvidenceVersion> AddVersionAsync(Guid organizationId, Guid evidenceId, Guid actorId, string correlationId, AddEvidenceVersionRequest request, CancellationToken cancellationToken)
    {
        var record = await repository.GetAsync(organizationId, evidenceId, cancellationToken) ?? throw new KeyNotFoundException("Evidence not found.");
        if (record.Status is EvidenceStatus.Archived or EvidenceStatus.Disposed) throw new InvalidOperationException("Archived or disposed evidence cannot be versioned.");
        ValidateMetadata(record.Title, request.FileName, request.ContentType);
        var bytes = Decode(request.Base64Content);
        var next = record.CurrentVersion + 1;
        var version = await BuildVersionAsync(record, next, actorId, request.FileName, request.ContentType, bytes, request.Notes, cancellationToken);
        var existing = await repository.GetVersionsAsync(evidenceId, cancellationToken);
        if (existing.Any(x => string.Equals(x.Sha256, version.Sha256, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("An identical evidence version already exists.");
        await repository.SaveVersionAsync(version, cancellationToken);
        record.CurrentVersion = next; record.ModifiedAtUtc = DateTimeOffset.UtcNow; record.ModifiedBy = actorId;
        await repository.SaveAsync(record, cancellationToken);
        await LogAsync(record, next, "Evidence.VersionAdded", actorId, correlationId, $"{{\"sha256\":\"{version.Sha256}\"}}", cancellationToken);
        return version;
    }

    public async Task<EvidenceDownload> DownloadAsync(Guid organizationId, Guid evidenceId, int? versionNumber, Guid actorId, string correlationId, CancellationToken cancellationToken)
    {
        var record = await repository.GetAsync(organizationId, evidenceId, cancellationToken) ?? throw new KeyNotFoundException("Evidence not found.");
        var number = versionNumber ?? record.CurrentVersion;
        var version = await repository.GetVersionAsync(evidenceId, number, cancellationToken) ?? throw new KeyNotFoundException("Evidence version not found.");
        var content = await storage.GetAsync(version.StorageKey, cancellationToken);
        var actual = Convert.ToHexString(SHA256.HashData(content)).ToLowerInvariant();
        if (!string.Equals(actual, version.Sha256, StringComparison.Ordinal)) throw new InvalidDataException("Evidence integrity verification failed.");
        await LogAsync(record, number, "Evidence.Downloaded", actorId, correlationId, "{}", cancellationToken);
        return new EvidenceDownload(version.OriginalFileName, version.ContentType, content, version.Sha256, number);
    }

    public async Task SetLegalHoldAsync(Guid organizationId, Guid evidenceId, bool enabled, Guid actorId, string correlationId, CancellationToken cancellationToken)
    {
        var record = await repository.GetAsync(organizationId, evidenceId, cancellationToken) ?? throw new KeyNotFoundException("Evidence not found.");
        record.LegalHold = enabled; record.ModifiedAtUtc = DateTimeOffset.UtcNow; record.ModifiedBy = actorId;
        await repository.SaveAsync(record, cancellationToken);
        await LogAsync(record, null, enabled ? "Evidence.LegalHoldApplied" : "Evidence.LegalHoldReleased", actorId, correlationId, "{}", cancellationToken);
    }

    private async Task<EvidenceVersion> BuildVersionAsync(EvidenceRecord record, int number, Guid actorId, string fileName, string contentType, byte[] bytes, string notes, CancellationToken cancellationToken)
    {
        var sha = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
        var key = await storage.PutAsync(record.OrganizationId, record.Id, number, bytes, cancellationToken);
        return new EvidenceVersion(Guid.NewGuid(), record.Id, number, Path.GetFileName(fileName), contentType.Trim(), bytes.LongLength, sha, key, notes.Trim(), DateTimeOffset.UtcNow, actorId);
    }

    private static byte[] Decode(string value)
    {
        byte[] bytes;
        try { bytes = Convert.FromBase64String(value); }
        catch (FormatException ex) { throw new ArgumentException("Base64Content is invalid.", nameof(value), ex); }
        if (bytes.Length == 0) throw new ArgumentException("Evidence content is empty.");
        if (bytes.Length > MaxBytes) throw new ArgumentException($"Evidence exceeds the {MaxBytes} byte limit.");
        return bytes;
    }

    private static void ValidateMetadata(string title, string fileName, string contentType)
    {
        if (string.IsNullOrWhiteSpace(title)) throw new ArgumentException("Title is required.");
        if (string.IsNullOrWhiteSpace(fileName)) throw new ArgumentException("FileName is required.");
        if (string.IsNullOrWhiteSpace(contentType)) throw new ArgumentException("ContentType is required.");
    }

    private Task LogAsync(EvidenceRecord record, int? version, string action, Guid actor, string correlation, string details, CancellationToken token) =>
        repository.AppendAccessAsync(new EvidenceAccessEvent(Guid.NewGuid(), record.OrganizationId, record.Id, version, action, actor, correlation, DateTimeOffset.UtcNow, details), token);
}
