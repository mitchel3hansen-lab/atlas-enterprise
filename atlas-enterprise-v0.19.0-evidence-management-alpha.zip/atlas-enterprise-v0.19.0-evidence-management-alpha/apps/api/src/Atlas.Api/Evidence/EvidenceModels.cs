namespace Atlas.Api.Evidence;

public enum EvidenceStatus { Active, Superseded, Archived, Disposed }
public enum EvidenceClassification { Public, Internal, Confidential, Restricted }

public sealed class EvidenceRecord
{
    public Guid Id { get; init; }
    public Guid OrganizationId { get; init; }
    public Guid? ObjectId { get; init; }
    public string? ObjectType { get; init; }
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public EvidenceClassification Classification { get; set; } = EvidenceClassification.Internal;
    public EvidenceStatus Status { get; set; } = EvidenceStatus.Active;
    public string RetentionPolicy { get; set; } = "standard-7-years";
    public bool LegalHold { get; set; }
    public int CurrentVersion { get; set; } = 1;
    public DateTimeOffset CreatedAtUtc { get; init; } = DateTimeOffset.UtcNow;
    public Guid CreatedBy { get; init; }
    public DateTimeOffset ModifiedAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public Guid ModifiedBy { get; set; }
}

public sealed record EvidenceVersion(
    Guid Id,
    Guid EvidenceId,
    int VersionNumber,
    string OriginalFileName,
    string ContentType,
    long SizeBytes,
    string Sha256,
    string StorageKey,
    string Notes,
    DateTimeOffset UploadedAtUtc,
    Guid UploadedBy);

public sealed record EvidenceAccessEvent(
    Guid Id,
    Guid OrganizationId,
    Guid EvidenceId,
    int? VersionNumber,
    string Action,
    Guid ActorId,
    string CorrelationId,
    DateTimeOffset OccurredAtUtc,
    string DetailsJson);

public sealed record CreateEvidenceRequest(
    Guid? ObjectId,
    string? ObjectType,
    string Title,
    string Description,
    EvidenceClassification Classification,
    string RetentionPolicy,
    string FileName,
    string ContentType,
    string Base64Content,
    string Notes);

public sealed record AddEvidenceVersionRequest(
    string FileName,
    string ContentType,
    string Base64Content,
    string Notes);

public sealed record EvidenceDownload(string FileName, string ContentType, byte[] Content, string Sha256, int VersionNumber);
