namespace Atlas.Api.Evidence;

public sealed class FileSystemEvidenceStorage(IWebHostEnvironment environment) : IEvidenceStorage
{
    private readonly string _root = Path.Combine(environment.ContentRootPath, "evidence-store");

    public async Task<string> PutAsync(Guid organizationId, Guid evidenceId, int versionNumber, byte[] content, CancellationToken cancellationToken)
    {
        var relative = Path.Combine(organizationId.ToString("N"), evidenceId.ToString("N"), $"v{versionNumber}.bin");
        var full = Path.Combine(_root, relative);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await File.WriteAllBytesAsync(full, content, cancellationToken);
        return relative.Replace('\\', '/');
    }

    public Task<byte[]> GetAsync(string storageKey, CancellationToken cancellationToken)
    {
        var safeRelative = storageKey.Replace('/', Path.DirectorySeparatorChar);
        var full = Path.GetFullPath(Path.Combine(_root, safeRelative));
        var root = Path.GetFullPath(_root) + Path.DirectorySeparatorChar;
        if (!full.StartsWith(root, StringComparison.Ordinal)) throw new InvalidOperationException("Invalid evidence storage key.");
        return File.ReadAllBytesAsync(full, cancellationToken);
    }
}
