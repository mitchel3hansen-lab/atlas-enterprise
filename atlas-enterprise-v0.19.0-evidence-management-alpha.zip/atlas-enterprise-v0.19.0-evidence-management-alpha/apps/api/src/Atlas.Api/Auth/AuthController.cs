using Atlas.Api.Domain;
using Atlas.Api.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Auth;

[ApiController]
[Route("api/v1/auth")]
public sealed class AuthController(
    AtlasDbContext db,
    PasswordService passwords,
    TokenService tokens,
    IWebHostEnvironment environment) : ControllerBase
{
    [AllowAnonymous]
    [HttpPost("login")]
    public async Task<ActionResult<LoginResponse>> Login(LoginRequest request, CancellationToken cancellationToken)
    {
        var normalizedEmail = request.Email.Trim().ToUpperInvariant();
        var user = await db.Users.SingleOrDefaultAsync(x => x.NormalizedEmail == normalizedEmail, cancellationToken);
        if (user is null || !user.IsActive || !passwords.Verify(request.Password, user.PasswordHash))
            return Unauthorized(new ProblemDetails { Title = "Invalid credentials" });

        var membership = await db.OrganizationMemberships.SingleOrDefaultAsync(
            x => x.UserId == user.Id && x.OrganizationId == request.OrganizationId && x.IsActive,
            cancellationToken);
        if (membership is null)
            return Forbid();

        var roleIds = await db.MembershipRoles.Where(x => x.MembershipId == membership.Id)
            .Select(x => x.RoleId).ToListAsync(cancellationToken);
        var roles = await db.Roles.Where(x => roleIds.Contains(x.Id)).Select(x => x.Name).ToListAsync(cancellationToken);
        var permissions = await (
            from rp in db.RolePermissions
            join p in db.Permissions on rp.PermissionId equals p.Id
            where roleIds.Contains(rp.RoleId)
            select p.Code).Distinct().ToListAsync(cancellationToken);

        var token = tokens.Create(user, membership, roles, permissions);
        return Ok(new LoginResponse(token, "Bearer", user.Id, membership.OrganizationId, roles, permissions));
    }

    [AllowAnonymous]
    [HttpPost("development/bootstrap")]
    public async Task<ActionResult<DevelopmentBootstrapResponse>> DevelopmentBootstrap(
        DevelopmentBootstrapRequest request,
        CancellationToken cancellationToken)
    {
        if (!environment.IsDevelopment())
            return NotFound();

        var organization = new Organization(Guid.NewGuid(), request.OrganizationName.Trim(), request.OrganizationSlug.Trim().ToLowerInvariant(), DateTimeOffset.UtcNow);
        var user = new AtlasUser
        {
            Id = Guid.NewGuid(),
            Email = request.Email.Trim(),
            NormalizedEmail = request.Email.Trim().ToUpperInvariant(),
            DisplayName = request.DisplayName.Trim(),
            PasswordHash = passwords.Hash(request.Password),
            CreatedAtUtc = DateTimeOffset.UtcNow
        };
        var membership = new OrganizationMembership
        {
            Id = Guid.NewGuid(), OrganizationId = organization.Id, UserId = user.Id, CreatedAtUtc = DateTimeOffset.UtcNow
        };
        var adminRole = new Role
        {
            Id = Guid.NewGuid(), OrganizationId = organization.Id, Name = "Organization Administrator",
            NormalizedName = "ORGANIZATION ADMINISTRATOR", IsSystemRole = false
        };

        db.Organizations.Add(organization);
        db.Users.Add(user);
        db.OrganizationMemberships.Add(membership);
        db.Roles.Add(adminRole);

        foreach (var code in Security.AtlasPermissions.All)
        {
            var permission = await db.Permissions.SingleOrDefaultAsync(x => x.Code == code, cancellationToken)
                ?? new Permission { Id = Guid.NewGuid(), Code = code, Description = code };
            if (db.Entry(permission).State == EntityState.Detached)
                db.Permissions.Add(permission);
            db.RolePermissions.Add(new RolePermission { RoleId = adminRole.Id, PermissionId = permission.Id });
        }
        db.MembershipRoles.Add(new MembershipRole { MembershipId = membership.Id, RoleId = adminRole.Id });
        await db.SaveChangesAsync(cancellationToken);

        return Created(string.Empty, new DevelopmentBootstrapResponse(organization.Id, user.Id, request.Email));
    }
}

public sealed record LoginRequest(string Email, string Password, Guid OrganizationId);
public sealed record LoginResponse(string AccessToken, string TokenType, Guid UserId, Guid OrganizationId, IReadOnlyList<string> Roles, IReadOnlyList<string> Permissions);
public sealed record DevelopmentBootstrapRequest(string OrganizationName, string OrganizationSlug, string DisplayName, string Email, string Password);
public sealed record DevelopmentBootstrapResponse(Guid OrganizationId, Guid UserId, string Email);
