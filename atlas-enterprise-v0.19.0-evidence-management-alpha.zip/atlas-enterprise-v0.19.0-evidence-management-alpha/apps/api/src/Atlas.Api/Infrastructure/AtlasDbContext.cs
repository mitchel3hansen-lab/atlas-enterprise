using Atlas.Api.Domain;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Infrastructure;

public sealed class AtlasDbContext(DbContextOptions<AtlasDbContext> options) : DbContext(options)
{
    public DbSet<Organization> Organizations => Set<Organization>();
    public DbSet<Facility> Facilities => Set<Facility>();
    public DbSet<FacilityAuditEvent> FacilityAuditEvents => Set<FacilityAuditEvent>();
    public DbSet<SafetyRecord> SafetyRecords => Set<SafetyRecord>();
    public DbSet<AtlasUser> Users => Set<AtlasUser>();
    public DbSet<OrganizationMembership> OrganizationMemberships => Set<OrganizationMembership>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<MembershipRole> MembershipRoles => Set<MembershipRole>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<UserInvitation> UserInvitations => Set<UserInvitation>();
    public DbSet<AccessAuditEvent> AccessAuditEvents => Set<AccessAuditEvent>();
    public DbSet<RevokedSession> RevokedSessions => Set<RevokedSession>();
    public DbSet<OrganizationAuditEvent> OrganizationAuditEvents => Set<OrganizationAuditEvent>();
    public DbSet<KnowledgeRelationship> KnowledgeRelationships => Set<KnowledgeRelationship>();
    public DbSet<EvidenceRecord> EvidenceRecords => Set<EvidenceRecord>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Organization>().HasKey(x => x.Id);
        modelBuilder.Entity<Organization>().HasIndex(x => x.Slug).IsUnique();
        modelBuilder.Entity<Organization>().HasIndex(x => x.Status);
        modelBuilder.Entity<Organization>().Property(x => x.Name).HasMaxLength(200);
        modelBuilder.Entity<Organization>().Property(x => x.LegalName).HasMaxLength(250);
        modelBuilder.Entity<Organization>().Property(x => x.DisplayName).HasMaxLength(200);
        modelBuilder.Entity<Organization>().Property(x => x.Slug).HasMaxLength(100);
        modelBuilder.Entity<Organization>().Property(x => x.Version).IsConcurrencyToken();

        modelBuilder.Entity<Facility>().HasKey(x => x.Id);
        modelBuilder.Entity<Facility>().HasIndex(x => new { x.OrganizationId, x.Code }).IsUnique();
        modelBuilder.Entity<Facility>().HasIndex(x => new { x.OrganizationId, x.Status });
        modelBuilder.Entity<Facility>().Property(x => x.Name).HasMaxLength(200);
        modelBuilder.Entity<Facility>().Property(x => x.Code).HasMaxLength(50);
        modelBuilder.Entity<Facility>().Property(x => x.TimeZone).HasMaxLength(100);
        modelBuilder.Entity<Facility>().Property(x => x.CountryCode).HasMaxLength(2);
        modelBuilder.Entity<Facility>().Property(x => x.Latitude).HasPrecision(9, 6);
        modelBuilder.Entity<Facility>().Property(x => x.Longitude).HasPrecision(9, 6);
        modelBuilder.Entity<Facility>().Property(x => x.Version).IsConcurrencyToken();
        modelBuilder.Entity<Facility>()
            .HasOne<Organization>()
            .WithMany()
            .HasForeignKey(x => x.OrganizationId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<FacilityAuditEvent>().HasKey(x => x.Id);
        modelBuilder.Entity<FacilityAuditEvent>().HasIndex(x => new { x.OrganizationId, x.FacilityId, x.OccurredAtUtc });

        modelBuilder.Entity<SafetyRecord>().HasKey(x => x.Id);
        modelBuilder.Entity<SafetyRecord>()
            .HasIndex(x => new { x.OrganizationId, x.RecordType, x.Status });

        modelBuilder.Entity<AtlasUser>().HasKey(x => x.Id);
        modelBuilder.Entity<AtlasUser>().HasIndex(x => x.NormalizedEmail).IsUnique();
        modelBuilder.Entity<AtlasUser>().Property(x => x.Email).HasMaxLength(320);
        modelBuilder.Entity<AtlasUser>().Property(x => x.NormalizedEmail).HasMaxLength(320);
        modelBuilder.Entity<AtlasUser>().Property(x => x.DisplayName).HasMaxLength(200);

        modelBuilder.Entity<OrganizationMembership>().HasKey(x => x.Id);
        modelBuilder.Entity<OrganizationMembership>()
            .HasIndex(x => new { x.OrganizationId, x.UserId }).IsUnique();
        modelBuilder.Entity<OrganizationMembership>()
            .HasOne<Organization>().WithMany().HasForeignKey(x => x.OrganizationId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<OrganizationMembership>()
            .HasOne<AtlasUser>().WithMany().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Role>().HasKey(x => x.Id);
        modelBuilder.Entity<Role>()
            .HasIndex(x => new { x.OrganizationId, x.NormalizedName }).IsUnique();

        modelBuilder.Entity<Permission>().HasKey(x => x.Id);
        modelBuilder.Entity<Permission>().HasIndex(x => x.Code).IsUnique();

        modelBuilder.Entity<MembershipRole>().HasKey(x => new { x.MembershipId, x.RoleId });
        modelBuilder.Entity<RolePermission>().HasKey(x => new { x.RoleId, x.PermissionId });

        modelBuilder.Entity<UserInvitation>().HasKey(x => x.Id);
        modelBuilder.Entity<UserInvitation>().HasIndex(x => x.TokenHash).IsUnique();
        modelBuilder.Entity<UserInvitation>().HasIndex(x => new { x.OrganizationId, x.NormalizedEmail });

        modelBuilder.Entity<AccessAuditEvent>().HasKey(x => x.Id);
        modelBuilder.Entity<AccessAuditEvent>().HasIndex(x => new { x.OrganizationId, x.OccurredAtUtc });

        modelBuilder.Entity<RevokedSession>().HasKey(x => x.Id);
        modelBuilder.Entity<RevokedSession>().HasIndex(x => x.JwtId).IsUnique();
        modelBuilder.Entity<RevokedSession>().HasIndex(x => new { x.OrganizationId, x.UserId });

        modelBuilder.Entity<OrganizationAuditEvent>().HasKey(x => x.Id);
        modelBuilder.Entity<OrganizationAuditEvent>().HasIndex(x => new { x.OrganizationId, x.OccurredAtUtc });

        modelBuilder.Entity<KnowledgeRelationship>().HasKey(x => x.Id);
        modelBuilder.Entity<KnowledgeRelationship>().HasIndex(x => new { x.OrganizationId, x.SourceType, x.SourceId });
        modelBuilder.Entity<KnowledgeRelationship>().HasIndex(x => new { x.OrganizationId, x.TargetType, x.TargetId });
        modelBuilder.Entity<KnowledgeRelationship>().Property(x => x.RelationshipType).HasMaxLength(100);
        modelBuilder.Entity<KnowledgeRelationship>().Property(x => x.Weight).HasPrecision(4, 3);

        modelBuilder.Entity<EvidenceRecord>().HasKey(x => x.Id);
        modelBuilder.Entity<EvidenceRecord>().HasIndex(x => new { x.OrganizationId, x.ObjectType, x.ObjectId });
        modelBuilder.Entity<EvidenceRecord>().Property(x => x.EvidenceType).HasMaxLength(100);
        modelBuilder.Entity<EvidenceRecord>().Property(x => x.Title).HasMaxLength(250);
        modelBuilder.Entity<EvidenceRecord>().Property(x => x.Confidence).HasPrecision(4, 3);
    }
}
