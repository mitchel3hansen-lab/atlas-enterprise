namespace Atlas.Api.Infrastructure;

public sealed class TenantContext
{
    public Guid? OrganizationId { get; private set; }

    public void Set(Guid organizationId) => OrganizationId = organizationId;
}
