using System.Text.Json;
using Atlas.Api.Domain;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Controllers;

[ApiController]
[Route("api/v1/organizations")]
[Authorize]
public sealed class OrganizationsController(AtlasDbContext db, TenantContext tenant) : ControllerBase
{
    [HttpGet("current")]
    [Authorize(Policy = AtlasPermissions.OrganizationsRead)]
    public async Task<ActionResult<Organization>> GetCurrent(CancellationToken ct)
    {
        if (tenant.OrganizationId is not Guid id) return Unauthorized();
        var entity = await db.Organizations.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id, ct);
        return entity is null ? NotFound() : Ok(entity);
    }

    [HttpGet]
    [Authorize(Policy = AtlasPermissions.OrganizationsRead)]
    public async Task<ActionResult<PagedOrganizationsResponse>> Search([FromQuery] string? q, [FromQuery] OrganizationStatus? status, [FromQuery] int page = 1, [FromQuery] int pageSize = 25, CancellationToken ct = default)
    {
        page = Math.Max(1, page); pageSize = Math.Clamp(pageSize, 1, 100);
        var query = db.Organizations.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(q)) { var term = q.Trim().ToLower(); query = query.Where(x => x.Name.ToLower().Contains(term) || x.LegalName.ToLower().Contains(term) || x.Slug.ToLower().Contains(term)); }
        if (status is not null) query = query.Where(x => x.Status == status);
        var total = await query.CountAsync(ct);
        var items = await query.OrderBy(x => x.DisplayName).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return Ok(new PagedOrganizationsResponse(items, page, pageSize, total));
    }

    [HttpPost]
    [Authorize(Policy = AtlasPermissions.OrganizationsManage)]
    public async Task<ActionResult<Organization>> Create(CreateOrganizationRequest request, CancellationToken ct)
    {
        var error = Validate(request.Name, request.LegalName, request.DisplayName, request.Slug, request.CountryCode, request.TimeZone);
        if (error is not null) return ValidationProblem(error);
        var slug = NormalizeSlug(request.Slug);
        if (await db.Organizations.AnyAsync(x => x.Slug == slug, ct)) return Conflict(new { message = "Organization slug already exists." });
        var now = DateTimeOffset.UtcNow;
        var entity = new Organization { Id = Guid.NewGuid(), Name = request.Name.Trim(), LegalName = request.LegalName.Trim(), DisplayName = request.DisplayName.Trim(), Slug = slug, Industry = request.Industry?.Trim(), TimeZone = request.TimeZone.Trim(), CountryCode = request.CountryCode.Trim().ToUpperInvariant(), Region = request.Region?.Trim(), LogoUrl = request.LogoUrl?.Trim(), PrimaryColor = request.PrimaryColor?.Trim(), SecondaryColor = request.SecondaryColor?.Trim(), CreatedAtUtc = now, UpdatedAtUtc = now, CreatedByUserId = tenant.UserId, UpdatedByUserId = tenant.UserId };
        db.Organizations.Add(entity); AddAudit(entity.Id, "organization.created", entity, now);
        await db.SaveChangesAsync(ct);
        return CreatedAtAction(nameof(GetById), new { id = entity.Id }, entity);
    }

    [HttpGet("{id:guid}")]
    [Authorize(Policy = AtlasPermissions.OrganizationsRead)]
    public async Task<ActionResult<Organization>> GetById(Guid id, CancellationToken ct)
    {
        var entity = await db.Organizations.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id, ct);
        return entity is null ? NotFound() : Ok(entity);
    }

    [HttpPatch("{id:guid}")]
    [Authorize(Policy = AtlasPermissions.OrganizationsManage)]
    public async Task<ActionResult<Organization>> Update(Guid id, UpdateOrganizationRequest request, CancellationToken ct)
    {
        var entity = await db.Organizations.SingleOrDefaultAsync(x => x.Id == id, ct);
        if (entity is null) return NotFound();
        var before = JsonSerializer.Serialize(entity);
        if (!string.IsNullOrWhiteSpace(request.Name)) entity.Name = request.Name.Trim();
        if (!string.IsNullOrWhiteSpace(request.LegalName)) entity.LegalName = request.LegalName.Trim();
        if (!string.IsNullOrWhiteSpace(request.DisplayName)) entity.DisplayName = request.DisplayName.Trim();
        entity.Industry = request.Industry?.Trim() ?? entity.Industry;
        entity.TimeZone = request.TimeZone?.Trim() ?? entity.TimeZone;
        entity.CountryCode = request.CountryCode?.Trim().ToUpperInvariant() ?? entity.CountryCode;
        entity.Region = request.Region?.Trim() ?? entity.Region;
        entity.LogoUrl = request.LogoUrl?.Trim() ?? entity.LogoUrl;
        entity.PrimaryColor = request.PrimaryColor?.Trim() ?? entity.PrimaryColor;
        entity.SecondaryColor = request.SecondaryColor?.Trim() ?? entity.SecondaryColor;
        entity.UpdatedAtUtc = DateTimeOffset.UtcNow; entity.UpdatedByUserId = tenant.UserId; entity.Version++;
        AddAudit(entity.Id, "organization.updated", new { before, after = entity }, entity.UpdatedAtUtc);
        await db.SaveChangesAsync(ct); return Ok(entity);
    }

    [HttpDelete("{id:guid}")]
    [Authorize(Policy = AtlasPermissions.OrganizationsManage)]
    public async Task<IActionResult> Archive(Guid id, CancellationToken ct)
    {
        var entity = await db.Organizations.SingleOrDefaultAsync(x => x.Id == id, ct); if (entity is null) return NotFound();
        if (entity.Status == OrganizationStatus.Archived) return NoContent();
        entity.Status = OrganizationStatus.Archived; entity.ArchivedAtUtc = entity.UpdatedAtUtc = DateTimeOffset.UtcNow; entity.UpdatedByUserId = tenant.UserId; entity.Version++;
        AddAudit(id, "organization.archived", new { entity.ArchivedAtUtc }, entity.UpdatedAtUtc); await db.SaveChangesAsync(ct); return NoContent();
    }

    [HttpPost("{id:guid}/restore")]
    [Authorize(Policy = AtlasPermissions.OrganizationsManage)]
    public async Task<ActionResult<Organization>> Restore(Guid id, CancellationToken ct)
    {
        var entity = await db.Organizations.SingleOrDefaultAsync(x => x.Id == id, ct); if (entity is null) return NotFound();
        entity.Status = OrganizationStatus.Active; entity.ArchivedAtUtc = null; entity.UpdatedAtUtc = DateTimeOffset.UtcNow; entity.UpdatedByUserId = tenant.UserId; entity.Version++;
        AddAudit(id, "organization.restored", new { }, entity.UpdatedAtUtc); await db.SaveChangesAsync(ct); return Ok(entity);
    }

    [HttpGet("{id:guid}/audit")]
    [Authorize(Policy = AtlasPermissions.OrganizationsRead)]
    public async Task<ActionResult<IReadOnlyList<OrganizationAuditEvent>>> Audit(Guid id, CancellationToken ct) => Ok(await db.OrganizationAuditEvents.AsNoTracking().Where(x => x.OrganizationId == id).OrderByDescending(x => x.OccurredAtUtc).Take(200).ToListAsync(ct));

    private void AddAudit(Guid organizationId, string action, object changes, DateTimeOffset when) => db.OrganizationAuditEvents.Add(new OrganizationAuditEvent { Id = Guid.NewGuid(), OrganizationId = organizationId, ActorUserId = tenant.UserId, Action = action, ChangesJson = JsonSerializer.Serialize(changes), OccurredAtUtc = when });
    private static string NormalizeSlug(string value) => string.Join('-', value.Trim().ToLowerInvariant().Split([' ', '_'], StringSplitOptions.RemoveEmptyEntries));
    private static Dictionary<string, string[]>? Validate(params string[] values) => values.Any(string.IsNullOrWhiteSpace) ? new() { ["organization"] = ["Name, legal name, display name, slug, country code, and time zone are required."] } : null;
}

public sealed record CreateOrganizationRequest(string Name, string LegalName, string DisplayName, string Slug, string? Industry, string TimeZone, string CountryCode, string? Region, string? LogoUrl, string? PrimaryColor, string? SecondaryColor);
public sealed record UpdateOrganizationRequest(string? Name, string? LegalName, string? DisplayName, string? Industry, string? TimeZone, string? CountryCode, string? Region, string? LogoUrl, string? PrimaryColor, string? SecondaryColor);
public sealed record PagedOrganizationsResponse(IReadOnlyList<Organization> Items, int Page, int PageSize, int Total);
