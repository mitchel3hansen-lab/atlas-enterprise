using Atlas.Api.Domain;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Controllers;

[ApiController]
[Route("api/v1/safety-records")]
[Authorize]
public sealed class SafetyRecordsController(AtlasDbContext db, TenantContext tenant) : ControllerBase
{
    [HttpGet]
    [Authorize(Policy = AtlasPermissions.SafetyRead)]
    public async Task<ActionResult<IReadOnlyList<SafetyRecord>>> Get(CancellationToken cancellationToken)
    {
        if (tenant.OrganizationId is not Guid organizationId)
            return Unauthorized();

        var records = await db.SafetyRecords.AsNoTracking()
            .Where(x => x.OrganizationId == organizationId)
            .OrderByDescending(x => x.OccurredAtUtc)
            .ToListAsync(cancellationToken);
        return Ok(records);
    }
}
