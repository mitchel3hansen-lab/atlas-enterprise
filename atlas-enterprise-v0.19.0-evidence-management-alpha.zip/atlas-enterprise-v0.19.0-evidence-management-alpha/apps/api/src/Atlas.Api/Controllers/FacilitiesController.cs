using System.Text.Json;
using Atlas.Api.Domain;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Controllers;

[ApiController]
[Route("api/v1/facilities")]
[Authorize]
public sealed class FacilitiesController(AtlasDbContext db, TenantContext tenant) : ControllerBase
{
    [HttpGet]
    [Authorize(Policy = AtlasPermissions.FacilitiesRead)]
    public async Task<ActionResult<PagedFacilitiesResponse>> Search(
        [FromQuery] string? q,
        [FromQuery] FacilityStatus? status,
        [FromQuery] FacilityType? type,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 25,
        CancellationToken ct = default)
    {
        if (tenant.OrganizationId is not Guid organizationId) return Unauthorized();
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);
        var query = db.Facilities.AsNoTracking().Where(x => x.OrganizationId == organizationId);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim().ToLower();
            query = query.Where(x => x.Name.ToLower().Contains(term) || x.Code.ToLower().Contains(term) || (x.City != null && x.City.ToLower().Contains(term)));
        }
        if (status is not null) query = query.Where(x => x.Status == status);
        if (type is not null) query = query.Where(x => x.Type == type);
        var total = await query.CountAsync(ct);
        var items = await query.OrderBy(x => x.Name).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return Ok(new PagedFacilitiesResponse(items, page, pageSize, total));
    }

    [HttpGet("{id:guid}")]
    [Authorize(Policy = AtlasPermissions.FacilitiesRead)]
    public async Task<ActionResult<Facility>> Get(Guid id, CancellationToken ct)
    {
        if (tenant.OrganizationId is not Guid organizationId) return Unauthorized();
        var entity = await db.Facilities.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.OrganizationId == organizationId, ct);
        return entity is null ? NotFound() : Ok(entity);
    }

    [HttpPost]
    [Authorize(Policy = AtlasPermissions.FacilitiesManage)]
    public async Task<ActionResult<Facility>> Create(CreateFacilityRequest request, CancellationToken ct)
    {
        if (tenant.OrganizationId is not Guid organizationId) return Unauthorized();
        if (string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Code) || string.IsNullOrWhiteSpace(request.TimeZone) || string.IsNullOrWhiteSpace(request.CountryCode))
            return ValidationProblem(new Dictionary<string, string[]> { ["facility"] = ["Name, code, time zone, and country code are required."] });
        if (!CoordinatesAreValid(request.Latitude, request.Longitude))
            return ValidationProblem(new Dictionary<string, string[]> { ["coordinates"] = ["Latitude must be -90 to 90 and longitude must be -180 to 180."] });
        var code = NormalizeCode(request.Code);
        if (await db.Facilities.AnyAsync(x => x.OrganizationId == organizationId && x.Code == code, ct))
            return Conflict(new { message = "Facility code already exists for this organization." });
        var now = DateTimeOffset.UtcNow;
        var entity = new Facility
        {
            Id = Guid.NewGuid(), OrganizationId = organizationId, Name = request.Name.Trim(), Code = code,
            Type = request.Type, Description = request.Description?.Trim(), TimeZone = request.TimeZone.Trim(),
            CountryCode = request.CountryCode.Trim().ToUpperInvariant(), Region = request.Region?.Trim(), City = request.City?.Trim(),
            AddressLine1 = request.AddressLine1?.Trim(), AddressLine2 = request.AddressLine2?.Trim(), PostalCode = request.PostalCode?.Trim(),
            Latitude = request.Latitude, Longitude = request.Longitude, EmergencyZone = request.EmergencyZone?.Trim(),
            CreatedAtUtc = now, UpdatedAtUtc = now, CreatedByUserId = tenant.UserId, UpdatedByUserId = tenant.UserId
        };
        db.Facilities.Add(entity);
        AddAudit(entity, "facility.created", entity, now);
        await db.SaveChangesAsync(ct);
        return CreatedAtAction(nameof(Get), new { id = entity.Id }, entity);
    }

    [HttpPatch("{id:guid}")]
    [Authorize(Policy = AtlasPermissions.FacilitiesManage)]
    public async Task<ActionResult<Facility>> Update(Guid id, UpdateFacilityRequest request, CancellationToken ct)
    {
        if (tenant.OrganizationId is not Guid organizationId) return Unauthorized();
        var entity = await db.Facilities.SingleOrDefaultAsync(x => x.Id == id && x.OrganizationId == organizationId, ct);
        if (entity is null) return NotFound();
        if (!CoordinatesAreValid(request.Latitude ?? entity.Latitude, request.Longitude ?? entity.Longitude))
            return ValidationProblem(new Dictionary<string, string[]> { ["coordinates"] = ["Latitude must be -90 to 90 and longitude must be -180 to 180."] });
        var before = JsonSerializer.Serialize(entity);
        if (!string.IsNullOrWhiteSpace(request.Name)) entity.Name = request.Name.Trim();
        if (!string.IsNullOrWhiteSpace(request.Code))
        {
            var code = NormalizeCode(request.Code);
            if (await db.Facilities.AnyAsync(x => x.OrganizationId == organizationId && x.Id != id && x.Code == code, ct))
                return Conflict(new { message = "Facility code already exists for this organization." });
            entity.Code = code;
        }
        if (request.Type is not null) entity.Type = request.Type.Value;
        if (request.Status is not null) entity.Status = request.Status.Value;
        entity.Description = request.Description ?? entity.Description;
        entity.TimeZone = request.TimeZone?.Trim() ?? entity.TimeZone;
        entity.CountryCode = request.CountryCode?.Trim().ToUpperInvariant() ?? entity.CountryCode;
        entity.Region = request.Region ?? entity.Region; entity.City = request.City ?? entity.City;
        entity.AddressLine1 = request.AddressLine1 ?? entity.AddressLine1; entity.AddressLine2 = request.AddressLine2 ?? entity.AddressLine2;
        entity.PostalCode = request.PostalCode ?? entity.PostalCode; entity.Latitude = request.Latitude ?? entity.Latitude;
        entity.Longitude = request.Longitude ?? entity.Longitude; entity.EmergencyZone = request.EmergencyZone ?? entity.EmergencyZone;
        entity.UpdatedAtUtc = DateTimeOffset.UtcNow; entity.UpdatedByUserId = tenant.UserId; entity.Version++;
        AddAudit(entity, "facility.updated", new { before, after = entity }, entity.UpdatedAtUtc);
        await db.SaveChangesAsync(ct);
        return Ok(entity);
    }

    [HttpDelete("{id:guid}")]
    [Authorize(Policy = AtlasPermissions.FacilitiesManage)]
    public async Task<IActionResult> Archive(Guid id, CancellationToken ct)
    {
        if (tenant.OrganizationId is not Guid organizationId) return Unauthorized();
        var entity = await db.Facilities.SingleOrDefaultAsync(x => x.Id == id && x.OrganizationId == organizationId, ct);
        if (entity is null) return NotFound();
        if (entity.Status == FacilityStatus.Archived) return NoContent();
        entity.Status = FacilityStatus.Archived; entity.ArchivedAtUtc = entity.UpdatedAtUtc = DateTimeOffset.UtcNow;
        entity.UpdatedByUserId = tenant.UserId; entity.Version++;
        AddAudit(entity, "facility.archived", new { entity.ArchivedAtUtc }, entity.UpdatedAtUtc);
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    [HttpPost("{id:guid}/restore")]
    [Authorize(Policy = AtlasPermissions.FacilitiesManage)]
    public async Task<ActionResult<Facility>> Restore(Guid id, CancellationToken ct)
    {
        if (tenant.OrganizationId is not Guid organizationId) return Unauthorized();
        var entity = await db.Facilities.SingleOrDefaultAsync(x => x.Id == id && x.OrganizationId == organizationId, ct);
        if (entity is null) return NotFound();
        entity.Status = FacilityStatus.Active; entity.ArchivedAtUtc = null; entity.UpdatedAtUtc = DateTimeOffset.UtcNow;
        entity.UpdatedByUserId = tenant.UserId; entity.Version++;
        AddAudit(entity, "facility.restored", new { }, entity.UpdatedAtUtc);
        await db.SaveChangesAsync(ct);
        return Ok(entity);
    }

    [HttpGet("{id:guid}/audit")]
    [Authorize(Policy = AtlasPermissions.FacilitiesRead)]
    public async Task<ActionResult<IReadOnlyList<FacilityAuditEvent>>> Audit(Guid id, CancellationToken ct)
    {
        if (tenant.OrganizationId is not Guid organizationId) return Unauthorized();
        return Ok(await db.FacilityAuditEvents.AsNoTracking()
            .Where(x => x.OrganizationId == organizationId && x.FacilityId == id)
            .OrderByDescending(x => x.OccurredAtUtc).Take(200).ToListAsync(ct));
    }

    private void AddAudit(Facility facility, string action, object changes, DateTimeOffset when) =>
        db.FacilityAuditEvents.Add(new FacilityAuditEvent { Id = Guid.NewGuid(), OrganizationId = facility.OrganizationId, FacilityId = facility.Id, ActorUserId = tenant.UserId, Action = action, ChangesJson = JsonSerializer.Serialize(changes), OccurredAtUtc = when });
    private static string NormalizeCode(string value) => value.Trim().ToUpperInvariant().Replace(' ', '-');
    private static bool CoordinatesAreValid(decimal? latitude, decimal? longitude) =>
        (latitude is null || latitude is >= -90 and <= 90) && (longitude is null || longitude is >= -180 and <= 180);
}

public sealed record CreateFacilityRequest(string Name, string Code, FacilityType Type, string? Description, string TimeZone, string CountryCode, string? Region, string? City, string? AddressLine1, string? AddressLine2, string? PostalCode, decimal? Latitude, decimal? Longitude, string? EmergencyZone);
public sealed record UpdateFacilityRequest(string? Name, string? Code, FacilityType? Type, FacilityStatus? Status, string? Description, string? TimeZone, string? CountryCode, string? Region, string? City, string? AddressLine1, string? AddressLine2, string? PostalCode, decimal? Latitude, decimal? Longitude, string? EmergencyZone);
public sealed record PagedFacilitiesResponse(IReadOnlyList<Facility> Items, int Page, int PageSize, int Total);
