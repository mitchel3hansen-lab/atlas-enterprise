using System.Globalization;
using System.Text.Json;

namespace Atlas.Api.Rules;

public sealed class RuleConditionEvaluator
{
    public RuleEvaluationResult Evaluate(string conditionJson, JsonElement payload)
    {
        var conditions = JsonSerializer.Deserialize<List<RuleCondition>>(conditionJson, JsonOptions) ?? [];
        var reasons = new List<string>();
        foreach (var condition in conditions)
        {
            if (!TryResolve(payload, condition.Field, out var actual))
            {
                reasons.Add($"Field '{condition.Field}' was not present.");
                return new(false, reasons);
            }

            var matched = Compare(actual, condition.Operator, condition.Value);
            reasons.Add($"{condition.Field} {condition.Operator} {condition.Value}: {(matched ? "matched" : "did not match")}");
            if (!matched) return new(false, reasons);
        }
        return new(true, reasons.Count == 0 ? ["Rule has no conditions and matched by default."] : reasons);
    }

    private static bool TryResolve(JsonElement element, string path, out JsonElement value)
    {
        value = element;
        foreach (var segment in path.Split('.', StringSplitOptions.RemoveEmptyEntries))
            if (value.ValueKind != JsonValueKind.Object || !value.TryGetProperty(segment, out value)) return false;
        return true;
    }

    private static bool Compare(JsonElement actual, string op, JsonElement expected) => op.ToLowerInvariant() switch
    {
        "eq" or "==" => actual.ToString().Equals(expected.ToString(), StringComparison.OrdinalIgnoreCase),
        "neq" or "!=" => !actual.ToString().Equals(expected.ToString(), StringComparison.OrdinalIgnoreCase),
        "contains" => actual.ToString().Contains(expected.ToString(), StringComparison.OrdinalIgnoreCase),
        "gt" or ">" => Number(actual) > Number(expected),
        "gte" or ">=" => Number(actual) >= Number(expected),
        "lt" or "<" => Number(actual) < Number(expected),
        "lte" or "<=" => Number(actual) <= Number(expected),
        "exists" => true,
        _ => throw new InvalidOperationException($"Unsupported rule operator '{op}'.")
    };

    private static decimal Number(JsonElement value) => decimal.Parse(value.ToString(), CultureInfo.InvariantCulture);
    private static readonly JsonSerializerOptions JsonOptions = new() { PropertyNameCaseInsensitive = true };
}
