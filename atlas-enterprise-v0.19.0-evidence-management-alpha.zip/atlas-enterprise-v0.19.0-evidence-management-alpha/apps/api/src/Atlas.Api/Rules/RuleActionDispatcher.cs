using System.Text.Json;

namespace Atlas.Api.Rules;

public interface IRuleActionHandler
{
    string Type { get; }
    Task<RuleActionResult> ExecuteAsync(RuleAction action, RuleEvent ruleEvent, CancellationToken cancellationToken);
}

public sealed class RuleActionDispatcher(IEnumerable<IRuleActionHandler> handlers)
{
    private readonly Dictionary<string, IRuleActionHandler> _handlers = handlers.ToDictionary(x => x.Type, StringComparer.OrdinalIgnoreCase);

    public async Task<IReadOnlyList<RuleActionResult>> DispatchAsync(string actionJson, RuleEvent ruleEvent, CancellationToken cancellationToken)
    {
        var actions = JsonSerializer.Deserialize<List<RuleAction>>(actionJson, new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? [];
        var results = new List<RuleActionResult>();
        foreach (var action in actions)
        {
            if (!_handlers.TryGetValue(action.Type, out var handler))
            {
                results.Add(new(action.Type, false, "No action handler is registered."));
                continue;
            }
            results.Add(await handler.ExecuteAsync(action, ruleEvent, cancellationToken));
        }
        return results;
    }
}

public sealed class AuditActionHandler(ILogger<AuditActionHandler> logger) : IRuleActionHandler
{
    public string Type => "audit.write";
    public Task<RuleActionResult> ExecuteAsync(RuleAction action, RuleEvent ruleEvent, CancellationToken cancellationToken)
    {
        logger.LogInformation("Rule audit action for {EventName}, object {ObjectType}/{ObjectId}, correlation {CorrelationId}", ruleEvent.EventName, ruleEvent.ObjectType, ruleEvent.ObjectId, ruleEvent.CorrelationId);
        return Task.FromResult(new RuleActionResult(Type, true, "Audit action recorded."));
    }
}
