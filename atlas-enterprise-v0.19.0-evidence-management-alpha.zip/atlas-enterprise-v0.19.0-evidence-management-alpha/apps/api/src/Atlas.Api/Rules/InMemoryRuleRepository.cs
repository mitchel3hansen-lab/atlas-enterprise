namespace Atlas.Api.Rules;

public sealed class InMemoryRuleRepository : IRuleRepository
{
    private readonly List<AutomationRule> _rules = [];
    private readonly List<RuleExecution> _executions = [];
    private readonly object _gate = new();

    public Task<IReadOnlyList<AutomationRule>> GetActiveForEventAsync(Guid organizationId, string eventName, CancellationToken cancellationToken)
    {
        lock (_gate) return Task.FromResult<IReadOnlyList<AutomationRule>>(_rules.Where(x => x.OrganizationId == organizationId && x.Status == RuleStatus.Active && x.TriggerEvent.Equals(eventName, StringComparison.OrdinalIgnoreCase)).ToList());
    }
    public Task<AutomationRule?> GetAsync(Guid organizationId, Guid ruleId, CancellationToken cancellationToken)
    { lock (_gate) return Task.FromResult(_rules.SingleOrDefault(x => x.OrganizationId == organizationId && x.Id == ruleId)); }
    public Task AddAsync(AutomationRule rule, CancellationToken cancellationToken)
    { lock (_gate) _rules.Add(rule); return Task.CompletedTask; }
    public Task UpdateAsync(AutomationRule rule, CancellationToken cancellationToken) => Task.CompletedTask;
    public Task AddExecutionAsync(RuleExecution execution, CancellationToken cancellationToken)
    { lock (_gate) _executions.Add(execution); return Task.CompletedTask; }
    public Task<IReadOnlyList<RuleExecution>> GetExecutionsAsync(Guid organizationId, Guid ruleId, int take, CancellationToken cancellationToken)
    { lock (_gate) return Task.FromResult<IReadOnlyList<RuleExecution>>(_executions.Where(x => x.OrganizationId == organizationId && x.RuleId == ruleId).OrderByDescending(x => x.StartedAtUtc).Take(take).ToList()); }
}
