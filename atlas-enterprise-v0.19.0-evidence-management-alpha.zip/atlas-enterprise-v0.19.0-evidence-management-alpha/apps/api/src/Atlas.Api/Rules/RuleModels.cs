using System.Text.Json;

namespace Atlas.Api.Rules;

public enum RuleStatus { Draft, Active, Disabled, Archived }
public enum RuleExecutionStatus { Matched, NotMatched, Succeeded, Failed, Skipped }

public sealed class AutomationRule
{
    public Guid Id { get; init; }
    public Guid OrganizationId { get; init; }
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public string TriggerEvent { get; set; } = "";
    public int Priority { get; set; } = 100;
    public RuleStatus Status { get; set; } = RuleStatus.Draft;
    public string ConditionJson { get; set; } = "{}";
    public string ActionJson { get; set; } = "[]";
    public int Version { get; set; } = 1;
    public DateTimeOffset CreatedAtUtc { get; init; } = DateTimeOffset.UtcNow;
    public Guid CreatedBy { get; init; }
    public DateTimeOffset ModifiedAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public Guid ModifiedBy { get; set; }
}

public sealed class RuleExecution
{
    public Guid Id { get; init; }
    public Guid OrganizationId { get; init; }
    public Guid RuleId { get; init; }
    public Guid? ObjectId { get; init; }
    public string? ObjectType { get; init; }
    public string TriggerEvent { get; init; } = "";
    public string CorrelationId { get; init; } = "";
    public RuleExecutionStatus Status { get; set; }
    public string ExplanationJson { get; set; } = "{}";
    public string ActionsJson { get; set; } = "[]";
    public string? Error { get; set; }
    public DateTimeOffset StartedAtUtc { get; init; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? CompletedAtUtc { get; set; }
}

public sealed record RuleEvent(
    Guid OrganizationId,
    string EventName,
    string CorrelationId,
    Guid? ObjectId,
    string? ObjectType,
    JsonElement Payload,
    Guid ActorId);

public sealed record RuleCondition(string Field, string Operator, JsonElement Value);
public sealed record RuleAction(string Type, JsonElement Parameters);
public sealed record RuleEvaluationResult(bool Matched, IReadOnlyList<string> Reasons);
public sealed record RuleActionResult(string Type, bool Succeeded, string Message);
