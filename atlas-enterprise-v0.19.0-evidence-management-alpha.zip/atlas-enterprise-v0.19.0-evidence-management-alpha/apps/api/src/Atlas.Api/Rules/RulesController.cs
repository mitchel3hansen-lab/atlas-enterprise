using System.Security.Claims;
using System.Text.Json;
using Atlas.Api.Middleware;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Atlas.Api.Rules;

[ApiController]
[Route("api/v1/rules")]
public sealed class RulesController(IRuleRepository repository, RulesEngine engine, TenantContext tenant) : ControllerBase
{
    [HttpPost]
    [Authorize(Policy = AtlasPermissions.RulesManage)]
    public async Task<ActionResult<AutomationRule>> Create(CreateRuleRequest request, CancellationToken ct)
    {
        var actor = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var rule = new AutomationRule { Id = Guid.NewGuid(), OrganizationId = tenant.OrganizationId, Name = request.Name.Trim(), Description = request.Description?.Trim() ?? "", TriggerEvent = request.TriggerEvent.Trim(), Priority = request.Priority, ConditionJson = request.Conditions.GetRawText(), ActionJson = request.Actions.GetRawText(), Status = RuleStatus.Draft, CreatedBy = actor, ModifiedBy = actor };
        await repository.AddAsync(rule, ct);
        return CreatedAtAction(nameof(Get), new { ruleId = rule.Id }, rule);
    }

    [HttpGet("{ruleId:guid}")]
    [Authorize(Policy = AtlasPermissions.RulesRead)]
    public async Task<ActionResult<AutomationRule>> Get(Guid ruleId, CancellationToken ct)
        => await repository.GetAsync(tenant.OrganizationId, ruleId, ct) is { } rule ? Ok(rule) : NotFound();

    [HttpPost("{ruleId:guid}/activate")]
    [Authorize(Policy = AtlasPermissions.RulesManage)]
    public async Task<IActionResult> Activate(Guid ruleId, CancellationToken ct)
    {
        var rule = await repository.GetAsync(tenant.OrganizationId, ruleId, ct);
        if (rule is null) return NotFound();
        rule.Status = RuleStatus.Active; rule.Version++; rule.ModifiedAtUtc = DateTimeOffset.UtcNow;
        await repository.UpdateAsync(rule, ct);
        return NoContent();
    }

    [HttpPost("evaluate")]
    [Authorize(Policy = AtlasPermissions.RulesExecute)]
    public async Task<ActionResult<IReadOnlyList<RuleExecution>>> Evaluate(EvaluateRuleEventRequest request, CancellationToken ct)
    {
        var actor = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var evt = new RuleEvent(tenant.OrganizationId, request.EventName, request.CorrelationId ?? HttpContext.TraceIdentifier, request.ObjectId, request.ObjectType, request.Payload, actor);
        return Ok(await engine.ProcessAsync(evt, ct));
    }

    [HttpGet("{ruleId:guid}/executions")]
    [Authorize(Policy = AtlasPermissions.RulesRead)]
    public Task<IReadOnlyList<RuleExecution>> Executions(Guid ruleId, [FromQuery] int take = 50, CancellationToken ct = default)
        => repository.GetExecutionsAsync(tenant.OrganizationId, ruleId, Math.Clamp(take, 1, 200), ct);
}

public sealed record CreateRuleRequest(string Name, string? Description, string TriggerEvent, int Priority, JsonElement Conditions, JsonElement Actions);
public sealed record EvaluateRuleEventRequest(string EventName, string? CorrelationId, Guid? ObjectId, string? ObjectType, JsonElement Payload);
