using System.Text.Json;

namespace Atlas.Api.Rules;

public sealed class RulesEngine(
    IRuleRepository repository,
    RuleConditionEvaluator evaluator,
    RuleActionDispatcher dispatcher,
    ILogger<RulesEngine> logger)
{
    public async Task<IReadOnlyList<RuleExecution>> ProcessAsync(RuleEvent ruleEvent, CancellationToken cancellationToken)
    {
        var rules = await repository.GetActiveForEventAsync(ruleEvent.OrganizationId, ruleEvent.EventName, cancellationToken);
        var executions = new List<RuleExecution>();

        foreach (var rule in rules.OrderBy(x => x.Priority).ThenBy(x => x.Id))
        {
            var evaluation = evaluator.Evaluate(rule.ConditionJson, ruleEvent.Payload);
            var execution = new RuleExecution
            {
                Id = Guid.NewGuid(), OrganizationId = ruleEvent.OrganizationId, RuleId = rule.Id,
                ObjectId = ruleEvent.ObjectId, ObjectType = ruleEvent.ObjectType,
                TriggerEvent = ruleEvent.EventName, CorrelationId = ruleEvent.CorrelationId,
                Status = evaluation.Matched ? RuleExecutionStatus.Matched : RuleExecutionStatus.NotMatched,
                ExplanationJson = JsonSerializer.Serialize(new { rule = rule.Name, rule.Version, evaluation.Reasons })
            };

            try
            {
                if (evaluation.Matched)
                {
                    var results = await dispatcher.DispatchAsync(rule.ActionJson, ruleEvent, cancellationToken);
                    execution.ActionsJson = JsonSerializer.Serialize(results);
                    execution.Status = results.All(x => x.Succeeded) ? RuleExecutionStatus.Succeeded : RuleExecutionStatus.Failed;
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Rule {RuleId} failed for correlation {CorrelationId}", rule.Id, ruleEvent.CorrelationId);
                execution.Status = RuleExecutionStatus.Failed;
                execution.Error = ex.Message;
            }
            execution.CompletedAtUtc = DateTimeOffset.UtcNow;
            await repository.AddExecutionAsync(execution, cancellationToken);
            executions.Add(execution);
        }
        return executions;
    }
}
