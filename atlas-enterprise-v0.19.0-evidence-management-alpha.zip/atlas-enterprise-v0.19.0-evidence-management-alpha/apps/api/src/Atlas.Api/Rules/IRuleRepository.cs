namespace Atlas.Api.Rules;

public interface IRuleRepository
{
    Task<IReadOnlyList<AutomationRule>> GetActiveForEventAsync(Guid organizationId, string eventName, CancellationToken cancellationToken);
    Task<AutomationRule?> GetAsync(Guid organizationId, Guid ruleId, CancellationToken cancellationToken);
    Task AddAsync(AutomationRule rule, CancellationToken cancellationToken);
    Task UpdateAsync(AutomationRule rule, CancellationToken cancellationToken);
    Task AddExecutionAsync(RuleExecution execution, CancellationToken cancellationToken);
    Task<IReadOnlyList<RuleExecution>> GetExecutionsAsync(Guid organizationId, Guid ruleId, int take, CancellationToken cancellationToken);
}
