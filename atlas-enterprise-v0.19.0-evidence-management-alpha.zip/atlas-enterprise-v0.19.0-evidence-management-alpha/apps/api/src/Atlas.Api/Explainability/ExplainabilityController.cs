using Atlas.Api.Domain;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Explainability;

[ApiController]
[Route("api/v1/explainability")]
[Authorize(Policy = AtlasPermissions.ExplainabilityRead)]
public sealed class ExplainabilityController(ExplainabilityService service, AtlasDbContext db, TenantContext tenant) : ControllerBase
{
    [HttpGet("{objectType}/{objectId:guid}")]
    public async Task<ActionResult<ExplainabilityResponse>> Explain(string objectType, Guid objectId, CancellationToken cancellationToken)
    {
        if (!Enum.TryParse<AtlasObjectType>(objectType, true, out var parsed))
            return BadRequest(new ProblemDetails { Title = "Unsupported object type", Detail = $"'{objectType}' is not an Atlas object type." });
        var result = await service.ExplainAsync(parsed, objectId, cancellationToken);
        return result is null ? Unauthorized() : Ok(result);
    }

    [HttpPost("relationships")]
    [Authorize(Policy = AtlasPermissions.ExplainabilityManage)]
    public async Task<ActionResult<KnowledgeRelationship>> AddRelationship(CreateRelationshipRequest request, CancellationToken cancellationToken)
    {
        if (tenant.OrganizationId is null) return Unauthorized();
        var relationship = new KnowledgeRelationship
        {
            Id = Guid.NewGuid(), OrganizationId = tenant.OrganizationId.Value,
            SourceType = request.SourceType, SourceId = request.SourceId,
            TargetType = request.TargetType, TargetId = request.TargetId,
            RelationshipType = request.RelationshipType.Trim(), Weight = Math.Clamp(request.Weight, 0m, 1m),
            Rationale = request.Rationale?.Trim(), CreatedAtUtc = DateTimeOffset.UtcNow, CreatedByUserId = null
        };
        db.KnowledgeRelationships.Add(relationship);
        await db.SaveChangesAsync(cancellationToken);
        return CreatedAtAction(nameof(Explain), new { objectType = relationship.SourceType, objectId = relationship.SourceId }, relationship);
    }

    [HttpPost("evidence")]
    [Authorize(Policy = AtlasPermissions.ExplainabilityManage)]
    public async Task<ActionResult<EvidenceRecord>> AddEvidence(CreateEvidenceRequest request, CancellationToken cancellationToken)
    {
        if (tenant.OrganizationId is null) return Unauthorized();
        var evidence = new EvidenceRecord
        {
            Id = Guid.NewGuid(), OrganizationId = tenant.OrganizationId.Value, ObjectType = request.ObjectType,
            ObjectId = request.ObjectId, EvidenceType = request.EvidenceType.Trim(), Title = request.Title.Trim(),
            Summary = request.Summary?.Trim(), SourceReference = request.SourceReference?.Trim(), Strength = request.Strength,
            Confidence = Math.Clamp(request.Confidence, 0m, 1m), ObservedAtUtc = request.ObservedAtUtc,
            CreatedAtUtc = DateTimeOffset.UtcNow
        };
        db.EvidenceRecords.Add(evidence);
        await db.SaveChangesAsync(cancellationToken);
        return CreatedAtAction(nameof(Explain), new { objectType = evidence.ObjectType, objectId = evidence.ObjectId }, evidence);
    }
}

public sealed record CreateRelationshipRequest(AtlasObjectType SourceType, Guid SourceId, AtlasObjectType TargetType, Guid TargetId, string RelationshipType, decimal Weight = 1m, string? Rationale = null);
public sealed record CreateEvidenceRequest(AtlasObjectType ObjectType, Guid ObjectId, string EvidenceType, string Title, string? Summary, string? SourceReference, EvidenceStrength Strength, decimal Confidence, DateTimeOffset ObservedAtUtc);
