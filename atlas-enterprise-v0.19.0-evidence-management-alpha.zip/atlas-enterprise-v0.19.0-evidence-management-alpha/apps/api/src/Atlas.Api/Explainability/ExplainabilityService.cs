using Atlas.Api.Domain;
using Atlas.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Explainability;

public sealed class ExplainabilityService(AtlasDbContext db, TenantContext tenant)
{
    public async Task<ExplainabilityResponse?> ExplainAsync(AtlasObjectType objectType, Guid objectId, CancellationToken cancellationToken)
    {
        if (tenant.OrganizationId is null) return null;
        var organizationId = tenant.OrganizationId.Value;

        var evidence = await db.EvidenceRecords.AsNoTracking()
            .Where(x => x.OrganizationId == organizationId && x.ObjectType == objectType && x.ObjectId == objectId)
            .OrderByDescending(x => x.Strength).ThenByDescending(x => x.ObservedAtUtc)
            .ToListAsync(cancellationToken);

        var outgoing = await db.KnowledgeRelationships.AsNoTracking()
            .Where(x => x.OrganizationId == organizationId && x.SourceType == objectType && x.SourceId == objectId)
            .ToListAsync(cancellationToken);
        var incoming = await db.KnowledgeRelationships.AsNoTracking()
            .Where(x => x.OrganizationId == organizationId && x.TargetType == objectType && x.TargetId == objectId)
            .ToListAsync(cancellationToken);

        var relationships = outgoing.Select(x => new ExplainabilityRelationship(x.Id, "outgoing", x.RelationshipType, x.TargetType.ToString(), x.TargetId, x.Weight, x.Rationale))
            .Concat(incoming.Select(x => new ExplainabilityRelationship(x.Id, "incoming", x.RelationshipType, x.SourceType.ToString(), x.SourceId, x.Weight, x.Rationale)))
            .OrderByDescending(x => x.Weight).ToList();

        var reasons = BuildReasons(evidence, relationships);
        var recommendations = BuildRecommendations(evidence, relationships);
        var confidence = CalculateConfidence(evidence, relationships);
        var summary = BuildSummary(objectType, evidence, relationships, reasons);

        return new ExplainabilityResponse(
            objectType.ToString(), objectId, summary, confidence, reasons,
            evidence.Select(x => new ExplainabilityEvidence(x.Id, x.EvidenceType, x.Title, x.Summary, x.SourceReference, x.Strength.ToString(), x.Confidence, x.ObservedAtUtc)).ToList(),
            relationships, recommendations, DateTimeOffset.UtcNow, "atlas-explainability/0.1");
    }

    private static List<ExplainabilityReason> BuildReasons(IReadOnlyList<EvidenceRecord> evidence, IReadOnlyList<ExplainabilityRelationship> relationships)
    {
        var reasons = new List<ExplainabilityReason>();
        if (evidence.Count == 0)
            reasons.Add(new("EVIDENCE_GAP", "Evidence is incomplete", "No direct evidence records are linked to this object.", "Decisions may rely on assumptions until evidence is added.", 1m));
        else
            reasons.Add(new("EVIDENCE_AVAILABLE", "Supporting evidence is available", $"{evidence.Count} evidence record(s) support this explanation.", "The conclusion can be reviewed against traceable sources.", 0.8m));

        if (relationships.Count == 0)
            reasons.Add(new("RELATIONSHIP_GAP", "Operational context is limited", "No knowledge-graph relationships are recorded.", "Dependencies and downstream effects may be hidden.", 0.9m));
        else
            reasons.Add(new("CONNECTED_CONTEXT", "Connected operational context", $"{relationships.Count} relationship(s) connect this object to the wider operating system.", "The explanation includes dependencies rather than isolated data.", 0.7m));

        if (evidence.Any(x => x.Strength == EvidenceStrength.Verified))
            reasons.Add(new("VERIFIED_SOURCE", "Verified evidence contributes", "At least one evidence item has been independently verified.", "Confidence is strengthened by validated evidence.", 1m));
        return reasons;
    }

    private static List<ExplainabilityRecommendation> BuildRecommendations(IReadOnlyList<EvidenceRecord> evidence, IReadOnlyList<ExplainabilityRelationship> relationships)
    {
        var items = new List<ExplainabilityRecommendation>();
        if (evidence.Count == 0)
            items.Add(new("ADD_EVIDENCE", "Add supporting evidence", "The engine cannot provide a high-confidence explanation without source material.", "High", ["Attach an inspection, incident, record, SOP, or verified observation", "Record the source and observation date"]));
        if (relationships.Count == 0)
            items.Add(new("MAP_RELATIONSHIPS", "Map operational relationships", "Connecting this object reveals causes, dependencies, and affected controls.", "Medium", ["Link relevant assets, hazards, controls, training, and actions", "Document the rationale for each relationship"]));
        if (evidence.Any(x => x.Confidence < 0.65m))
            items.Add(new("VERIFY_LOW_CONFIDENCE", "Verify low-confidence evidence", "One or more evidence items have confidence below 65%.", "High", ["Confirm the source", "Replace estimates with direct observations where practical"]));
        if (items.Count == 0)
            items.Add(new("REVIEW_AND_ACT", "Review the explanation and act", "The evidence and connected context support informed action.", "Normal", ["Review contributing reasons", "Assign an owner to accepted actions", "Verify whether the action improved the outcome"]));
        return items;
    }

    private static decimal CalculateConfidence(IReadOnlyList<EvidenceRecord> evidence, IReadOnlyList<ExplainabilityRelationship> relationships)
    {
        if (evidence.Count == 0) return relationships.Count == 0 ? 0.25m : 0.40m;
        var average = evidence.Average(x => x.Confidence);
        var evidenceBreadth = Math.Min(0.15m, evidence.Count * 0.03m);
        var contextBreadth = Math.Min(0.10m, relationships.Count * 0.02m);
        var verified = evidence.Any(x => x.Strength == EvidenceStrength.Verified) ? 0.05m : 0m;
        return Math.Round(Math.Min(0.99m, average * 0.75m + evidenceBreadth + contextBreadth + verified), 2);
    }

    private static string BuildSummary(AtlasObjectType type, IReadOnlyList<EvidenceRecord> evidence, IReadOnlyList<ExplainabilityRelationship> relationships, IReadOnlyList<ExplainabilityReason> reasons)
        => $"This {type.ToString().ToLowerInvariant()} is explained by {evidence.Count} evidence record(s) and {relationships.Count} operational relationship(s). The primary finding is: {reasons[0].Title}.";
}
