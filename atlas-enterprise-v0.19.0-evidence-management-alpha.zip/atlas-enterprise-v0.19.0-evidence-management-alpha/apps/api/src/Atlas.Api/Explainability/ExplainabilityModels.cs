namespace Atlas.Api.Explainability;

public sealed record ExplainabilityReason(string Code, string Title, string Detail, string Impact, decimal Weight);
public sealed record ExplainabilityEvidence(Guid Id, string Type, string Title, string? Summary, string? SourceReference, string Strength, decimal Confidence, DateTimeOffset ObservedAtUtc);
public sealed record ExplainabilityRecommendation(string Code, string Title, string Rationale, string Priority, IReadOnlyList<string> SuggestedActions);
public sealed record ExplainabilityRelationship(Guid Id, string Direction, string RelationshipType, string ObjectType, Guid ObjectId, decimal Weight, string? Rationale);
public sealed record ExplainabilityResponse(
    string ObjectType,
    Guid ObjectId,
    string Summary,
    decimal Confidence,
    IReadOnlyList<ExplainabilityReason> Reasons,
    IReadOnlyList<ExplainabilityEvidence> Evidence,
    IReadOnlyList<ExplainabilityRelationship> Relationships,
    IReadOnlyList<ExplainabilityRecommendation> Recommendations,
    DateTimeOffset GeneratedAtUtc,
    string EngineVersion);
