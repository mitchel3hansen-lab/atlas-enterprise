using System.Text;
using Atlas.Api.Auth;
using Atlas.Api.Infrastructure;
using Atlas.Api.KnowledgeGraph;
using Atlas.Api.Explainability;
using Atlas.Api.Middleware;
using Atlas.Api.Security;
using Atlas.Api.Rules;
using Atlas.Api.Evidence;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        Description = "Paste an ATLAS access token."
    });
    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        [new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }] = Array.Empty<string>()
    });
});
builder.Services.AddHealthChecks();
builder.Services.AddDbContext<AtlasDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("Atlas")));
builder.Services.AddScoped<TenantContext>();
builder.Services.AddScoped<ExplainabilityService>();
builder.Services.AddScoped<KnowledgeGraphService>();
builder.Services.AddSingleton<IRuleRepository, InMemoryRuleRepository>();
builder.Services.AddSingleton<IEvidenceRepository, InMemoryEvidenceRepository>();
builder.Services.AddSingleton<IEvidenceStorage, FileSystemEvidenceStorage>();
builder.Services.AddSingleton<EvidenceService>();
builder.Services.AddSingleton<RuleConditionEvaluator>();
builder.Services.AddSingleton<IRuleActionHandler, AuditActionHandler>();
builder.Services.AddSingleton<RuleActionDispatcher>();
builder.Services.AddSingleton<RulesEngine>();
builder.Services.AddSingleton<PasswordService>();
builder.Services.AddSingleton<InvitationTokenService>();
builder.Services.Configure<JwtOptions>(builder.Configuration.GetSection(JwtOptions.SectionName));
builder.Services.AddSingleton<TokenService>();
builder.Services.AddSingleton<IAuthorizationHandler, PermissionAuthorizationHandler>();

var jwt = builder.Configuration.GetSection(JwtOptions.SectionName).Get<JwtOptions>()
    ?? throw new InvalidOperationException("JWT configuration is required.");
if (Encoding.UTF8.GetByteCount(jwt.SigningKey) < 32)
    throw new InvalidOperationException("JWT signing key must be at least 32 bytes.");

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwt.Issuer,
            ValidateAudience = true,
            ValidAudience = jwt.Audience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.SigningKey)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1)
        };
    });

builder.Services.AddAuthorization(options =>
{
    foreach (var permission in AtlasPermissions.All)
        options.AddPolicy(permission, policy => policy.Requirements.Add(new PermissionRequirement(permission)));
});

var app = builder.Build();

app.UseMiddleware<CorrelationIdMiddleware>();
app.UseAuthentication();
app.UseMiddleware<TenantContextMiddleware>();
app.UseAuthorization();
app.UseSwagger();
app.UseSwaggerUI();
app.MapHealthChecks("/health");
app.MapControllers();

app.Run();

public partial class Program;
