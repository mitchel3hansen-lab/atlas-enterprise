import { useMemo, useState } from "react";

type Condition = { field: string; operator: string; value: string };
type Action = { type: string; parameters: Record<string, string> };

export function RuleBuilder() {
  const [name, setName] = useState("Critical Incident Escalation");
  const [eventName, setEventName] = useState("Incident.Created");
  const [condition, setCondition] = useState<Condition>({ field: "severity", operator: "eq", value: "Critical" });
  const [action] = useState<Action>({ type: "audit.write", parameters: { message: "Critical incident escalation triggered" } });
  const preview = useMemo(() => JSON.stringify({ name, triggerEvent: eventName, conditions: [condition], actions: [action] }, null, 2), [name, eventName, condition, action]);

  return <section aria-labelledby="rule-builder-title">
    <h2 id="rule-builder-title">Automation Rule Builder</h2>
    <label>Rule name<input value={name} onChange={e => setName(e.target.value)} /></label>
    <label>Trigger event<input value={eventName} onChange={e => setEventName(e.target.value)} /></label>
    <fieldset><legend>Condition</legend>
      <input aria-label="Field" value={condition.field} onChange={e => setCondition({ ...condition, field: e.target.value })} />
      <select aria-label="Operator" value={condition.operator} onChange={e => setCondition({ ...condition, operator: e.target.value })}><option value="eq">Equals</option><option value="gte">Greater than or equal</option><option value="contains">Contains</option></select>
      <input aria-label="Value" value={condition.value} onChange={e => setCondition({ ...condition, value: e.target.value })} />
    </fieldset>
    <h3>Explainable configuration preview</h3><pre>{preview}</pre>
  </section>;
}
