import { useMemo, useState } from 'react';

type EvidenceRecord = { id: string; title: string; classification: string; currentVersion: number; legalHold: boolean };

export function EvidencePanel({ objectType, objectId, token }: { objectType: string; objectId: string; token: string }) {
  const [items, setItems] = useState<EvidenceRecord[]>([]);
  const [message, setMessage] = useState('');
  const headers = useMemo(() => ({ Authorization: `Bearer ${token}` }), [token]);

  async function refresh() {
    const response = await fetch(`/api/v1/evidence/object/${encodeURIComponent(objectType)}/${objectId}`, { headers });
    if (!response.ok) { setMessage(`Unable to load evidence (${response.status}).`); return; }
    setItems(await response.json());
    setMessage('');
  }

  return <section aria-labelledby="evidence-heading">
    <div className="panel-header"><h2 id="evidence-heading">Evidence</h2><button onClick={refresh}>Refresh</button></div>
    {message && <p role="alert">{message}</p>}
    {items.length === 0 ? <p>No evidence linked to this record.</p> : <ul>{items.map(item =>
      <li key={item.id}><strong>{item.title}</strong> · {item.classification} · v{item.currentVersion}{item.legalHold ? ' · Legal hold' : ''}</li>
    )}</ul>}
  </section>;
}
