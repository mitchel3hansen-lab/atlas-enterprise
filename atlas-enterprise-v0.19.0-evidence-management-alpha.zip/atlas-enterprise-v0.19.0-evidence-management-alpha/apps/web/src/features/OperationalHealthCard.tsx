export type OperationalHealth = {
 score:number; confidence:number; status:string; trend:string; trendDelta:number;
 contributions:{indicatorCode:string;indicatorName:string;normalizedScore:number;weightedContribution:number}[];
 recommendations:{title:string;recommendedAction:string;estimatedScoreGain?:number}[];
};
export function OperationalHealthCard({health}:{health:OperationalHealth}) {
 const drivers=[...health.contributions].sort((a,b)=>b.weightedContribution-a.weightedContribution).slice(0,3);
 const recommendation=health.recommendations[0];
 return <section aria-labelledby="operational-health-title">
  <h2 id="operational-health-title">Operational Health</h2>
  <p><strong>{health.score.toFixed(1)}</strong> {health.status}</p>
  <p>Trend: {health.trend} ({health.trendDelta>=0?"+":""}{health.trendDelta.toFixed(1)})</p>
  <p>Confidence: {Math.round(health.confidence*100)}%</p>
  <h3>Top drivers</h3>
  <ul>{drivers.map(x=><li key={x.indicatorCode}>{x.indicatorName}: {x.normalizedScore.toFixed(0)}</li>)}</ul>
  {recommendation&&<aside><h3>{recommendation.title}</h3><p>{recommendation.recommendedAction}</p></aside>}
 </section>;
}
