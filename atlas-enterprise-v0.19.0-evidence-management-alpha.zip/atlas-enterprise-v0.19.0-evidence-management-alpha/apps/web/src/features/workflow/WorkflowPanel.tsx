import { useMemo } from 'react';

type HistoryEntry = { eventType: string; fromState?: string; toState?: string; occurredAt: string; actorName?: string };
type Props = { currentState: string; owner?: string; dueAt?: string; history: HistoryEntry[]; onTransition?: (key: string) => void };

export function WorkflowPanel({ currentState, owner, dueAt, history, onTransition }: Props) {
  const overdue = useMemo(() => !!dueAt && new Date(dueAt).getTime() < Date.now(), [dueAt]);
  return <section aria-labelledby="workflow-title" className="workflow-panel">
    <header><div><small>Workflow</small><h2 id="workflow-title">{currentState}</h2></div><span className={overdue ? 'status overdue' : 'status'}>{overdue ? 'Overdue' : 'On track'}</span></header>
    <dl><div><dt>Owner</dt><dd>{owner ?? 'Unassigned'}</dd></div><div><dt>Due</dt><dd>{dueAt ? new Date(dueAt).toLocaleString() : 'No SLA'}</dd></div></dl>
    <div className="workflow-actions">
      <button onClick={() => onTransition?.('submit')}>Submit</button>
      <button onClick={() => onTransition?.('assign')}>Assign</button>
      <button onClick={() => onTransition?.('close')}>Close</button>
    </div>
    <ol className="timeline">{history.map((item, index) => <li key={`${item.occurredAt}-${index}`}><strong>{item.eventType}</strong><span>{item.fromState && item.toState ? `${item.fromState} → ${item.toState}` : item.toState}</span><time>{new Date(item.occurredAt).toLocaleString()}</time></li>)}</ol>
  </section>;
}
