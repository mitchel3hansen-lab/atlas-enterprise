import { useState } from "react";

type FieldDefinition = {
  key: string;
  label: string;
  fieldType: string;
  isRequired: boolean;
};

type Props = {
  objectKey: string;
  singularName: string;
  initialFields: FieldDefinition[];
  onSave: (fields: FieldDefinition[]) => Promise<void>;
};

export function ObjectDefinitionDesigner({ objectKey, singularName, initialFields, onSave }: Props) {
  const [fields, setFields] = useState(initialFields);
  const [saving, setSaving] = useState(false);

  function addField() {
    setFields(current => [...current, {
      key: `field_${current.length + 1}`,
      label: "New field",
      fieldType: "Text",
      isRequired: false
    }]);
  }

  async function save() {
    setSaving(true);
    try { await onSave(fields); } finally { setSaving(false); }
  }

  return (
    <section aria-labelledby="definition-designer-title">
      <header>
        <p>Object key: <code>{objectKey}</code></p>
        <h2 id="definition-designer-title">{singularName} Definition</h2>
      </header>

      <table>
        <thead><tr><th>Label</th><th>Key</th><th>Type</th><th>Required</th></tr></thead>
        <tbody>{fields.map((field, index) => (
          <tr key={`${field.key}-${index}`}>
            <td><input aria-label={`Field ${index + 1} label`} value={field.label}
              onChange={e => setFields(items => items.map((x, i) => i === index ? { ...x, label: e.target.value } : x))} /></td>
            <td><code>{field.key}</code></td>
            <td><select value={field.fieldType}
              onChange={e => setFields(items => items.map((x, i) => i === index ? { ...x, fieldType: e.target.value } : x))}>
              <option>Text</option><option>RichText</option><option>Integer</option>
              <option>Decimal</option><option>Date</option><option>DateTime</option>
              <option>Boolean</option><option>SingleSelect</option><option>MultiSelect</option>
              <option>User</option><option>Facility</option><option>Asset</option><option>File</option>
            </select></td>
            <td><input type="checkbox" checked={field.isRequired}
              onChange={e => setFields(items => items.map((x, i) => i === index ? { ...x, isRequired: e.target.checked } : x))} /></td>
          </tr>
        ))}</tbody>
      </table>

      <div><button type="button" onClick={addField}>Add field</button>
      <button type="button" disabled={saving} onClick={save}>{saving ? "Saving…" : "Save draft"}</button></div>
    </section>
  );
}
