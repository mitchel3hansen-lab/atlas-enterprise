import { useMemo, useState } from "react";

type Node = { id: string; objectType: string; displayName: string; depth: number };
type Props = { rootLabel: string; nodes: Node[]; onDepthChange?: (depth: number) => void };

export function RelationshipExplorer({ rootLabel, nodes, onDepthChange }: Props) {
  const [depth, setDepth] = useState(2);
  const grouped = useMemo(() => Object.entries(nodes.reduce<Record<string, Node[]>>((a, n) => {
    (a[n.objectType] ??= []).push(n); return a;
  }, {})), [nodes]);
  return <section aria-label={`Relationships for ${rootLabel}`}>
    <header><h2>Relationship Explorer</h2><label>Traversal depth <select value={depth} onChange={e => {
      const next = Number(e.target.value); setDepth(next); onDepthChange?.(next);
    }}><option value={1}>1</option><option value={2}>2</option><option value={3}>3</option></select></label></header>
    {grouped.map(([type, items]) => <div key={type}><h3>{type} ({items.length})</h3><ul>
      {items.map(n => <li key={n.id}>{n.displayName} <small>Depth {n.depth}</small></li>)}
    </ul></div>)}
  </section>;
}
