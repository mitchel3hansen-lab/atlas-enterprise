# Atlas Enterprise v0.18.0 — Rules & Automation Alpha

Adds a declarative, explainable rules runtime that responds to Atlas business events. The release includes tenant-scoped rule definitions, activation, condition evaluation, registered action dispatch, execution history, idempotency schema, permissions, API routes, a React rule builder, tests, migration/rollback, ADR, PRD, UAT, and a critical-incident example.

## Alpha limitations
- The included repository adapter is in-memory for local demonstration; the PostgreSQL schema is provided for the production adapter.
- Scheduling tables are included, but a durable scheduler worker is deferred.
- Only allow-listed action handlers execute; arbitrary user scripts are intentionally unsupported.
