# Genesis Continuous Build Plan

## Completed in v0.8.0
- Formal Constitution
- Manufacturing PRD
- Architecture baseline
- ADR for modular monolith
- Dockerized API, web, and PostgreSQL source baseline
- Tenant and correlation middleware
- Organization and safety-record API contracts
- Responsive command-center UI
- CI validation workflow

## Step 2 — Identity and tenant security
- OpenID Connect integration
- Development identity provider
- User, role, permission, and membership model
- Authorization policies
- Tenant-isolation integration tests

## Step 3 — Database lifecycle
- EF Core migrations
- Seed data
- Migration rollback process
- Backup and restore runbook

## Step 4 — Safety workflow
- Incident lifecycle
- Hazard and near-miss intake
- CAPA assignment and verification
- Attachments, comments, and audit history

## Step 5 — Inspection workflow
- Templates, questions, schedules, findings, scoring, and actions

## Step 6 — Learning foundation
- Course catalog, assignment, completion, certification, and training matrix

Each step must leave the repository runnable, documented, tested, and ready for the next increment.


## Completed: v0.10.0

User invitations, membership administration, role assignment, effective permissions, access auditing, and session-revocation persistence.

## Next: v0.11.0

Invitation acceptance, refresh-token rotation, enforced revocation, access reviews, and notification delivery.
