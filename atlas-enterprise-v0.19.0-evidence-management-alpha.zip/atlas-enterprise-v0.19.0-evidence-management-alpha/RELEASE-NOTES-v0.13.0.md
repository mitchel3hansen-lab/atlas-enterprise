# Atlas Enterprise v0.13.0 — Explainable Operational Intelligence

## Added

- Atlas Explainability Engine service and generic Why API
- Tenant-scoped evidence records
- Directed knowledge-graph relationships
- Deterministic reasons, recommendations, and confidence calculation
- Evidence and relationship creation endpoints
- New explainability permissions
- PostgreSQL migration V013
- Mission Control insight card with reusable Why panel
- ATS-0013 specification, knowledge-graph architecture, and ADR-0025

## Validation

- Source structure and migration presence validated.
- Frontend build was attempted; dependency installation did not finish within the available execution window.
- Backend compilation was not run because the .NET SDK is not installed in this environment.
