# ATLAS Genesis v0.10.0

## User and Access Administration

Added:

- Tenant-scoped membership administration API
- User invitation lifecycle foundation
- Role assignment replacement endpoint
- Effective-permission resolution endpoint
- Membership deactivation
- Append-only access audit events
- Revoked-session persistence model
- PostgreSQL V010 migration
- Administration UI concept
- Architecture documentation and ADR-0022

## Next release

v0.11.0 will implement invitation acceptance, refresh-token rotation, session revocation enforcement, access-review reporting, and email notification integration.
