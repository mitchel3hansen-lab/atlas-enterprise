# ATLAS Enterprise v0.11.0 — Foundation

## Added
- Full organization profile and lifecycle model.
- Search, paging, filtering, create, update, archive, restore, and audit APIs.
- PostgreSQL migration V011.
- Organization administration UI with metrics, filters, lifecycle controls, and create dialog.
- PLT-002 PRD, ADR-0023, and administration guide.

## Validation
- React production build validated.
- Backend source review completed; .NET compilation requires the .NET SDK in CI or a developer workstation.
