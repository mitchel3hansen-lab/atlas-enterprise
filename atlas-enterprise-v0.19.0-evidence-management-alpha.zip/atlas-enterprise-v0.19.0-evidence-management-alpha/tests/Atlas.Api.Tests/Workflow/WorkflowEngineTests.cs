using System.Security.Claims;
using System.Text.Json;
using Atlas.Api.Workflow;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;

public sealed class WorkflowEngineTests
{
    [Fact]
    public void Validate_rejects_missing_required_field()
    {
        var definition = new WorkflowDefinition(Guid.NewGuid(), Guid.NewGuid(), "incident", "Incident", 1,
            [new("draft", "Draft"), new("submitted", "Submitted")],
            [new("submit", "draft", "submitted", ["Supervisor"], ["description"])]);
        var instance = new WorkflowInstance(Guid.NewGuid(), definition.TenantId, definition.Id, 1, "incident", Guid.NewGuid(), "draft", "active", 0, DateTimeOffset.UtcNow);
        var actor = new ClaimsPrincipal(new ClaimsIdentity([new Claim(ClaimTypes.Role, "Supervisor")], "test"));
        using var doc = JsonDocument.Parse("{}");
        var engine = new WorkflowEngine(new StubRepository(), NullLogger<WorkflowEngine>.Instance);
        var result = engine.Validate(definition, instance, "submit", doc.RootElement, actor);
        Assert.False(result.Allowed);
        Assert.Contains("description", result.Reason);
    }

    private sealed class StubRepository : IWorkflowRepository
    {
        public Task AddInstanceAsync(WorkflowInstance instance, CancellationToken ct) => Task.CompletedTask;
        public Task AppendHistoryAsync(Guid tenantId, WorkflowHistoryEntry entry, CancellationToken ct) => Task.CompletedTask;
        public Task<IReadOnlyList<WorkflowHistoryEntry>> GetHistoryAsync(Guid tenantId, Guid instanceId, CancellationToken ct) => Task.FromResult<IReadOnlyList<WorkflowHistoryEntry>>([]);
        public Task<WorkflowInstance?> GetInstanceAsync(Guid tenantId, Guid instanceId, CancellationToken ct) => Task.FromResult<WorkflowInstance?>(null);
        public Task<WorkflowDefinition?> GetPublishedDefinitionAsync(Guid tenantId, string key, CancellationToken ct) => Task.FromResult<WorkflowDefinition?>(null);
        public Task<WorkflowDefinition?> GetDefinitionByIdAsync(Guid tenantId, Guid definitionId, int version, CancellationToken ct) => Task.FromResult<WorkflowDefinition?>(null);
        public Task<bool> TryUpdateStateAsync(Guid tenantId, Guid instanceId, string fromState, string toState, string status, int expectedLockVersion, CancellationToken ct) => Task.FromResult(true);
    }
}
