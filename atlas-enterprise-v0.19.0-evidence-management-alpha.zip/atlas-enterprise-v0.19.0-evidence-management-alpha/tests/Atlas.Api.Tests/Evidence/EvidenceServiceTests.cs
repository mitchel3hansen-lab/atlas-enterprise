using Atlas.Api.Evidence;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.FileProviders;
using Xunit;

namespace Atlas.Api.Tests.Evidence;

public sealed class EvidenceServiceTests : IDisposable
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), "atlas-evidence-tests", Guid.NewGuid().ToString("N"));

    [Fact]
    public async Task Create_and_download_preserves_sha256_integrity()
    {
        var repository = new InMemoryEvidenceRepository();
        var storage = new FileSystemEvidenceStorage(new TestEnvironment(_root));
        var service = new EvidenceService(repository, storage);
        var org = Guid.NewGuid(); var actor = Guid.NewGuid();
        var content = System.Text.Encoding.UTF8.GetBytes("incident photo placeholder");
        var record = await service.CreateAsync(org, actor, "test", new CreateEvidenceRequest(
            Guid.NewGuid(), "Incident", "Scene photo", "Initial condition", EvidenceClassification.Confidential,
            "incident-10-years", "scene.txt", "text/plain", Convert.ToBase64String(content), "uploaded by investigator"), default);

        var download = await service.DownloadAsync(org, record.Id, null, actor, "test", default);

        Assert.Equal(content, download.Content);
        Assert.Equal(64, download.Sha256.Length);
        Assert.Equal(1, download.VersionNumber);
    }

    [Fact]
    public async Task Duplicate_content_is_rejected_as_new_version()
    {
        var repository = new InMemoryEvidenceRepository();
        var storage = new FileSystemEvidenceStorage(new TestEnvironment(_root));
        var service = new EvidenceService(repository, storage);
        var org = Guid.NewGuid(); var actor = Guid.NewGuid();
        var encoded = Convert.ToBase64String([1, 2, 3]);
        var record = await service.CreateAsync(org, actor, "test", new CreateEvidenceRequest(null, null, "Document", "", EvidenceClassification.Internal, "standard", "a.bin", "application/octet-stream", encoded, ""), default);

        await Assert.ThrowsAsync<InvalidOperationException>(() => service.AddVersionAsync(org, record.Id, actor, "test", new AddEvidenceVersionRequest("b.bin", "application/octet-stream", encoded, ""), default));
    }

    public void Dispose() { if (Directory.Exists(_root)) Directory.Delete(_root, true); }

    private sealed class TestEnvironment(string root) : IWebHostEnvironment
    {
        public string ApplicationName { get; set; } = "Atlas.Tests";
        public IFileProvider WebRootFileProvider { get; set; } = new NullFileProvider();
        public string WebRootPath { get; set; } = root;
        public string EnvironmentName { get; set; } = "Test";
        public string ContentRootPath { get; set; } = root;
        public IFileProvider ContentRootFileProvider { get; set; } = new NullFileProvider();
    }
}
