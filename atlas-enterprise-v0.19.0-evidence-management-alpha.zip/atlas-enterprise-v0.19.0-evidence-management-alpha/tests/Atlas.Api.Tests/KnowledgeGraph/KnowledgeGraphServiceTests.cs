using Atlas.Api.KnowledgeGraph;
using Xunit;

namespace Atlas.Api.Tests.KnowledgeGraph;

public sealed class KnowledgeGraphServiceTests
{
    [Fact]
    public async Task EnsureNode_returns_existing_subject_node()
    {
        var existing = new GraphNode(Guid.NewGuid(), Guid.NewGuid(), null, "Incident", Guid.NewGuid(), "INC-001", new Dictionary<string, object?>(), 1);
        var repo = new StubRepository { Existing = existing };
        var service = new KnowledgeGraphService(repo);
        var result = await service.EnsureNodeAsync(existing.TenantId, Guid.NewGuid(),
            new("Incident", existing.ObjectId, "INC-001", null, null), default);
        Assert.Equal(existing.Id, result.Id);
        Assert.Equal(0, repo.CreateCalls);
    }

    [Fact]
    public async Task Connect_rejects_self_relationship()
    {
        var service = new KnowledgeGraphService(new StubRepository()); var id = Guid.NewGuid();
        await Assert.ThrowsAsync<ArgumentException>(() => service.ConnectAsync(Guid.NewGuid(), Guid.NewGuid(),
            new(id, id, "RELATED_TO", 1m, null, null, null), null, default));
    }

    private sealed class StubRepository : IKnowledgeGraphRepository
    {
        public GraphNode? Existing { get; set; } public int CreateCalls { get; private set; }
        public Task<GraphNode?> FindNodeAsync(Guid t,string o,Guid i,CancellationToken c)=>Task.FromResult(Existing);
        public Task<GraphNode> CreateNodeAsync(GraphNode n,Guid a,CancellationToken c){CreateCalls++;return Task.FromResult(n);}
        public Task<GraphNode?> GetNodeAsync(Guid t,Guid n,CancellationToken c)=>Task.FromResult<GraphNode?>(null);
        public Task<RelationshipType?> GetRelationshipTypeAsync(Guid t,string c,CancellationToken x)=>Task.FromResult<RelationshipType?>(null);
        public Task<GraphEdge> CreateEdgeAsync(GraphEdge e,Guid a,string? c,CancellationToken x)=>Task.FromResult(e);
        public Task<IReadOnlyList<GraphEdge>> GetAdjacentEdgesAsync(Guid t,Guid n,CancellationToken c)=>Task.FromResult<IReadOnlyList<GraphEdge>>(Array.Empty<GraphEdge>());
        public Task<IReadOnlyList<GraphNode>> GetNodesAsync(Guid t,IEnumerable<Guid> i,CancellationToken c)=>Task.FromResult<IReadOnlyList<GraphNode>>(Array.Empty<GraphNode>());
    }
}
