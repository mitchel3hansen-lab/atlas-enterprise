using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Atlas.Api.Auth;
using Atlas.Api.Infrastructure;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Atlas.Api.Tests;

public sealed class SecurityTests : IClassFixture<AtlasFactory>
{
    private readonly AtlasFactory _factory;
    public SecurityTests(AtlasFactory factory) => _factory = factory;

    [Fact]
    public async Task Protected_route_rejects_anonymous_request()
    {
        var response = await _factory.CreateClient().GetAsync("/api/v1/safety-records");
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Token_tenant_cannot_be_overridden_by_header()
    {
        var client = _factory.CreateClient();
        var bootstrap = await (await client.PostAsJsonAsync("/api/v1/auth/development/bootstrap", new
        {
            organizationName = "Tenant A", organizationSlug = $"tenant-a-{Guid.NewGuid():N}",
            displayName = "Admin", email = $"admin-{Guid.NewGuid():N}@example.test", password = "StrongPassword!123"
        })).Content.ReadFromJsonAsync<DevelopmentBootstrapResponse>();
        Assert.NotNull(bootstrap);

        var login = await (await client.PostAsJsonAsync("/api/v1/auth/login", new
        {
            bootstrap!.Email, password = "StrongPassword!123", bootstrap.OrganizationId
        })).Content.ReadFromJsonAsync<LoginResponse>();
        Assert.NotNull(login);

        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", login!.AccessToken);
        client.DefaultRequestHeaders.Add("X-Atlas-Organization-Id", Guid.NewGuid().ToString());
        var response = await client.GetAsync("/api/v1/organizations/current");
        var organization = await response.Content.ReadFromJsonAsync<OrganizationResponse>();

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal(bootstrap.OrganizationId, organization!.Id);
    }

    private sealed record OrganizationResponse(Guid Id, string Name, string Slug);
}

public sealed class AtlasFactory : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");
        builder.ConfigureServices(services =>
        {
            services.RemoveAll<DbContextOptions<AtlasDbContext>>();
            services.AddDbContext<AtlasDbContext>(options => options.UseInMemoryDatabase($"atlas-tests-{Guid.NewGuid():N}"));
        });
    }
}
