# Test Strategy

1. Domain unit tests for state transitions and business rules.
2. API integration tests using disposable PostgreSQL containers.
3. Authorization and tenant-isolation tests for every endpoint.
4. Frontend component tests for critical forms and dashboards.
5. End-to-end tests for report, investigate, assign CAPA, verify, and close workflows.
6. Accessibility checks for keyboard navigation, labels, contrast, and screen-reader semantics.
7. Security scanning for dependencies, containers, and secrets.
