# Atlas Enterprise v0.19.0 — Evidence Management Alpha

Atlas Enterprise is an operational intelligence platform. This repository consolidates identity, organizational context, facilities, explainability, operational health, metadata objects, workflow, knowledge graph, rules automation, and evidence management.

## v0.19.0 highlight
Evidence records now support tenant isolation, immutable versions, SHA-256 integrity verification, object links, retention metadata, legal hold, and audited access events.

## Local start
```bash
docker compose up --build
```

The included filesystem evidence adapter is intended for local development and single-node evaluation. Use encrypted durable object storage for production.
