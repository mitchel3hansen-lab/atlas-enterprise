# ATLAS Enterprise v0.12.0 — Facility Foundation

## Added
- PLT-003 Facility Management vertical slice.
- Tenant-scoped facility search, detail, create, update, archive, restore, and audit APIs.
- Facility type and lifecycle classifications.
- Address, time-zone, coordinates, and emergency-zone fields.
- Unique organization/facility-code enforcement.
- Facility audit event model and migration `V012`.
- `facilities.read` and `facilities.manage` permissions.
- Responsive Facility Management administration interface.
- PRD-0003, ADR-0024, administrator guide, and test cases.

## Validation
- React/TypeScript production build completed successfully.
- Backend source was statically reviewed. The .NET SDK is not installed in the build environment, so backend compilation and automated .NET tests were not executed.
