# ATLAS Genesis v0.9.0 Release Notes

## Theme

Identity and Tenant Security

## Completed

- Replaced trust in `X-Atlas-Organization-Id` with a tenant claim from a validated JWT.
- Added user, membership, role, permission, membership-role, and role-permission models.
- Added secure password hashing and credential validation.
- Added login and development bootstrap APIs.
- Added policy-based authorization to organization and safety endpoints.
- Added database migration, ADR, security architecture guide, and security tests.

## Next continuous step: v0.10.0

User and Access Administration:

- Invite users
- Activate and deactivate memberships
- Assign and remove roles
- List effective permissions
- Refresh/revoke sessions
- Audit all access changes
- Add a basic administration UI
