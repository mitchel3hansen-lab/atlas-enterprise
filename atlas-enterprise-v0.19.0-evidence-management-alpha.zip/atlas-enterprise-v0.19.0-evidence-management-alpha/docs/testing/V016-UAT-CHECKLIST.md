# v0.16 UAT
- [ ] Start the standard incident workflow.
- [ ] Reject submission without description, occurrence time, or facility.
- [ ] Permit Supervisor submission.
- [ ] Restrict assignment to Safety Manager.
- [ ] Detect stale lock version.
- [ ] Complete Draft through Closed.
- [ ] Verify ordered immutable history.
- [ ] Confirm tenant isolation.
- [ ] Confirm SLA breach query and UI status.
