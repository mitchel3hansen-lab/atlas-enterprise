# v0.17.0 UAT Checklist

- [ ] Register Incident, Facility, Equipment, Hazard, Employee, and CAPA nodes.
- [ ] Confirm duplicate registration returns the existing node.
- [ ] Create typed relationships with rationale and confidence.
- [ ] Reject a self-relationship.
- [ ] Reject a relationship that violates source/target type constraints.
- [ ] Run depth 1, 2, and 3 traversals and confirm cycle safety.
- [ ] Verify tenant isolation.
- [ ] Verify graph event and correlation identifier creation.
- [ ] Display results in Relationship Explorer.
