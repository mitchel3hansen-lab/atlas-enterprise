# v0.19.0 Evidence UAT

- [ ] Authorized investigator creates evidence linked to an Incident.
- [ ] Unauthorized user receives 403.
- [ ] Evidence appears in the object's evidence list.
- [ ] Download returns the original filename and checksum headers.
- [ ] Second version increments version number.
- [ ] Duplicate content is rejected.
- [ ] Legal hold can be applied only with `evidence.legal_hold`.
- [ ] Archived evidence rejects new versions.
- [ ] Cross-tenant lookup returns not found.
- [ ] Tampered stored content fails integrity verification.
