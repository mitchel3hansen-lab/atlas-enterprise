# Facility Management Test Cases

## API
- Create a facility with valid required fields.
- Reject duplicate code within one organization.
- Permit the same code in a different organization.
- Reject invalid latitude or longitude.
- Search by name, code, and city.
- Filter by type and lifecycle status.
- Archive and restore a facility.
- Return audit events newest first.

## Security
- Reject unauthenticated requests.
- Reject users without facilities permissions.
- Prevent cross-tenant read, update, archive, restore, and audit access.

## UI
- Filter facilities by type and status.
- Show an empty state when no records match.
- Create a facility through the dialog.
- Archive and restore a displayed facility.
