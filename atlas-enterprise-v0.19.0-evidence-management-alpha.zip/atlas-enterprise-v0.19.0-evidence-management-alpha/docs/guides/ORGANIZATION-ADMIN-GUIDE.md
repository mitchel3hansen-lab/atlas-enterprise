# Organization Administration Guide

Use **Administration → Organizations** to search and filter tenants. Select **Create organization** to establish a new workspace. Archive disables normal operational use without deleting records; Restore reactivates the tenant. Review the organization audit endpoint for lifecycle history.
