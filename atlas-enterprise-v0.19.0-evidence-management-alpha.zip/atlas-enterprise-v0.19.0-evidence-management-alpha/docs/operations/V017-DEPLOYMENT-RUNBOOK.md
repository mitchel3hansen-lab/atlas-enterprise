# v0.17.0 Deployment Runbook

1. Back up the Atlas PostgreSQL database.
2. Deploy API and web artifacts to a staging environment.
3. Apply `V017__knowledge_graph_engine.sql`.
4. Seed approved relationship types before enabling write access.
5. Grant `knowledge_graph.read` and `knowledge_graph.manage` through Atlas roles.
6. Run the v0.17 UAT checklist and tenant-isolation tests.
7. Enable graph endpoints behind the `KnowledgeGraphAlpha` feature flag.

## Rollback
Disable the feature flag first. Preserve graph data for audit purposes. Application rollback does not require destructive schema rollback.
