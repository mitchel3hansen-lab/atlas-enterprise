# v0.19.0 Deployment Runbook

1. Back up the Atlas database.
2. Apply `V019__evidence_management_engine.sql`.
3. Provision a writable `evidence-store` volume for the API container.
4. Restrict filesystem access to the API service account.
5. Deploy API and web artifacts.
6. Verify `/health` and Swagger.
7. Upload a test file, download it, and compare the `X-Atlas-SHA256` header.
8. Confirm tenant isolation and evidence permissions.

Rollback removes evidence tables only after exported binary content and metadata are retained. The alpha filesystem adapter must not be used for multi-node production.
