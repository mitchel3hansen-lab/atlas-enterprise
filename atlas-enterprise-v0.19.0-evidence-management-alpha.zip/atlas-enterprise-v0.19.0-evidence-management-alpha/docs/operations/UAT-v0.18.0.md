# v0.18.0 UAT Checklist

- [ ] Create a draft rule for `Incident.Created`.
- [ ] Activate the rule.
- [ ] Submit a critical incident payload and verify a successful execution.
- [ ] Submit a low-severity payload and verify a documented non-match.
- [ ] Confirm another tenant cannot read or execute the rule.
- [ ] Reuse the same correlation ID and verify the persistence layer prevents duplicate execution.
- [ ] Confirm the execution record includes condition reasons and action results.
- [ ] Disable the rule and verify it no longer runs.
