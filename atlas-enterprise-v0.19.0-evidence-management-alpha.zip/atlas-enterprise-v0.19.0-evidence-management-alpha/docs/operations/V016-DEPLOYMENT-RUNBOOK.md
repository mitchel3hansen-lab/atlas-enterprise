# v0.16 Deployment Runbook
1. Back up PostgreSQL.
2. Apply migrations V014, V015, and V016 in order.
3. Deploy API, then web.
4. Import `docs/sample-incident-workflow.json` as a published definition.
5. Run health checks and the UAT checklist.
Rollback requires disabling new workflow writes before reverting application binaries; workflow history must not be deleted.
