# ATLAS Identity and Tenant Security

## Security boundary

1. The API validates JWT signature, issuer, audience, and expiration.
2. The token identifies the user, organization membership, roles, and permissions.
3. `TenantContextMiddleware` reads the organization only from the validated claim.
4. Authorization policies require explicit permission claims.
5. Repositories and controllers apply organization filters to tenant-owned data.

## Core entities

- `AtlasUser`: global human identity.
- `OrganizationMembership`: explicit relationship between one user and one tenant.
- `Role`: configurable permission bundle, optionally tenant-owned.
- `Permission`: stable capability code used by authorization policies.
- `MembershipRole`: membership-to-role assignment.
- `RolePermission`: role-to-permission assignment.

## Development flow

1. Start PostgreSQL and API.
2. Apply the migration scripts.
3. POST `/api/v1/auth/development/bootstrap` once.
4. POST `/api/v1/auth/login` with the returned organization ID.
5. Use the returned bearer token in Swagger or API requests.

The bootstrap endpoint intentionally returns 404 outside Development.
