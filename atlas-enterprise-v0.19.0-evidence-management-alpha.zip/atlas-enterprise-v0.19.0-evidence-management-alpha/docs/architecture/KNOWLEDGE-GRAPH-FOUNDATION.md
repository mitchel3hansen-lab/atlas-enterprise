# Knowledge Graph Foundation

Atlas stores operational context as tenant-scoped directed relationships between typed objects.

## Relationship shape

- source object type and identifier;
- target object type and identifier;
- relationship type;
- normalized weight from 0 to 1;
- optional rationale;
- creator and timestamp.

Examples include:

- Hazard **affects** Asset
- Incident **reveals** Hazard
- Control **mitigates** Risk
- Training **qualifies** Person
- Inspection **verifies** Control
- Regulation **governs** Process

## Storage decision

v0.13.0 uses PostgreSQL adjacency tables inside the modular monolith. This supports transactional consistency, tenant isolation, ordinary backups, and straightforward querying. A specialized graph database is deferred until measured traversal requirements justify the operational cost.

## Safety boundaries

Relationships never grant authorization. Both the source and target remain subject to tenant and product permissions. Cross-tenant edges are prohibited by the API and schema contract.
