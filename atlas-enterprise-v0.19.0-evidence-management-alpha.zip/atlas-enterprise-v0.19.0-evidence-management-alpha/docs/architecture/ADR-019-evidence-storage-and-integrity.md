# ADR-019 — Evidence Storage and Integrity

## Decision
Separate evidence metadata from binary storage. Persist immutable versions with a SHA-256 digest and verify the digest when content is read.

## Rationale
The abstraction permits local development storage now and object-storage adapters later. Immutable versions preserve investigative history. Digest verification detects corruption or unauthorized modification.

## Security controls
- Tenant-scoped metadata lookup.
- Path traversal protection in the filesystem adapter.
- Permission separation for read, manage, download, and legal hold.
- 25 MiB alpha upload limit.
- No overwrite operation; changes create a new version.

## Consequences
The alpha filesystem adapter is suitable for local development, not clustered production. Production deployment requires durable encrypted object storage, malware scanning, backup, and key-management controls.
