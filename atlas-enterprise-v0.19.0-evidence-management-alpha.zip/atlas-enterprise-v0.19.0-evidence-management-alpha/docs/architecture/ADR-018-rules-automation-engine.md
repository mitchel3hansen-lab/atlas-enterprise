# ADR-018: Rules and Automation Engine

**Status:** Accepted  
**Release:** v0.18.0

## Decision
Atlas will evaluate tenant-scoped, versioned automation rules from immutable business events. Rules use declarative JSON conditions and registered action handlers. Every evaluation persists an explainability record, including the matched conditions, action results, correlation ID, object reference, and failure details.

## Consequences
- Product packs can change policy without recompiling the platform.
- Action handlers remain allow-listed platform code; arbitrary scripts are not executed.
- Idempotency is enforced per organization, rule, and correlation ID.
- Event delivery should eventually use an outbox and durable worker; Alpha exposes the runtime contract and synchronous evaluation endpoint.
