# User and Access Administration

Version 0.10.0 introduces tenant-scoped access administration.

## Capabilities

- Invite users with single-use, hashed invitation tokens.
- List organization memberships and assigned roles.
- Replace role assignments atomically.
- Resolve effective permissions from role-permission relationships.
- Deactivate memberships without deleting identity or audit history.
- Record access changes as append-only audit events.
- Persist revoked session identifiers for token invalidation workflows.

## Security rules

1. All administration endpoints require an authenticated tenant context.
2. Read operations require `users.read`; mutations require `users.manage`.
3. Role assignment only accepts platform roles or roles owned by the active tenant.
4. Invitation plaintext tokens are returned once; only SHA-256 hashes are stored.
5. Membership deactivation is reversible at the data layer but auditable.
6. Audit events never update or delete through the public API.

## Next hardening increment

Wire JWT `jti` claims to the revoked-session store, add refresh-token rotation, email delivery adapters, invitation acceptance, and self-service MFA enrollment.
