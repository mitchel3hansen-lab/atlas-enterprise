# ATLAS Software Architecture v1.0

## Architectural style
A modular monolith is the initial deployment model. Domain boundaries, internal events, and stable APIs preserve a future path to independently deployed services without premature operational complexity.

## Technology baseline
- Backend: ASP.NET Core 8
- Data: PostgreSQL 16
- ORM: EF Core
- Frontend: React, TypeScript, Vite
- Authentication: OpenID Connect/JWT target; development identity stub initially
- Deployment: Docker Compose locally; Kubernetes-compatible containers later
- CI/CD: GitHub Actions

## Core domains
- Identity and Access
- Tenancy and Organization
- Workflow
- Notifications
- Documents
- Search
- Audit
- Safety
- Learning
- Readiness
- Assets
- Intelligence

## Tenant isolation
Every business record includes `OrganizationId`. Facility-scoped records also include `FacilityId`. The API derives tenant context from authenticated claims and rejects client attempts to cross tenant boundaries.

## Data conventions
- UUID primary keys
- UTC timestamps
- Optimistic concurrency token on mutable aggregate roots
- Soft deletion only where legally and operationally appropriate
- Immutable audit events for material changes

## API conventions
- `/api/v1/...`
- RFC 7807 problem details
- Cursor or page-based pagination
- Explicit filtering and sorting allowlists
- Idempotency keys for retry-sensitive commands
- Correlation IDs for tracing

## Security baseline
- Least-privilege permissions
- Secrets outside source control
- Validated input and parameterized persistence
- Audit of authentication and privileged changes
- Dependency and container scanning in CI
