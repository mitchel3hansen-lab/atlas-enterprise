# Knowledge Graph Alpha PRD

## Goal
Connect operational records so Atlas can perform cross-object impact analysis and support evidence-grounded intelligence.

## Alpha scope
- Idempotent node registration
- Typed relationship catalog
- Evidence-backed edges
- One-to-six-hop traversal
- Tenant isolation
- Immutable graph events
- Incident relationship explorer

## Primary demonstration
Create an Incident node, connect it to Facility, Equipment, Hazard, Employee, and CAPA nodes, then run a depth-two impact analysis that returns a complete evidence chain.

## Acceptance criteria
1. Duplicate subject nodes are not created.
2. Invalid source/target types are rejected.
3. Cross-tenant access is impossible.
4. Self-links are rejected.
5. Traversal is cycle-safe and depth-limited.
6. Relationship creation emits an auditable event.
7. API and UI expose relationship rationale and confidence.
