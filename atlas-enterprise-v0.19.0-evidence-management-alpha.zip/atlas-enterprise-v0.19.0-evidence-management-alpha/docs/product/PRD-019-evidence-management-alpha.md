# PRD-019 — Evidence Management Alpha

## Objective
Provide tenant-scoped, tamper-evident evidence records for Atlas operational objects.

## Alpha scope
- Upload a file as a new evidence record.
- Link evidence to an Atlas object.
- Add immutable versions.
- Calculate and verify SHA-256 checksums.
- Record access events and correlation identifiers.
- Apply or release legal hold.
- Store retention-policy metadata.
- Enforce evidence permissions.

## Acceptance criteria
1. Every stored version has an immutable version number and SHA-256 digest.
2. Download recalculates the digest and fails closed on mismatch.
3. Identical content cannot be added twice to the same evidence record.
4. Tenant boundaries are checked before metadata or content access.
5. Legal hold changes are audited.
6. Archived or disposed records cannot receive new versions.

## Deferred
Malware scanning, S3/Azure Blob adapters, cryptographic signatures, disposition workflow, OCR, redaction, and external evidence sharing.
