# ATS-0013 — Atlas Explainability Engine

**Status:** Implemented foundation  
**Version:** 0.1  
**Product release:** Atlas Enterprise v0.13.0

## Purpose

The Explainability Engine gives every Atlas object a structured answer to four questions:

1. What changed or is important?
2. Why does it matter?
3. What evidence supports the conclusion?
4. What should happen next?

## Contract

`GET /api/v1/explainability/{objectType}/{objectId}` returns:

- plain-language summary;
- deterministic reasons;
- linked evidence;
- incoming and outgoing knowledge-graph relationships;
- confidence score;
- recommended next actions;
- engine version and generation timestamp.

## Design guarantees

- Tenant scope comes from the validated token context.
- Identical persisted evidence and relationships produce the same reasons and recommendations.
- Confidence is bounded from 0.00 to 0.99 and is never presented as certainty.
- Recommendations assist human judgment; they do not close records or execute controls automatically.
- Evidence gaps and relationship gaps are surfaced explicitly rather than hidden.

## Initial scoring model

Confidence combines average source confidence, evidence breadth, relationship breadth, and a verified-evidence bonus. The algorithm is intentionally simple and auditable in the first release. It will be versioned before future scoring changes.

## Extension path

Atlas Risk will add domain rules for hazards, controls, incidents, inspections, training, and corrective actions. Exchange Packs may provide declarative rules but may not distribute executable code.
