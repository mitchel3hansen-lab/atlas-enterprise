# PRD-018: Rules and Automation Alpha

## Objective
Turn Atlas business events into explainable, tenant-safe actions without hard-coded product logic.

## Alpha scope
- Create and activate rules
- Match event names
- Evaluate AND-based conditions
- Dispatch allow-listed actions
- Persist execution history and explanations
- Protect routes with dedicated permissions
- Demonstrate a critical incident escalation rule

## Acceptance criteria
1. An active rule evaluates only for its organization and trigger event.
2. Missing or failed conditions produce a visible non-match explanation.
3. Unsupported actions fail safely and are recorded.
4. Duplicate organization/rule/correlation executions are rejected by storage.
5. Rule execution history is queryable.
