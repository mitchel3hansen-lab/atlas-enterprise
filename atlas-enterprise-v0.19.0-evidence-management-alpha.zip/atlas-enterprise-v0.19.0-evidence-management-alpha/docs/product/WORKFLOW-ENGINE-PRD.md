# Workflow Orchestration Engine PRD

## Objective
Provide one tenant-aware workflow runtime for every Atlas object.

## Acceptance criteria
- Publish versioned definitions.
- Start and transition instances.
- Enforce role and required-field guards.
- Preserve immutable history.
- Prevent lost updates through lock versions.
- Track task ownership and SLA deadlines.
- Expose REST APIs and an explainable UI timeline.
