# PRD-0003 — Facility Management

## Objective
Provide secure, tenant-scoped management of physical operating locations that future ATLAS records can reference consistently.

## Personas
- Organization Administrator
- Safety and Risk Manager
- Emergency Manager
- Operations Leader

## Capabilities
- Create, view, search, filter, update, archive, and restore facilities.
- Classify facilities as sites, plants, warehouses, offices, laboratories, distribution centers, or other.
- Store address, time-zone, geographic coordinates, and emergency-zone context.
- Enforce unique facility codes within an organization.
- Record immutable audit events for lifecycle changes.

## Acceptance Criteria
1. Users only see facilities belonging to their authenticated organization.
2. Facility code is unique within the tenant.
3. Latitude and longitude are validated.
4. Archived facilities remain available for historical records but are excluded by active filters.
5. Every create, update, archive, and restore action creates an audit event.
6. API results support search, type/status filtering, pagination, and deterministic ordering.
