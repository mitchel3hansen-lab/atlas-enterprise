# PLT-002 Organizations — Product Requirements

## Purpose
Provide secure tenant lifecycle management for ATLAS platform administrators.

## Users
Platform Administrator; Organization Administrator (read/update current tenant only); Auditor (read/audit only).

## Scope
Create, search, view, update, archive, restore, branding fields, status, pagination, and immutable audit history.

## Acceptance criteria
1. Slugs are unique and normalized.
2. Required fields are validated server-side.
3. Archive is reversible and does not delete tenant records.
4. All lifecycle changes create audit events.
5. Results support search, status filtering, paging, and deterministic sorting.
6. Authorization policies protect read and management operations.
7. The UI is responsive and keyboard accessible.

## Out of scope
Billing, custom domains, mergers, data export, and cross-tenant delegation.
