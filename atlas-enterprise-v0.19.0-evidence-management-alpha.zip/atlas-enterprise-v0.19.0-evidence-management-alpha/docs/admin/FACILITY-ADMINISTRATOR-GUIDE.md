# Facility Administrator Guide

Use **Administration → Facilities** to manage operating locations.

## Required fields
- Facility name
- Facility code
- Facility type
- Time zone
- Country code

## Lifecycle
- **Active:** available for new operational records.
- **Inactive:** temporarily unavailable without historical removal.
- **Archived:** retired from normal use; historical references remain intact.

## Governance
Use stable facility codes that match internal reporting conventions. Confirm local time zone and emergency zone because these fields will support notifications, drills, incident response, reporting, and escalation rules.
