# ADR-0023: Organization Lifecycle

**Status:** Accepted  
**Decision:** Organizations use soft archival rather than destructive deletion. A unique immutable identity and slug anchor all tenant-owned records. Status transitions and profile changes are written to a dedicated append-only audit stream.

## Rationale
Enterprise retention, legal hold, traceability, and restoration requirements make hard deletion unsafe. A dedicated audit stream prevents administration history from being mixed with access-security events.

## Consequences
Queries must explicitly account for status. Storage is retained after archival. Future purge capability requires a separate governed process.
