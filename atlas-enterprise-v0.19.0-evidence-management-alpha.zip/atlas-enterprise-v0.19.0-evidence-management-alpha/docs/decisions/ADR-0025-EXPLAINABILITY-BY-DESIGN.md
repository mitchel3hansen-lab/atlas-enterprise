# ADR-0025 — Explainability by Design

**Status:** Accepted

## Decision

Explainability is a reusable Atlas Core capability rather than a presentation-only feature or an opaque AI response.

Every explanation must expose its reasons, evidence, confidence, relationships, recommendations, and engine version. Missing evidence must lower confidence and create an explicit evidence-gap recommendation.

## Consequences

- Product teams reuse one contract across Atlas Risk, Safety, Quality, Emergency, and Mission Control.
- Explanations can be tested and audited.
- Future AI-generated language must remain grounded in the deterministic explanation payload.
- Schema and rule changes require versioning and regression tests.
