# ADR-0022: Tenant-scoped access administration

**Status:** Accepted  
**Release:** 0.10.0

## Decision

ATLAS will model access through organization memberships, role assignments, and derived permissions. Invitations are organization-bound and stored as hashes. Access changes generate append-only audit events.

## Rationale

A user may belong to more than one organization, and their authority may differ in each tenant. Membership-scoped roles prevent global privilege leakage and make access reviews explainable.

## Consequences

- APIs must always filter memberships and roles by the active tenant.
- Permission changes take effect on the next token issuance until session revocation is fully enforced.
- Administrators can review effective permissions without interpreting role internals.
