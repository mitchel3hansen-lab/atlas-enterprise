# ADR-0024 — Facility as Shared Operational Context

## Status
Accepted for v0.12.0.

## Decision
Facility is a tenant-owned platform entity rather than a Safety-specific record. It stores physical location, local time, emergency-zone, lifecycle, and optional geospatial context. All APIs apply organization scoping from the authenticated tenant context.

## Rationale
Incidents, inspections, training assignments, emergency plans, assets, audits, and compliance evidence all require a common location model. A shared facility entity prevents incompatible location records across modules.

## Consequences
- Facility codes are unique per organization, not globally.
- Facilities use soft archival to preserve historical relationships.
- Detailed building, department, production-area, and emergency-zone hierarchies remain future child entities.
