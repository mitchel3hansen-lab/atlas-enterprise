# ADR-0029: Knowledge Graph Engine

**Status:** Accepted  
**Release:** v0.17.0

## Context
Atlas objects require typed, explainable relationships across incidents, people, equipment, hazards, controls, evidence, CAPAs, and facilities.

## Decision
Implement a tenant-isolated property graph abstraction on PostgreSQL using versioned nodes, typed edges, confidence, rationale, evidence references, and immutable graph events. Keep the repository contract replaceable so a specialized graph database can be introduced later without changing product APIs.

## Consequences
- Relational deployment remains simple for Alpha.
- Traversal depth is capped to protect API performance.
- Every relationship must be authorized, auditable, and explainable.
- Product modules consume graph services and never write graph tables directly.
