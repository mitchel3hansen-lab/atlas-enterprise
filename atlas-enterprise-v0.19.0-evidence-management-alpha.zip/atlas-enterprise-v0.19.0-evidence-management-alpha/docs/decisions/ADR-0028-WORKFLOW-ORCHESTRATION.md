# ADR-0028: Workflow Orchestration Engine
Status: Accepted

Atlas will use versioned metadata-defined state machines. Runtime instances reference an immutable published version. State updates use optimistic concurrency, append immutable history, and emit domain events. Product modules may configure workflows but may not implement independent workflow runtimes.
