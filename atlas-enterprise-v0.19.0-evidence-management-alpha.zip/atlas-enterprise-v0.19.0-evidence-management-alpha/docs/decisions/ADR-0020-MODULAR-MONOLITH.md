# ADR-0020: Start as a Modular Monolith

Status: Accepted

## Decision
ATLAS will begin as a modular monolith with explicit domain boundaries and internal events.

## Rationale
This approach minimizes deployment and operational complexity while preserving disciplined domain separation. It supports fast iteration during pilot development and provides a controlled path to extract services when scale, ownership, or reliability requirements justify it.

## Consequences
- One primary API deployment initially
- Shared database with schema and ownership boundaries
- Cross-domain access only through application contracts
- Service extraction requires demonstrated business or operational need
