# ADR-0021: Identity and Tenant Security

**Status:** Accepted  
**Release:** Genesis v0.9.0

## Decision

ATLAS will use standards-based JWT bearer authentication at the API boundary, organization memberships for tenant access, role-to-permission authorization, and tenant context derived only from validated token claims.

## Rationale

A client-supplied organization header is not a trustworthy security boundary. Binding the active organization to a validated membership claim prevents callers from changing tenants by modifying a request header. Fine-grained permission claims provide stable policy names while allowing roles to remain configurable by each organization.

## Consequences

- Every protected request requires a valid access token.
- Tenant-scoped queries must filter by `TenantContext.OrganizationId`.
- Role changes require token renewal before new permissions appear.
- Development bootstrap is available only in the Development environment.
- Production deployments must replace the development signing key and should later move to an external OpenID Connect provider with asymmetric signing keys.
