import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import './styles/app.css';

const members = [
  { name: 'Mitch Hansen', email: 'mitch@example.com', role: 'Organization Administrator', status: 'Active' },
  { name: 'Alejandra Ruiz', email: 'alejandra@example.com', role: 'Safety Manager', status: 'Active' },
  { name: 'Rafa Torres', email: 'rafa@example.com', role: 'Facility Supervisor', status: 'Invitation pending' }
];

function App() {
  const [view, setView] = useState<'command'|'admin'>('admin');
  return <div className="shell">
    <aside><h1>ATLAS</h1><p>Operational Intelligence</p><nav>
      <a onClick={() => setView('command')} className={view==='command'?'active':''}>Command Center</a>
      <a>Safety</a><a>Inspections</a><a>Learning</a><a>Ready</a>
      <a onClick={() => setView('admin')} className={view==='admin'?'active':''}>Administration</a>
    </nav></aside>
    <main>{view === 'admin' ? <Administration/> : <CommandCenter/>}</main>
  </div>;
}

function Administration() { return <>
  <header><div><span>Genesis Alpha · v0.10.0</span><h2>User & Access Administration</h2></div><button>Invite user</button></header>
  <section className="metrics">
    <article><small>Active users</small><strong>24</strong></article>
    <article><small>Pending invitations</small><strong>3</strong></article>
    <article><small>Roles</small><strong>6</strong></article>
    <article><small>Access reviews due</small><strong>2</strong></article>
  </section>
  <section className="panel"><div><h3>Organization access</h3><p>Review memberships, role assignments, and account status.</p></div>
    <table><thead><tr><th>User</th><th>Email</th><th>Role</th><th>Status</th></tr></thead><tbody>
      {members.map(m => <tr key={m.email}><td>{m.name}</td><td>{m.email}</td><td>{m.role}</td><td>{m.status}</td></tr>)}
    </tbody></table>
  </section>
</> }

function CommandCenter() { return <><header><div><span>Genesis Alpha</span><h2>Safety Command Center</h2></div><button>Report an event</button></header><section className="panel"><h3>Operational overview</h3><p>Return to Administration to manage tenant access.</p></section></> }

ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>);
