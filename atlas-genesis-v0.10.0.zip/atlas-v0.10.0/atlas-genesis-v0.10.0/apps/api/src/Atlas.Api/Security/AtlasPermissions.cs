namespace Atlas.Api.Security;

public static class AtlasPermissions
{
    public const string OrganizationsRead = "organizations.read";
    public const string OrganizationsManage = "organizations.manage";
    public const string UsersRead = "users.read";
    public const string UsersManage = "users.manage";
    public const string SafetyRead = "safety.read";
    public const string SafetyManage = "safety.manage";

    public static readonly string[] All =
    [
        OrganizationsRead,
        OrganizationsManage,
        UsersRead,
        UsersManage,
        SafetyRead,
        SafetyManage
    ];
}
