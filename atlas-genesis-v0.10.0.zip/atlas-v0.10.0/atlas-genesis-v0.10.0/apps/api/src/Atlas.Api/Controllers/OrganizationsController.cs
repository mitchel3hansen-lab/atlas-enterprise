using Atlas.Api.Domain;
using Atlas.Api.Infrastructure;
using Atlas.Api.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Api.Controllers;

[ApiController]
[Route("api/v1/organizations")]
[Authorize]
public sealed class OrganizationsController(AtlasDbContext db, TenantContext tenant) : ControllerBase
{
    [HttpGet("current")]
    [Authorize(Policy = AtlasPermissions.OrganizationsRead)]
    public async Task<ActionResult<Organization>> GetCurrent(CancellationToken cancellationToken)
    {
        if (tenant.OrganizationId is not Guid organizationId)
            return Unauthorized();
        var organization = await db.Organizations.AsNoTracking().SingleOrDefaultAsync(x => x.Id == organizationId, cancellationToken);
        return organization is null ? NotFound() : Ok(organization);
    }

    [HttpPatch("current")]
    [Authorize(Policy = AtlasPermissions.OrganizationsManage)]
    public async Task<ActionResult<Organization>> UpdateCurrent(UpdateOrganizationRequest request, CancellationToken cancellationToken)
    {
        if (tenant.OrganizationId is not Guid organizationId)
            return Unauthorized();
        var existing = await db.Organizations.SingleOrDefaultAsync(x => x.Id == organizationId, cancellationToken);
        if (existing is null) return NotFound();
        var updated = existing with { Name = request.Name.Trim() };
        db.Entry(existing).CurrentValues.SetValues(updated);
        await db.SaveChangesAsync(cancellationToken);
        return Ok(updated);
    }
}

public sealed record UpdateOrganizationRequest(string Name);
