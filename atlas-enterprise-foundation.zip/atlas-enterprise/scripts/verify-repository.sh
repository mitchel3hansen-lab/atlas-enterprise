#!/usr/bin/env sh
set -eu

test -f Atlas.sln
test -f LICENSE
test -f docker-compose.yml
test -f apps/api/Atlas.Api.csproj
test -f apps/web/package.json
test -f .github/workflows/ci.yml

echo "Repository structure verified."
