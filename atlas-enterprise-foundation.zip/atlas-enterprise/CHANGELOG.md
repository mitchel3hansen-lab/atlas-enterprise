# Changelog

All notable changes to the canonical Atlas Enterprise repository will be recorded here.

The project follows Semantic Versioning after the first public release. Historical package notes are retained under `docs/archive/releases/` for traceability and are not treated as independent repositories.

## Unreleased

### Added

- Canonical repository governance and Apache 2.0 licensing
- Root development environment with PostgreSQL, Redis, Mailpit, API, and web services
- GitHub Actions continuous-integration workflow
- Branch, release, and architecture-decision governance

### Changed

- Consolidated historical package artifacts into a single source-of-truth repository
