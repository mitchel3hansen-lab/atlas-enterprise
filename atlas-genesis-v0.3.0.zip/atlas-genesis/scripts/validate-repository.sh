#!/usr/bin/env bash
set -euo pipefail
required=(README.md CONTRIBUTING.md SECURITY.md Atlas.sln docs/handbook/engineering-constitution.md docs/api/platform-core.openapi.yaml)
for file in "${required[@]}"; do
  test -s "$file" || { echo "Missing or empty: $file"; exit 1; }
done
echo "Repository structure validation passed."
