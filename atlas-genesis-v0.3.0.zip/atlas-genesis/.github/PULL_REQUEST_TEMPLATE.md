## Purpose

## Changes

## Verification
- [ ] Tests added or updated
- [ ] Documentation updated
- [ ] Security and tenant isolation reviewed
- [ ] API compatibility reviewed
- [ ] Migration/rollback considered

## Related issue / ADR
