# Foundation Bounded Context

Owns tenants, organizations, facilities, departments, locations, and organization hierarchy.
