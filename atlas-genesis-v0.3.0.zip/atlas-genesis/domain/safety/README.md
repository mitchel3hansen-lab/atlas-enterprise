# Safety Bounded Context

Planned aggregate roots: Incident, Hazard, Inspection, Investigation, CorrectiveAction, SafetyObservation.

Safety references Foundation IDs for tenant, organization, facility, department, location, and person assignments.
