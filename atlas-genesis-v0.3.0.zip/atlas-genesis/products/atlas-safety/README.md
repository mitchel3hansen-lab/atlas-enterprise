# Atlas Safety

Atlas Safety is the first ATLAS product. Its MVP is an auditable incident-to-CAPA workflow built exclusively on shared platform capabilities.

This folder currently establishes the product boundary. Business implementation begins after Platform Foundation and tenant-aware persistence are complete.
