using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain.Identity;

public sealed class User : AtlasEntity
{
    private User() { }

    public string Email { get; private set; } = string.Empty;
    public string NormalizedEmail { get; private set; } = string.Empty;
    public string DisplayName { get; private set; } = string.Empty;
    public bool IsEnabled { get; private set; } = true;

    public static User Create(Guid tenantId, string email, string displayName, Guid? actorId, DateTimeOffset now)
    {
        if (tenantId == Guid.Empty) throw new ArgumentException("Tenant ID is required.", nameof(tenantId));
        if (string.IsNullOrWhiteSpace(email)) throw new ArgumentException("Email is required.", nameof(email));
        if (string.IsNullOrWhiteSpace(displayName)) throw new ArgumentException("Display name is required.", nameof(displayName));

        var normalizedEmail = email.Trim().ToUpperInvariant();
        if (!normalizedEmail.Contains('@')) throw new ArgumentException("A valid email address is required.", nameof(email));

        return new User
        {
            Id = Guid.NewGuid(), TenantId = tenantId,
            Email = email.Trim(), NormalizedEmail = normalizedEmail,
            DisplayName = displayName.Trim(), CreatedAt = now, UpdatedAt = now,
            CreatedBy = actorId, UpdatedBy = actorId
        };
    }

    public void Disable(Guid actorId, DateTimeOffset now)
    {
        IsEnabled = false;
        Status = "disabled";
        UpdatedBy = actorId;
        UpdatedAt = now;
        Version++;
    }
}
