namespace Atlas.Platform.Domain.Identity;

public sealed class UserRole
{
    private UserRole() { }
    public Guid TenantId { get; private init; }
    public Guid UserId { get; private init; }
    public Guid RoleId { get; private init; }
    public DateTimeOffset AssignedAt { get; private init; }
    public Guid? AssignedBy { get; private init; }

    public static UserRole Create(Guid tenantId, Guid userId, Guid roleId, Guid? assignedBy, DateTimeOffset now)
    {
        if (tenantId == Guid.Empty || userId == Guid.Empty || roleId == Guid.Empty) throw new ArgumentException("Tenant, user, and role IDs are required.");
        return new UserRole { TenantId = tenantId, UserId = userId, RoleId = roleId, AssignedAt = now, AssignedBy = assignedBy };
    }
}
