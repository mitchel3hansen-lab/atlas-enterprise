namespace Atlas.Platform.Domain.Identity;

public sealed class RolePermission
{
    private RolePermission() { }
    public Guid RoleId { get; private init; }
    public Guid PermissionId { get; private init; }
    public static RolePermission Create(Guid roleId, Guid permissionId) =>
        roleId == Guid.Empty || permissionId == Guid.Empty
            ? throw new ArgumentException("Role and permission IDs are required.")
            : new RolePermission { RoleId = roleId, PermissionId = permissionId };
}
