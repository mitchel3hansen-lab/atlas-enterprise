namespace Atlas.Platform.Domain.Identity;

public sealed class Permission
{
    private Permission() { }
    public Guid Id { get; private init; }
    public string Key { get; private set; } = string.Empty;
    public string Description { get; private set; } = string.Empty;

    public static Permission Create(string key, string description)
    {
        if (string.IsNullOrWhiteSpace(key)) throw new ArgumentException("Permission key is required.", nameof(key));
        return new Permission { Id = Guid.NewGuid(), Key = key.Trim().ToLowerInvariant(), Description = description.Trim() };
    }
}
