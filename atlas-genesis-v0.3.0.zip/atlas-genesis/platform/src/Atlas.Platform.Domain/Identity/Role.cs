using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain.Identity;

public sealed class Role : AtlasEntity
{
    private Role() { }
    public string Name { get; private set; } = string.Empty;
    public string NormalizedName { get; private set; } = string.Empty;
    public string Description { get; private set; } = string.Empty;
    public bool IsSystemRole { get; private set; }

    public static Role Create(Guid tenantId, string name, string description, bool isSystemRole, Guid? actorId, DateTimeOffset now)
    {
        if (tenantId == Guid.Empty) throw new ArgumentException("Tenant ID is required.", nameof(tenantId));
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Role name is required.", nameof(name));
        return new Role
        {
            Id = Guid.NewGuid(), TenantId = tenantId, Name = name.Trim(),
            NormalizedName = name.Trim().ToUpperInvariant(), Description = description.Trim(),
            IsSystemRole = isSystemRole, CreatedAt = now, UpdatedAt = now,
            CreatedBy = actorId, UpdatedBy = actorId
        };
    }
}
