using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain;

public sealed class Facility : AtlasEntity
{
    private Facility() { }

    public Guid OrganizationId { get; private init; }
    public string Name { get; private set; } = string.Empty;
    public string? Code { get; private set; }

    public static Facility Create(Guid tenantId, Guid organizationId, string name, string? code, Guid? actorId, DateTimeOffset now)
    {
        if (tenantId == Guid.Empty) throw new ArgumentException("Tenant is required.", nameof(tenantId));
        if (organizationId == Guid.Empty) throw new ArgumentException("Organization is required.", nameof(organizationId));
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Name is required.", nameof(name));
        if (name.Trim().Length > 200) throw new ArgumentException("Name cannot exceed 200 characters.", nameof(name));
        if (code?.Trim().Length > 32) throw new ArgumentException("Code cannot exceed 32 characters.", nameof(code));

        return new Facility
        {
            Id = Guid.NewGuid(), TenantId = tenantId, OrganizationId = organizationId,
            Name = name.Trim(), Code = string.IsNullOrWhiteSpace(code) ? null : code.Trim().ToUpperInvariant(),
            CreatedAt = now, UpdatedAt = now, CreatedBy = actorId, UpdatedBy = actorId
        };
    }
}
