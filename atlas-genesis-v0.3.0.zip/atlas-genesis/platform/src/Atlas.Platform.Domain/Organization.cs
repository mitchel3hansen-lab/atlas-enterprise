using Atlas.Sdk.Core;

namespace Atlas.Platform.Domain;

public sealed class Organization : AtlasEntity
{
    private Organization() { }

    public string Name { get; private set; } = string.Empty;
    public string NormalizedName { get; private set; } = string.Empty;

    public static Organization Create(Guid tenantId, string name, Guid? actorId, DateTimeOffset now)
    {
        if (tenantId == Guid.Empty) throw new ArgumentException("Tenant is required.", nameof(tenantId));
        var normalizedName = NormalizeName(name);

        return new Organization
        {
            Id = Guid.NewGuid(), TenantId = tenantId, Name = name.Trim(), NormalizedName = normalizedName,
            CreatedAt = now, UpdatedAt = now, CreatedBy = actorId, UpdatedBy = actorId
        };
    }

    public static string NormalizeName(string name)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Name is required.", nameof(name));
        if (name.Trim().Length > 200) throw new ArgumentException("Name cannot exceed 200 characters.", nameof(name));
        return name.Trim().ToUpperInvariant();
    }
}
