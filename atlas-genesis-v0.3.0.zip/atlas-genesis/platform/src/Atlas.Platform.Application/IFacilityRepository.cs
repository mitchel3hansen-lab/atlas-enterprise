using Atlas.Platform.Domain;

namespace Atlas.Platform.Application;

public interface IFacilityRepository
{
    Task<IReadOnlyCollection<Facility>> ListAsync(Guid tenantId, Guid organizationId, CancellationToken cancellationToken);
    Task<Facility?> GetAsync(Guid tenantId, Guid facilityId, CancellationToken cancellationToken);
    Task AddAsync(Facility facility, CancellationToken cancellationToken);
}
