using Atlas.Platform.Domain;

namespace Atlas.Platform.Application;

public interface IOrganizationRepository
{
    Task<IReadOnlyCollection<Organization>> ListAsync(Guid tenantId, CancellationToken cancellationToken);
    Task<Organization?> GetAsync(Guid tenantId, Guid organizationId, CancellationToken cancellationToken);
    Task<bool> NameExistsAsync(Guid tenantId, string normalizedName, CancellationToken cancellationToken);
    Task AddAsync(Organization organization, CancellationToken cancellationToken);
}
