namespace Atlas.Platform.Application.Identity;

public static class AtlasPermissions
{
    public const string OrganizationsRead = "organizations.read";
    public const string OrganizationsWrite = "organizations.write";
    public const string FacilitiesRead = "facilities.read";
    public const string FacilitiesWrite = "facilities.write";
    public const string UsersRead = "users.read";
    public const string UsersWrite = "users.write";
    public const string TenantAdmin = "tenant.admin";

    public static readonly string[] All =
    [OrganizationsRead, OrganizationsWrite, FacilitiesRead, FacilitiesWrite, UsersRead, UsersWrite, TenantAdmin];
}
