using Atlas.Platform.Domain.Identity;

namespace Atlas.Platform.Application.Identity;

public interface IIdentityRepository
{
    Task<IReadOnlyCollection<User>> ListUsersAsync(Guid tenantId, CancellationToken cancellationToken);
    Task<User?> GetUserAsync(Guid tenantId, Guid userId, CancellationToken cancellationToken);
    Task<bool> EmailExistsAsync(Guid tenantId, string normalizedEmail, CancellationToken cancellationToken);
    Task AddUserAsync(User user, CancellationToken cancellationToken);
    Task<IReadOnlyCollection<string>> GetPermissionKeysAsync(Guid tenantId, Guid userId, CancellationToken cancellationToken);
}
