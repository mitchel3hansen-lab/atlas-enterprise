using Atlas.Platform.Domain.Identity;

namespace Atlas.Platform.Application.Identity;

public sealed class IdentityService(IIdentityRepository repository, TimeProvider timeProvider)
{
    public Task<IReadOnlyCollection<User>> ListUsersAsync(Guid tenantId, CancellationToken cancellationToken) =>
        repository.ListUsersAsync(tenantId, cancellationToken);

    public async Task<User> CreateUserAsync(Guid tenantId, string email, string displayName, Guid actorId, CancellationToken cancellationToken)
    {
        var normalized = email.Trim().ToUpperInvariant();
        if (await repository.EmailExistsAsync(tenantId, normalized, cancellationToken))
            throw new ConflictException("A user with this email already exists in the tenant.");

        var user = User.Create(tenantId, email, displayName, actorId, timeProvider.GetUtcNow());
        await repository.AddUserAsync(user, cancellationToken);
        return user;
    }
}
