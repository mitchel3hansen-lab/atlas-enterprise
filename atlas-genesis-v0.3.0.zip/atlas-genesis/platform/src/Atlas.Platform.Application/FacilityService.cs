using Atlas.Platform.Domain;

namespace Atlas.Platform.Application;

public sealed class FacilityService(
    IFacilityRepository facilities,
    IOrganizationRepository organizations,
    TimeProvider timeProvider)
{
    public Task<IReadOnlyCollection<Facility>> ListAsync(Guid tenantId, Guid organizationId, CancellationToken cancellationToken) =>
        facilities.ListAsync(tenantId, organizationId, cancellationToken);

    public Task<Facility?> GetAsync(Guid tenantId, Guid facilityId, CancellationToken cancellationToken) =>
        facilities.GetAsync(tenantId, facilityId, cancellationToken);

    public async Task<Facility> CreateAsync(
        Guid tenantId,
        Guid organizationId,
        string name,
        string? code,
        Guid? actorId,
        CancellationToken cancellationToken)
    {
        var organization = await organizations.GetAsync(tenantId, organizationId, cancellationToken);
        if (organization is null)
            throw new NotFoundException("Organization was not found in the current tenant.");

        var facility = Facility.Create(tenantId, organizationId, name, code, actorId, timeProvider.GetUtcNow());
        await facilities.AddAsync(facility, cancellationToken);
        return facility;
    }
}
