using Atlas.Platform.Domain;

namespace Atlas.Platform.Application;

public sealed class OrganizationService(IOrganizationRepository repository, TimeProvider timeProvider)
{
    public Task<IReadOnlyCollection<Organization>> ListAsync(Guid tenantId, CancellationToken cancellationToken) =>
        repository.ListAsync(tenantId, cancellationToken);

    public Task<Organization?> GetAsync(Guid tenantId, Guid organizationId, CancellationToken cancellationToken) =>
        repository.GetAsync(tenantId, organizationId, cancellationToken);

    public async Task<Organization> CreateAsync(Guid tenantId, string name, Guid? actorId, CancellationToken cancellationToken)
    {
        var normalizedName = Organization.NormalizeName(name);
        if (await repository.NameExistsAsync(tenantId, normalizedName, cancellationToken))
            throw new ConflictException("An organization with this name already exists in the tenant.");

        var organization = Organization.Create(tenantId, name, actorId, timeProvider.GetUtcNow());
        await repository.AddAsync(organization, cancellationToken);
        return organization;
    }
}
