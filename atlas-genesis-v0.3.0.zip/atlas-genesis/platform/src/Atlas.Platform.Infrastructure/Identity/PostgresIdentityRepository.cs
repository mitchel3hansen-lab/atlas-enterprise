using Atlas.Platform.Application.Identity;
using Atlas.Platform.Domain.Identity;
using Atlas.Platform.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Platform.Infrastructure.Identity;

public sealed class PostgresIdentityRepository(AtlasDbContext dbContext) : IIdentityRepository
{
    public async Task<IReadOnlyCollection<User>> ListUsersAsync(Guid tenantId, CancellationToken cancellationToken) =>
        await dbContext.Users.AsNoTracking().Where(x => x.TenantId == tenantId).OrderBy(x => x.DisplayName).ToArrayAsync(cancellationToken);

    public Task<User?> GetUserAsync(Guid tenantId, Guid userId, CancellationToken cancellationToken) =>
        dbContext.Users.AsNoTracking().SingleOrDefaultAsync(x => x.TenantId == tenantId && x.Id == userId, cancellationToken);

    public Task<bool> EmailExistsAsync(Guid tenantId, string normalizedEmail, CancellationToken cancellationToken) =>
        dbContext.Users.AnyAsync(x => x.TenantId == tenantId && x.NormalizedEmail == normalizedEmail, cancellationToken);

    public async Task AddUserAsync(User user, CancellationToken cancellationToken)
    {
        dbContext.Users.Add(user);
        await dbContext.SaveChangesAsync(cancellationToken);
    }

    public async Task<IReadOnlyCollection<string>> GetPermissionKeysAsync(Guid tenantId, Guid userId, CancellationToken cancellationToken) =>
        await (from userRole in dbContext.UserRoles
               join role in dbContext.Roles on userRole.RoleId equals role.Id
               join rolePermission in dbContext.RolePermissions on role.Id equals rolePermission.RoleId
               join permission in dbContext.Permissions on rolePermission.PermissionId equals permission.Id
               where userRole.TenantId == tenantId && userRole.UserId == userId && role.TenantId == tenantId
               select permission.Key).Distinct().ToArrayAsync(cancellationToken);
}
