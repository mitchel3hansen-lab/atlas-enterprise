using Atlas.Platform.Application;
using Atlas.Platform.Domain;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Platform.Infrastructure.Persistence;

public sealed class PostgresOrganizationRepository(AtlasDbContext dbContext) : IOrganizationRepository
{
    public async Task<IReadOnlyCollection<Organization>> ListAsync(Guid tenantId, CancellationToken cancellationToken) =>
        await dbContext.Organizations.AsNoTracking().Where(x => x.TenantId == tenantId)
            .OrderBy(x => x.Name).ToArrayAsync(cancellationToken);

    public Task<Organization?> GetAsync(Guid tenantId, Guid organizationId, CancellationToken cancellationToken) =>
        dbContext.Organizations.AsNoTracking().SingleOrDefaultAsync(x => x.TenantId == tenantId && x.Id == organizationId, cancellationToken);

    public Task<bool> NameExistsAsync(Guid tenantId, string normalizedName, CancellationToken cancellationToken) =>
        dbContext.Organizations.AnyAsync(x => x.TenantId == tenantId && x.NormalizedName == normalizedName, cancellationToken);

    public async Task AddAsync(Organization organization, CancellationToken cancellationToken)
    {
        dbContext.Organizations.Add(organization);
        await dbContext.SaveChangesAsync(cancellationToken);
    }
}
