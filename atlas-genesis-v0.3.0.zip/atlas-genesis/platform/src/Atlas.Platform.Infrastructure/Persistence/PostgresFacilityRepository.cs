using Atlas.Platform.Application;
using Atlas.Platform.Domain;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Platform.Infrastructure.Persistence;

public sealed class PostgresFacilityRepository(AtlasDbContext dbContext) : IFacilityRepository
{
    public async Task<IReadOnlyCollection<Facility>> ListAsync(Guid tenantId, Guid organizationId, CancellationToken cancellationToken) =>
        await dbContext.Facilities.AsNoTracking()
            .Where(x => x.TenantId == tenantId && x.OrganizationId == organizationId)
            .OrderBy(x => x.Name).ToArrayAsync(cancellationToken);

    public Task<Facility?> GetAsync(Guid tenantId, Guid facilityId, CancellationToken cancellationToken) =>
        dbContext.Facilities.AsNoTracking().SingleOrDefaultAsync(x => x.TenantId == tenantId && x.Id == facilityId, cancellationToken);

    public async Task AddAsync(Facility facility, CancellationToken cancellationToken)
    {
        dbContext.Facilities.Add(facility);
        await dbContext.SaveChangesAsync(cancellationToken);
    }
}
