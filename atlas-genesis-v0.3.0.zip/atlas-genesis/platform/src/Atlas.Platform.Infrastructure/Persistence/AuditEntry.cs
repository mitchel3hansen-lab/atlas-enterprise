namespace Atlas.Platform.Infrastructure.Persistence;

public sealed class AuditEntry
{
    public Guid Id { get; init; }
    public Guid TenantId { get; init; }
    public string EntityType { get; init; } = string.Empty;
    public Guid EntityId { get; init; }
    public string Action { get; init; } = string.Empty;
    public string ChangesJson { get; init; } = "{}";
    public DateTimeOffset OccurredAt { get; init; }
    public Guid? ActorId { get; init; }
}
