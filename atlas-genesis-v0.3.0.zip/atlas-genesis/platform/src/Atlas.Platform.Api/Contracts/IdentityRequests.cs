namespace Atlas.Platform.Api.Contracts;

public sealed record CreateUserRequest(string Email, string DisplayName);
public sealed record DevelopmentTokenRequest(Guid UserId, Guid TenantId, string[] Permissions);
