namespace Atlas.Platform.Api.Contracts;

public sealed record CreateOrganizationRequest(string Name);
public sealed record CreateFacilityRequest(string Name, string? Code);
