using System.Security.Claims;

namespace Atlas.Platform.Api.Middleware;

public sealed class TenantMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        if (!context.Request.Path.StartsWithSegments("/api") || context.Request.Path.StartsWithSegments("/api/v1/auth/dev-token"))
        {
            await next(context);
            return;
        }

        var tenantClaim = context.User.FindFirstValue("tenant_id");
        if (!Guid.TryParse(tenantClaim, out var tenantId) || tenantId == Guid.Empty)
        {
            context.Response.StatusCode = StatusCodes.Status401Unauthorized;
            await context.Response.WriteAsJsonAsync(new ProblemDetails
            {
                Status = 401, Title = "Authenticated tenant required",
                Detail = "The access token must contain a valid tenant_id claim."
            });
            return;
        }

        if (context.Request.Headers.TryGetValue("X-Atlas-Tenant-Id", out var requestedTenant) &&
            (!Guid.TryParse(requestedTenant, out var requestedTenantId) || requestedTenantId != tenantId))
        {
            context.Response.StatusCode = StatusCodes.Status403Forbidden;
            await context.Response.WriteAsJsonAsync(new ProblemDetails
            {
                Status = 403, Title = "Tenant switching denied",
                Detail = "The requested tenant does not match the authenticated tenant claim."
            });
            return;
        }

        context.Items["TenantId"] = tenantId;
        await next(context);
    }
}
