using Atlas.Platform.Application;
using Microsoft.EntityFrameworkCore;

namespace Atlas.Platform.Api.Middleware;

public sealed class ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try { await next(context); }
        catch (Exception exception)
        {
            var (status, title) = exception switch
            {
                UnauthorizedAccessException => (401, "Authentication failed"),
                NotFoundException => (404, "Resource not found"),
                ConflictException or DbUpdateException => (409, "Resource conflict"),
                ArgumentException => (400, "Validation failed"),
                _ => (500, "Unexpected server error")
            };
            if (status == 500) logger.LogError(exception, "Unhandled request failure");
            context.Response.StatusCode = status;
            await context.Response.WriteAsJsonAsync(new ProblemDetails
            {
                Status = status, Title = title,
                Detail = status == 500 ? "An unexpected error occurred." : exception.Message
            });
        }
    }
}
