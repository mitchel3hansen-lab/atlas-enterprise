using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace Atlas.Platform.Api.Auth;

public sealed class DevelopmentTokenService(IConfiguration configuration, TimeProvider timeProvider)
{
    public string Issue(Guid userId, Guid tenantId, IEnumerable<string> permissions)
    {
        var key = configuration["Authentication:SigningKey"] ?? throw new InvalidOperationException("Authentication:SigningKey is required.");
        var issuer = configuration["Authentication:Issuer"] ?? "atlas-platform";
        var audience = configuration["Authentication:Audience"] ?? "atlas-api";
        var claims = new List<Claim> { new("sub", userId.ToString()), new("tenant_id", tenantId.ToString()) };
        claims.AddRange(permissions.Distinct(StringComparer.OrdinalIgnoreCase).Select(x => new Claim("permission", x)));
        var now = timeProvider.GetUtcNow();
        var token = new JwtSecurityToken(issuer, audience, claims, now.UtcDateTime, now.AddHours(1).UtcDateTime,
            new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)), SecurityAlgorithms.HmacSha256));
        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
