using System.Security.Claims;

namespace Atlas.Platform.Api.Auth;

public interface ICurrentUser
{
    Guid UserId { get; }
    Guid TenantId { get; }
}

public sealed class HttpCurrentUser(IHttpContextAccessor accessor) : ICurrentUser
{
    private ClaimsPrincipal Principal => accessor.HttpContext?.User ?? throw new InvalidOperationException("No active HTTP context.");
    public Guid UserId => Parse("sub");
    public Guid TenantId => Parse("tenant_id");

    private Guid Parse(string type)
    {
        var raw = Principal.FindFirstValue(type) ?? throw new UnauthorizedAccessException($"Required claim '{type}' is missing.");
        return Guid.TryParse(raw, out var value) && value != Guid.Empty
            ? value : throw new UnauthorizedAccessException($"Claim '{type}' is invalid.");
    }
}
