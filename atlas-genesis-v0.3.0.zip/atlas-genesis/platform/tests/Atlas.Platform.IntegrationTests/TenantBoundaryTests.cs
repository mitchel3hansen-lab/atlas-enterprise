using Atlas.Platform.Application.Identity;

namespace Atlas.Platform.IntegrationTests;

public sealed class TenantBoundaryTests
{
    [Fact]
    public void PermissionCatalog_HasNoDuplicates()
    {
        Assert.Equal(AtlasPermissions.All.Length, AtlasPermissions.All.Distinct(StringComparer.OrdinalIgnoreCase).Count());
    }

    [Fact]
    public void TenantContext_IsTokenClaimBased()
    {
        const string requiredClaim = "tenant_id";
        Assert.Equal("tenant_id", requiredClaim);
    }
}
