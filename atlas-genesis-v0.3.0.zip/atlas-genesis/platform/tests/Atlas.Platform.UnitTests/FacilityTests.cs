using Atlas.Platform.Domain;

namespace Atlas.Platform.UnitTests;

public sealed class FacilityTests
{
    [Fact]
    public void Create_NormalizesCode()
    {
        var facility = Facility.Create(Guid.NewGuid(), Guid.NewGuid(), " Lindon ", " li-01 ", null, DateTimeOffset.UtcNow);
        Assert.Equal("Lindon", facility.Name);
        Assert.Equal("LI-01", facility.Code);
    }

    [Fact]
    public void Create_RejectsMissingOrganization() =>
        Assert.Throws<ArgumentException>(() => Facility.Create(Guid.NewGuid(), Guid.Empty, "Lindon", null, null, DateTimeOffset.UtcNow));
}
