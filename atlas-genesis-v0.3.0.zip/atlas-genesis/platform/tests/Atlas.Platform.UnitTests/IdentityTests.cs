using Atlas.Platform.Domain.Identity;

namespace Atlas.Platform.UnitTests;

public sealed class IdentityTests
{
    [Fact]
    public void UserCreate_NormalizesEmail()
    {
        var tenantId = Guid.NewGuid();
        var user = User.Create(tenantId, " Safety@Example.com ", " Mitch Hansen ", null, DateTimeOffset.UtcNow);
        Assert.Equal("Safety@Example.com", user.Email);
        Assert.Equal("SAFETY@EXAMPLE.COM", user.NormalizedEmail);
        Assert.Equal("Mitch Hansen", user.DisplayName);
    }

    [Fact]
    public void RoleCreate_NormalizesName()
    {
        var role = Role.Create(Guid.NewGuid(), " Tenant Admin ", "Administration", true, null, DateTimeOffset.UtcNow);
        Assert.Equal("TENANT ADMIN", role.NormalizedName);
        Assert.True(role.IsSystemRole);
    }
}
