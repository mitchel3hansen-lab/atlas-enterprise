using Atlas.Platform.Domain;

namespace Atlas.Platform.UnitTests;

public sealed class OrganizationTests
{
    [Fact]
    public void Create_TrimsNameAndSetsTenant()
    {
        var tenantId = Guid.NewGuid();
        var now = DateTimeOffset.UtcNow;
        var organization = Organization.Create(tenantId, "  Somafina  ", null, now);
        Assert.Equal(tenantId, organization.TenantId);
        Assert.Equal("Somafina", organization.Name);
        Assert.Equal(now, organization.CreatedAt);
    }

    [Fact]
    public void Create_RejectsBlankName() =>
        Assert.Throws<ArgumentException>(() => Organization.Create(Guid.NewGuid(), " ", null, DateTimeOffset.UtcNow));
}
