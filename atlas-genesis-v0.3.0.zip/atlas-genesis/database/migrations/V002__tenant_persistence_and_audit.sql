ALTER TABLE organizations ADD COLUMN normalized_name varchar(200);
UPDATE organizations SET normalized_name = upper(trim(name));
ALTER TABLE organizations ALTER COLUMN normalized_name SET NOT NULL;
ALTER TABLE organizations DROP CONSTRAINT IF EXISTS uq_organizations_tenant_name;
ALTER TABLE organizations ADD CONSTRAINT uq_organizations_tenant_normalized_name UNIQUE (tenant_id, normalized_name);

ALTER TABLE facilities ADD COLUMN code varchar(32);
CREATE UNIQUE INDEX uq_facilities_org_code ON facilities (organization_id, code) WHERE code IS NOT NULL;

CREATE TABLE audit_entries (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    entity_type varchar(200) NOT NULL,
    entity_id uuid NOT NULL,
    action varchar(32) NOT NULL,
    changes_json jsonb NOT NULL DEFAULT '{}'::jsonb,
    occurred_at timestamptz NOT NULL,
    actor_id uuid NULL
);
CREATE INDEX ix_audit_entries_tenant_occurred ON audit_entries (tenant_id, occurred_at DESC);
CREATE INDEX ix_audit_entries_entity ON audit_entries (entity_type, entity_id);
