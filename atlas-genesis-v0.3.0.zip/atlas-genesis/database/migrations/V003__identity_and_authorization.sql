BEGIN;

CREATE TABLE IF NOT EXISTS users (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    email varchar(320) NOT NULL,
    normalized_email varchar(320) NOT NULL,
    display_name varchar(200) NOT NULL,
    is_enabled boolean NOT NULL DEFAULT true,
    status varchar(32) NOT NULL DEFAULT 'active',
    version bigint NOT NULL DEFAULT 1,
    created_at timestamptz NOT NULL,
    created_by uuid NULL,
    updated_at timestamptz NOT NULL,
    updated_by uuid NULL,
    CONSTRAINT uq_users_tenant_email UNIQUE (tenant_id, normalized_email)
);

CREATE TABLE IF NOT EXISTS roles (
    id uuid PRIMARY KEY,
    tenant_id uuid NOT NULL,
    name varchar(100) NOT NULL,
    normalized_name varchar(100) NOT NULL,
    description varchar(500) NOT NULL DEFAULT '',
    is_system_role boolean NOT NULL DEFAULT false,
    status varchar(32) NOT NULL DEFAULT 'active',
    version bigint NOT NULL DEFAULT 1,
    created_at timestamptz NOT NULL,
    created_by uuid NULL,
    updated_at timestamptz NOT NULL,
    updated_by uuid NULL,
    CONSTRAINT uq_roles_tenant_name UNIQUE (tenant_id, normalized_name)
);

CREATE TABLE IF NOT EXISTS permissions (
    id uuid PRIMARY KEY,
    permission_key varchar(150) NOT NULL UNIQUE,
    description varchar(500) NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS user_roles (
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    assigned_at timestamptz NOT NULL,
    assigned_by uuid NULL,
    PRIMARY KEY (tenant_id, user_id, role_id)
);

CREATE TABLE IF NOT EXISTS role_permissions (
    role_id uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id uuid NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE INDEX IF NOT EXISTS ix_users_tenant_status ON users (tenant_id, status);
CREATE INDEX IF NOT EXISTS ix_user_roles_user ON user_roles (tenant_id, user_id);

INSERT INTO permissions (id, permission_key, description) VALUES
    ('10000000-0000-0000-0000-000000000001', 'organizations.read', 'Read organizations'),
    ('10000000-0000-0000-0000-000000000002', 'organizations.write', 'Create and modify organizations'),
    ('10000000-0000-0000-0000-000000000003', 'facilities.read', 'Read facilities'),
    ('10000000-0000-0000-0000-000000000004', 'facilities.write', 'Create and modify facilities'),
    ('10000000-0000-0000-0000-000000000005', 'users.read', 'Read tenant users'),
    ('10000000-0000-0000-0000-000000000006', 'users.write', 'Create and modify tenant users'),
    ('10000000-0000-0000-0000-000000000007', 'tenant.admin', 'Administer tenant identity and access')
ON CONFLICT (permission_key) DO NOTHING;

COMMIT;
