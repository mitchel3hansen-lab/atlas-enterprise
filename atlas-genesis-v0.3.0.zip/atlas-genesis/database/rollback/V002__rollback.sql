BEGIN;
DROP TABLE IF EXISTS audit_entries;
DROP INDEX IF EXISTS uq_facilities_org_code;
ALTER TABLE facilities DROP COLUMN IF EXISTS code;
ALTER TABLE organizations DROP CONSTRAINT IF EXISTS uq_organizations_tenant_normalized_name;
ALTER TABLE organizations DROP COLUMN IF EXISTS normalized_name;
ALTER TABLE organizations ADD CONSTRAINT uq_organizations_tenant_name UNIQUE (tenant_id, name);
COMMIT;
