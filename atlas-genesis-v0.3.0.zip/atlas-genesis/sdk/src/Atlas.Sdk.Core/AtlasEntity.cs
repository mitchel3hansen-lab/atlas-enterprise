namespace Atlas.Sdk.Core;

public abstract class AtlasEntity
{
    public Guid Id { get; protected init; }
    public Guid TenantId { get; protected init; }
    public string Status { get; protected set; } = "active";
    public long Version { get; protected set; } = 1;
    public DateTimeOffset CreatedAt { get; protected init; }
    public Guid? CreatedBy { get; protected init; }
    public DateTimeOffset UpdatedAt { get; protected set; }
    public Guid? UpdatedBy { get; protected set; }
}
