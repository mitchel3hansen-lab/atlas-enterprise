namespace Atlas.Sdk.Core;

public abstract record DomainEvent(
    Guid EventId,
    Guid TenantId,
    DateTimeOffset OccurredAt,
    string EventType,
    int SchemaVersion = 1);
