# Security Policy

Do not disclose suspected vulnerabilities in public issues. Report them privately to the repository owner with reproduction steps, affected versions, and impact. Never include production secrets, personal data, regulated records, or customer information in a report.

Supported branch: `main`.
