# Contributing to ATLAS

1. Create work from a tracked issue with acceptance criteria.
2. Add or update an ADR for significant architecture changes.
3. Keep domain rules outside controllers and infrastructure adapters.
4. Include tests for changed behavior.
5. Update relevant API and developer documentation.
6. Use Conventional Commits (`feat:`, `fix:`, `docs:`, `refactor:`, `test:`, `chore:`).
7. Obtain required CODEOWNER review before merge.

Pull requests must pass build, test, formatting, dependency, secret, and security checks.
