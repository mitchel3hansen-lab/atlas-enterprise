# ATLAS Engineering Constitution

**Version:** 0.1.0  
**Status:** Accepted

## Purpose

ATLAS exists to help organizations protect people, operate responsibly, and make better decisions through connected operational intelligence.

## Non-negotiable principles

1. **Platform before duplication.** Shared capabilities belong in the platform.
2. **Domain before interface.** Business rules remain independent from UI and infrastructure.
3. **APIs are products.** Public contracts are versioned, documented, tested, and observable.
4. **Tenant isolation is mandatory.** Every customer-owned record is scoped and authorized by tenant.
5. **Security and privacy are design inputs.** Least privilege, auditability, and data minimization are defaults.
6. **AI is evidence-bound.** High-impact recommendations require traceable evidence and appropriate human approval.
7. **Documentation changes with implementation.** A code change that invalidates documentation is incomplete.
8. **Operational readiness is part of delivery.** Health, logs, metrics, recovery, and support ownership are required.

## Definition of done

A change is complete only when its implementation, tests, security controls, documentation, observability, migration strategy, and release notes satisfy the applicable quality gates.
