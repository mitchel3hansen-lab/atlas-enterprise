# Genesis Roadmap

## Sprint 001 — Foundation
Governance, ADRs, canonical model, repository, and CI skeleton.

## Sprint 002 — Organization vertical slice
PostgreSQL persistence, tenant context, organization/facility CRUD, validation, audit, tests, and OpenAPI conformance.

## Sprint 003 — Identity and authorization
OIDC integration, roles, permissions, tenant membership, policy checks, and security tests.

## Sprint 004 — Workflow and events
Workflow state machine, task assignment, outbox, event publication, retry, and dead-letter handling.

## Sprint 005 — Atlas Safety incident slice
Incident intake, triage, investigation workflow, corrective actions, notifications, search, and management dashboard.
