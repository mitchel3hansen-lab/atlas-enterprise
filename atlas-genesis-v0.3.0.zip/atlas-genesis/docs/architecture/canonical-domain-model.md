# Canonical Domain Model v0.1

## Shared entity envelope

Every aggregate root contains:

- `id`: UUID
- `tenantId`: UUID
- `status`: controlled lifecycle value
- `version`: optimistic-concurrency token
- `createdAt`, `createdBy`
- `updatedAt`, `updatedBy`

## Foundation relationships

```text
Tenant 1---* Organization
Organization 1---* Facility
Facility 1---* Department
Facility 1---* Location
Department 0..1---* Person assignment
```

## Safety relationships

```text
Facility 1---* Incident
Incident 1---* Investigation
Incident 0..*---* CorrectiveAction
Hazard 0..*---* Control
Inspection 1---* Finding
Finding 0..*---* CorrectiveAction
```

## Ownership

Foundation owns organization structure. Safety stores stable IDs to Foundation records but does not modify Foundation-owned data directly.
