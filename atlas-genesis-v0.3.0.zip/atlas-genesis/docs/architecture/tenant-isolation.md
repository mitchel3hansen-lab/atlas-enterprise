# Tenant Isolation Architecture

ATLAS v0.2 enforces tenant scope at three boundaries:

1. **Transport:** every `/api` request requires `X-Atlas-Tenant-Id`.
2. **Application:** service methods require an explicit tenant identifier.
3. **Persistence:** every repository predicate includes `TenantId`; unique constraints are tenant-aware.

The header is a development bootstrap mechanism, not final authentication. Sprint 003 will derive the tenant from a validated identity token and prohibit caller-selected tenant switching unless explicitly authorized.

## Invariants

- A record from one tenant is never returned to another tenant.
- Parent records are resolved inside the active tenant before children are created.
- Database uniqueness rules include tenant or parent scope.
- Audit entries contain the tenant identifier and actor when known.
