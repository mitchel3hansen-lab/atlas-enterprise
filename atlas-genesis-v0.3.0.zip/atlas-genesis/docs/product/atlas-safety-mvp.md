# Atlas Safety MVP

## Outcome
Provide a complete, auditable path from a reported operational event to investigation, corrective action, verification, and closure.

## Initial personas
- Employee or contractor reporter
- Supervisor
- Safety professional
- Corrective-action owner
- Executive reviewer
- System administrator

## First vertical slice
1. Submit an incident or near miss.
2. Assign location and responsible supervisor.
3. Triage severity and regulatory significance.
4. Open investigation and capture evidence.
5. Assign CAPA with due dates and escalation.
6. Verify effectiveness and close.
7. Preserve an immutable audit trail.
