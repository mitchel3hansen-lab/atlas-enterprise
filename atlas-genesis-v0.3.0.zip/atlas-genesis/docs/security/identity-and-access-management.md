# Identity and Access Management

## Trust model

ATLAS trusts only tokens that pass issuer, audience, signature, and lifetime validation. Tenant context is obtained from the `tenant_id` claim. The `sub` claim identifies the actor recorded in audit fields.

## Production requirements

1. Replace the development symmetric key with an external OpenID Connect provider.
2. Use asymmetric key validation and automatic signing-key rotation.
3. Require MFA for privileged roles.
4. Disable the development token endpoint outside Development.
5. Keep access tokens short-lived and use secure refresh-token handling at the identity provider.
6. Review privileged role assignments at least quarterly.

## Authorization model

Permissions are stable API contracts. Tenant roles aggregate permissions, and tenant-scoped user-role assignments grant them. Endpoints deny access by default unless an explicit authorization policy is satisfied.

## Tenant switching

A token is valid for one tenant context. Cross-tenant support requires a newly issued token after explicit authorization; changing a header cannot switch tenants.
