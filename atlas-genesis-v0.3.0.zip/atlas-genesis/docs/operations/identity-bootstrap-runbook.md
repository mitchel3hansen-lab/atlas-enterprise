# Identity Bootstrap Runbook

## Local development

1. Apply migrations V001 through V003.
2. Start the API with `ASPNETCORE_ENVIRONMENT=Development`.
3. POST to `/api/v1/auth/dev-token` with a user ID, tenant ID, and required permission keys.
4. Send the returned token as `Authorization: Bearer <token>`.

The local endpoint does not prove the user exists and exists only to exercise authentication and authorization during development.

## Production

Connect an OpenID Connect identity provider, map its stable subject to the ATLAS user record, and issue the tenant and permission claims from a trusted token-enrichment process. Never expose the development token endpoint.
