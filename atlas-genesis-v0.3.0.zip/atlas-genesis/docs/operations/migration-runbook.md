# Database Migration Runbook

## Apply

1. Back up the database and verify restore capability.
2. Place the application in maintenance mode for destructive migrations.
3. Apply files in lexical order from `database/migrations`.
4. Verify schema objects and run the smoke-test endpoints.
5. Record migration version, operator, timestamp, and deployment identifier.

Example:

```bash
psql "$ATLAS_DATABASE_URL" -v ON_ERROR_STOP=1 -f database/migrations/V001__foundation.sql
psql "$ATLAS_DATABASE_URL" -v ON_ERROR_STOP=1 -f database/migrations/V002__tenant_persistence_and_audit.sql
```

## Rollback

Rollback is an exception path. First restore from backup when data loss is possible. For V002, the reviewed rollback script is `database/rollback/V002__rollback.sql`. It removes audit data and new columns, so obtain incident commander and data owner approval before execution.
