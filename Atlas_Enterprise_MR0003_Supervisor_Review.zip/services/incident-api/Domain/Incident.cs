namespace Atlas.IncidentApi.Domain;

public sealed record Incident(
    Guid Id,
    Guid TenantId,
    string IncidentNumber,
    string Title,
    string Description,
    string IncidentType,
    string Severity,
    string Status,
    string WorkflowState,
    DateTimeOffset OccurredAt,
    Guid ReporterId,
    string Site,
    string Department,
    DateTimeOffset CreatedAt,
    DateTimeOffset UpdatedAt,
    DateTimeOffset? SubmittedAt,
    DateTimeOffset? SupervisorReviewedAt,
    Guid? SupervisorReviewerId,
    string? ReviewOutcome);

public sealed record IncidentTimelineEvent(
    Guid Id,
    Guid IncidentId,
    string EventType,
    string Description,
    Guid PerformedBy,
    DateTimeOffset OccurredAt);

public sealed record IncidentComment(
    Guid Id,
    Guid IncidentId,
    Guid AuthorId,
    string AuthorRole,
    string CommentType,
    string Body,
    DateTimeOffset CreatedAt);

public sealed record IncidentDetails(
    Incident Incident,
    IReadOnlyList<IncidentTimelineEvent> Timeline,
    IReadOnlyList<IncidentComment> Comments);
