import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const apiUrl = import.meta.env.VITE_INCIDENT_API_URL ?? "http://localhost:8085";
const tenantId = "11111111-1111-1111-1111-111111111111";
const employeeId = "22222222-2222-2222-2222-222222222222";
const supervisorId = "33333333-3333-3333-3333-333333333333";
const supervisorDepartment = "Warehouse";

type Incident = {
  id: string;
  incidentNumber: string;
  title: string;
  severity: string;
  status: string;
  workflowState: string;
  site: string;
  department: string;
  occurredAt: string;
};

function App() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [comments, setComments] = useState<Record<string, string>>({});

  async function loadIncidents() {
    const response = await fetch(`${apiUrl}/api/incidents?tenantId=${tenantId}`);
    if (response.ok) setIncidents(await response.json());
  }

  useEffect(() => {
    loadIncidents().catch(() => setMessage("Unable to load incidents."));
  }, []);

  async function create(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setMessage("");

    const form = new FormData(event.currentTarget);
    const payload = {
      tenantId,
      reporterId: employeeId,
      title: String(form.get("title") ?? ""),
      description: String(form.get("description") ?? ""),
      incidentType: String(form.get("incidentType") ?? ""),
      severity: String(form.get("severity") ?? "Medium"),
      occurredAt: new Date(String(form.get("occurredAt"))).toISOString(),
      site: String(form.get("site") ?? ""),
      department: String(form.get("department") ?? "")
    };

    try {
      const response = await fetch(`${apiUrl}/api/incidents`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.title ?? "Unable to create incident.");

      setMessage(`Incident ${result.incidentNumber} created as a draft.`);
      event.currentTarget.reset();
      await loadIncidents();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unexpected error.");
    } finally {
      setBusy(false);
    }
  }

  async function submit(incidentId: string) {
    await postAction(
      `${apiUrl}/api/incidents/${incidentId}/submit`,
      { tenantId, actorId: employeeId },
      "Incident submitted to Supervisor Review."
    );
  }

  async function review(incident: Incident, decision: string) {
    const comment = comments[incident.id]?.trim();
    if (!comment) {
      setMessage("A supervisor review comment is required.");
      return;
    }

    await postAction(
      `${apiUrl}/api/incidents/${incident.id}/supervisor-review`,
      {
        tenantId,
        reviewerId: supervisorId,
        reviewerRole: "Supervisor",
        reviewerDepartment: supervisorDepartment,
        decision,
        comment
      },
      decision === "Approve"
        ? "Incident approved and routed to Safety Review."
        : "Incident returned for correction."
    );
  }

  async function postAction(url: string, body: unknown, success: string) {
    setBusy(true);
    setMessage("");
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message ?? result.title ?? "Action failed.");

      setMessage(success);
      await loadIncidents();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unexpected error.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main>
      <header>
        <span className="eyebrow">ATLAS ENTERPRISE</span>
        <h1>Incident Operations</h1>
        <p>Create, submit, and review incidents from one controlled workflow.</p>
      </header>

      <section className="panel">
        <h2>Report an Incident</h2>
        <form onSubmit={create}>
          <label>
            Incident title
            <input name="title" required maxLength={200} />
          </label>

          <div className="grid">
            <label>
              Incident type
              <select name="incidentType" required defaultValue="">
                <option value="" disabled>Select type</option>
                <option>Near Miss</option>
                <option>First Aid</option>
                <option>Recordable</option>
                <option>Property Damage</option>
                <option>Chemical Exposure</option>
              </select>
            </label>

            <label>
              Severity
              <select name="severity" defaultValue="Medium">
                <option>Low</option>
                <option>Medium</option>
                <option>High</option>
                <option>Critical</option>
              </select>
            </label>
          </div>

          <label>
            What happened?
            <textarea name="description" required rows={5} />
          </label>

          <div className="grid">
            <label>
              Occurred at
              <input name="occurredAt" type="datetime-local" required />
            </label>
            <label>
              Site
              <input name="site" required placeholder="Lindon" />
            </label>
            <label>
              Department
              <input name="department" required defaultValue="Warehouse" />
            </label>
          </div>

          <button disabled={busy}>{busy ? "Working…" : "Save Incident Draft"}</button>
        </form>
      </section>

      <section className="panel">
        <div className="section-heading">
          <div>
            <h2>Incident Queue</h2>
            <p>{incidents.length} active record{incidents.length === 1 ? "" : "s"}</p>
          </div>
          <button className="secondary" onClick={() => loadIncidents()}>
            Refresh
          </button>
        </div>

        <div className="incident-list">
          {incidents.map((incident) => (
            <article key={incident.id}>
              <div className="incident-summary">
                <span className="number">{incident.incidentNumber}</span>
                <h3>{incident.title}</h3>
                <p>{incident.site} · {incident.department}</p>
                <div className="badges">
                  <span className={`badge ${incident.severity.toLowerCase()}`}>
                    {incident.severity}
                  </span>
                  <span className="badge">{incident.workflowState}</span>
                </div>
              </div>

              <div className="incident-actions">
                {incident.status === "Draft" && (
                  <button disabled={busy} onClick={() => submit(incident.id)}>
                    Submit
                  </button>
                )}

                {incident.workflowState === "SupervisorReview" && (
                  <div className="review-box">
                    <strong>Supervisor Review</strong>
                    <textarea
                      rows={3}
                      placeholder="Document the initial review."
                      value={comments[incident.id] ?? ""}
                      onChange={(event) =>
                        setComments({
                          ...comments,
                          [incident.id]: event.target.value
                        })
                      }
                    />
                    <div className="review-actions">
                      <button
                        disabled={busy || incident.department !== supervisorDepartment}
                        onClick={() => review(incident, "Approve")}
                      >
                        Approve for Safety
                      </button>
                      <button
                        className="secondary"
                        disabled={busy || incident.department !== supervisorDepartment}
                        onClick={() => review(incident, "ReturnForCorrection")}
                      >
                        Return for Correction
                      </button>
                    </div>
                    {incident.department !== supervisorDepartment && (
                      <small>
                        Demo supervisor is assigned to {supervisorDepartment}.
                      </small>
                    )}
                  </div>
                )}
              </div>
            </article>
          ))}
          {incidents.length === 0 && <p>No incidents have been created yet.</p>}
        </div>
      </section>

      {message && <output>{message}</output>}
    </main>
  );
}

createRoot(document.getElementById("root")!).render(
  <React.StrictMode><App /></React.StrictMode>
);
