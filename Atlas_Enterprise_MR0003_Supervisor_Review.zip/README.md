# Atlas Enterprise

Atlas is an operational intelligence platform beginning with a complete incident-management vertical slice.

## Current capabilities

- Create a validated incident draft
- Generate a tenant-scoped incident number
- Persist timeline events
- List incidents
- Retrieve details, comments, and timeline
- Submit a draft into Supervisor Review
- Approve an incident into Safety Review
- Return an incident for correction
- Enforce demonstration department-level supervisor access

## Start locally

```bash
docker compose down -v
docker compose up --build
```

Open:

- Web: http://localhost:5173
- Incident API Swagger: http://localhost:8085/swagger
- PostgreSQL: localhost:5432

## Current workflow

```text
Draft
→ SupervisorReview
→ SafetyReview

or

SupervisorReview
→ CorrectionRequested
```

## Important security limitation

Tenant, actor, role, and department values are demonstration inputs. Authentication and server-derived authorization claims are required before pilot deployment.
